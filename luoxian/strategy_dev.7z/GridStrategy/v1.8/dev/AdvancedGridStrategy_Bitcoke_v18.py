from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path
import numpy as np

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}
TRADED_INFO_TITLE: Dict[int, str] = {0: "Start(USD)", 1: "Current(USD)", 2: "RunTime(Min)", 3: "Volume(ETH)", 4: "Rebate(USD)", 5: "Commission(USD)"}

class AdvancedGridStrategy_Bitcoke_v18(CtaTemplate):

    author = "最新网格交易策略v1.8"

    lerver_rate = 5                 # 杠杆比例
    grid_gap_tick_count = 20        # 网格间距
    period = 9                      # a fast_period of moving average
    pos_num = 0.2                   # 算big_percent时候用到
    open_min_volume = 112

    balance = 0                     # 账户余额
    long_pos = 0                    # 多头持仓
    short_pos = 0                   # 空头持仓
    max_pos_volume = 0
    grid_base_pos_pst = 0

    big_percent = 0
    small_percent = 0
    long_short_open = 0
    long_short_close = 0

    ma_value = 0
    ma_status = 0                   # 0: None, 1: Bullish, 2: Bearish

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0

    }

    parameters = ['lerver_rate', 'grid_gap_tick_count', 'period', 'pos_num', 'open_min_volume']
    variables = ['balance', 'ma_status','long_pos','short_pos', 'big_percent', 'small_percent', 'grid_base_pos_pst', 'long_short_open', 'long_short_close', 'max_pos_volume']


    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # k-line
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume

        # symbol (removed '.ExchangeName')
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.market_price = 0

        self.last_long_pos = 0
        self.last_short_pos = 0

        self.max_pos_volume = 0
        self.grid_gap = self.pricetick * self.grid_gap_tick_count

        self.main_process_thread = None

        self.trading_direction = None

        self.registered_order_info = {
            Direction.LONG: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            },
            Direction.SHORT: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            }
        }

        self.order_info_queue = {}
        self.modified_order_info = {
            Offset.OPEN: {
                'changed': False,
                'price': 0
            },
            Offset.CLOSE: {
                'changed': False,
                'price': 0
            }
        }


    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('BITCOKE')

        # k-line
        self.load_bar(2)


    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.init()

        self.stop_main_process = False

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.main_process_thread.start()


    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        # k-line
        self.bargenerator.update_tick(tick)

        self.last_last_tick = self.last_tick
        self.last_tick = tick
        self.market_price = round_to(tick.last_price, self.pricetick)

        if self.is_valid_tick(tick) == False:
            pass

        self.put_event()


    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        am = self.arraymanager
        am.update_bar(bar)
        if not am.inited:
            return

        self.ma_value = am.kama(self.period)

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        # main process daemon
        while self.stop_main_process == False:
            sleep(1)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        volume = self.order_info_queue[open_orderid]['volume']
                        self.send_new_order(direction, OPEN, price, volume)

                # close
                if (direction == LONG and self.short_pos > 0) or (direction == SHORT and self.long_pos > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            volume = self.order_info_queue[close_orderid]['volume']
                            self.send_new_order(direction, CLOSE, price, volume)

        sleep(2)

        # cancel all orders when strategy has been stopped
        long_open_cancel_orderid = self.registered_order_info[LONG][OPEN]
        if long_open_cancel_orderid != '':
            if long_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_open_cancel_orderid)

        short_open_cancel_orderid = self.registered_order_info[SHORT][OPEN]
        if short_open_cancel_orderid != '':
            if short_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_open_cancel_orderid)

        long_close_cancel_orderid = self.registered_order_info[LONG][CLOSE]
        if long_close_cancel_orderid != '':
            if long_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_close_cancel_orderid)

        short_close_cancel_orderid = self.registered_order_info[SHORT][CLOSE]
        if short_close_cancel_orderid != '':
            if short_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_close_cancel_orderid)

        sleep(2)

        self.stop_main_process = False


    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1, old_volume = -1):
        new_price = self.get_order_price(direction, offset)
        if old_price != -1 and round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        if new_price == 0:
            return

        sleep(1)

        self.calc_max_pos_and_trade_volume(direction)

        # calculate the new volume
        if offset == OPEN:
            new_volume = self.long_short_open
            if direction == LONG:
                if old_price != -1 and old_volume != -1:
                    new_volume = old_volume + self.long_short_open * ((old_price - new_price) / self.grid_gap)
                    if new_volume < self.long_short_open:
                        new_volume = self.long_short_open
            elif direction == SHORT:
                if old_price != -1 and old_volume != -1:
                    new_volume = old_volume - self.long_short_open * ((old_price - new_price) / self.grid_gap)
                    if new_volume < self.long_short_open:
                        new_volume = self.long_short_open

            if new_volume < self.open_min_volume:
                new_volume = self.open_min_volume
        elif offset == CLOSE:
            new_volume = self.long_short_close
            if direction == LONG:
                if self.short_pos > 0:
                    if old_price != -1 and old_volume != -1:
                        new_volume = old_volume + self.long_short_close * ((new_price - old_price) / self.grid_gap)
                        if new_volume < self.long_short_close:
                            new_volume = self.long_short_close

                    if new_volume > self.short_pos:
                        new_volume = self.short_pos
                else:
                    return
            elif direction == SHORT:
                if self.long_pos > 0:
                    if old_price != -1 and old_volume != -1:
                        new_volume = old_volume - self.long_short_close * ((new_price - old_price) / self.grid_gap)
                        if new_volume < self.long_short_close:
                            new_volume = self.long_short_close

                    if new_volume > self.long_pos:
                        new_volume = self.long_pos
                else:
                    return

        if float(new_volume) <= 0.0:
            return

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        if offset == CLOSE and float(new_volume) == 0.0:
            return

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False


    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        if direction == Direction.LONG :
            if offset == Offset.OPEN:
                price = self.market_price - self.pricetick
            elif offset == Offset.CLOSE:
                price = self.market_price + self.pricetick

            if price > tick.ask_price_1:
                price = tick.bid_price_1 - self.pricetick
        elif direction == Direction.SHORT:
            if offset == Offset.OPEN:
                price = self.market_price + self.pricetick
            elif offset == Offset.CLOSE:
                price = self.market_price - self.pricetick

            if price < tick.bid_price_1:
                price = tick.ask_price_1 + self.pricetick

        price = round_to(price, self.pricetick)

        return price


    """
    "   Desc: Calculate max_pos_volume
    """
    def calc_max_pos_and_trade_volume(self, direction):
        self.max_pos_volume = self.balance * self.lerver_rate

        if self.market_price > self.ma_value:
            self.ma_status = 1
        elif self.market_price < self.ma_value:
            self.ma_status = 2
        else:
            self.ma_status = 0

        # self.big_percent = (1 + (abs(self.long_pos - self.short_pos) / (self.max_pos_volume * self.pos_num)))
        # self.small_percent = (1 - (abs(self.long_pos - self.short_pos) / (self.max_pos_volume * self.pos_num)))

        self.big_percent = 1.1
        self.small_percent = 0.9

        self.grid_base_pos_pst = self.grid_gap / self.market_price

        # self.grid_base_pos_pst * self.max_pos_volume

        # calculate long_short_open volume
        if self.ma_status == 1:
            if direction == Direction.LONG:
                self.long_short_open = round_to(max(self.open_min_volume * self.big_percent, self.min_volume), self.min_volume)
                self.long_short_close = round_to(max(self.open_min_volume * self.small_percent, self.min_volume), self.min_volume)
            elif direction == Direction.SHORT:
                self.long_short_open = round_to(max(self.open_min_volume * self.small_percent, self.min_volume), self.min_volume)
                self.long_short_close = round_to(max(self.open_min_volume * self.big_percent, self.min_volume), self.min_volume)
        elif self.ma_status == 2:
            if direction == Direction.LONG:
                self.long_short_open = round_to(max(self.open_min_volume * self.small_percent, self.min_volume), self.min_volume)
                self.long_short_close = round_to(max(self.open_min_volume * self.big_percent, self.min_volume), self.min_volume)
            elif direction == Direction.SHORT:
                self.long_short_open = round_to(max(self.open_min_volume * self.big_percent, self.min_volume), self.min_volume)
                self.long_short_close = round_to(max(self.open_min_volume * self.small_percent, self.min_volume), self.min_volume)


    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BITCOKE':
            if account.accountid == 'USDT':
                if 'USD' in self.symbol:
                    self.balance = account.balance


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.long_pos = position.volume
                # all long pos are closed
                if self.last_long_pos > 0 and self.long_pos == 0:
                    print('All long pos are closed.')

                self.last_long_pos = self.long_pos
            elif direction == SHORT:
                self.short_pos = position.volume
                # all short pos closed
                if self.last_short_pos > 0 and self.short_pos == 0:
                    print('All short pos are closed.')

                self.last_short_pos = self.short_pos


    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_direction_offset_str(direction, offset)

                print(f'{"order type": >15}{"price": >10}{"volume": >10}{"taker": >10}{"maker": >10}{"traded": >10}{"total": >10}{"long pos": >15}{"short pos": >15}')
                print(f'{order_type_str: >15}{order.price: >10}{order.volume: >10}{self.summary_count["taker"]: >10}{self.summary_count["maker"]: >10}{self.summary_count["traded"]: >10}{self.summary_count["total"]: >10}{self.long_pos: >15}{self.short_pos: >15}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
