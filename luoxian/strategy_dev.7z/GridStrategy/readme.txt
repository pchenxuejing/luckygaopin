Lastest Grid Strategy.

This strategy is based on high frequency trading.

Both of open and close order are updating real-time of which price are satisfy the limit volume logic.

Volume of open and close order is more when price low and high, few when price is middle.