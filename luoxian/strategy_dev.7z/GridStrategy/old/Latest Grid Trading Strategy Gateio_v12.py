from vnpy.app.cta_strategy import (
    CtaTemplate,
    StopOrder,
    TickData,
    BarData,
    TradeData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, Interval
from datetime import time, datetime
from vnpy.trader.object import PositionData,AccountData
from copy import deepcopy
import os
from collections import defaultdict
import numpy as np
from vnpy.trader.event import EVENT_TIMER, EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread
from time import sleep

class LatestGridStrategy_GateIO_v1(CtaTemplate):
    
    author = "最新网格交易策略v1.1"

    grid_gap_tick_count = 10       # 网格间距
    lerver_rate = 100   # 杠杆比例
    
    pos_num = 0.1       # 算big_percent时候用到
    max_pos_pst = 0.1

    modify_limit_volume = 300
    modify_pricetick_n = 3

    balance = 0         # 账户余额
    long_pos = 0        # 多头持仓
    short_pos = 0       # 空头持仓

    target_pos = 0
    big_percent = 0
    small_percent = 0

    long_short_open = 0
    long_short_close = 0

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0

    }

    mid_price = 0
    open_pos_info = {
        'total_price': 0,
        'total_volume': 0
    }

    parameters = ["grid_gap_tick_count","max_pos_pst", "lerver_rate",'pos_num','modify_limit_volume','modify_pricetick_n']

    variables = ['balance','long_pos','short_pos','target_pos', 'big_percent', 'long_short_open', 'long_short_close']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume

        self.symbol = self.vt_symbol.split('.')[0]
        
        self.init()


    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.market_price = 0
        self.last_trading_status = False

        self.last_long_pos = 0
        self.last_short_pos = 0

        self.max_pos_volume = 0
        self.grid_gap = self.pricetick * self.grid_gap_tick_count

        self.main_process_thread = None
        self.restart_strategy_thread = None
        self.clear_order_thread = None

        self.trading_direction = None

        self.order_type = {
            Direction.LONG: {
                'bid': [ Direction.LONG, Offset.OPEN ],
                'ask': [ Direction.SHORT, Offset.CLOSE ]
            },
            Direction.SHORT: {
                'bid': [ Direction.SHORT, Offset.OPEN ],
                'ask': [ Direction.LONG, Offset.CLOSE ]
            }
        }

        self.registered_order_info = {
            Direction.LONG: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            },
            Direction.SHORT: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            }
        }

        self.order_info_queue = {}
        
        self.wait_for_reasonable_price = False


    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('GATEIOS')

        # self.load_bar(10)
        self.write_log("策略初始化")

        # self.write_log_to_file('Strategy is initialized.')
        

    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status=300

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)
        self.write_log("策略启动")

        self.cancel_all()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

        # clear unnecessary orders
        self.clear_order_thread = Thread(target = self.clear_orders)
        self.clear_order_thread.setDaemon(True)

        self.clear_order_thread.start()

        # self.write_log_to_file('Strategy is started.')
    

    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.stop_main_process = True
        
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)
        self.write_log("策略停止")

        self.cancel_all()

        # self.write_log_to_file('Strategy is stopped.')
    

    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.last_last_tick = self.last_tick
        self.last_tick = tick
        self.market_price = tick.last_price
        
        if self.last_tick == None:
            print("ON tick: tick is none")
    

    def cancel_all_submitting_orders(self):
        print("Cancell all submitting orders")
        sleep(5)

        trading_direction = self.trading_direction

        if trading_direction != None:
            try:
                order_info_queue = deepcopy(self.order_info_queue)
            except:
                order_info_queue = deepcopy(self.order_info_queue)
            for vt_orderid in order_info_queue:
                # print("Order waiting for submitting", vt_orderid)
                # while True:
                #     if vt_orderid not in self.order_info_queue:
                #         break
                #     elif self.order_info_queue[vt_orderid]['status'] != Status.SUBMITTING:
                #         break
                #     sleep(0.05)
                # print('Submitting finish')

                if vt_orderid in self.order_info_queue:
                    self.cancel_order(vt_orderid)
                    sleep(0.5)
    

    def clear_orders(self):
        while True:
            direction = self.trading_direction

            if direction == Direction.LONG:
                opposite_direction = Direction.SHORT
            else:
                opposite_direction = Direction.LONG

            if direction != None and self.stop_main_process == False:

                try:
                    order_info_queue = deepcopy(self.order_info_queue)
                except:
                    order_info_queue = deepcopy(self.order_info_queue)
                # print(self.order_info_queue)
                # print(self.registered_order_info)
                for vt_orderid in order_info_queue:

                    if vt_orderid == self.registered_order_info[direction][Offset.OPEN] or vt_orderid == self.registered_order_info[opposite_direction][Offset.CLOSE]:
                        continue

                    if vt_orderid in self.order_info_queue and (self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED):
                        self.cancel_order(vt_orderid)
                        sleep(0.2)

                sleep(1)


    def restart_strategy(self):
        self.stop_main_process = True

        while self.stop_main_process == True:
            sleep(0.05)

        sleep(5)

        print("Restarted completely")
        
        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

    
    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    def main_process(self):

        LONG = Direction.LONG
        SHORT = Direction.SHORT
        OPEN = Offset.OPEN
        CLOSE = Offset.CLOSE

        print("Balance is ", self.balance)

        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or self.market_price == 0 or self.is_valid_tick(self.last_tick) == False:
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance is ", self.balance)

        # send long_open order and short_open order when strategy start
        self.send_long_short_open_order_when_start()

        # print(self.trading_direction)
        # print(self.registered_order_info)
        # print(self.order_info_queue)

        # main process deamon
        while self.stop_main_process == False:
            sleep(0.05)

            if self.trading == False or self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False:
                print("Tick is invalid.")
                continue

            # if self.wait_for_reasonable_price == True:
            #     if self.trading_direction == LONG and self.last_tick.ask_price_1 > self.mid_price or self.trading_direction == SHORT and self.last_tick.bid_price_1 < self.mid_price:
            #         self.wait_for_reasonable_price = False

            #         direction = self.trading_direction
            #         if direction == LONG:
            #             opposite_direction = SHORT
            #         else:
            #             opposite_direction = LONG

            #         direction_price = self.get_maker_order_price(direction)
            #         opposite_direction_price = self.get_maker_order_price(opposite_direction)

            #         # send order to open long position
            #         self.send_new_order(direction, OPEN, direction_price)

            #         # send order to close long position
            #         self.send_new_order(opposite_direction, CLOSE, opposite_direction_price)
                
            #     continue

            # check long and short open order which is placed when starts
            if self.trading_direction == None:

                for direction in (LONG, SHORT):

                    vt_orderid = self.registered_order_info[direction][OPEN]

                    if vt_orderid == '':
                        continue

                    if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:
                        # if self.mid_price == None:
                        #     self.mid_price = self.order_info_queue[vt_orderid]['price']

                        if direction == LONG:
                            cancel_direction = SHORT
                        else:
                            cancel_direction = LONG

                        cancel_orderid = self.registered_order_info[cancel_direction][OPEN]

                        # print("First order waiting for submitting", cancel_orderid)
                        # while self.order_info_queue[cancel_orderid]['status'] == Status.SUBMITTING:
                        #     if self.stop_main_process == True:
                        #         break
                        #     sleep(0.05)
                        # print('First finish')

                        self.cancel_order(cancel_orderid)
                        self.registered_order_info[cancel_direction][OPEN] = ''
                        
                        self.trading_direction = direction

                        break
            
            if self.trading_direction != None:
                trading_direction = self.trading_direction
                
                orders = self.order_type[trading_direction]

                for order_type in orders:
                    direction = orders[order_type][0]
                    offset = orders[order_type][1]

                    if direction == LONG:
                        opposite_direction = SHORT
                    else:
                        opposite_direction = LONG
                    
                    if offset == OPEN:
                        opposite_offset = CLOSE
                    else:
                        opposite_offset = OPEN

                    if self.registered_order_info[direction][offset] == '':
                        continue
                    else:
                        vt_orderid = self.registered_order_info[direction][offset]
                        
                        if self.order_info_queue[vt_orderid]['status'] == Status.REJECTED:
                            price = self.order_info_queue[vt_orderid]['price']
                            volume = self.order_info_queue[vt_orderid]['volume']
                            
                            self.remove_order_info_queue(vt_orderid)

                            self.send_new_order(direction, offset, price, volume)

                            continue
                        
                        # send new order to grid
                        if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:
                            # if self.mid_price == None:
                            #     self.mid_price = self.order_info_queue[vt_orderid]['price']

                            direction_price = self.get_maker_order_price(direction)
                            opposite_direction_price = self.get_maker_order_price(opposite_direction)

                            # if trading_direction == direction and self.mid_price != None:
                            #     if direction == LONG and opposite_direction_price <= self.mid_price or direction == SHORT and opposite_direction_price >= self.mid_price:
                            #         self.cancel_all_submitting_orders()
                            #         self.wait_for_reasonable_price = True

                            #         break

                            # send order to open long position
                            self.send_new_order(direction, offset, direction_price)

                            opposite_vt_orderid = self.registered_order_info[opposite_direction][opposite_offset]
                            
                            opposite_direction_volume = -1
                            if opposite_vt_orderid in self.order_info_queue:
                                if self.order_info_queue[opposite_vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[opposite_vt_orderid]['status'] == Status.PARTTRADED:
                                    opposite_direction_volume = self.order_info_queue[opposite_vt_orderid]['volume']
                                
                            # send order to close long position
                            self.send_new_order(opposite_direction, opposite_offset, opposite_direction_price, opposite_direction_volume)

                            break
                        
                        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                            # change order based on modify limit volume
                            self.change_order_based_on_modify_limit_volume(direction, offset)
                        
                        # if self.wait_for_reasonable_price == True:
                        #     break
                        
        # cancel all orders when strategy stop
        self.cancel_all_submitting_orders()
        self.stop_main_process = False


    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == Offset.NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'
            
            if status == Status.SUBMITTING and self.order_info_queue[vt_orderid]['status'] != Status.SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        if offset != Offset.NONE:
            self.registered_order_info[direction][offset] = vt_orderid

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    
    def remove_order_info_queue(self, vt_orderid):
        direction = self.order_info_queue[vt_orderid]['direction']
        offset = self.order_info_queue[vt_orderid]['offset']

        self.registered_order_info[direction][offset] = ''
        del self.order_info_queue[vt_orderid]


    """
    "   desc:   Check the modify_limit_volume logic and Change order
    "   input:  order_type, tick
    "   output: bool: True => changed, False => not changed
    """
    def change_order_based_on_modify_limit_volume(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)

        pricetick = self.pricetick

        # get order price and volume
        vt_orderid = self.registered_order_info[direction][offset]

        order_price = self.order_info_queue[vt_orderid]['price']
        order_volume = self.order_info_queue[vt_orderid]['volume']

        if order_price * order_volume == 0:
            return

        new_order_price = round_to(self.get_maker_order_price(direction), pricetick)
            
        if abs((new_order_price - order_price) / pricetick) > 0:

            new_order_price = round_to(new_order_price, pricetick)
            new_order_volume = self.calculate_volume_when_price_change(direction, offset, new_order_price)

            # if self.trading_direction != direction and self.mid_price != None:
            #     if direction == Direction.LONG and new_order_price >= self.mid_price or direction == Direction.SHORT and new_order_price <= self.mid_price:
            #         self.cancel_all_submitting_orders()
            #         self.wait_for_reasonable_price = True
            #         return

            if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                self.send_new_order(direction, offset, new_order_price, new_order_volume)


    """
    "   desc:   Calculate volume when all of price change happen
    "   input:  order_type, new_order_price
    "   output: new_order_volume: default => 0
    """
    def calculate_volume_when_price_change(self, direction, offset, new_price):
        vt_orderid = self.registered_order_info[direction][offset]

        if vt_orderid == '':
            self.calculate_trade_volume()

            if offset == Offset.OPEN:
                volume = self.long_short_open
            else:
                volume = self.long_short_close
            
            return volume
        else:
            old_price = self.order_info_queue[vt_orderid]['price']
            old_volume = self.order_info_queue[vt_orderid]['volume']

        if old_price * old_volume == 0:
            return 0

        if self.trading_direction == Direction.LONG:
            multiple = 1
        else:
            multiple = -1

        self.calculate_trade_volume()

        if offset == Offset.OPEN:
            new_volume = old_volume + multiple * self.long_short_open * ((old_price - new_price) / self.grid_gap)
            if new_volume < self.min_volume:
                new_volume = self.long_short_open
        else:
            new_volume = old_volume + multiple * self.long_short_close * ((new_price - old_price) / self.grid_gap)
            if new_volume < self.min_volume:
                new_volume = self.long_short_close

        
        new_volume = round_to(new_volume, self.min_volume)

        # print(self.trading_direction, direction, offset, old_price, old_volume, new_price, new_volume)

        return new_volume


    """
    "   desc:   Send long and short open order when trading is started
    "   output: new_order_volume: default => 0
    """
    def send_long_short_open_order_when_start(self):
        # print("Check if tick is none: send_long_short_open_order_when_start")
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return False

            sleep(0.05)
        # print("Check finish")

        # calculate long_ short_open_price
        bid_price = self.get_maker_order_price(Direction.LONG)
        ask_price = self.get_maker_order_price(Direction.SHORT)
        
        if self.long_pos != 0:
            # send order to open long position
            self.send_new_order(Direction.LONG, Offset.OPEN, bid_price)

            # send order to close long position
            self.send_new_order(Direction.SHORT, Offset.CLOSE, ask_price)

            self.trading_direction = Direction.LONG
        elif self.short_pos != 0:
            # send order to open short position
            self.send_new_order(Direction.SHORT, Offset.OPEN, ask_price)

            # send order to close short position
            self.send_new_order(Direction.LONG, Offset.CLOSE, bid_price)

            self.trading_direction = Direction.SHORT
        else:
            # send order to open long position
            self.send_new_order(Direction.LONG, Offset.OPEN, bid_price)

            # send order to open short position
            self.send_new_order(Direction.SHORT, Offset.OPEN, ask_price)

            self.trading_direction = None


    """
    "   desc:   Calculate long_short_open, long_short_close volume
    "   input:  market_price
    """
    def calculate_trade_volume(self):
        self.target_pos = self.balance * self.lerver_rate / self.market_price
        self.big_percent = (1 + (abs(self.long_pos - self.short_pos) / (self.target_pos * self.pos_num)))
        self.small_percent = (1 - (abs(self.long_pos - self.short_pos) / (self.target_pos * self.pos_num)))
        self.grid_base_pos_pst = self.grid_gap / self.market_price
        
        # calculate long_short_open volume
        self.long_short_open = max(round_to(self.grid_base_pos_pst * self.target_pos * self.small_percent, self.min_volume), self.min_volume)

        # calculate long_short_close volume
        self.long_short_close = max(round_to(self.grid_base_pos_pst * self.target_pos * self.big_percent, self.min_volume), self.min_volume)
    

    """
    "   desc:   Change taker order to maker order
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_maker_order_price(self, direction):
        # print("Check if tick is none: get_maker_order_price")
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)
        # print("Check finish")

        pricetick = self.pricetick
        modify_limit_volume = self.modify_limit_volume


        if direction == Direction.LONG :

            price = tick.bid_price_1
            total_volume = tick.bid_volume_1

            if total_volume < modify_limit_volume:
                price = tick.bid_price_2
                total_volume += tick.bid_volume_2

                if total_volume < modify_limit_volume:
                    price = tick.bid_price_3
                    total_volume += tick.bid_volume_3

                    if total_volume < modify_limit_volume:
                        price = tick.bid_price_4
                        total_volume += tick.bid_volume_4

                        if total_volume < modify_limit_volume:
                            price = tick.bid_price_5
                            total_volume += tick.bid_volume_4

                            if total_volume < modify_limit_volume:
                                price = tick.bid_price_5 - pricetick

        elif direction == Direction.SHORT:

            price = tick.ask_price_1
            total_volume = tick.ask_volume_1

            if total_volume < modify_limit_volume:
                price = tick.ask_price_2
                total_volume += tick.ask_volume_2

                if total_volume < modify_limit_volume:
                    price = tick.ask_price_3
                    total_volume += tick.ask_volume_3

                    if total_volume < modify_limit_volume:
                        price = tick.ask_price_4
                        total_volume += tick.ask_volume_4

                        if total_volume < modify_limit_volume:
                            price = tick.ask_price_5
                            total_volume += tick.ask_volume_4

                            if total_volume < modify_limit_volume:
                                price = tick.ask_price_5 + pricetick

        price = round_to(price, pricetick)

        return price
    

    def check_if_maker_order(self, direction, offset, price, volume):
        # print("Check if tick is none: check_if_maker_order")
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)
        # print("Check finish")
        
        new_price = price
        new_volume = volume
        if direction == Direction.LONG:
            if price > tick.bid_price_1:
                new_price = self.get_maker_order_price(direction)
                new_volume = self.calculate_volume_when_price_change(direction, offset, new_price)
        
        else:
            if price < tick.ask_price_1:
                price = self.get_maker_order_price(direction)
                new_volume = self.calculate_volume_when_price_change(direction, offset, new_price)
        
        
        return (new_price, new_volume)


    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == Status.SUBMITTING:
            self.summary_count['total'] += 1
        
        elif order.status == Status.NOTTRADED:
            order_type = 'maker'
        
        elif order.status == Status.PARTTRADED:
            pass
        
        elif order.status == Status.ALLTRADED:
            if vt_orderid in self.order_info_queue:
                if self.order_info_queue[vt_orderid]['offset'] == Offset.OPEN:
                    self.open_pos_info['total_price'] += order.price * order.volume
                    self.open_pos_info['total_volume'] += order.volume
                    self.mid_price = round_to(self.open_pos_info['total_price'] / self.open_pos_info['total_volume'], self.pricetick)
                elif self.order_info_queue[vt_orderid]['offset'] == Offset.CLOSE:
                    if order.volume < self.open_pos_info['total_volume']:
                        self.open_pos_info['total_volume'] -= order.volume
                        self.open_pos_info['total_price'] -= order.price * order.volume
                        self.mid_price = round_to(self.open_pos_info['total_price'] / self.open_pos_info['total_volume'], self.pricetick)
                    else:
                        self.open_pos_info['total_volume'] = 0
                        self.open_pos_info['total_price'] = 0
                        self.mid_price = 0
            
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1
                
                print(f'{"taker": >10}{"maker": >10}{"traded": >10}{"total": >10}{"long pos": >15}{"short pos": >15}{"mid-price": >15}')
                print(f'{self.summary_count["taker"]: >10}{self.summary_count["maker"]: >10}{self.summary_count["traded"]: >10}{self.summary_count["total"]: >10}{self.long_pos: >15}{self.short_pos: >15}{self.mid_price: >15}')
            except:
                pass
        
        elif order.status == Status.CANCELLED:
            if vt_orderid in self.order_info_queue:
                try:
                    del self.order_info_queue[vt_orderid]
                except:
                    pass
            self.summary_count['cancelled'] += 1
        
        elif order.status == Status.REJECTED:
            self.summary_count['rejected'] += 1
        
        if order.status != Status.CANCELLED:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)


    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, price, volume = -1):
        
        # cancel previous order
        origin_vt_orderid = self.registered_order_info[direction][offset]
        
        if origin_vt_orderid != '':
            # print("send_new_order: waiting for submitting ", origin_vt_orderid)
            # while self.order_info_queue[origin_vt_orderid]['status'] == Status.SUBMITTING:
            #     if self.stop_main_process == True:
            #         break
            #     sleep(0.05)
            # print('send_new_order: finish')
            
            if self.order_info_queue[origin_vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == Status.PARTTRADED:
                self.cancel_order(origin_vt_orderid)
                self.registered_order_info[direction][offset] = ''
            elif self.order_info_queue[origin_vt_orderid]['status'] == Status.ALLTRADED or self.order_info_queue[origin_vt_orderid]['status'] == Status.REJECTED:
                self.remove_order_info_queue(origin_vt_orderid)

        if self.stop_main_process == True:
            return False

        price = round_to(price, self.pricetick)
        
        if volume <= 0:
            self.calculate_trade_volume()

            if offset == Offset.OPEN:
                volume = self.long_short_open
            else:
                volume = self.long_short_close

        volume = round_to(volume, self.min_volume)

        if price * volume == 0:
            return False

        vt_orderid = ''

        if direction == Direction.LONG:
            if offset == Offset.OPEN:

                # if self.short_pos == 0:
                # price = self.get_maker_order_price(direction, offset, price)
                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)

                # if self.short_pos == 0:
                try:
                    vt_orderid = self.buy(price, volume)[-1]
                except:
                    print("catched exception")
                    vt_orderid = self.buy(price, volume)[-1]

            else:
                if self.short_pos <= 0:
                    return False

                self.calculate_max_pos_volume()

                overflow_volume = 0

                if self.short_pos > self.max_pos_volume + volume:
                    overflow_volume = self.short_pos - self.max_pos_volume - volume

                volume = round_to(volume + overflow_volume, self.min_volume)

                if self.short_pos < volume and self.short_pos > 0:
                    volume = round_to(self.short_pos, self.min_volume)
                
                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)

                if price >= self.mid_price and self.mid_price != 0:
                    price = round_to(self.mid_price - self.pricetick, self.pricetick)

                try:
                    vt_orderid = self.cover(price, volume)[-1]
                except:
                    print("catched exception")
                    vt_orderid = self.cover(price, volume)[-1]

        else:
            if offset == Offset.OPEN:
                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)

                # if self.long_pos == 0:
                try:
                    vt_orderid = self.short(price, volume)[-1]
                except:
                    print("catched exception")
                    vt_orderid = self.short(price, volume)[-1]

            else:
                if self.long_pos <= 0:
                    return False

                self.calculate_max_pos_volume()

                overflow_volume = 0

                if self.long_pos > self.max_pos_volume + volume:
                    overflow_volume = self.long_pos - self.max_pos_volume - volume
                
                volume = round_to(volume + overflow_volume, self.min_volume)

                if self.long_pos < volume and self.long_pos > 0:
                    volume = round_to(self.long_pos, self.min_volume)

                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)

                if price <= self.mid_price:
                    price = round_to(self.mid_price + self.pricetick, self.pricetick)

                try:
                    vt_orderid = self.sell(price, volume)[-1]
                except:
                    print("catched exception")
                    vt_orderid = self.sell(price, volume)[-1]

        if len(vt_orderid) > 0:
        #     # self.write_log_to_file("Submit new order", order_type, vt_orderid, price, volume)
            self.set_order_info_queue(vt_orderid, direction, offset, price, volume, Status.SUBMITTING)
        

    """
    "   desc:   Calculate max position volume
    "   input:  price
    "   output: Set max_pos_volume
    """
    def calculate_max_pos_volume(self):
        self.target_pos = self.balance * self.lerver_rate / self.market_price
        self.max_pos_volume = self.target_pos * self.max_pos_pst


    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data

        # print(account)

        if account.gateway_name == 'GATEIOS':
            self.balance = account.balance
    

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data

        # print(position)

        if position.vt_symbol == self.vt_symbol:
            if position.direction == Direction.LONG:
                self.long_pos = position.volume

                # closed all long pos
                if self.last_long_pos > 0 and self.long_pos == 0:
                    self.write_log(f"多仓全平")

                    print('Restart because all long pos are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_long_pos = self.long_pos

            elif position.direction == Direction.SHORT:
                self.short_pos = position.volume

                # closed all short pos
                if self.last_short_pos > 0 and self.short_pos == 0:
                    self.write_log(f"空仓全平")
                    
                    print('Restart because all short pos are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_short_pos = self.short_pos
    
    """
    "   desc:   Write log to file
    "   Log File Path: C:/trading_logs/[day]/[hour]
    """
    # def write_log_to_file(self, info, order_type = '', vt_orderid = '', price = 0, volume = 0):
    #     now = datetime.now()
    #     date_time = now.strftime("%m/%d/%Y, %H:%M:%S, %f")
    #     log_path = "C:\\trading_logs\\" + now.strftime("%Y-%m-%d") + "\\" + now.strftime("%H") + ".txt"
        
    #     os.makedirs(os.path.dirname(log_path), exist_ok=True)
    #     with open(log_path , "a") as f:
    #         f.write('##############\n')
    #         f.write("#  " +date_time + '\n')
    #         f.write("#  " + info + '\n')

    #         if len(order_type) > 0:
    #             f.write("#  order_type = " + order_type + ",  vt_orderid = " + vt_orderid + ",  price = " + str(price) + ",  volume = " + str(volume) + '\n')
    #             f.write("#  long_pos = " + str(self.long_pos) + ",  short_pos = " + str(self.short_pos) + ",  target_pos = " + str(self.target_pos) + ",  max_pos_volume = " + str(self.max_pos_volume) + '\n')
    #             f.write("#  long_short_open = " + str(self.long_short_open) + ",  long_short_close = " + str(self.long_short_close) + '\n')
            
    #         f.write('##############\n\n')