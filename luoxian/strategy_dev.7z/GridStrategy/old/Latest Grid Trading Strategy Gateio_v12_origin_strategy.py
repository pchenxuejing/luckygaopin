from vnpy.app.cta_strategy import (
    CtaTemplate,
    StopOrder,
    TickData,
    BarData,
    TradeData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, Interval
from datetime import time, datetime
from vnpy.trader.object import PositionData,AccountData
from copy import deepcopy
import os
from collections import defaultdict
import numpy as np
from vnpy.trader.event import EVENT_TIMER, EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread
from time import sleep

class GridStrategy_GateIO_v12(CtaTemplate):
    
    author = "最新网格交易策略v1.1"

    grid_gap_tick_count = 10       # 网格间距
    lerver_rate = 100   # 杠杆比例
    
    pos_num = 0.1       # 算big_percent时候用到
    max_pos_pst = 0.1

    modify_limit_volume = 300
    modify_pricetick_n = 3

    balance = 0         # 账户余额
    long_pos = 0        # 多头持仓
    short_pos = 0       # 空头持仓

    target_pos = 0
    big_percent = 0
    small_percent = 0

    long_short_open = 0
    long_short_close = 0

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0

    }

    parameters = ["grid_gap_tick_count","max_pos_pst", "lerver_rate",'pos_num','modify_limit_volume','modify_pricetick_n']

    variables = ['balance','long_pos','short_pos','target_pos', 'big_percent', 'long_short_open', 'long_short_close']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume

        self.symbol = self.vt_symbol.split('.')[0]
        
        self.init()


    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.market_price = 0

        self.last_long_pos = 0
        self.last_short_pos = 0

        self.max_pos_volume = 0
        self.grid_gap = self.pricetick * self.grid_gap_tick_count

        self.main_process_thread = None
        self.restart_strategy_thread = None
        self.clear_order_thread = None

        self.trading_direction = None

        self.registered_order_info = {
            Direction.LONG: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            },
            Direction.SHORT: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            }
        }

        self.order_info_queue = {}
        self.modified_order_offset = {
            Offset.OPEN: False,
            Offset.CLOSE: False
        }


    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('GATEIOS')

        self.write_log("策略初始化")

        # self.write_log_to_file('Strategy is initialized.')
        

    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status=300

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)
        self.write_log("策略启动")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

        # clear unnecessary orders
        self.clear_order_thread = Thread(target = self.clear_orders)
        self.clear_order_thread.setDaemon(True)

        self.clear_order_thread.start()

        # self.write_log_to_file('Strategy is started.')
    

    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.stop_main_process = True
        
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)
        self.write_log("策略停止")

        # self.write_log_to_file('Strategy is stopped.')
    

    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.last_last_tick = self.last_tick
        self.last_tick = tick
        
        if self.is_valid_tick(tick) == False:
            # print("ON tick: tick is none")
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)
    

    def clear_orders(self):
        while True:
            direction = self.trading_direction

            if direction == Direction.LONG:
                opposite_direction = Direction.SHORT
            else:
                opposite_direction = Direction.LONG

            if direction != None:

                try:
                    order_info_queue = deepcopy(self.order_info_queue)
                except:
                    order_info_queue = deepcopy(self.order_info_queue)
                    
                for vt_orderid in order_info_queue:

                    if vt_orderid == self.registered_order_info[direction][Offset.OPEN] or vt_orderid == self.registered_order_info[opposite_direction][Offset.CLOSE]:
                        continue

                    if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:

                        # try:
                        #     self.cancel_order(vt_orderid)
                        # except:
                        #     self.cancel_order(vt_orderid)

                        sleep(0.5)
                    else:
                        del self.order_info_queue[vt_orderid]

                sleep(60)


    def restart_strategy(self):
        self.stop_main_process = True

        while self.stop_main_process == True:
            sleep(0.05)

        print("Restarted completely")
        
        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

    
    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    def main_process(self):

        LONG = Direction.LONG
        SHORT = Direction.SHORT
        OPEN = Offset.OPEN
        CLOSE = Offset.CLOSE
        grid_gap = self.grid_gap
        pricetick = self.pricetick
        min_volume = self.min_volume

        print("Balance is ", self.balance)
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or self.is_valid_tick(self.last_tick) == False:
            if self.stop_main_process == True:
                break
            sleep(0.05)
        print("Balance is ", self.balance)

        # send long_open order and short_open order when strategy start
        self.send_long_short_open_order_when_start()

        last_trading_direction = self.trading_direction

        # main process deamon
        while self.stop_main_process == False:
            sleep(0.1)

            if self.trading == False or self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False:
                print("Tick is invalid.")
                continue

            # check long and short open order which is placed when starts
            if self.trading_direction == None:

                for direction in (LONG, SHORT):

                    vt_orderid = self.registered_order_info[direction][OPEN]

                    if vt_orderid == '':
                        continue
                
                    if vt_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:

                        if direction == LONG:
                            cancel_direction = SHORT
                        else:
                            cancel_direction = LONG

                        cancel_orderid = self.registered_order_info[cancel_direction][OPEN]

                        self.cancel_order(cancel_orderid)
                        self.registered_order_info[cancel_direction][OPEN] = ''
                        
                        self.trading_direction = direction

                        break
            
            if self.trading_direction != None:
                trading_direction = self.trading_direction

                for direction in (LONG, SHORT):

                    if self.stop_main_process == True:
                        break
                    
                    if direction == LONG:
                        opposite_direction = SHORT
                        multiple = 1
                    else:
                        opposite_direction = LONG
                        multiple = -1

                    if direction == trading_direction:
                        offset = OPEN
                        opposite_offset = CLOSE
                    else:
                        offset = CLOSE
                        opposite_offset = OPEN

                    if self.registered_order_info[direction][offset] == '':
                        continue
                    else:
                        vt_orderid = self.registered_order_info[direction][offset]

                        if vt_orderid not in self.order_info_queue:
                            continue
                        
                        # resend rejected order
                        if self.order_info_queue[vt_orderid]['status'] == Status.REJECTED:
                            price = self.order_info_queue[vt_orderid]['price']
                            volume = self.order_info_queue[vt_orderid]['volume']

                            self.send_new_order(direction, offset, price, volume)

                            continue
                        
                        # send new order when order is filled
                        if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:
                            grid_gap = self.grid_gap
                            traded_price = self.order_info_queue[vt_orderid]['price']

                            if offset == OPEN:
                                if last_trading_direction == trading_direction:
                                    # calculate open price
                                    open_price = round_to(traded_price - multiple * grid_gap, pricetick)

                                    # send open order
                                    self.send_new_order(direction, OPEN, open_price)

                                    # change close order
                                    close_id = self.registered_order_info[opposite_direction][CLOSE]

                                    if close_id != '':
                                        while close_id not in self.order_info_queue or self.order_info_queue[close_id]['status'] == Status.SUBMITTING:
                                            if self.stop_main_process == True:
                                                break
                                            sleep(0.05)
                                        
                                        close_status = self.order_info_queue[close_id]['status']

                                        # calculate new close price
                                        if self.modified_order_offset[CLOSE] == True:
                                            close_price = round_to(traded_price + multiple * grid_gap * self.small_percent, pricetick)
                                        # calculate new close price from previous order
                                        else:
                                            origin_close_price = self.order_info_queue[close_id]['price']

                                            close_price = round_to(origin_close_price - multiple * grid_gap * self.small_percent, pricetick)


                                        # calculate volume
                                        if close_status == Status.NOTTRADED or close_status == Status.PARTTRADED:
                                            
                                            if self.modified_order_offset[CLOSE] == True:
                                                close_volume = self.calculate_volume_when_price_change(opposite_direction, CLOSE, close_price)
                                            else:
                                                close_volume = round_to(self.order_info_queue[close_id]['volume'], min_volume)

                                        elif close_status == Status.ALLTRADED or close_status == Status.CANCELLED or close_status == Status.REJECTED:
                                            self.calculate_trade_volume()
                                            close_volume = self.long_short_close
                                    else:
                                        close_price = round_to(traded_price + multiple * grid_gap * self.small_percent, pricetick)
                                        
                                        self.calculate_trade_volume()
                                        close_volume = self.long_short_close

                                    self.send_new_order(opposite_direction, CLOSE, close_price, close_volume)
                            
                                else:
                                    # calculate open price
                                    open_price = round_to(traded_price - multiple * grid_gap, pricetick)

                                    # send open order
                                    self.send_new_order(direction, OPEN, open_price)

                                    # calculate close price
                                    close_price = round_to(traded_price + multiple * grid_gap * self.small_percent, pricetick)

                                    # send open order
                                    self.send_new_order(opposite_direction, CLOSE, close_price)
                            else:
                                # calculate close price
                                close_price = round_to(traded_price - multiple * grid_gap * self.small_percent, pricetick)

                                #send close order
                                self.send_new_order(direction, CLOSE, close_price)

                                # change open order
                                open_id = self.registered_order_info[opposite_direction][OPEN]

                                if open_id != '':
                                    while self.order_info_queue[open_id]['status'] == Status.SUBMITTING:
                                        if self.stop_main_process == True:
                                            break
                                        sleep(0.05)
                                    
                                    open_status = self.order_info_queue[open_id]['status']

                                    # calculate new open price
                                    if self.modified_order_offset[OPEN] == True:
                                        open_price = round_to(traded_price + multiple * grid_gap, pricetick)
                                    # calculate new open price from previous order
                                    else:
                                        origin_open_price = self.order_info_queue[open_id]['price']

                                        open_price = round_to(origin_open_price - multiple * grid_gap, pricetick)


                                    if open_status == Status.NOTTRADED or open_status == Status.PARTTRADED:
                                        
                                        if self.modified_order_offset[OPEN] == True:
                                            open_volume = self.calculate_volume_when_price_change(opposite_direction, OPEN, open_price)
                                        else:
                                            open_volume = round_to(self.order_info_queue[open_id]['volume'], min_volume)

                                    elif open_status == Status.ALLTRADED or open_status == Status.CANCELLED or open_status == Status.REJECTED:
                                        self.calculate_trade_volume()
                                        open_volume = self.long_short_open
                                else:
                                    open_price = round_to(traded_price + multiple * grid_gap, pricetick)

                                    self.calculate_trade_volume()
                                    open_volume = self.long_short_open

                                self.send_new_order(opposite_direction, OPEN, open_price, open_volume)
                            
                            # no modified_order when order is filled
                            self.modified_order_offset = {
                                Offset.OPEN: False,
                                Offset.CLOSE: False
                            }

                            break
                                    
                        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                            # change order based on modify limit volume
                            self.change_order_based_on_modify_limit_volume(direction, offset)

                last_trading_direction = trading_direction        

        sleep(5)
        
        # cancel all orders when strategy stop
        direction = self.trading_direction
        if direction != None:
            if direction == LONG:
                opposite_direction = SHORT
            else:
                opposite_direction = LONG
            
            open_id = self.registered_order_info[direction][OPEN]
            
            if open_id in self.order_info_queue and (self.order_info_queue[open_id]['status'] == Status.NOTTRADED or self.order_info_queue[open_id]['status'] == Status.PARTTRADED):
                self.cancel_order(open_id)
            
            close_id = self.registered_order_info[opposite_direction][CLOSE]

            if close_id in self.order_info_queue and (self.order_info_queue[close_id]['status'] == Status.NOTTRADED or self.order_info_queue[close_id]['status'] == Status.PARTTRADED):
                self.cancel_order(close_id)
        
        sleep(5)

        self.stop_main_process = False


    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == Offset.NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   desc:   Check the modify_limit_volume logic and Change order
    "   input:  order_type, tick
    "   output: bool: True => changed, False => not changed
    """
    def change_order_based_on_modify_limit_volume(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)

        # get order price and volume
        vt_orderid = self.registered_order_info[direction][offset]

        order_price = self.order_info_queue[vt_orderid]['price']
        order_volume = self.order_info_queue[vt_orderid]['volume']

        if order_price * order_volume == 0:
            return

        modify_limit_volume = self.modify_limit_volume
        modify_pricetick_n = self.modify_pricetick_n
        pricetick = self.pricetick

        new_order_price = -1

        if direction == Direction.LONG:
            if tick.bid_price_1 == order_price:
                total_volume = tick.bid_volume_1 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.bid_volume_2

                    if modify_limit_volume > total_volume:
                        total_volume += tick.bid_volume_3

                        if modify_limit_volume > total_volume:
                            total_volume += tick.bid_volume_4

                            if modify_limit_volume > total_volume:
                                new_order_price = tick.bid_price_5 + pricetick

                            else:
                                new_order_price = tick.bid_price_4 + pricetick
                            
                        else:
                            new_order_price = tick.bid_price_3 + pricetick

                    else:
                        new_order_price = tick.bid_price_2 + pricetick

            elif tick.bid_price_2 == order_price:
                total_volume = tick.bid_volume_1 + tick.bid_volume_2 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.bid_volume_3

                    if modify_limit_volume > total_volume:
                        total_volume += tick.bid_volume_4

                        if modify_limit_volume > total_volume:
                            new_order_price = tick.bid_price_5 + pricetick

                        else:
                            new_order_price = tick.bid_price_4 + pricetick
                        
                    else:
                        new_order_price = tick.bid_price_3 + pricetick

        elif direction == Direction.SHORT:
            if tick.ask_price_1 == order_price:
                total_volume = tick.ask_volume_1 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.ask_volume_2

                    if modify_limit_volume > total_volume:
                        total_volume += tick.ask_volume_3

                        if modify_limit_volume > total_volume:
                            total_volume += tick.ask_volume_4

                            if modify_limit_volume > total_volume:
                                new_order_price = tick.ask_price_5 - pricetick

                            else:
                                new_order_price = tick.ask_price_4 - pricetick
                            
                        else:
                            new_order_price = tick.ask_price_3 - pricetick

                    else:
                        new_order_price = tick.ask_price_2 - pricetick

            elif tick.ask_price_2 == order_price:
                total_volume = tick.ask_volume_1 + tick.ask_volume_2 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.ask_volume_3

                    if modify_limit_volume > total_volume:
                        total_volume += tick.ask_volume_4

                        if modify_limit_volume > total_volume:
                            new_order_price = tick.ask_price_5 - pricetick

                        else:
                            new_order_price = tick.ask_price_4 - pricetick
                        
                    else:
                        new_order_price = tick.ask_price_3 - pricetick
            
        if new_order_price > 0 and abs((new_order_price - order_price) / pricetick) >= modify_pricetick_n:

            new_order_price = round_to(new_order_price, pricetick)
            new_order_volume = self.calculate_volume_when_price_change(direction, offset, new_order_price)

            if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                is_changed = self.send_new_order(direction, offset, new_order_price, new_order_volume)
                if is_changed == True:
                    print("Changed :", direction, offset, order_price, new_order_price, order_volume, new_order_volume)
                    
                    self.modified_order_offset[offset] = True
                


    """
    "   desc:   Calculate volume when all of price change happen
    "   input:  order_type, new_order_price
    "   output: new_order_volume: default => 0
    """
    def calculate_volume_when_price_change(self, direction, offset, new_price):
        vt_orderid = self.registered_order_info[direction][offset]

        if vt_orderid == '':
            self.calculate_trade_volume()

            if offset == Offset.OPEN:
                volume = self.long_short_open
            else:
                volume = self.long_short_close
            
            return volume
        else:
            old_price = self.order_info_queue[vt_orderid]['price']
            old_volume = self.order_info_queue[vt_orderid]['volume']

        if old_price * old_volume == 0:
            return 0

        if self.trading_direction == Direction.LONG:
            multiple = 1
        else:
            multiple = -1

        self.calculate_trade_volume()

        if offset == Offset.OPEN:
            new_volume = old_volume + multiple * self.long_short_open * ((old_price - new_price) / self.grid_gap)
            if new_volume < self.min_volume:
                new_volume = self.long_short_open
        else:
            new_volume = old_volume + multiple * self.long_short_close * ((new_price - old_price) / self.grid_gap)
            if new_volume < self.min_volume:
                new_volume = self.long_short_close

        
        new_volume = round_to(new_volume, self.min_volume)

        return new_volume


    """
    "   desc:   Send long and short open order when trading is started
    "   output: new_order_volume: default => 0
    """
    def send_long_short_open_order_when_start(self):
        
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return False

            sleep(0.05)

        self.calculate_trade_volume()
        
        if self.long_pos != 0:
            # calculate ask bid_price
            bid_price = round_to(self.market_price - self.grid_gap, self.pricetick)
            
            ask_price = round_to(self.market_price + self.grid_gap * self.small_percent, self.pricetick)

            # send order to open long position
            self.send_new_order(Direction.LONG, Offset.OPEN, bid_price)

            # send order to close long position
            self.send_new_order(Direction.SHORT, Offset.CLOSE, ask_price)

            self.trading_direction = Direction.LONG
        elif self.short_pos != 0:
            # calculate ask bid_price
            bid_price = round_to(self.market_price - self.grid_gap * self.small_percent, self.pricetick)
            
            ask_price = round_to(self.market_price + self.grid_gap, self.pricetick)

            # send order to open short position
            self.send_new_order(Direction.SHORT, Offset.OPEN, ask_price)

            # send order to close short position
            self.send_new_order(Direction.LONG, Offset.CLOSE, bid_price)

            self.trading_direction = Direction.SHORT
        else:
            # calculate ask bid_price
            bid_price = round_to(self.market_price - self.grid_gap, self.pricetick)
            
            ask_price = round_to(self.market_price + self.grid_gap, self.pricetick)

            # send order to open long position
            self.send_new_order(Direction.LONG, Offset.OPEN, bid_price)

            # send order to open short position
            self.send_new_order(Direction.SHORT, Offset.OPEN, ask_price)

            self.trading_direction = None


    """
    "   desc:   Calculate long_short_open, long_short_close volume
    "   input:  market_price
    """
    def calculate_trade_volume(self):
        self.target_pos = self.balance * self.lerver_rate / self.market_price
        self.big_percent = (1 + (abs(self.long_pos - self.short_pos) / (self.target_pos * self.pos_num)))
        self.small_percent = (1 - (abs(self.long_pos - self.short_pos) / (self.target_pos * self.pos_num)))
        self.grid_base_pos_pst = self.grid_gap / self.market_price
        
        # calculate long_short_open volume
        self.long_short_open = max(round_to(self.grid_base_pos_pst * self.target_pos, self.min_volume), self.min_volume)

        # calculate long_short_close volume
        self.long_short_close = max(round_to(self.grid_base_pos_pst * self.target_pos * self.big_percent, self.min_volume), self.min_volume)
    

    """
    "   desc:   Change taker order to maker order
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_maker_order_price(self, direction):
        
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)
        

        pricetick = self.pricetick
        modify_limit_volume = self.modify_limit_volume

        if direction == Direction.LONG :

            price = tick.bid_price_1
            total_volume = tick.bid_volume_1

            if total_volume < modify_limit_volume:
                price = tick.bid_price_2
                total_volume += tick.bid_volume_2

                if total_volume < modify_limit_volume:
                    price = tick.bid_price_3
                    total_volume += tick.bid_volume_3

                    if total_volume < modify_limit_volume:
                        price = tick.bid_price_4
                        total_volume += tick.bid_volume_4

                        if total_volume < modify_limit_volume:
                            price = tick.bid_price_5
                            total_volume += tick.bid_volume_4

                            if total_volume < modify_limit_volume:
                                price = tick.bid_price_5 - pricetick

        elif direction == Direction.SHORT:

            price = tick.ask_price_1
            total_volume = tick.ask_volume_1

            if total_volume < modify_limit_volume:
                price = tick.ask_price_2
                total_volume += tick.ask_volume_2

                if total_volume < modify_limit_volume:
                    price = tick.ask_price_3
                    total_volume += tick.ask_volume_3

                    if total_volume < modify_limit_volume:
                        price = tick.ask_price_4
                        total_volume += tick.ask_volume_4

                        if total_volume < modify_limit_volume:
                            price = tick.ask_price_5
                            total_volume += tick.ask_volume_4

                            if total_volume < modify_limit_volume:
                                price = tick.ask_price_5 + pricetick

        price = round_to(price, pricetick)

        return price
    

    def check_if_maker_order(self, direction, offset, price, volume):

        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)
        
        new_price = price
        new_volume = volume
        if direction == Direction.LONG:
            if price > tick.bid_price_1:
                new_price = self.get_maker_order_price(direction)
                new_volume = self.calculate_volume_when_price_change(direction, offset, new_price)
        
        else:
            if price < tick.ask_price_1:
                price = self.get_maker_order_price(direction)
                new_volume = self.calculate_volume_when_price_change(direction, offset, new_price)
        
        
        return (new_price, new_volume)


    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == Status.SUBMITTING:
            self.summary_count['total'] += 1
        
        elif order.status == Status.NOTTRADED:
            order_type = 'maker'
        
        elif order.status == Status.PARTTRADED:
            pass
        
        elif order.status == Status.ALLTRADED:
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1
                
                print(f'{"taker": >10}{"maker": >10}{"traded": >10}{"total": >10}{"long pos": >15}{"short pos": >15}{"balance": >22}')
                print(f'{self.summary_count["taker"]: >10}{self.summary_count["maker"]: >10}{self.summary_count["traded"]: >10}{self.summary_count["total"]: >10}{self.long_pos: >15}{self.short_pos: >15}{self.balance: >22}')
            except:
                pass
        
        elif order.status == Status.CANCELLED:
            self.summary_count['cancelled'] += 1
        
        elif order.status == Status.REJECTED:
            self.summary_count['rejected'] += 1
        
        self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)


    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, price, volume = -1):
        
        # get orifin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == Status.SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == Status.REJECTED:
                return False

            elif self.order_info_queue[origin_vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == Status.PARTTRADED:
                self.cancel_order(origin_vt_orderid)

            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        price = round_to(price, self.pricetick)
        
        if volume <= 0:
            self.calculate_trade_volume()

            if offset == Offset.OPEN:
                volume = self.long_short_open
            else:
                volume = self.long_short_close

        volume = round_to(volume, self.min_volume)

        if price * volume == 0:
            return False

        if direction == Direction.LONG:
            if offset == Offset.OPEN:

                self.calculate_max_pos_volume()

                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)
                
                if self.long_pos >= self.max_pos_volume:
                    return False

                if self.max_pos_volume < self.long_pos + volume:
                    volume = round_to(self.max_pos_volume - self.long_pos, self.min_volume)

                try:
                    vt_orderid = self.buy(price, volume)[-1]
                except:
                    print("catched exception: long open")
                    vt_orderid = self.buy(price, volume)[-1]

            else:
                if self.short_pos <= 0:
                    return False

                # self.calculate_max_pos_volume()

                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)

                if self.short_pos < volume and self.short_pos > 0:
                    volume = round_to(self.short_pos, self.min_volume)
                
                try:
                    vt_orderid = self.cover(price, volume)[-1]
                except:
                    print("catched exception: long close")
                    vt_orderid = self.cover(price, volume)[-1]

        else:
            if offset == Offset.OPEN:

                self.calculate_max_pos_volume()

                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)
                
                if self.short_pos >= self.max_pos_volume:
                    return False

                if self.max_pos_volume < self.short_pos + volume:
                    volume = round_to(self.max_pos_volume - self.short_pos, self.min_volume)
                
                try:
                    vt_orderid = self.short(price, volume)[-1]
                except:
                    print("catched exception: short open")
                    vt_orderid = self.short(price, volume)[-1]

            else:
                if self.long_pos <= 0:
                    return False

                (price, volume) = self.check_if_maker_order(direction, offset, price, volume)

                if self.long_pos < volume and self.long_pos > 0:
                    volume = round_to(self.long_pos, self.min_volume)

                try:
                    vt_orderid = self.sell(price, volume)[-1]
                except:
                    print("catched exception: short close")
                    vt_orderid = self.sell(price, volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            return True
        else:
            return False
        

    """
    "   desc:   Calculate max position volume
    "   input:  price
    "   output: Set max_pos_volume
    """
    def calculate_max_pos_volume(self):
        self.target_pos = self.balance * self.lerver_rate / self.market_price
        self.max_pos_volume = self.target_pos * self.max_pos_pst


    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data

        # print(account)

        if account.gateway_name == 'GATEIOS':
            self.balance = account.balance
    

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data

        # print(position)

        if position.vt_symbol == self.vt_symbol:
            if position.direction == Direction.LONG:
                self.long_pos = position.volume

                # closed all long pos
                if self.last_long_pos > 0 and self.long_pos == 0:
                    self.write_log(f"多仓全平")

                    print('Restart because all long pos are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_long_pos = self.long_pos

            elif position.direction == Direction.SHORT:
                self.short_pos = position.volume

                # closed all short pos
                if self.last_short_pos > 0 and self.short_pos == 0:
                    self.write_log(f"空仓全平")
                    
                    print('Restart because all short pos are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_short_pos = self.short_pos
    
    """
    "   desc:   Write log to file
    "   Log File Path: C:/trading_logs/[day]/[hour]
    """
    # def write_log_to_file(self, info, order_type = '', vt_orderid = '', price = 0, volume = 0):
    #     now = datetime.now()
    #     date_time = now.strftime("%m/%d/%Y, %H:%M:%S, %f")
    #     log_path = "C:\\trading_logs\\" + now.strftime("%Y-%m-%d") + "\\" + now.strftime("%H") + ".txt"
        
    #     os.makedirs(os.path.dirname(log_path), exist_ok=True)
    #     with open(log_path , "a") as f:
    #         f.write('##############\n')
    #         f.write("#  " +date_time + '\n')
    #         f.write("#  " + info + '\n')

    #         if len(order_type) > 0:
    #             f.write("#  order_type = " + order_type + ",  vt_orderid = " + vt_orderid + ",  price = " + str(price) + ",  volume = " + str(volume) + '\n')
    #             f.write("#  long_pos = " + str(self.long_pos) + ",  short_pos = " + str(self.short_pos) + ",  target_pos = " + str(self.target_pos) + ",  max_pos_volume = " + str(self.max_pos_volume) + '\n')
    #             f.write("#  long_short_open = " + str(self.long_short_open) + ",  long_short_close = " + str(self.long_short_close) + '\n')
            
    #         f.write('##############\n\n')