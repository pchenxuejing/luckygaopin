from vnpy.app.cta_strategy import (
    CtaTemplate,
    StopOrder,
    TickData,
    BarData,
    TradeData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, Interval
from datetime import time, datetime
from vnpy.trader.object import PositionData,AccountData
from copy import deepcopy
import os
from collections import defaultdict
import numpy as np
from vnpy.trader.event import EVENT_TIMER, EVENT_ACCOUNT, EVENT_POSITION

class LatestGridStrategyV12(CtaTemplate):
    
    author = "最新网格交易策略v12"

    grid_gap_tick_count = 10       # 网格间距
    lerver_rate = 10   # 杠杆比例
    
    pos_num = 1       # 算big_percent时候用到
    max_pos_pst = 1

    modify_limit_volume = 500
    modify_pricetick_n = 5

    balance = 0         # 账户余额
    long_pos = 0        # 多头持仓
    short_pos = 0       # 空头持仓

    target_pos = 0
    big_percent = 0

    long_short_open = 0
    long_short_close = 0

    parameters = ["grid_gap_tick_count","max_pos_pst", "lerver_rate",'pos_num','modify_limit_volume','modify_pricetick_n']

    variables = ['balance','long_pos','short_pos','target_pos', 'big_percent', 'long_short_open', 'long_short_close']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # connect on_bar to BarGenerator
        # self.bg = BarGenerator(self.on_bar)
        # self.am = ArrayManager()

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume

        self.symbol = self.vt_symbol.split('.')[0]
        
        self.init()


    def init(self):
        # mappings between orders
        self.registerd_orderids = {
            'long_open': '',
            'long_close': '',
            'short_open': '',
            'short_close': ''
        }
        self.submitting_orderids = deepcopy(self.registerd_orderids)
        self.modified_orderids = deepcopy(self.registerd_orderids)
        self.orderid_to_order_infos = {}

        self.last_tick = None
        self.market_price = 0
        self.last_trading_status = False

        self.last_long_pos = 0
        self.last_short_pos = 0

        self.last_traded_order_type = ''
        self.max_pos_volume = 0
        self.grid_gap = self.pricetick * self.grid_gap_tick_count


    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('GATEIOS')

        # self.load_bar(10)
        self.write_log("策略初始化")

        # self.write_log_to_file('Strategy is initialized.')
        

    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status=300

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)
        self.write_log("策略启动")

        # self.write_log_to_file('Strategy is started.')
    

    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.cancel_all()
        
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)
        self.write_log("策略停止")

        # self.write_log_to_file('Strategy is stopped.')
    

    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        
        self.last_tick = tick

        self.market_price = tick.last_price

        # self.bg.update_tick(tick)

        if self.market_price > 0 and self.balance > 0:
            # when start strategy
            if self.last_trading_status == False and self.trading:
                self.open_long_short_position_when_start()

            elif self.last_trading_status & self.trading:
                count = 0
                
                for value in self.registerd_orderids.values():
                    if value != '':
                        count += 1
                for value in self.submitting_orderids.values():
                    if value != '':
                        count += 1

                if count < 2:
                    self.cancel_all()
                    print('restart')
                    self.init()
                    return
                            
                for order_type in self.registerd_orderids.keys():

                    # if order_type == self.modified_order_type:
                    #     continue
                    
                    vt_orderid = self.registerd_orderids[order_type]

                    if len(vt_orderid) == 0:
                        continue

                    # check modify_limit_volume
                    is_changed = self.change_order_based_on_modify_limit_volume(order_type, tick)

                    if is_changed == True:
                        print("Changed by modify limit volume: ", order_type)
                        # self.write_log_to_file('Change based on modify_limit_volume')

            self.last_trading_status = self.trading

        self.put_event()

    
    def get_order_direction(self, order_type):
        if order_type == 'long_open' or order_type == 'short_close':
            return False
        elif order_type == 'long_close' or order_type == 'short_open':
            return True

    
    """
    "   desc:   Get order price from order_infos based on order type
    "   input:  order_type
    "   output: order_price, default: 0
    """
    def get_order_price_by_order_type(self, order_type):

        vt_orderid = self.registerd_orderids[order_type]

        try:
            order_price = self.orderid_to_order_infos[vt_orderid]['price']
        except:
            order_price = 0
        
        return order_price
        

    """
    "   desc:   Get order volume from order_infos based on order type
    "   input:  order_type
    "   output: order_volume, default: 0
    """
    def get_order_volume_by_order_type(self, order_type):
        
        vt_orderid = self.registerd_orderids[order_type]

        try:
            order_volume = self.orderid_to_order_infos[vt_orderid]['volume']
        except:
            order_volume = 0

        return order_volume


    """
    "   desc:   Check the modify_limit_volume logic and Change order
    "   input:  order_type, tick
    "   output: bool: True => changed, False => not changed
    """
    def change_order_based_on_modify_limit_volume(self, order_type, tick):

        pricetick = self.pricetick

        modify_limit_volume = self.modify_limit_volume
        modify_pricetick_n = self.modify_pricetick_n

        # get order price and volume
        order_price = self.get_order_price_by_order_type(order_type)
        order_volume = self.get_order_volume_by_order_type(order_type)

        if order_price * order_volume == 0:
            return False

        new_order_price = -1

        if order_type == 'long_open' or order_type =='short_close':
            if tick.bid_price_1 == order_price:
                total_volume = tick.bid_volume_1 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.bid_volume_2

                    if modify_limit_volume > total_volume:
                        total_volume += tick.bid_volume_3

                        if modify_limit_volume > total_volume:
                            total_volume += tick.bid_volume_4

                            if modify_limit_volume > total_volume:
                                new_order_price = tick.bid_price_5 + pricetick

                            else:
                                new_order_price = tick.bid_price_4 + pricetick
                            
                        else:
                            new_order_price = tick.bid_price_3 + pricetick

                    else:
                        new_order_price = tick.bid_price_2 + pricetick

            elif tick.bid_price_2 == order_price:
                total_volume = tick.bid_volume_1 + tick.bid_volume_2 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.bid_volume_3

                    if modify_limit_volume > total_volume:
                        total_volume += tick.bid_volume_4

                        if modify_limit_volume > total_volume:
                            new_order_price = tick.bid_price_5 + pricetick

                        else:
                            new_order_price = tick.bid_price_4 + pricetick
                        
                    else:
                        new_order_price = tick.bid_price_3 + pricetick

        elif order_type == 'short_open' or order_type =='long_close':
            if tick.ask_price_1 == order_price:
                total_volume = tick.ask_volume_1 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.ask_volume_2

                    if modify_limit_volume > total_volume:
                        total_volume += tick.ask_volume_3

                        if modify_limit_volume > total_volume:
                            total_volume += tick.ask_volume_4

                            if modify_limit_volume > total_volume:
                                new_order_price = tick.ask_price_5 - pricetick

                            else:
                                new_order_price = tick.ask_price_4 - pricetick
                            
                        else:
                            new_order_price = tick.ask_price_3 - pricetick

                    else:
                        new_order_price = tick.ask_price_2 - pricetick

            elif tick.ask_price_2 == order_price:
                total_volume = tick.ask_volume_1 + tick.ask_volume_2 - order_volume

                if modify_limit_volume > total_volume:
                    total_volume += tick.ask_volume_3

                    if modify_limit_volume > total_volume:
                        total_volume += tick.ask_volume_4

                        if modify_limit_volume > total_volume:
                            new_order_price = tick.ask_price_5 - pricetick

                        else:
                            new_order_price = tick.ask_price_4 - pricetick
                        
                    else:
                        new_order_price = tick.ask_price_3 - pricetick
        else:
            return False
            
        if new_order_price > 0 and abs((new_order_price - order_price) / pricetick) >= modify_pricetick_n:

            new_order_volume = self.calculate_volume_when_price_change(order_type, new_order_price)
            
            if new_order_volume == 0:
                return False

            print("modified volume: ", order_volume, new_order_volume)

            return self.send_new_order(order_type, new_order_price, new_order_volume)
        else:
            return False


    """
    "   desc:   Calculate volume when all of price change happen
    "   input:  order_type, new_order_price
    "   output: new_order_volume: default => 0
    """
    def calculate_volume_when_price_change(self, order_type, new_order_price):
        order_price = self.get_order_price_by_order_type(order_type)
        order_volume = self.get_order_volume_by_order_type(order_type)

        if order_price * order_volume == 0:
            return 0

        self.calculate_trade_volume()

        if order_type == 'long_open' or order_type == 'short_open':
            new_order_volume = order_volume + self.long_short_open * (abs(new_order_price - order_price) / self.grid_gap)

        else:
            new_order_volume = order_volume + self.long_short_close * (abs(new_order_price - order_price) / self.grid_gap)
        
        new_order_volume = round_to(new_order_volume, self.min_volume)

        return new_order_volume


    """
    "   desc:   Calculate convert volume when price changed order is cancelled
    "   input:  order_type, new_order_price
    "   output: new_order_volume: default => 0
    """
    def calculate_revert_volume(self, order_type, new_order_price):
        order_price = self.get_order_price_by_order_type(order_type)
        order_volume = self.get_order_volume_by_order_type(order_type)

        if order_price * order_volume == 0:
            return -1
        
        self.calculate_trade_volume()

        if order_type == 'long_open' or order_type == 'short_open':
            new_order_volume = order_volume - self.long_short_open * (abs(new_order_price - order_price) / self.grid_gap)

        else:
            new_order_volume = order_volume - self.long_short_close * (abs(new_order_price - order_price) / self.grid_gap)
        
        new_order_volume = round_to(new_order_volume, self.min_volume)
        
        return new_order_volume


    """
    "   desc:   Send long and short open order when trading is started
    "   output: new_order_volume: default => 0
    """
    def open_long_short_position_when_start(self):
        market_price = self.market_price

        # calculate long_ short_open_price
        long_open_price = market_price - self.grid_gap
        short_open_price = market_price + self.grid_gap

        # send buy order to open long position
        self.send_new_order('long_open', long_open_price)

        # send short order to open short position
        self.send_new_order('short_open', short_open_price)


    """
    "   desc:   Calculate long_short_open, long_short_close volume
    "   input:  market_price
    """
    def calculate_trade_volume(self):
        self.target_pos = self.balance * self.lerver_rate / self.last_tick.last_price
        self.big_percent = (1 + (abs(self.long_pos - self.short_pos) / (self.target_pos * self.pos_num)))
        self.grid_base_pos_pst = self.grid_gap / self.last_tick.last_price
        
        # calculate long_short_open volume
        self.long_short_open = max(round_to(self.grid_base_pos_pst * self.target_pos, self.min_volume), self.min_volume)

        # calculate long_short_close volume
        self.long_short_close = max(round_to(self.grid_base_pos_pst * self.target_pos * self.big_percent, self.min_volume), self.min_volume)
    

    """
    "   desc:   Change taker order to maker order
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_maker_order_price(self, order_type, order_price):
        
        # tick = self.last_tick
        pricetick = self.pricetick
        market_price = self.market_price

        if order_type == 'long_open' or order_type =='short_close':
            if order_price >= market_price:
                # if tick.bid_price_1 + pricetick < market_price:
                #     new_order_price = tick.bid_price_1 + pricetick
                # else:
                #     new_order_price = tick.bid_price_1

                new_order_price = round_to(market_price - self.grid_gap, pricetick)

                return new_order_price
            else:
                return order_price

        elif order_type == 'short_open' or order_type =='long_close':
            if order_price > 0 and order_price <= market_price:
                # if tick.ask_price_1 - pricetick > market_price:
                #     new_order_price = tick.ask_price_1 - pricetick
                # else:
                #     new_order_price = tick.ask_price_1

                new_order_price = round_to(market_price + self.grid_gap, pricetick)

                new_order_price = round_to(new_order_price, pricetick)
                
                return new_order_price
            else:
                return order_price
        

    # Not used
    def on_bar(self, bar: BarData):
        """
        Callback of new bar data update.
        """
        self.am.update_bar(bar)

        
        if not self.am.inited:
            return

        self.put_event()


    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):

        vt_orderid = order.vt_orderid
        try:
            order_type = self.orderid_to_order_infos[vt_orderid]['type']
        except:
            order_type = ''

        if len(order_type) == 0:
            print(order)
            return

        print('\n')
        print(vt_orderid, order_type, order.status, order.price, order.volume, self.market_price)

        if order.status == Status.SUBMITTING:
            pass
        
        elif order.status == Status.NOTTRADED:
            if self.submitting_orderids[order_type] == vt_orderid:
                self.registerd_orderids[order_type] = vt_orderid
                self.submitting_orderids[order_type] = ''
        
        elif order.status == Status.PARTTRADED:
            if self.submitting_orderids[order_type] == vt_orderid:
                self.registerd_orderids[order_type] = vt_orderid
                self.submitting_orderids[order_type] = ''

            if vt_orderid == self.modified_orderids[order_type]:
                self.modified_orderids[order_type] = ''
        
        elif order.status == Status.ALLTRADED:
            if self.submitting_orderids[order_type] == vt_orderid:
                self.registerd_orderids[order_type] = vt_orderid
                self.submitting_orderids[order_type] = ''

            if vt_orderid == self.modified_orderids[order_type]:
                self.modified_orderids[order_type] = ''

            # if vt_orderid == self.registerd_orderids[order_type]:
            #     self.write_log_to_file("Completed order data", order_type, vt_orderid, order.price, order.volume)
                
                self.registerd_orderids[order_type]  = ''
            else:
                self.registerd_orderids[order_type]  = ''
                return

            del self.orderid_to_order_infos[vt_orderid]

            last_traded_order_type = self.last_traded_order_type
            self.last_traded_order_type = order_type
            traded_price = order.price

            if order_type == 'long_open':

                if order_type != last_traded_order_type:
                    short_open_orderid = self.registerd_orderids['short_open']
                    if len(short_open_orderid) > 0:
                        self.cancel_order(short_open_orderid)

                    # send long open order
                    long_open_price = round_to(traded_price - self.grid_gap, self.pricetick)
                    
                    self.send_new_order('long_open', long_open_price)

                    # send long close order
                    long_close_price = round_to(traded_price + self.grid_gap, self.pricetick)
                    
                    self.send_new_order('long_close', long_close_price)

                else:
                    # send long open order
                    long_open_price = round_to(traded_price - self.grid_gap, self.pricetick)

                    self.send_new_order('long_open', long_open_price)
                    
                    # change long close order
                    long_close_price = self.get_order_price_by_order_type('long_close')
                    long_close_price = round_to(long_close_price - self.grid_gap, self.pricetick)

                    long_close_volume = self.get_order_volume_by_order_type('long_close')

                    modified_orderids = deepcopy(self.modified_orderids)

                    self.send_new_order('long_close', long_close_price, long_close_volume)

                    self.modified_orderids = deepcopy(modified_orderids)
                        
            elif order_type == 'long_close':

                # calculate long close order price
                long_close_price = round_to(traded_price + self.grid_gap, self.pricetick)

                # send long close order
                self.send_new_order('long_close', long_close_price)
                
                # change long open order
                long_open_price = self.get_order_price_by_order_type('long_open')
                long_open_price = round_to(traded_price + self.grid_gap, self.pricetick)

                long_open_volume = self.get_order_volume_by_order_type('long_open')

                modified_orderids = deepcopy(self.modified_orderids)

                self.send_new_order('long_open', long_open_price, long_open_volume)

                self.modified_orderids = deepcopy(modified_orderids)

            elif order_type == 'short_open':

                if order_type != last_traded_order_type:
                    long_open_orderid = self.registerd_orderids['long_open']
                    if len(long_open_orderid) > 0:
                        self.cancel_order(long_open_orderid)

                    # send short open order
                    short_open_price = round_to(traded_price + self.grid_gap, self.pricetick)

                    self.send_new_order('short_open', short_open_price)

                    short_close_price = round_to(traded_price - self.grid_gap, self.pricetick)
                    # send short close order                    
                    self.send_new_order('short_close', short_close_price)
                else:
                    # send short open order
                    short_open_price = round_to(traded_price + self.grid_gap, self.pricetick)

                    self.send_new_order('short_open', short_open_price)
                    
                    # change short close order
                    short_close_price = self.get_order_price_by_order_type('short_close')
                    short_close_price =  round_to(short_close_price + self.grid_gap, self.pricetick)

                    short_close_volume = self.get_order_volume_by_order_type('short_close')

                    modified_orderids = deepcopy(self.modified_orderids)

                    self.send_new_order('short_close', short_close_price, short_close_volume)

                    self.modified_orderids = deepcopy(modified_orderid)

            elif order_type == 'short_close':
                    
                # calculate short close order price
                short_close_price = round_to(traded_price - self.grid_gap, self.pricetick)
                
                # send short close order
                self.send_new_order('short_close', short_close_price)
                
                # change short open order
                short_open_price = self.get_order_price_by_order_type('short_open')
                short_open_price = round_to(short_open_price - self.grid_gap, self.pricetick)

                short_open_volume = self.get_order_volume_by_order_type('short_open')

                modified_orderids = deepcopy(self.modified_orderids)

                self.send_new_order('short_open',  short_open_price, short_open_volume)

                self.modified_orderids = deepcopy(modified_orderids)
        
        elif order.status == Status.CANCELLED:
            # self.write_log_to_file("Cancelled order data", order_type, vt_orderid, order.price, order.volume)

            if self.registerd_orderids[order_type] == vt_orderid:
                self.registerd_orderids[order_type] = ''
            
            del self.orderid_to_order_infos[vt_orderid]
        
        elif order.status == Status.REJECTED:
            
            if vt_orderid == self.submitting_orderids[order_type]:
                self.submitting_orderids[order_type] = ''

            if vt_orderid == self.modified_orderids[order_type]:
                self.modified_orderids[order_type] = ''
            
            del self.orderid_to_order_infos[vt_orderid]

        if order.status == Status.ALLTRADED or order.status == Status.PARTTRADED:
            traded_price = order.price
            
            # revert modified_order
            for modified_order_type in self.modified_orderids.keys():

                if modified_order_type == order_type or self.modified_orderids[modified_order_type] == '':
                    continue

                # calculate revert price
                if modified_order_type == 'long_open' or modified_order_type == 'short_close':
                    new_order_price = round_to(traded_price - self.grid_gap, self.pricetick)
                else:
                    new_order_price = round_to(traded_price + self.grid_gap, self.pricetick)
                
                # calculate revert volume
                new_order_volume = self.calculate_revert_volume(modified_order_type, new_order_price)

                if new_order_volume > 0:
                    self.send_new_order(modified_order_type, new_order_price, new_order_volume)
                else:
                    self.send_new_order(modified_order_type, new_order_price)
                    
                print("Reverted :", modified_order_type, new_order_price, new_order_volume)
            
                self.modified_orderids[modified_order_type] = ''

        # print(order_type)
        print(str(self.registerd_orderids))

        # start -> log file print to debug
        sorted_data = []
        for key, value in self.registerd_orderids.items():
            if len(value) > 0:
                tmp = list(self.orderid_to_order_infos[value].values())
                tmp.append(value)
                sorted_data.append(tmp)
        
        for i in range(len(sorted_data)):
            for j in range(i+1, len(sorted_data)):
                if sorted_data[i][1] < sorted_data[j][1]:
                    tmp = sorted_data[i]
                    sorted_data[i] = sorted_data[j]
                    sorted_data[j] = tmp
        order_info_str = ''
        for value in sorted_data:
            order_info_str += "\n" + str(value)
        # if len(order_info_str) > 0:
        #     self.write_log_to_file("Order data" + order_info_str)
        # <- end

    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, order_type, price, volume = -1):
        
        is_Modified = False

        # cancel previous order
        origin_vt_orderid = self.registerd_orderids[order_type]
        submitting_orderid = self.submitting_orderids[order_type]
        
        if len(submitting_orderid) > 0:
            return False

        if len(origin_vt_orderid) > 0:
            self.cancel_order(origin_vt_orderid)
            is_Modified = True

        price = round_to(price, self.pricetick)
        
        if volume < 0:
            self.calculate_trade_volume()

            if order_type == 'long_open' or order_type == 'short_open':
                volume = self.long_short_open
            else:
                volume = self.long_short_close

        volume = round_to(volume, self.min_volume)

        if price * volume == 0:
            return False

        if order_type == 'long_open':

            # if self.short_pos == 0:
            price = self.get_maker_order_price(order_type, price)

            vt_orderid = self.buy(price, volume)[-1]

        elif order_type == 'long_close':
            self.calculate_max_pos_volume()

            overflow_volume = 0

            if self.long_pos > self.max_pos_volume:
                overflow_volume = self.long_pos - self.max_pos_volume

            volume = round_to(volume + overflow_volume, self.min_volume)

            price = self.get_maker_order_price(order_type, price)

            vt_orderid = self.cover(price, volume)[-1]

        elif order_type == 'short_open':

            # if self.long_pos == 0:
            price = self.get_maker_order_price(order_type,price)

            vt_orderid = self.short(price, volume)[-1]

        elif order_type == 'short_close':
            self.calculate_max_pos_volume()

            overflow_volume = 0

            if self.short_pos > self.max_pos_volume:
                overflow_volume = self.short_pos - self.max_pos_volume
            
            volume = round_to(volume + overflow_volume, self.min_volume)

            price = self.get_maker_order_price(order_type, price)

            vt_orderid = self.sell(price, volume)[-1]

        if len(vt_orderid) > 0:
            # self.write_log_to_file("Submit new order", order_type, vt_orderid, price, volume)

            self.orderid_to_order_infos[vt_orderid] = {
                'type': order_type,
                'price': price,
                'volume': volume
            }
            self.submitting_orderids[order_type] = vt_orderid

            # print("info: ", self.orderid_to_order_infos)
            # print("submitting: ", self.submitting_orderids)

            if is_Modified == True:
                # self.write_log_to_file("Submit cancel order", order_type, origin_vt_orderid)
                self.modified_orderids[order_type] = vt_orderid

            return True
        else:
            return False
        

    """
    "   desc:   Calculate max position volume
    "   input:  price
    "   output: Set max_pos_volume
    """
    def calculate_max_pos_volume(self):
        self.target_pos = self.balance * self.lerver_rate / self.market_price
        self.max_pos_volume = self.target_pos * self.max_pos_pst


    

    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data

        if account.gateway_name == 'GATEIOS':
            self.balance = account.balance
    

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data

        if position.vt_symbol == self.vt_symbol:
            if position.direction == Direction.LONG:
                self.long_pos = position.volume

                # closed all long pos
                if self.last_long_pos > 0 and self.long_pos == 0:
                    self.write_log(f"多仓全平")

                    self.cancel_all()
                    print('Restarted because all long pos are closed.')
                    self.init()

                self.last_long_pos = self.long_pos

            elif position.direction == Direction.SHORT:
                self.short_pos = position.volume

                # closed all short pos
                if self.last_short_pos > 0 and self.short_pos == 0:
                    self.write_log(f"空仓全平")
                    
                    self.cancel_all()
                    print('Restarted because all short pos are closed.')
                    self.init()

                self.last_short_pos = self.short_pos
    
    """
    "   desc:   Write log to file
    "   Log File Path: C:/trading_logs/[day]/[hour]
    """
    def write_log_to_file(self, info, order_type = '', vt_orderid = '', price = 0, volume = 0):
        now = datetime.now()
        date_time = now.strftime("%m/%d/%Y, %H:%M:%S, %f")
        log_path = "C:\\trading_logs\\" + now.strftime("%Y-%m-%d") + "\\" + now.strftime("%H") + ".txt"
        
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path , "a") as f:
            f.write('##############\n')
            f.write("#  " +date_time + '\n')
            f.write("#  " + info + '\n')

            if len(order_type) > 0:
                f.write("#  order_type = " + order_type + ",  vt_orderid = " + vt_orderid + ",  price = " + str(price) + ",  volume = " + str(volume) + '\n')
                f.write("#  long_pos = " + str(self.long_pos) + ",  short_pos = " + str(self.short_pos) + ",  target_pos = " + str(self.target_pos) + ",  max_pos_volume = " + str(self.max_pos_volume) + '\n')
                f.write("#  long_short_open = " + str(self.long_short_open) + ",  long_short_close = " + str(self.long_short_close) + '\n')
            
            f.write('##############\n\n')