from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}
TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(D)", 1: "Earned($)", 2: "D/M/Y(%)", 3: "Trade Amount($)", 4: "Maker Rebate($)", 5: "Available($)", 6: "Max.($)", 7: "Min.($)"}

class AdvancedGridStrategy_Bitcoke_XETHUSD_4989v10(CtaTemplate):

    author = "AdvancedGridStrategy(Bitcoke Futures)_4989v10(XETHUSD)"

    # Parameters
    start_balance = 0.0                     # a start balance (funded amount at first time)
    leverage = 100                          # a leverage
    pos_num = 0.01                          # a pos num
    profit_tick = 1                         # a profit price
    kama_big_percent = 1.1                  # a big percent for kama
    kama_period = 5                         # a kama_period of moving average
    maker_fee_percent = -0.01               # a maker fee, it depends on exchange policy
    open_min_volume = 100                   # a min volume of open order
    option = 0                              # 0: default, 1: do not send open order when position is 0, 2: close all positions with market price, 3: do not send long open order, 4: do not send short open order

    # Variables
    balance = 0                             # an available balance of account
    fixed_balance = 0                       # a fixed balance (min of start_balance and current balance)
    max_balance = 0                         # a maximium value of balance when trading
    min_balance = 0                         # a minimium value of balance when trading
    rebate = 0                              # a rebate till now (for a maker)
    max_pos_volume = 0                      # a max pos volume
    base_volume = 0                         # an open volume per 1tick
    market_price = 0                        # a market price
    long_close_big_percent = 0              # a big percent for long close
    short_close_big_percent = 0             # a big percent for short close
    grid_base_pos_pst = 0                   # a grid_base_pos_pst

    # k-line
    kama_value = 0                          # a ma value of fast period
    ma_status = 0                           # 0: None, 1: Bullish, 2: Bearish

    last_traded_long_open_price = 0         # the latest traded long open price
    last_traded_short_open_price = 0        # the latest traded short open price

    last_traded_long_close_price = 0        # the latest traded long open price
    last_traded_short_close_price = 0       # the latest traded short open price

    # un/realizedPNL
    realized_pnl = {}                       # an realizedPNL of long/short position
    unrealized_pnl = {}                     # an unrealizedPNL of long/short position
    traded_open_volume = {}                 # a volume of traded long/short open

    # Statistic data
    start_time = 0                          # a start time when strategy is started
    restart_time = 0                        # a restart time
    last_runtime = 0                        # a last runtime
    total_runtime = 0                       # a total runtime
    total_volume = 0                        # a total traded volume
    current_runtime = 0                     # a current runtime
    current_traded_volume = 0               # a current traded volume

    close_all_long_pos_signal = 0           # a signal for close all long position
    close_all_short_pos_signal = 0          # a signal for close all short position

    pos_volume = {LONG: 0, SHORT: 0}        # a position volume
    last_pos_volume = {LONG: 0, SHORT: 0}   # a last position volume before closing all positoins
    entry_price = {LONG: 0, SHORT: 0}       # an entry price of position
    close_entry_price = {LONG: 0, SHORT: 0} # an entry price of position when send a close order

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['start_balance', 'leverage', 'pos_num', 'profit_tick', 'kama_big_percent', 'kama_period', 'maker_fee_percent', 'option']
    variables = ['long_close_big_percent', 'short_close_big_percent', 'grid_base_pos_pst', 'base_volume', 'max_pos_volume', 'kama_value']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # k-line
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume = contract.min_volume

        # symbol (removed '.ExchangeName')
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.main_process_thread = None
        self.restart_strategy_thread = None

        self.order_info_queue = {}
        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.last_pos_volume = {LONG: 0, SHORT: 0}

        self.realized_pnl = {LONG: 0, SHORT: 0}
        self.unrealized_pnl = {LONG: 0, SHORT: 0}
        self.traded_open_volume = {LONG: 0, SHORT: 0}

        self.restart_time = 0


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BITCOKE')

        # k-line
        self.load_bar(2)


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.init()

        self.stop_main_process = False

        # main thread
        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.main_process_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        # k-line
        self.bargenerator.update_tick(tick)

        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round((tick.ask_price_1 + tick.bid_price_1) / 2, 2)

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        am = self.arraymanager
        am.update_bar(bar)
        if not am.inited:
            return

        self.kama_value = am.kama(self.kama_period)

        self.put_event()


    """
    "   Desc: restart process
    """
    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        self.read_tradedinfo_from_file()

        if self.start_time == 0:
            self.start_time = time()

        if self.restart_time == 0:
            self.restart_time = time()

        if self.last_runtime == 0:
            self.last_runtime = self.total_runtime

        if self.min_balance == 0:
            self.min_balance = self.balance

        # main process daemon
        print_count = 0
        while self.stop_main_process == False:
            sleep(1)

            if self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            if self.balance > self.max_balance:
                self.max_balance = self.balance

            if self.balance < self.min_balance:
                self.min_balance = self.balance

            if print_count == 333 or print_count == 0:
                print(f'==')
                print(f'|{TRADED_INFO_TITLE[0]: >15}{TRADED_INFO_TITLE[1]: >24}{TRADED_INFO_TITLE[2]: >24}{TRADED_INFO_TITLE[3]: >24}{TRADED_INFO_TITLE[4]: >24}{TRADED_INFO_TITLE[5]: >16}{TRADED_INFO_TITLE[6]: >16}{TRADED_INFO_TITLE[7]: >16} |')
                print(f'------------------------------------------------------------------------------------------------------------------------------------------------------------------')
                runtime_days = round(self.total_runtime / 1440, 2)
                profit = round(self.balance - self.start_balance, 2)
                profit_percent = f'{round((profit / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (self.start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0
                total_volume = self.total_volume
                rebate = f'{round(self.rebate, 2)}'
                available = f'{round(self.balance, 2)}'
                max_balance = round(self.max_balance, 2)
                min_balance = round(self.min_balance, 2)
                print(f'|{runtime_days: >14}{profit: >24}{profit_percent: >24}{total_volume: >24}{rebate: >24}{available: >16}{max_balance: >16}{min_balance: >16}  |')
                print(f'==')
                print_count = 1
            print_count += 1

            self.current_runtime = round((time() - self.start_time) / 60)
            self.total_runtime = self.last_runtime + self.current_runtime

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)
                    elif self.order_info_queue[open_orderid]['status'] == SUBMITTING:
                        print('==')
                        print('| Restarting...')
                        print('==')
                        self.restart_strategy_thread = Thread(target = self.restart_strategy)
                        self.restart_strategy_thread.setDaemon(True)
                        self.restart_strategy_thread.start()

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)
                        elif self.order_info_queue[close_orderid]['status'] == SUBMITTING:
                            print('==')
                            print('| Restarting...')
                            print('==')
                            self.restart_strategy_thread = Thread(target = self.restart_strategy)
                            self.restart_strategy_thread.setDaemon(True)
                            self.restart_strategy_thread.start()

        sleep(2)

        # cancel all long/short open/close orders
        for direction in (LONG, SHORT):
            open_orderid = self.registered_order_info[direction][OPEN]
            if open_orderid != '':
                if open_orderid in self.order_info_queue and (self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED):
                    self.cancel_order(open_orderid)

            close_orderid = self.registered_order_info[direction][CLOSE]
            if close_orderid != '':
                if close_orderid in self.order_info_queue and (self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED):
                    self.cancel_order(close_orderid)

        self.write_tradedinfo_to_file()

        sleep(2)

        self.stop_main_process = False


    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1):
        if self.stop_main_process == True:
            return

        self.calc_max_pos_and_init_volume()

        new_price = self.get_order_price(direction, offset)
        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get previous vt_orderid
        previous_vt_orderid = self.registered_order_info[direction][offset]
        if previous_vt_orderid != '':
            if previous_vt_orderid not in self.order_info_queue or self.order_info_queue[previous_vt_orderid]['status'] == REJECTED:
                return
            elif self.order_info_queue[previous_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[previous_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(previous_vt_orderid)

            self.registered_order_info[direction][offset] = ''
            del self.order_info_queue[previous_vt_orderid]

        if new_price == 0:
            return

        # calculate the new volume
        if offset == OPEN:
            if self.option == 2:
                return

            new_volume = self.base_volume
            if direction == LONG:
                if self.last_traded_long_open_price:
                    kama_big_percent = self.kama_big_percent if self.ma_status == 1 else 1
                    new_volume = kama_big_percent * self.base_volume * abs(self.last_traded_long_open_price - new_price) / self.pricetick
            elif direction == SHORT:
                if self.last_traded_short_open_price:
                    kama_big_percent = self.kama_big_percent if self.ma_status == 2 else 1
                    new_volume = kama_big_percent * self.base_volume * abs(new_price - self.last_traded_short_open_price) / self.pricetick
        elif offset == CLOSE:
            new_volume = 0
            if direction == LONG:
                if self.pos_volume[SHORT] > 0:
                    self.close_all_short_pos_signal = 0
                    self.close_entry_price[SHORT] = self.entry_price[SHORT]
                    if self.option == 2:
                        new_volume = self.pos_volume[SHORT]
                    else:
                        if self.pos_volume[SHORT] < self.pos_volume[LONG]:
                            return
                        else:
                            if self.last_traded_long_close_price:
                                new_volume = round_to((self.last_traded_long_close_price - new_price) * self.long_close_big_percent * self.base_volume / self.pricetick, self.min_volume)
                            else:
                                new_volume = round_to(self.long_close_big_percent * self.base_volume, self.min_volume)

                        if new_volume > self.pos_volume[SHORT]:
                            self.close_all_short_pos_signal = 1
                            new_volume = self.pos_volume[SHORT]
            elif direction == SHORT:
                if self.pos_volume[LONG] > 0:
                    self.close_all_long_pos_signal = 0
                    self.close_entry_price[LONG] = self.entry_price[LONG]
                    if self.option == 2:
                        new_volume = self.pos_volume[LONG]
                    else:
                        if self.pos_volume[LONG] < self.pos_volume[SHORT]:
                            return
                        else:
                            if self.last_traded_short_close_price:
                                new_volume = round_to((new_price - self.last_traded_short_close_price) * self.short_close_big_percent * self.base_volume / self.pricetick, self.min_volume)
                            else:
                                new_volume = round_to(self.short_close_big_percent * self.base_volume, self.min_volume)

                        if new_volume > self.pos_volume[LONG]:
                            self.close_all_long_pos_signal = 1
                            new_volume = self.pos_volume[LONG]

        if new_volume < self.open_min_volume:
            return

        new_volume = round_to(new_volume, self.min_volume)

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return
        else:
            return


    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        self.unrealized_pnl[LONG] = (tick.bid_price_1 / self.entry_price[LONG] - 1) * self.pos_volume[LONG] if self.pos_volume[LONG] > 0 else 0
        self.unrealized_pnl[SHORT] = (1 - tick.ask_price_1 / self.entry_price[SHORT]) * self.pos_volume[SHORT] if self.pos_volume[SHORT] > 0 else 0

        if self.market_price > self.kama_value:
            self.ma_status = 1
        elif self.market_price < self.kama_value:
            self.ma_status = 2

        if direction == LONG:
            price = tick.bid_price_1
            if offset == OPEN:
                if self.pos_volume[LONG] > self.max_pos_volume:
                    return 0
            elif offset == CLOSE:
                if self.option == 2:
                    pass
                else:
                    if self.last_traded_short_open_price and price > self.last_traded_short_open_price - self.profit_tick * self.pricetick:
                        price = self.last_traded_short_open_price - self.profit_tick * self.pricetick
        elif direction == SHORT:
            price = tick.ask_price_1
            if offset == OPEN:
                if self.pos_volume[SHORT] > self.max_pos_volume:
                    return 0
            elif offset == CLOSE:
                if self.option == 2:
                    pass
                else:
                    if self.last_traded_long_open_price and price < self.last_traded_long_open_price + self.profit_tick * self.pricetick:
                        price = self.last_traded_long_open_price + self.profit_tick * self.pricetick

        price = round_to(price, self.pricetick)

        return price


    """
    "   Desc: Calculate max_pos_volume
    """
    def calc_max_pos_and_init_volume(self):
        self.grid_base_pos_pst = self.pricetick / self.market_price
        self.fixed_balance = round(min(self.start_balance, self.balance), 2)
        self.max_pos_volume = round_to(self.fixed_balance * self.leverage, self.min_volume)
        self.base_volume = round_to(max(self.grid_base_pos_pst * self.max_pos_volume, self.open_min_volume), self.min_volume)
        maker_fee_price = 2 * self.market_price * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
        self.long_close_big_percent = 1 + (self.pos_volume[SHORT] / (self.max_pos_volume * self.pos_num))
        self.short_close_big_percent = 1 + (self.pos_volume[LONG] / (self.max_pos_volume * self.pos_num))


    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BITCOKE':
            if account.accountid == 'USDT':
                if 'USD' in self.symbol:
                    self.balance = account.available


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.realized_pnl[LONG] = 0
                    self.unrealized_pnl[LONG] = 0
                    self.traded_open_volume[LONG] = 0
                    self.last_traded_long_open_price = 0
                    self.last_traded_short_close_price = 0
                    if (time() - self.restart_time) > 24 * 60 * 60:
                        print('==')
                        print('| Restarting...')
                        print('==')
                        self.restart_strategy_thread = Thread(target = self.restart_strategy)
                        self.restart_strategy_thread.setDaemon(True)
                        self.restart_strategy_thread.start()

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.realized_pnl[SHORT] = 0
                    self.unrealized_pnl[SHORT] = 0
                    self.traded_open_volume[SHORT] = 0
                    self.last_traded_short_open_price = 0
                    self.last_traded_long_close_price = 0
                    if (time() - self.restart_time) > 24 * 60 * 60:
                        print('==')
                        print('| Restarting...')
                        print('==')
                        self.restart_strategy_thread = Thread(target = self.restart_strategy)
                        self.restart_strategy_thread.setDaemon(True)
                        self.restart_strategy_thread.start()

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price


    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.current_traded_volume += order.volume
                self.total_volume += order.volume

                if order.type == OrderType.LIMIT:
                    direction = self.order_info_queue[vt_orderid]['direction']
                    offset = self.order_info_queue[vt_orderid]['offset']
                    direction_offset = self.get_order_direction_offset_str(direction, offset)

                    self.traded_summary['maker'] += 1
                    self.rebate -= order.volume * self.maker_fee_percent / 100

                    if direction == LONG:
                        if offset == OPEN:
                            self.last_traded_long_open_price = order.price
                            self.last_traded_short_close_price = 0
                            self.last_traded_short_open_price = 0

                            # calc long_pnl
                            self.traded_open_volume[LONG] += order.volume
                            if self.maker_fee_percent > 0:
                                self.realized_pnl[LONG] -= order.volume * self.maker_fee_percent / 100
                        elif offset == CLOSE:
                            self.last_traded_long_close_price = order.price
                            self.last_traded_short_open_price = 0
                            self.last_traded_short_close_price = 0

                            # calc short_pnl
                            if self.maker_fee_percent > 0:
                                self.realized_pnl[SHORT] -= order.volume * self.maker_fee_percent / 100

                            if self.close_all_short_pos_signal == 0:
                                loss_amount = (1 - order.price / self.entry_price[SHORT]) * order.volume
                                self.realized_pnl[SHORT] += loss_amount
                    elif direction == SHORT:
                        if offset == OPEN:
                            self.last_traded_short_open_price = order.price
                            self.last_traded_long_close_price = 0
                            self.last_traded_long_open_price = 0

                            # calc short_pnl
                            self.traded_open_volume[SHORT] += order.volume
                            if self.maker_fee_percent > 0:
                                self.realized_pnl[SHORT] -= order.volume * self.maker_fee_percent / 100
                        elif offset == CLOSE:
                            self.last_traded_short_close_price = order.price
                            self.last_traded_long_open_price = 0
                            self.last_traded_long_close_price = 0

                            # calc long_pnl
                            if self.maker_fee_percent > 0:
                                self.realized_pnl[LONG] -= order.volume * self.maker_fee_percent / 100

                            if self.close_all_long_pos_signal == 0:
                                loss_amount = (order.price / self.entry_price[LONG] - 1) * order.volume
                                self.realized_pnl[LONG] += loss_amount

                # current date and time
                now = datetime.now()
                date_time = now.strftime("%Y-%m-%d %H:%M")

                if order.type == OrderType.LIMIT:
                    if direction == LONG:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >7}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >10}{round(self.entry_price[LONG], 2): >12}{order.price: >12}{order.volume: >10}{round(self.traded_open_volume[LONG], 2): >15}/{round(self.realized_pnl[LONG], 3): <10}{round(self.unrealized_pnl[LONG], 3): <10}{round(self.traded_open_volume[SHORT], 2): >12}/{round(self.realized_pnl[SHORT], 3): <10}{round(self.unrealized_pnl[SHORT], 3): <10}{self.current_runtime: >9}{round(self.current_traded_volume, 2): >16}{date_time: >24}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >7}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >10}{round(self.entry_price[SHORT], 2): >12}{order.price: >12}{order.volume: >10}{round(self.traded_open_volume[LONG], 2): >15}/{round(self.realized_pnl[LONG], 3): <10}{round(self.unrealized_pnl[LONG], 3): <10}{round(self.traded_open_volume[SHORT], 2): >12}/{round(self.realized_pnl[SHORT], 3): <10}{round(self.unrealized_pnl[SHORT], 3): <10}{self.current_runtime: >9}{round(self.current_traded_volume, 2): >16}{date_time: >24}')
                    elif direction == SHORT:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >7}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >10}{round(self.entry_price[SHORT], 2): >12}{order.price: >12}{order.volume: >10}{round(self.traded_open_volume[LONG], 2): >15}/{round(self.realized_pnl[LONG], 3): <10}{round(self.unrealized_pnl[LONG], 3): <10}{round(self.traded_open_volume[SHORT], 2): >12}/{round(self.realized_pnl[SHORT], 3): <10}{round(self.unrealized_pnl[SHORT], 3): <10}{self.current_runtime: >9}{round(self.current_traded_volume, 2): >16}{date_time: >24}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >7}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >10}{round(self.entry_price[LONG], 2): >12}{order.price: >12}{order.volume: >10}{round(self.traded_open_volume[LONG], 2): >15}/{round(self.realized_pnl[LONG], 3): <10}{round(self.unrealized_pnl[LONG], 3): <10}{round(self.traded_open_volume[SHORT], 2): >12}/{round(self.realized_pnl[SHORT], 3): <10}{round(self.unrealized_pnl[SHORT], 3): <10}{self.current_runtime: >9}{round(self.current_traded_volume, 2): >16}{date_time: >24}')
            except:
                pass
        elif order.status == CANCELLED:
            self.traded_summary['cancelled'] += 1
        elif order.status == REJECTED:
            self.traded_summary['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")


    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   Desc: Write a traded info to a log file
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\bitcoke\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{self.total_runtime}, {self.total_volume}, {self.rebate}, {self.realized_pnl[LONG]}, {self.realized_pnl[SHORT]}, {self.traded_open_volume[LONG]}, {self.traded_open_volume[SHORT]}, {self.max_balance}, {self.min_balance}'
            f.write(traded_info)


    """
    "   Desc: Read a traded info from a log file
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\bitcoke\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.total_runtime = 0
                self.total_volume = 0
                self.rebate = 0
                self.realized_pnl[LONG] = 0
                self.realized_pnl[SHORT] = 0
                self.traded_open_volume[LONG] = 0
                self.traded_open_volume[SHORT] = 0
                self.max_balance = 0
                self.min_balance = 0
            else:
                self.total_runtime = float(data.split(', ')[0].strip())
                self.total_volume = float(data.split(', ')[1].strip())
                self.rebate = float(data.split(', ')[2].strip())
                self.realized_pnl[LONG] = float(data.split(', ')[3].strip())
                self.realized_pnl[SHORT] = float(data.split(', ')[4].strip())
                self.traded_open_volume[LONG] = float(data.split(', ')[5].strip())
                self.traded_open_volume[SHORT] = float(data.split(', ')[6].strip())
                self.max_balance = float(data.split(', ')[7].strip())
                self.min_balance = float(data.split(', ')[8].strip())
