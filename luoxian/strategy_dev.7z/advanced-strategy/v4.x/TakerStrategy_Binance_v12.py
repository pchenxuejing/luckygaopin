from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType, Interval
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}

class TakerStrategy_Binance_v12(CtaTemplate):

    author = "TakerStrategy (Binance) v1.2"

    # Parameters
    open_volume = 0.1                   # open volume
    profit_price = 5                    # profit price
    fast_period = 2                     # a fast_period of moving average
    slow_period = 3                     # a slow_period of moving average
    taker_fee_rate = 0.0004             # it depends on exchange policy (for a taker)
    option = 0                          # 1: cover, 2: sell, 3: buy, 4: short

    # Variables
    balance = 0                         # account balance
    balance_before_taker = 0            # a balanace before taker order
    taker_profit = 0                    # a taker profit (= current balance - taker balance)
    open_price = 0                      # open price
    close_price = 0                     # close price
    commission = 0                      # commission till now (for a taker)
    fast_ma0 = 0                        # last ma value of fast period
    fast_ma1 = 0                        # previous ma value of fast period
    slow_ma0 = 0                        # last ma value of slow period
    slow_ma1 = 0                        # previous ma value of slow period
    ma_status = 0                       # 0: None, 1: Bullish, 2: Bearish
    cross_over = False                  # cross over (it means bullish)
    cross_below = False                 # cross below (it means bearish)
    taker_fee_price = 0                 # a taker fee price of unit volume (it depends on exchange policy)

    # Statistic data
    start_time = 0                      # start time when strategy is started
    last_runtime = 0                    # last runtime
    start_balance = 0                   # start balance (funded amount at first time)
    total_runtime = 0                   # total runtime
    total_volume = 0                    # total traded volume
    total_amount = 0                    # total traded amount
    current_runtime = 0                 # current runtime
    current_traded_volume = 0           # current traded volume
    current_traded_amount = 0           # current traded amount
    pnl = 0                             # pnl

    profit_taker_order_processed = 0    # for calculating a profit
    loss_taker_order_processed = 0      # for calculating a loss

    pos_volume = {LONG: 0, SHORT: 0}    # position volume
    entry_price = {LONG: 0, SHORT: 0}   # entry price of position

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['open_volume', 'profit_price', 'fast_period', 'slow_period', 'taker_fee_rate', 'option']
    variables = ['balance', 'pnl', 'taker_profit', 'ma_status']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # ma
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.main_process_thread = None


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')
        # ma
        self.load_bar(2)


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
         # ma
        self.bargenerator.update_tick(tick)

        self.last_last_tick = self.last_tick
        self.last_tick = tick
        self.close_price = tick.last_price

        if self.is_valid_tick(tick) == False:
            pass

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        am = self.arraymanager
        am.update_bar(bar)
        if not am.inited:
            return

        self.open_price = am.close[-1]

        fast_ma = am.ema(self.fast_period, array=True)
        self.fast_ma0 = fast_ma[-1]
        self.fast_ma1 = fast_ma[-2]

        slow_ma = am.ema(self.slow_period, array=True)
        self.slow_ma0 = slow_ma[-1]
        self.slow_ma1 = slow_ma[-2]

        if self.fast_ma0 > self.slow_ma0:
            self.ma_status = 1
        elif self.fast_ma0 < self.slow_ma0:
            self.ma_status = 2
        else:
            self.ma_status = 0

        self.cross_over = self.fast_ma0 > self.slow_ma0 and self.fast_ma1 < self.slow_ma1
        self.cross_below = self.fast_ma0 < self.slow_ma0 and self.fast_ma1 > self.slow_ma1

        balance_before_taker = self.balance

        if self.option == 0:
            # 1: long, 2: short
            loss_taker_order = 0
            if self.pos_volume[LONG] > 0 and self.pos_volume[SHORT] > 0:
                if self.close_price > self.entry_price[LONG]:
                    loss_taker_order = 2
                    if self.close_price < self.entry_price[SHORT]:
                        loss_taker_order = 0
                else:
                    loss_taker_order = 1
                    if self.close_price > self.entry_price[SHORT]:
                        if self.cross_over:
                            loss_taker_order = 2

            if self.cross_over:
                if self.pos_volume[LONG] == 0:
                    self.buy(0, self.open_volume)

                if self.pos_volume[SHORT] == 0:
                    self.short(0, self.open_volume)
                else:
                    if self.close_price < self.entry_price[SHORT] - self.profit_price:
                        self.cover(0, self.open_volume)
                        self.short(0, self.open_volume)
                        self.balance_before_taker = balance_before_taker
                        self.profit_taker_order_processed = 1
                    elif (self.close_price - self.entry_price[SHORT]) > 2 * self.profit_price:
                        if self.taker_profit > 0 and loss_taker_order == 2:
                            predict_loss = self.open_volume * ((self.close_price - self.entry_price[SHORT]) / 2 + self.taker_fee_price)
                            if self.taker_profit > predict_loss:
                                self.short(0, self.open_volume)
                                self.cover(0, self.open_volume)
                                self.balance_before_taker = balance_before_taker
                                self.loss_taker_order_processed = 1
            elif self.cross_below:
                if self.pos_volume[SHORT] == 0:
                    self.short(0, self.open_volume)

                if self.pos_volume[LONG] == 0:
                     self.buy(0, self.open_volume)
                else:
                    if self.close_price > self.entry_price[LONG] + self.profit_price:
                        self.sell(0, self.open_volume)
                        self.buy(0, self.open_volume)
                        self.balance_before_taker = balance_before_taker
                        self.profit_taker_order_processed = 1
                    elif (self.entry_price[LONG] - self.close_price) > 2 * self.profit_price:
                        if self.taker_profit > 0 and loss_taker_order == 1:
                            predict_loss = self.open_volume * ((self.entry_price[LONG] - self.close_price) / 2 + self.taker_fee_price)
                            if self.taker_profit > predict_loss:
                                self.buy(0, self.open_volume)
                                self.sell(0, self.open_volume)
                                self.balance_before_taker = balance_before_taker
                                self.loss_taker_order_processed = 1

        self.put_event()


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        self.read_tradedinfo_from_file()

        if self.start_time == 0:
            self.start_time = time()

        if self.last_runtime == 0:
            self.last_runtime = self.total_runtime

        # main process daemon
        count = 0
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            self.current_runtime = round((time() - self.start_time) / 60)
            self.total_runtime = self.last_runtime + self.current_runtime
            self.pnl = self.balance - self.start_balance

            if self.profit_taker_order_processed == 1:
                if count > 1:
                    self.taker_profit += (self.balance - self.balance_before_taker) / 2
                    self.profit_taker_order_processed = 0
                    count = 0
                else:
                    count += 1

            if self.loss_taker_order_processed == 1:
                if count > 1:
                    self.taker_profit += self.balance - self.balance_before_taker
                    self.loss_taker_order_processed = 0
                    count = 0
                else:
                    count += 1

            if self.option == 1:
                self.cover(0, self.pos_volume[SHORT])
            elif self.option == 2:
                self.sell(0, self.pos_volume[LONG])
            elif self.option == 3:
                self.buy(0, self.open_volume)
            elif self.option == 4:
                self.short(0, self.open_volume)

            self.calc_taker_fee_price()
            self.write_tradedinfo_to_file()

        self.stop_main_process = False


    """
    "   Desc: Calc a taker fee price per unit volume according to several price range
    """
    def calc_taker_fee_price(self):
        if self.taker_fee_rate > 0:
            if self.close_price <= 1000:
                self.taker_fee_price = round_to(2 * 1000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 2000:
                self.taker_fee_price = round_to(2 * 2000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 3000:
                self.taker_fee_price = round_to(2 * 3000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 4000:
                self.taker_fee_price = round_to(2 * 4000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 5000:
                self.taker_fee_price = round_to(2 * 5000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 6000:
                self.taker_fee_price = round_to(2 * 6000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 7000:
                self.taker_fee_price = round_to(2 * 7000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 8000:
                self.taker_fee_price = round_to(2 * 8000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 9000:
                self.taker_fee_price = round_to(2 * 9000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 10000:
                self.taker_fee_price = round_to(2 * 10000 * self.taker_fee_rate, self.pricetick)
            else:
                self.taker_fee_price = round_to(2 * self.close_price * self.taker_fee_rate, self.pricetick)


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            if account.accountid in self.symbol:
                self.balance = account.balance
                if self.start_balance == 0:
                    self.start_balance = self.balance


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)

            self.entry_price[direction] = position.price


    """
    "   Desc: Callback function for order traded
    """
    def on_trade(self, trade: TradeData):
        """
        Callback of new trade data update.
        """
        self.current_traded_volume += round(trade.volume, 3)
        self.total_volume += round(trade.volume, 3)

        self.current_traded_amount += trade.price * trade.volume
        self.total_amount += trade.price * trade.volume

        self.traded_summary['taker'] += 1
        self.commission += trade.price * trade.volume * self.taker_fee_rate

        # current date and time
        now = datetime.now()
        date_time = now.strftime("%Y-%m-%d %H:%M:%S")

        if trade.direction == LONG:
            print(f'{"BINANCE": >9}{self.traded_summary["taker"]: >7}{PRICE_TRENDING[self.ma_status]: >6}{trade.direction: >18}{round(self.entry_price[LONG], 3): >12}{round(self.entry_price[SHORT], 3): >12}{round(trade.price, 3): >12}{trade.volume: >7}{self.current_runtime: >9}{round(self.current_traded_volume, 3): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')
        else:
            print(f'{"BINANCE": >9}{self.traded_summary["taker"]: >7}{PRICE_TRENDING[self.ma_status]: >6}{trade.direction: >18}{round(self.entry_price[LONG], 3): >12}{round(self.entry_price[SHORT], 3): >12}{round(trade.price, 3): >12}{trade.volume: >7}{self.current_runtime: >9}{round(self.current_traded_volume, 3): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')

        self.put_event()


    """
    "   Desc: Write a traded info to a log file
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\root\\strategies\\log_taker_binance.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{self.start_balance}, {self.taker_profit}, {self.total_runtime}, {self.total_volume}, {round(self.total_amount, 3)}, {round(self.commission, 3)}'
            f.write(traded_info)


    """
    "   Desc: Read a traded info from a log file
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\root\\strategies\\log_taker_binance.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.start_balance = 0
                self.taker_profit = 0
                self.total_runtime = 0
                self.total_volume = 0
                self.total_amount = 0
                self.commission = 0
            else:
                self.start_balance = float(data.split(', ')[0].strip())
                self.taker_profit = float(data.split(', ')[1].strip())
                self.total_runtime = float(data.split(', ')[2].strip())
                self.total_volume = float(data.split(', ')[3].strip())
                self.total_amount = float(data.split(', ')[4].strip())
                self.commission = float(data.split(', ')[5].strip())
