from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

OPPOSITE_DIRECTION: Dict[Direction, Direction] = {LONG: SHORT, SHORT: LONG}
OPPOSITE_OFFSET: Dict[Offset, Offset] = {OPEN: CLOSE, CLOSE: OPEN}

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}
TRADED_INFO_TITLE: Dict[int, str] = {0: "Start(USD)", 1: "Current(USD)", 2: "RunTime(Min)", 3: "Volume(ETH)", 4: "Amount(USD)", 5: "Rebate(USD)", 6: "Commission(USD)"}

class AdvancedGridStrategy_Binances_v42_ETHBUSD(CtaTemplate):

    author = "AdvancedGridStrategy(Binance) v4.2"

    # Parameters
    leverage = 10                       # leverage
    open_volume_rate = 1.0              # open volume rate when calculating a open_init_volume, its max value should be 1.0, if its value is 0.0, then close all current positions with ask1/bid1 price
    grid_gap = 50                       # grid gap (pricetick)
    profit_tick = 50                    # profit pricetick count
    ma_cat = 1                          # 0: sma, 1: ema, 2: wma, 3: kama
    period = 3                          # a period of moving average
    maker_fee_rate = 0.00012            # it depends on exchange policy (for a maker)
    max_close_volume = 100              # it depends on exchange policy
    open_order_min_price = 6.0          # it depends on exchange policy
    option = 0                          # 0: default, 1: only sending a close order, 2: only close all positions with ask1/bid1 price

    # Vairables
    balance = 0                         # account balance
    max_balance = 0                     # maximium value of balance when trading
    pnl = 0                             # PNL
    profit = 0                          # profit till now
    long_pnl = 0                        # pnl for a long position
    short_pnl = 0                       # pnl for a short position
    rebate = 0                          # rebate till now (for a maker)
    commission = 0                      # commission till now (for a taker)
    max_pos_volume = 0                  # max pos volume
    open_init_volume = 0                # opne init volume
    open_min_volume = 0                 # calculated by open_order_min_price (depends on exchange policy)

    long_profit_count = 0               # long profit calc count
    short_profit_count = 0              # short profit calc count

    traded_long_open_order_dict = {}    # dict for traded long_open price and volume
    traded_short_open_order_dict = {}   # dict for traded short_open price and volume

    open_price = 0                      # an open price for a current candlestick
    close_price = 0                     # a close price for a current candlestick
    maker_fee_price = 0                 # maker fee price for a unit volume (1)
    taker_fee_price = 0                 # taker fee price for a unit volume (1)

    taker_fee_rate = 0.0003             # it depends on exchange policy (for a taker)
    taker_long_order_volume = 0         # long order volume for a taker
    taker_short_order_volume = 0        # short order volume for a taker

    ma = 0                              # a slow ma value (kama, sma, ema, wma)
    ma_status = 0                       # 0: None, 1: Bullish, 2: Bearish

    # Statistic data
    start_time = 0                      # start time
    prev_runtime = 0                    # recorded total runtime
    start_balance = 0                   # start balance (funded amount at first time)
    total_runtime = 0                   # total runtime
    total_volume = 0                    # total traded volume
    total_amount = 0                    # total traded amount
    current_runtime = 0                 # current runtime
    current_traded_volume = 0           # current traded volume
    current_traded_amount = 0           # current traded amount

    pos_volume = {LONG: 0, SHORT: 0}
    entry_price = {LONG: 0, SHORT: 0}
    last_pos_volume = {LONG: 0, SHORT: 0}
    last_open_traded_price = {LONG: 0, SHORT: 0}

    summary_count = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['leverage', 'open_volume_rate', 'grid_gap', 'profit_tick', 'ma_cat', 'period', 'maker_fee_rate', 'max_close_volume', 'open_order_min_price', 'option']
    variables = ['balance', 'max_balance', 'pnl', 'profit', 'max_pos_volume', 'open_init_volume', 'open_min_volume']

    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # ma
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.main_process_thread = None

        self.last_pos_volume[LONG] = 0
        self.last_pos_volume[SHORT] = 0

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }
        self.order_info_queue = {}

        self.read_tradedinfo_from_file()

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')
        # ma
        self.load_bar(2)

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

        self.put_event()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
         # ma
        self.bargenerator.update_tick(tick)

        self.last_last_tick = self.last_tick
        self.last_tick = tick
        self.close_price = tick.last_price

        if self.is_valid_tick(tick) == False:
            pass

        self.put_event()

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        am = self.arraymanager
        am.update_bar(bar)
        if not am.inited:
            return

        self.open_price = am.close[-1]

        if self.ma_cat == 0:
            ma_value = am.sma(self.period, array=True)
            self.ma = ma_value[-1]
        elif self.ma_cat == 1:
            ma_value = am.ema(self.period, array=True)
            self.ma = ma_value[-1]
        elif self.ma_cat == 2:
            ma_value = am.wma(self.period, array=True)
            self.ma = ma_value[-1]
        else:
            ma_value = am.kama(self.period, array=True)
            self.ma = ma_value[-1]

        self.put_event()

    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        if self.start_time == 0:
            self.start_time = time()

        if self.prev_runtime == 0:
            self.prev_runtime = self.total_runtime

        print_count = 0
        # main process daemon
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            if print_count == 300 or print_count == 0:
                print(f'{TRADED_INFO_TITLE[0]: >21}{TRADED_INFO_TITLE[1]: >21}{TRADED_INFO_TITLE[2]: >21}{TRADED_INFO_TITLE[3]: >21}{TRADED_INFO_TITLE[4]: >24}{TRADED_INFO_TITLE[5]: >21}{TRADED_INFO_TITLE[6]: >21}')
                print(f'{round_to(self.start_balance, self.min_volume): >21}{round_to(self.balance, self.min_volume): >21}{self.total_runtime: >21}{round_to(self.total_volume, self.min_volume): >21}{round_to(self.total_amount, self.min_volume): >24}{round_to(self.rebate, self.min_volume): >21}{round_to(self.commission, self.min_volume): >21}')
                print_count = 1
            print_count += 1

            self.current_runtime = round_to((time() - self.start_time) / 60, 1)
            self.total_runtime = self.prev_runtime + self.current_runtime

            if self.pos_volume[LONG] > 0:
                self.long_pnl = (self.close_price - self.entry_price[LONG]) * self.pos_volume[LONG]

            if self.pos_volume[SHORT] > 0:
                self.short_pnl = (self.entry_price[SHORT] - self.close_price) * self.pos_volume[SHORT]

            self.pnl = self.long_pnl + self.short_pnl
            self.profit = self.balance - self.max_balance

            self.calc_maker_fee_price()

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)

        sleep(2)

        # cancel all orders when strategy has been stopped
        long_open_cancel_orderid = self.registered_order_info[LONG][OPEN]
        if long_open_cancel_orderid != '':
            if long_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_open_cancel_orderid)

        short_open_cancel_orderid = self.registered_order_info[SHORT][OPEN]
        if short_open_cancel_orderid != '':
            if short_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_open_cancel_orderid)

        long_close_cancel_orderid = self.registered_order_info[LONG][CLOSE]
        if long_close_cancel_orderid != '':
            if long_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_close_cancel_orderid)

        short_close_cancel_orderid = self.registered_order_info[SHORT][CLOSE]
        if short_close_cancel_orderid != '':
            if short_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_close_cancel_orderid)

        sleep(2)

        self.stop_main_process = False

    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1):
        if offset == OPEN:
            self.calc_max_pos_and_init_volume(direction, offset)

        new_price = self.get_order_price(direction, offset)
        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        if new_price == 0:
            return

        # calculate the new volume
        if offset == OPEN:
            new_volume = self.open_init_volume
            if direction == LONG:
                if self.pos_volume[LONG] > 0:
                    if self.pos_volume[LONG] > self.max_pos_volume:
                        return
                    else:
                        if new_price > self.entry_price[LONG]:
                            new_volume = self.open_min_volume
                        else:
                            if self.last_open_traded_price[LONG] > 0:
                                new_volume = self.open_init_volume * (self.last_open_traded_price[LONG] - new_price)

                        if new_volume + self.pos_volume[LONG] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[LONG]
            elif direction == SHORT:
                if self.pos_volume[SHORT] > 0:
                    if self.pos_volume[SHORT] > self.max_pos_volume:
                        return
                    else:
                        if new_price < self.entry_price[SHORT]:
                            new_volume = self.open_min_volume
                        else:
                            if self.last_open_traded_price[SHORT] > 0:
                                new_volume = self.open_init_volume * (new_price - self.last_open_traded_price[SHORT])

                        if new_volume + self.pos_volume[SHORT] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[SHORT]

            if new_volume < self.open_min_volume:
                new_volume = self.open_min_volume
        elif offset == CLOSE:
            if direction == LONG:
                if self.option == 2:
                    new_volume = self.pos_volume[SHORT]
                else:
                    if self.pos_volume[SHORT] > 0:
                        new_volume = self.get_close_volume_from_dict(LONG, new_price)
                        if self.short_pnl + self.profit > self.maker_fee_price * self.pos_volume[SHORT] / 2:
                            if new_price < self.entry_price[SHORT] - self.maker_fee_price:
                                new_volume = self.pos_volume[SHORT]
                    else:
                        return
            elif direction == SHORT:
                if self.option == 2:
                    new_volume = self.pos_volume[LONG]
                else:
                    if self.pos_volume[LONG] > 0:
                        new_volume = self.get_close_volume_from_dict(SHORT, new_price)
                        if self.long_pnl + self.profit > self.maker_fee_price * self.pos_volume[LONG] / 2:
                            if new_price > self.entry_price[LONG] + self.maker_fee_price:
                                new_volume = self.pos_volume[LONG]
                    else:
                        return

            if new_volume <= 0 or new_volume <= 0.0:
                return
            elif new_volume > self.max_close_volume:
                new_volume = self.max_close_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        if offset == CLOSE and new_volume == 0.0:
            return

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False

    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        if self.close_price > self.ma:
            self.ma_status = 1
        elif self.close_price < self.ma:
            self.ma_status = 2
        else:
            self.ma_status = 0

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        # send only close order
        if self.option == 1:
            if offset == OPEN:
                return 0
        # close current all positions with ask1/bid1 price
        elif self.option == 2:
            if direction == LONG:
                if offset == OPEN:
                    return 0
                else:
                    return tick.bid_price_1 + ask1_bid1_pricetick
            else:
                if offset == OPEN:
                    return 0
                else:
                    return tick.ask_price_1 - ask1_bid1_pricetick

        if direction == LONG:
            price = tick.bid_price_1 + ask1_bid1_pricetick
            if offset == OPEN:
                if self.last_open_traded_price[LONG] > 0:
                    if (self.last_open_traded_price[LONG] - price) < self.grid_gap * self.pricetick:
                        return 0
            elif offset == CLOSE:
                if self.ma_status == 2:
                    if price > self.entry_price[SHORT]:
                        return 0

                if self.short_pnl + self.profit > self.maker_fee_price * self.pos_volume[SHORT] / 2:
                    return price

                if len(self.traded_short_open_order_dict) == 0:
                    returnValue = self.read_dict_from_file(SHORT)
                    if returnValue == False:
                        self.traded_short_open_order_dict[self.entry_price[SHORT] - self.maker_fee_price - self.profit_tick * self.pricetick] = round_to(self.pos_volume[SHORT], self.min_volume)
                elif len(self.traded_short_open_order_dict) == 1:
                    last_volume = self.traded_short_open_order_dict[min(self.traded_short_open_order_dict.keys())]
                    if self.pos_volume[SHORT] > last_volume:
                        self.traded_short_open_order_dict[self.entry_price[SHORT] - self.maker_fee_price - self.profit_tick * self.pricetick] = round_to(self.pos_volume[SHORT] - last_volume, self.min_volume)
                    elif self.pos_volume[SHORT] < last_volume:
                        self.traded_short_open_order_dict[min(self.traded_short_open_order_dict.keys())] = self.pos_volume[SHORT]

                if len(self.traded_short_open_order_dict) > 0:
                    max_price = max(self.traded_short_open_order_dict.keys())
                    if price > max_price:
                        price = max_price
                else:
                    return 0
        elif direction == SHORT:
            price = tick.ask_price_1 - ask1_bid1_pricetick
            if offset == OPEN:
                if self.last_open_traded_price[SHORT] > 0:
                    if (price - self.last_open_traded_price[SHORT]) < self.grid_gap * self.pricetick:
                        return 0
            elif offset == CLOSE:
                if self.ma_status == 1:
                    if price < self.entry_price[LONG]:
                        return 0

                if self.long_pnl + self.profit > self.maker_fee_price * self.pos_volume[LONG] / 2:
                    return price

                if len(self.traded_long_open_order_dict) == 0:
                    returnValue = self.read_dict_from_file(LONG)
                    if returnValue == False:
                        self.traded_long_open_order_dict[self.entry_price[LONG] + self.maker_fee_price + self.profit_tick * self.pricetick] = round_to(self.pos_volume[LONG], self.min_volume)
                elif len(self.traded_long_open_order_dict) == 1:
                    last_volume = self.traded_long_open_order_dict[min(self.traded_long_open_order_dict.keys())]
                    if self.pos_volume[LONG] > last_volume:
                        self.traded_long_open_order_dict[self.entry_price[LONG] + self.maker_fee_price + self.profit_tick * self.pricetick] = round_to(self.pos_volume[LONG] - last_volume, self.min_volume)
                    elif self.pos_volume[LONG] < last_volume:
                        self.traded_long_open_order_dict[min(self.traded_long_open_order_dict.keys())] = round_to(self.pos_volume[LONG], self.min_volume)

                if len(self.traded_long_open_order_dict) > 0:
                    min_price = min(self.traded_long_open_order_dict.keys())
                    if price < min_price:
                        price = min_price
                else:
                    return 0

        price = round_to(price, self.pricetick)

        return price

    """
    "   Desc: Calculate max_pos_volume
    """
    def calc_max_pos_and_init_volume(self, direction, offset):
        self.max_pos_volume = round_to((self.balance + self.pnl) * self.leverage / self.close_price, self.min_volume)
        self.open_min_volume = round_to(self.open_order_min_price / self.close_price, self.min_volume)
        self.open_init_volume = round_to(100 * self.open_volume_rate * self.open_min_volume / self.grid_gap, self.min_volume)

    """
    "   Desc: Calc a maker fee price with several price range
    """
    def calc_maker_fee_price(self):
        if self.maker_fee_rate > 0:
            if self.close_price <= 1000:
                self.maker_fee_price = round_to(2 * 1000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 2000:
                self.maker_fee_price = round_to(2 * 2000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 3000:
                self.maker_fee_price = round_to(2 * 3000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 4000:
                self.maker_fee_price = round_to(2 * 4000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 5000:
                self.maker_fee_price = round_to(2 * 5000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 6000:
                self.maker_fee_price = round_to(2 * 6000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 7000:
                self.maker_fee_price = round_to(2 * 7000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 8000:
                self.maker_fee_price = round_to(2 * 8000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 9000:
                self.maker_fee_price = round_to(2 * 9000 * self.maker_fee_rate, self.pricetick)
            elif self.close_price <= 10000:
                self.maker_fee_price = round_to(2 * 10000 * self.maker_fee_rate, self.pricetick)
            else:
                self.maker_fee_price = round_to(2 * self.close_price * self.maker_fee_rate, self.pricetick)

    """
    "   Desc: Calc a taker fee price per unit volume according to several price range
    """
    def calc_taker_fee_price(self):
        if self.taker_fee_rate > 0:
            if self.close_price <= 1000:
                self.taker_fee_price = round_to(2 * 1000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 2000:
                self.taker_fee_price = round_to(2 * 2000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 3000:
                self.taker_fee_price = round_to(2 * 3000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 4000:
                self.taker_fee_price = round_to(2 * 4000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 5000:
                self.taker_fee_price = round_to(2 * 5000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 6000:
                self.taker_fee_price = round_to(2 * 6000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 7000:
                self.taker_fee_price = round_to(2 * 7000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 8000:
                self.taker_fee_price = round_to(2 * 8000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 9000:
                self.taker_fee_price = round_to(2 * 9000 * self.taker_fee_rate, self.pricetick)
            elif self.close_price <= 10000:
                self.taker_fee_price = round_to(2 * 10000 * self.taker_fee_rate, self.pricetick)
            else:
                self.taker_fee_price = round_to(2 * self.close_price * self.taker_fee_rate, self.pricetick)

    """
    "   Desc: Update traded open order dict
    """
    def update_traded_open_order_dict(self, direction, price, volume, status):
        price = round_to(price, self.pricetick)
        volume = round_to(volume, self.min_volume)
        if status == 0:
            if direction == LONG:
                if price in self.traded_long_open_order_dict:
                    self.traded_long_open_order_dict[price] += volume
                else:
                    self.traded_long_open_order_dict[price] = volume

                self.write_dict_to_file(LONG)
            elif direction == SHORT:
                if price in self.traded_short_open_order_dict:
                    self.traded_short_open_order_dict[price] += volume
                else:
                    self.traded_short_open_order_dict[price] = volume

                self.write_dict_to_file(SHORT)
        elif status == 1:
            if direction == LONG:
                if len(self.traded_short_open_order_dict) > 0:
                    key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                    for k in sorted(key_copy_short, reverse=True):
                        if k >= price and volume > 0:
                            if self.traded_short_open_order_dict[k] == 0.0:
                                del self.traded_short_open_order_dict[k]
                                continue

                            if volume > self.traded_short_open_order_dict[k]:
                                volume -= self.traded_short_open_order_dict[k]
                                del self.traded_short_open_order_dict[k]
                            elif volume == self.traded_short_open_order_dict[k]:
                                del self.traded_short_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_short_open_order_dict[k]
                                if k_v > volume:
                                    self.traded_short_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break

                self.write_dict_to_file(SHORT)
            elif direction == SHORT:
                if len(self.traded_long_open_order_dict) > 0:
                    key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                    for k in sorted(key_copy_long):
                        if price >= k and volume > 0:
                            if self.traded_long_open_order_dict[k] == 0.0:
                                del self.traded_long_open_order_dict[k]
                                continue

                            if volume > self.traded_long_open_order_dict[k]:
                                volume -= self.traded_long_open_order_dict[k]
                                del self.traded_long_open_order_dict[k]
                            elif volume == self.traded_long_open_order_dict[k]:
                                del self.traded_long_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_long_open_order_dict[k]
                                if k_v > volume:
                                    self.traded_long_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break

                self.write_dict_to_file(LONG)

    """
    "   Desc: Get close voluem from an open order dict
    """
    def get_close_volume_from_dict(self, direction, price):
        close_volume = 0
        if direction == LONG:
            if len(self.traded_short_open_order_dict) > 0:
                key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                for k in sorted(key_copy_short, reverse=True):
                    if k >= price:
                        if self.traded_short_open_order_dict[k] == 0.0:
                            del self.traded_short_open_order_dict[k]
                        else:
                            close_volume += self.traded_short_open_order_dict[k]
        elif direction == SHORT:
            if len(self.traded_long_open_order_dict) > 0:
                key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                for k in sorted(key_copy_long):
                    if price >= k:
                        if self.traded_long_open_order_dict[k] == 0.0:
                            del self.traded_long_open_order_dict[k]
                        else:
                            close_volume += self.traded_long_open_order_dict[k]

        return round_to(close_volume, self.min_volume)

    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
            else:
                return 'L_NONE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'
            else:
                return 'S_NONE'

    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance
            if self.start_balance == 0:
                self.start_balance = self.balance

            if self.max_balance == 0:
                self.max_balance = self.balance
            else:
                if self.balance > self.max_balance:
                    self.max_balance = self.balance

    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.traded_long_open_order_dict = {}
                    self.last_open_traded_price[LONG] = 0

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.traded_short_open_order_dict = {}
                    self.last_open_traded_price[SHORT] = 0

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price

    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                direction_offset = self.get_order_direction_offset_str(direction, offset)

                self.current_traded_volume += round_to(order.volume, self.min_volume)
                self.total_volume += round_to(order.volume, self.min_volume)

                if order.type == OrderType.LIMIT:
                    self.summary_count['maker'] += 1
                    self.current_traded_amount += round_to(order.price * order.volume, self.min_volume)
                    self.total_amount += round_to(order.price * order.volume, self.min_volume)
                    self.rebate -= round_to(order.price * order.volume * self.maker_fee_rate, self.min_volume)

                    if direction == LONG:
                        if offset == OPEN:
                            self.last_open_traded_price[LONG] = order.price
                            long_open_order_price = round_to(order.price + self.maker_fee_price + self.profit_tick * self.pricetick, self.pricetick)
                            long_open_volume = round_to(order.volume, self.min_volume)
                            self.update_traded_open_order_dict(LONG, long_open_order_price, long_open_volume, 0)
                        elif offset == CLOSE:
                            if self.pos_volume[SHORT] > 0:
                                self.last_open_traded_price[SHORT] = round_to(order.price + self.maker_fee_price + self.profit_tick * self.pricetick, self.pricetick)
                            long_close_order_price = round_to(order.price, self.pricetick)
                            long_close_order_volume = round_to(order.volume, self.min_volume)
                            self.update_traded_open_order_dict(LONG, long_close_order_price, long_close_order_volume, 1)
                    elif direction == SHORT:
                        if offset == OPEN:
                            self.last_open_traded_price[SHORT] = order.price
                            short_open_order_price = round_to(order.price - self.maker_fee_price - self.profit_tick * self.pricetick, self.pricetick)
                            short_open_order_volume = round_to(order.volume, self.min_volume)
                            self.update_traded_open_order_dict(SHORT, short_open_order_price, short_open_order_volume, 0)
                        elif offset == CLOSE:
                            if self.pos_volume[LONG] > 0:
                                self.last_open_traded_price[LONG] = round_to(order.price - self.maker_fee_price - self.profit_tick * self.pricetick, self.pricetick)
                            short_close_order_price = round_to(order.price, self.pricetick)
                            short_close_order_volume = round_to(order.volume, self.min_volume)
                            self.update_traded_open_order_dict(SHORT, short_close_order_price, short_close_order_volume, 1)
                elif order.type == OrderType.MARKET:
                    self.summary_count['taker'] += 1
                    self.current_traded_amount += round_to(self.close_price * order.volume, self.min_volume)
                    self.total_amount += round_to(self.close_price * order.volume, self.min_volume)
                    self.commission += round_to(self.close_price * order.volume * self.taker_fee_rate, self.min_volume)

                    if direction == LONG:
                        if offset == OPEN:
                            self.taker_long_order_volume = order.volume
                        else:
                            self.taker_short_order_volume = 0
                    else:
                        if offset == OPEN:
                            self.taker_short_order_volume = order.volume
                        else:
                            self.taker_long_order_volume = 0

                self.write_tradedinfo_to_file()

                long_max_price = 0
                long_min_price = 0
                if len(self.traded_long_open_order_dict) > 0:
                    long_max_price = round_to(max(self.traded_long_open_order_dict.keys()), self.pricetick)
                    long_min_price = round_to(min(self.traded_long_open_order_dict.keys()), self.pricetick)

                short_min_price = 0
                short_max_price = 0
                if len(self.traded_short_open_order_dict) > 0:
                    short_min_price = round_to(min(self.traded_short_open_order_dict.keys()), self.pricetick)
                    short_max_price = round_to(max(self.traded_short_open_order_dict.keys()), self.pricetick)

                # current date and time
                now = datetime.now()
                date_time = now.strftime("%m-%d %H:%M:%S")

                long_entry_price = round_to(self.entry_price[LONG], self.pricetick)
                short_entry_price = round_to(self.entry_price[SHORT], self.pricetick)
                if order.type == OrderType.LIMIT:
                    if direction == LONG:
                        if offset == OPEN:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
                        elif offset == CLOSE:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
                    elif direction == SHORT:
                        if offset == OPEN:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
                        elif offset == CLOSE:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
                elif order.type == OrderType.MARKET:
                    if direction == LONG:
                        if offset == OPEN:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{self.close_price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
                        else:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{self.close_price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
                    elif direction == SHORT:
                        if offset == OPEN:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{self.close_price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
                        else:
                            print(f'{self.summary_count["maker"]: >7}/{self.summary_count["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{self.close_price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round_to(self.current_traded_amount, self.min_volume): >15}{date_time: >18}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")

    """
    Callback of new trade data update.
    """
    def on_trade(self, trade: TradeData):
        self.put_event()

    """
    "   Desc: Write a dict to a txt file
    """
    def write_dict_to_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\root\\strategies\\long_dict.txt"
        else:
            log_file = "C:\\Users\\root\\strategies\\short_dict.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            if direction == SHORT:
                f.write(str(self.traded_short_open_order_dict).replace("{", "").replace("}", ""))
            else:
                f.write(str(self.traded_long_open_order_dict).replace("{", "").replace("}", ""))

    """
    "   Desc: Read dict from a txt file
    """
    def read_dict_from_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\root\\strategies\\long_dict.txt"
        else:
            log_file = "C:\\Users\\root\\strategies\\short_dict.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                return False
            else:
                if direction == SHORT:
                    self.traded_short_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                else:
                    self.traded_long_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                return True

    """
    "   Desc: Write a traded info to a log file
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\root\\strategies\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{round_to(self.start_balance, self.min_volume)}, {round_to(self.max_balance, self.min_volume)}, {self.total_runtime}, {round_to(self.total_volume, self.min_volume)}, {round_to(self.total_amount, self.min_volume)}, {round_to(self.rebate, self.min_volume)}, {round_to(self.commission, self.min_volume)}, {round_to(self.last_open_traded_price[LONG], self.pricetick)}, {round_to(self.last_open_traded_price[SHORT], self.pricetick)}'
            f.write(traded_info)

    """
    "   Desc: Read a traded info from a log file
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\root\\strategies\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.start_balance = 0
                self.max_balance = 0
                self.total_runtime = 0
                self.total_volume = 0
                self.total_amount = 0
                self.rebate = 0
                self.commission = 0
                self.last_open_traded_price[LONG] = 0
                self.last_open_traded_price[SHORT] = 0
            else:
                self.start_balance = float(data.split(', ')[0].strip())
                self.max_balance = float(data.split(', ')[1].strip())
                self.total_runtime = float(data.split(', ')[2].strip())
                self.total_volume = float(data.split(', ')[3].strip())
                self.total_amount = float(data.split(', ')[4].strip())
                self.rebate = float(data.split(', ')[5].strip())
                self.commission = float(data.split(', ')[6].strip())
                self.last_open_traded_price[LONG] = float(data.split(', ')[7].strip())
                self.last_open_traded_price[SHORT] = float(data.split(', ')[8].strip())
