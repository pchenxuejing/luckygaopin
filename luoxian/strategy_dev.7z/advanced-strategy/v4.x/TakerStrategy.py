from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType, Interval
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}

class TakerStrategy(CtaTemplate):

    author = "TakerStrategy"

    # Parameters
    open_volume = 1                     # open volume
    option = 0                          # 1: buy, 2: sell, 3: short, 4: cover

    # Variables
    balance = 0                         # account balance

    taker_processed = 0                 # 1: taker order has been processed

    pos_volume = {LONG: 0, SHORT: 0}    # position volume
    entry_price = {LONG: 0, SHORT: 0}   # entry price of position

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['open_volume', 'option']
    variables = ['balance']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.main_process_thread = None

        self.taker_processed = 0


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BITCOKE')


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        # self.gateway.query_account()
        # self.gateway.query_position()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):

        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        # main process daemon
        count = 0
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            if self.option == 1 and self.taker_processed == 0:
                self.taker_processed = 1
                self.buy(0, self.open_volume)
            elif self.option == 2 and self.taker_processed == 0:
                self.taker_processed = 1
                self.sell(0, self.open_volume)
            elif self.option == 3 and self.taker_processed == 0:
                self.taker_processed = 1
                self.short(0, self.open_volume)
            elif self.option == 4 and self.taker_processed == 0:
                self.taker_processed = 1
                self.cover(0, self.open_volume)

        self.stop_main_process = False


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BITCOKE':
            if account.accountid == 'USDT':
                if 'USD' in self.symbol:
                    self.balance = account.balance
        else:
            if account.accountid in self.symbol:
                self.balance = account.balance


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)

            self.entry_price[direction] = position.price


    """
    "   Desc: Callback function for order traded
    """
    def on_trade(self, trade: TradeData):
        # current date and time
        now = datetime.now()
        date_time = now.strftime("%Y-%m-%d %H:%M:%S")

        print(f'{round(trade.price, 3): >12}{trade.volume: >7}{date_time: >27}')

        self.put_event()
