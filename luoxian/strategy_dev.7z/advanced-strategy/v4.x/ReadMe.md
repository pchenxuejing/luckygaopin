======= v4.x =======

1. v4.0
Strategy for a Maker and Taker


2. v4.1
Grid Strategy for only a Maker
Close long/short positions when market price hits a traded open order price.


3. v4.2
This is my main strategy!
Grid Strategy for only a Maker, also integrated with moving average
Close long/short positions when market price hits a traded open order price according to ma_status.

If ma_status = 1, close a short position when market price hits a traded short open order price and do not close a long position though market price hits a traded long open order price.
If ma_status = 2, close a long position when market price hits a traded long open order price and do not close a short position though market price hits a traded short open order price.


4. v4.3
Taker and Maker order
(I don't like this version.:( Because I can lost a lot of money if use this strategy.)


5. v4.4
This is my main strategy!
Grid Strategy for a Maker and Taker, also integrated with moving average
Close long/short positions when market price hits a traded open order price according to ma_status.

If ma_status = 1, close a short position when market price hits a traded short open order price and do not close a long position though market price hits a traded long open order price.
If ma_status = 2, close a long position when market price hits a traded long open order price and do not close a short position though market price hits a traded short open order price.

If difference price between entry_price and market_price is larger than taker_process_price, then process a taker order with pos_volume.
And then, update a open_order_price_dict with entry_price +/- taker_fee_price.


6. v4.5
This is my main strategy!
Grid Strategy for only a Maker, also integrated with double moving average (5, 10)
Close long/short positions when market price hits a traded open order price according to ma_status.

If ma_status = 1, open only a long open order and close a short position when market price hits a traded short open order price and do not close a long position though market price hits a traded long open order price.
If ma_status = 2, open only a short open order and close a long position when market price hits a traded long open order price and do not close a short position though market price hits a traded short open order price.

In this version, the main point is in update_traded_open_order_dict function.


7. v4.6
- Difference with v4.5
a calc logic of long_pnl and short_pnl


8. v4.7
- Difference with v4.6
modified a unit of grid_gap and profit_price parameter
removed a saving some parameters to log file (last_traded_long/short_open_price and commission)
added a new logic for maximizing a profit according to fastest_ma value


9. v4.8 (The lastest and final version)
- Difference with v4.7
added a taker order logic

if taker_option is 1, v4.8 = v4.7, otherwise v4.8 = v4.7 + taker_logic

v4.8 = v4.7 + taker_logic



    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # ma
        self.bargenerator = BarGenerator(self.on_bar, 1, self.on_1h_bar, Interval.HOUR)
        self.arraymanager = ArrayManager(45)

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    self.bargenerator = BarGenerator(self.on_bar, 1, self.on_1h_bar, Interval.HOUR)


    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        # self.bargenerator.update_bar(bar)


    """
    Callback of new bar data update.
    """
    # def on_1h_bar(self, bar: BarData):
    #     am = self.arraymanager
    #     am.update_bar(bar)
    #     if not am.inited:
    #         return

    #     self.open_price = am.close[-1]

    #     fast_ma = am.ema(self.fast_period, array=True)
    #     self.fast_ma0 = fast_ma[-1]
    #     self.fast_ma1 = fast_ma[-2]

    #     slow_ma = am.ema(self.slow_period, array=True)
    #     self.slow_ma0 = slow_ma[-1]
    #     self.slow_ma1 = slow_ma[-2]

    #     cross_over = self.fast_ma0 > self.slow_ma0 and self.fast_ma1 < self.slow_ma1
    #     cross_below = self.fast_ma0 < self.slow_ma0 and self.fast_ma1 > self.slow_ma1

    #     if cross_over:
    #         if self.pos_volume[LONG] == 0:
    #             self.buy(0, self.open_volume)

    #         if self.pos_volume[SHORT] == 0:
    #             self.short(0, self.pos_volume[SHORT])
    #     elif cross_below:
    #         if self.pos_volume[SHORT] == 0:
    #             self.short(0, self.open_volume)

    #         if self.pos_volume[LONG] == 0:
    #             self.buy(0, self.open_volume)

    #     self.put_event()
