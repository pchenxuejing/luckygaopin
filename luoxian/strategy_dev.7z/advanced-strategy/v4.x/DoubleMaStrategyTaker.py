from vnpy.app.cta_strategy import (
    CtaTemplate,
    StopOrder,
    TickData,
    BarData,
    TradeData,
    OrderData,
    BarGenerator,
    ArrayManager,
)

from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
from typing import Dict
from time import sleep, time
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

DIRECTION_STR: Dict[Direction, str] = {Direction.LONG: "BUY", Direction.SHORT: "SELL"}

class DoubleMaStrategyTaker(CtaTemplate):
    author = "DoubleMaStrategyTaker v1.0"

    leverage = 10.0         # leverage
    open_volume_rate = 1.0  # open volume rate
    fee = 0.0004            # fee rate
    fast_period = 9         # fast period
    slow_period = 15        # slow period
    ma_cat = 0              # 0: kama, 1: sma, 2: ema
    option = 0

    balance = 0
    open_volume = 0
    rebate = 0
    fast_ma0 = 0.0
    fast_ma1 = 0.0
    slow_ma0 = 0.0
    slow_ma1 = 0.0
    open_price = 0.0
    close_price = 0.0

    start_time = 0
    prev_runtime = 0
    count = 0

    runtime = 0
    traded_volume = 0
    traded_amount = 0

    pos_volume = {
        LONG: 0,
        SHORT: 0
    }

    ma_values = {}

    parameters = ["leverage", "open_volume_rate", "fee", "fast_period", "slow_period", "ma_cat", "option"]
    variables = ["balance", "open_volume", "rebate", "ma_values"]

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        self.bg = BarGenerator(self.on_bar)
        self.am = ArrayManager()

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.ma_values = {
            "f0": 0,
            "s0": 0,
            "f1": 0,
            "s1": 0
        }

    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')

        self.write_log("策略初始化")
        self.load_bar(2)

        self.read_tradedinfo_from_file()

    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.write_log("策略启动")
        self.put_event()

    def on_stop(self):
        """
        Callback when strategy is stopped.
        """
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.write_log("策略停止")

        self.put_event()

    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.bg.update_tick(tick)

    def on_bar(self, bar: BarData):
        """
        Callback of new bar data update.
        """
        am = self.am
        am.update_bar(bar)
        if not am.inited:
            return

        self.open_price = am.open[-1]
        self.close_price = am.close[-1]

        self.open_volume = round_to(self.balance * self.leverage * self.open_volume_rate / self.close_price, self.min_volume)

        if self.start_time == 0:
            self.start_time = time()

        if self.prev_runtime == 0:
            self.prev_runtime = self.runtime

        self.runtime = self.prev_runtime + round_to((time() - self.start_time) / 60, 1)

        if self.option == 0:
            if self.ma_cat == 0:
                fast_ma = am.kama(self.fast_period, array=True)
            elif self.ma_cat == 1:
                fast_ma = am.sma(self.fast_period, array=True)
            else:
                fast_ma = am.ema(self.fast_period, array=True)
            self.fast_ma0 = fast_ma[-1]
            self.fast_ma1 = fast_ma[-2]

            if self.ma_cat == 0:
                slow_ma = am.kama(self.slow_period, array=True)
            elif self.ma_cat == 1:
                slow_ma = am.sma(self.slow_period, array=True)
            else:
                slow_ma = am.ema(self.slow_period, array=True)
            self.slow_ma0 = slow_ma[-1]
            self.slow_ma1 = slow_ma[-2]

            self.ma_values["f0"] = self.fast_ma0
            self.ma_values["s0"] = self.slow_ma0
            self.ma_values["f1"] = self.fast_ma1
            self.ma_values["s1"] = self.slow_ma1

            cross_over = self.fast_ma0 > self.slow_ma0 and self.fast_ma1 < self.slow_ma1
            cross_below = self.fast_ma0 < self.slow_ma0 and self.fast_ma1 > self.slow_ma1

            if cross_over:
                self.buy(0, self.open_volume)
                if self.pos_volume[SHORT] > 0:
                    self.cover(0, self.pos_volume[SHORT])
            elif cross_below:
                self.short(0, self.open_volume)
                if self.pos_volume[LONG] > 0:
                    self.sell(0, self.pos_volume[LONG])
        elif self.option == 1:
            if self.ma_cat == 0:
                fast_ma = am.kama(self.fast_period, array=True)
            elif self.ma_cat == 1:
                fast_ma = am.sma(self.fast_period, array=True)
            else:
                fast_ma = am.ema(self.fast_period, array=True)
            self.fast_ma0 = fast_ma[-1]
            self.fast_ma1 = fast_ma[-2]

            if self.ma_cat == 0:
                slow_ma = am.kama(self.slow_period, array=True)
            elif self.ma_cat == 1:
                slow_ma = am.sma(self.slow_period, array=True)
            else:
                slow_ma = am.ema(self.slow_period, array=True)
            self.slow_ma0 = slow_ma[-1]
            self.slow_ma1 = slow_ma[-2]

            self.ma_values["f0"] = self.fast_ma0
            self.ma_values["s0"] = self.slow_ma0
            self.ma_values["f1"] = self.fast_ma1
            self.ma_values["s1"] = self.slow_ma1

            cross_over = self.fast_ma0 > self.slow_ma0 and self.fast_ma1 < self.slow_ma1
            cross_below = self.fast_ma0 < self.slow_ma0 and self.fast_ma1 > self.slow_ma1

            if self.fast_ma0 > self.slow_ma0:
                if self.fast_ma1 < self.slow_ma1:
                    self.buy(0, self.open_volume)
                    if self.pos_volume[SHORT] > 0:
                        self.cover(0, self.pos_volume[SHORT])
                else:
                    if self.fast_ma0 < self.fast_ma1:
                        if self.pos_volume[LONG] > 0:
                            self.sell(0, self.pos_volume[LONG])
            elif self.fast_ma0 < self.slow_ma0:
                if self.fast_ma1 > self.slow_ma1:
                    self.short(0, self.open_volume)
                    if self.pos_volume[LONG] > 0:
                        self.sell(0, self.pos_volume[LONG])
                else:
                    if self.fast_ma0 > self.fast_ma1:
                        if self.pos_volume[SHORT] > 0:
                            self.cover(0, self.pos_volume[SHORT])
        else:
            if self.pos_volume[LONG] > 0:
                self.sell(0, self.pos_volume[LONG])

            if self.pos_volume[SHORT] > 0:
                self.cover(0, self.pos_volume[SHORT])

        self.put_event()

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)

    def on_order(self, order: OrderData):
        """
        Callback of new order data update.
        """
        pass

    def on_trade(self, trade: TradeData):
        """
        Callback of new trade data update.
        """
        self.count += 1
        self.traded_volume += round_to(trade.volume, self.min_volume)
        self.traded_amount += round_to(trade.price * trade.volume, self.pricetick)
        self.rebate = self.traded_amount * self.fee
        traded_info = f'({self.count}) {DIRECTION_STR[trade.direction]}, {round_to(trade.price, self.pricetick)}, {round_to(trade.volume, self.min_volume)} [::] {self.start_balance}, {round_to(self.balance, self.pricetick)}, {round_to(self.traded_volume, self.min_volume)}, {round_to(self.traded_amount, self.pricetick)}, {self.runtime}'
        print(traded_info)
        self.write_tradedinfo_to_file()
        self.put_event()

    def on_stop_order(self, stop_order: StopOrder):
        """
        Callback of stop order update.
        """
        pass

    """
    "   desc:   Write a traded info to log file
    "   Log File Path: C:/Users/Administrator/strategies, /home/users/
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\admin\\strategies\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{self.start_balance}, {self.runtime}, {round_to(self.traded_volume, self.min_volume)}, {round_to(self.traded_amount, self.pricetick)}'
            f.write(traded_info)

    """
    "   desc:   Read a traded info from log file
    "   Log File Path: C:/Users/Administrator/strategies, /home/users/
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\admin\\strategies\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.start_balance = self.balance
                self.runtime = 0
                self.traded_volume = 0
                self.traded_amount = 0
            else:
                self.start_balance = float(data.split(', ')[0].strip())
                self.runtime = float(data.split(', ')[1].strip())
                self.traded_volume = float(data.split(', ')[2].strip())
                self.traded_amount = float(data.split(', ')[3].strip())
