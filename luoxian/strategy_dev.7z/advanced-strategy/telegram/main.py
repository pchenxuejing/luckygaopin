import os
import fire
import uuid
import base64
import logging
from telethon import TelegramClient, events, sync
from telethon.tl.types import PeerUser, PeerChat, PeerChannel

# python main.py download --channel [channel] --output image

api_id=26176799
api_hash="99f615ac30dd0b5ae87bc318995f1155"

client = TelegramClient('session_name', api_id, api_hash)
client.start()

logging.basicConfig(level=logging.DEBUG)
logging.getLogger('telethon').setLevel(level=logging.WARNING)
idownload = logging.getLogger('xiazai')
idownload.setLevel(level=logging.INFO)

def download(channel,output):
    xiwang_channel = client.get_entity(channel)
    c = client.get_entity(PeerChannel(xiwang_channel.id))

    if not os.path.isdir(output):
        os.makedirs(output)

    for m in client.iter_messages(c):
        uuidstring = str(uuid.uuid1())
        z = base64.encodebytes(uuid.UUID(uuidstring).bytes).decode("ascii").rstrip('=\n').replace('/', '_')
        suid = "{}/{}".format(output,z)

        m.download_media(suid)

        fname = "{}.jpg".format(suid)
        if os.path.isfile(fname):
            idownload.info("✔  {} Downloaded Sucessful".format(fname))

if __name__ == '__main__':
    fire.Fire()