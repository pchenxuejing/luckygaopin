from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path
import numpy as np

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}
TRADED_INFO_TITLE: Dict[int, str] = {0: "RunTime", 1: "Initial/Current", 2: "Volume/Amount", 3: "Rebate/Commission"}

class AdvancedGridStrategy_Binance_ETHBUSD_4989v1(CtaTemplate):

    author = "AdvancedGridStrategy(Binance Futures)_ETHBUSD_4989v1"

    # Parameters
    leverage = 5                            # a leverage
    open_volume_rate = 1                    # an open volume rate, it will be used when calculating an open_init_volume
    profit_pricetick = 50                   # a profit pricetick
    volume_step_percent = 10                # a volume step percent for a updated_open_dict
    fast_period = 5                         # a fast_period of moving average
    slow_period = 10                        # a slow_period of moving average
    maker_fee_percent = 0.012               # a maker fee, it depends on exchange policy
    taker_fee_percent = 0.04                # a taker fee, it depends on exchange policy
    pnl_percent = 10                        # a loss percent
    open_order_min_price = 10               # an open order min price, it depends on exchange policy
    max_close_volume = 200                  # a max close volume of one time, it depends on exchange policy

    # Variables
    balance = 0                             # an account balance
    last_balance = 0                        # a balanace before taker order
    pnl = 0                                 # a PNL
    rebate = 0                              # a rebate till now (for a maker)
    commission = 0                          # a commission till now (for a taker)
    long_pnl = 0                            # a pnl for a long position
    short_pnl = 0                           # a pnl for a short position
    long_update_pnl = 0                     # 1: set long_pnl to 0,  2: update a long_pnl
    short_update_pnl = 0                    # 1: set short_pnl to 0, 2: update a short_pnl
    max_pos_volume = 0                      # a max pos volume
    open_min_volume = 0                     # an open min volume, will be calculated by open_order_min_price (it depends on exchange policy)
    open_init_volume = 0                    # an opne init volume per a 1$

    open_price = 0                          # an open price for a current candlestick
    close_price = 0                         # a close price for a current candlestick
    maker_fee_price = 0                     # a maker fee price for a unit volume (1)
    taker_fee_price = 0                     # a taker fee price of unit volume (it depends on exchange policy)
    extra_price = 0                         # a plus of maker_fee and profit

    fast_ma0 = 0                            # a ma value of fast period
    fast_ma1 = 0                            # a ma value of fast period
    slow_ma0 = 0                            # a ma value of slow period
    slow_ma1 = 0                            # a ma value of slow period
    ma_status = 0                           # 0: None, 1: Bullish, 2: Bearish
    fastest_ma = 0                          # a ma value of 2 period

    traded_long_open_order_dict = {}        # a dict for traded long_open price and volume
    traded_short_open_order_dict = {}       # a dict for traded short_open price and volume

    long_open_traded_min_price = 0          # a min price of traded_long_open_order_dict
    long_open_traded_max_price = 0          # a max price of traded_long_open_order_dict
    short_open_traded_max_price = 0         # a max price of traded_short_open_order_dict
    short_open_traded_min_price = 0         # a min price of traded_short_open_order_dict

    long_maker_rebate = 0                   # a rebate of long direction
    short_maker_rebate = 0                  # a rebate of short direction

    # Statistic data
    start_time = 0                          # a start time when strategy is started
    last_runtime = 0                        # a last runtime
    start_balance = 0                       # a start balance (funded amount at first time)
    total_runtime = 0                       # a total runtime
    total_volume = 0                        # a total traded volume
    total_amount = 0                        # a total traded amount
    current_runtime = 0                     # a current runtime
    current_traded_volume = 0               # a current traded volume
    current_traded_amount = 0               # a current traded amount

    pos_volume = {LONG: 0, SHORT: 0}        # a position volume
    entry_price = {LONG: 0, SHORT: 0}       # an entry price of position
    last_pos_volume = {LONG: 0, SHORT: 0}   # a last position volume before closing all positoins

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['leverage', 'open_volume_rate', 'profit_pricetick', 'volume_step_percent', 'fast_period', 'slow_period', 'maker_fee_percent', 'taker_fee_percent', 'pnl_percent', 'max_close_volume', 'open_order_min_price']
    variables = ['balance', 'pnl', 'long_pnl', 'short_pnl', 'ma_status', 'max_pos_volume', 'open_init_volume', 'open_min_volume']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # k-line
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume

        # symbol (removed '.ExchangeName')
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.main_process_thread = None
        self.dict_filtering_thread = None

        self.last_pos_volume[LONG] = 0
        self.last_pos_volume[SHORT] = 0

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }
        self.order_info_queue = {}

        self.traded_long_open_order_dict = {}
        self.traded_short_open_order_dict = {}

        self.long_open_traded_min_price = 0
        self.long_open_traded_max_price = 0
        self.short_open_traded_max_price = 0
        self.short_open_traded_min_price = 0

        self.long_update_pnl = 0
        self.short_update_pnl = 0


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')

        # k-line
        self.load_bar(2)


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.stop_main_process = False

        # main thread
        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.main_process_thread.start()

        # filtering dict file in order to remove an unnecessary key/value
        self.dict_filtering_thread = Thread(target = self.dict_filtering)
        self.dict_filtering_thread.setDaemon(True)
        self.dict_filtering_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        # k-line
        self.bargenerator.update_tick(tick)

        self.last_last_tick = self.last_tick
        self.last_tick = tick

        self.close_price = tick.last_price

        if self.is_valid_tick(tick) == False:
            pass

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        am = self.arraymanager
        am.update_bar(bar)
        if not am.inited:
            return

        self.open_price = am.close[-1]
        self.fastest_ma = am.ema(2)

        fast_ma = am.ema(self.fast_period, array=True)
        self.fast_ma0 = fast_ma[-1]
        self.fast_ma1 = fast_ma[-2]

        slow_ma = am.ema(self.slow_period, array=True)
        self.slow_ma0 = slow_ma[-1]
        self.slow_ma1 = slow_ma[-2]

        if self.fast_ma0 > self.slow_ma0:
            self.ma_status = 1
        elif self.fast_ma0 < self.slow_ma0:
            self.ma_status = 2
        else:
            self.ma_status = 0

        cross_over = self.fast_ma0 > self.slow_ma0 and self.fast_ma1 < self.slow_ma1
        cross_below = self.fast_ma0 < self.slow_ma0 and self.fast_ma1 > self.slow_ma1

        if cross_over:
            if self.pos_volume[SHORT] > 0 and self.short_pnl > 0 and self.close_price > self.entry_price[SHORT]:
                short_predict_pnl = round((self.entry_price[SHORT] - self.close_price - self.taker_fee_price / 2) * self.pos_volume[SHORT], 5)
                if self.short_pnl * self.pnl_percent / 100 + short_predict_pnl > 0:
                    close_volume = 0
                    if self.pos_volume[SHORT] > self.max_close_volume:
                        close_volume = self.max_close_volume
                    else:
                        close_volume = self.pos_volume[SHORT]

                    self.short_update_pnl = 1

                    self.cover(0, close_volume)
        elif cross_below:
            if self.pos_volume[LONG] > 0 and self.long_pnl > 0 and self.close_price < self.entry_price[LONG]:
                long_predict_pnl = round((self.close_price - self.entry_price[LONG] - self.taker_fee_price / 2) * self.pos_volume[LONG], 5)
                if self.long_pnl * self.pnl_percent / 100 + long_predict_pnl > 0:
                    close_volume = 0
                    if self.pos_volume[LONG] > self.max_close_volume:
                        close_volume = self.max_close_volume
                    else:
                        close_volume = self.pos_volume[LONG]

                    self.long_update_pnl = 1

                    self.sell(0, close_volume)

        self.put_event()


    """
    "   Desc: filtering thread
    """
    def dict_filtering(self):
        while True:
            if len(self.traded_long_open_order_dict) > 0 and len(self.traded_short_open_order_dict) > 0:
                if self.close_price > self.long_open_traded_min_price:
                    key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                    for k in sorted(key_copy_long):
                        if self.traded_long_open_order_dict[k] == 0.0:
                            del self.traded_long_open_order_dict[k]
                        else:
                            if len(str(k)) > 9:
                                v = self.traded_long_open_order_dict[k]
                                r_k = round(k, 2)
                                del self.traded_long_open_order_dict[k]
                                self.traded_long_open_order_dict[r_k] = v

                if self.close_price < self.short_open_traded_max_price:
                    key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                    for k in sorted(key_copy_short, reverse=True):
                        if self.traded_short_open_order_dict[k] == 0.0:
                            del self.traded_short_open_order_dict[k]
                        else:
                            if len(str(k)) > 9:
                                v = self.traded_short_open_order_dict[k]
                                r_k = round(k, 2)
                                del self.traded_short_open_order_dict[k]
                                self.traded_short_open_order_dict[r_k] = v

            sleep(10)


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        self.read_tradedinfo_from_file()

        if self.start_time == 0:
            self.start_time = time()

        if self.last_runtime == 0:
            self.last_runtime = self.total_runtime

        if self.start_balance == 0:
            self.start_balance = self.balance

        if self.last_balance == 0:
            self.last_balance = self.balance

        print_count = 0
        count = 0
        # main process daemon
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            if print_count == 333 or print_count == 0:
                print(f'{TRADED_INFO_TITLE[0]: >21}{TRADED_INFO_TITLE[1]: >36}{TRADED_INFO_TITLE[2]: >36}{TRADED_INFO_TITLE[3]: >36}')
                initial_current = f'{round(self.start_balance, 3)}/{round(self.balance, 3)}'
                volume_amount = f'{round_to(self.total_volume, self.min_volume)}/{round(self.total_amount, 3)}'
                rebate_commission = f'{round(self.rebate, 3)}/{round(self.commission, 3)}'
                print(f'{self.total_runtime: >21}{initial_current: >36}{volume_amount: >36}{rebate_commission: >36}')
                print(f'=========')
                print_count = 1
            print_count += 1

            self.current_runtime = round((time() - self.start_time) / 60)
            self.total_runtime = self.last_runtime + self.current_runtime

            l_pnl = 0
            if self.pos_volume[LONG] > 0:
                l_pnl = round((self.close_price - self.entry_price[LONG]) * self.pos_volume[LONG], 5)

            s_pnl = 0
            if self.pos_volume[SHORT] > 0:
                s_pnl = round((self.entry_price[SHORT] - self.close_price) * self.pos_volume[SHORT], 5)

            self.pnl = l_pnl + s_pnl

            self.calc_maker_fee_price()
            self.calc_taker_fee_price()

            if self.long_update_pnl == 2:
                for x in range(3):
                    continue

                self.long_pnl += round(self.balance - self.last_balance, 5) + self.long_maker_rebate
                self.long_maker_rebate = 0

                self.long_update_pnl = 0

                self.write_tradedinfo_to_file()

            if self.short_update_pnl == 2:
                for x in range(3):
                    continue

                self.short_pnl += round(self.balance - self.last_balance, 5) + self.short_maker_rebate
                self.short_maker_rebate = 0

                self.short_update_pnl = 0

                self.write_tradedinfo_to_file()

            self.last_balance = self.balance

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)

        sleep(2)

        # cancel all orders when strategy has been stopped
        long_open_cancel_orderid = self.registered_order_info[LONG][OPEN]
        if long_open_cancel_orderid != '':
            if long_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_open_cancel_orderid)

        short_open_cancel_orderid = self.registered_order_info[SHORT][OPEN]
        if short_open_cancel_orderid != '':
            if short_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_open_cancel_orderid)

        long_close_cancel_orderid = self.registered_order_info[LONG][CLOSE]
        if long_close_cancel_orderid != '':
            if long_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_close_cancel_orderid)

        short_close_cancel_orderid = self.registered_order_info[SHORT][CLOSE]
        if short_close_cancel_orderid != '':
            if short_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_close_cancel_orderid)

        sleep(2)

        self.stop_main_process = False


    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1):
        if offset == OPEN:
            self.calc_max_pos_and_init_volume()

        new_price = self.get_order_price(direction, offset)
        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        if new_price == 0:
            return

        # calculate the new volume
        if offset == OPEN:
            new_volume = max(self.open_init_volume, self.open_min_volume)
            if direction == LONG:
                if self.pos_volume[LONG] > 0:
                    if self.pos_volume[LONG] > self.max_pos_volume:
                        return
                    else:
                        pos_rate = 1
                        if self.pos_volume[SHORT] > 0:
                            pos_rate = 1 + (self.pos_volume[LONG] / self.pos_volume[SHORT]) / 100

                        rate = round(self.long_open_traded_max_price / new_price, 3)

                        new_volume = pos_rate * rate * self.open_init_volume * (self.long_open_traded_min_price - new_price - self.extra_price)
                        if new_volume + self.pos_volume[LONG] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[LONG]
                else:
                    if self.pos_volume[SHORT] > 0:
                        rate = max(round(new_price / self.short_open_traded_min_price, 3), 1)
                        new_volume = rate * new_volume
            elif direction == SHORT:
                if self.pos_volume[SHORT] > 0:
                    if self.pos_volume[SHORT] > self.max_pos_volume:
                        return
                    else:
                        pos_rate = 1
                        if self.pos_volume[LONG] > 0:
                            pos_rate = 1 + (self.pos_volume[SHORT] / self.pos_volume[LONG]) / 100

                        rate = round(new_price / self.short_open_traded_min_price, 3)

                        new_volume = pos_rate * rate * self.open_init_volume * (new_price - self.short_open_traded_max_price - self.extra_price)
                        if new_volume + self.pos_volume[SHORT] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[SHORT]
                else:
                    if self.pos_volume[LONG] > 0:
                        rate = max(round(self.long_open_traded_max_price / new_price, 3), 1)
                        new_volume = rate * new_volume

            if float(new_volume) <= 0.0:
                return
            elif new_volume < self.open_min_volume:
                return
            elif new_volume > self.max_close_volume:
                new_volume = self.max_close_volume
        elif offset == CLOSE:
            if direction == LONG:
                if self.pos_volume[SHORT] > 0:
                    new_volume = self.get_close_volume_from_dict(LONG, new_price)
                    if new_volume > self.pos_volume[SHORT]:
                        new_volume = self.pos_volume[SHORT]
                else:
                    return
            elif direction == SHORT:
                if self.pos_volume[LONG] > 0:
                    new_volume = self.get_close_volume_from_dict(SHORT, new_price)
                    if new_volume > self.pos_volume[LONG]:
                        new_volume = self.pos_volume[LONG]
                else:
                    return

            if float(new_volume) <= 0.0:
                return
            elif new_volume > self.max_close_volume:
                new_volume = self.max_close_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        if offset == CLOSE and float(new_volume) == 0.0:
            return

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False


    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        if self.pos_volume[LONG] > 0:
            if len(self.traded_long_open_order_dict) == 0:
                returnValue = self.read_dict_from_file(LONG)
                if returnValue == False:
                    self.traded_long_open_order_dict[self.entry_price[LONG] + self.extra_price] = round_to(self.pos_volume[LONG], self.min_volume)
            elif len(self.traded_long_open_order_dict) == 1:
                last_volume = self.traded_long_open_order_dict[min(self.traded_long_open_order_dict.keys())]
                if self.pos_volume[LONG] > last_volume:
                    self.traded_long_open_order_dict[self.entry_price[LONG] + self.extra_price] = round_to(self.pos_volume[LONG] - last_volume, self.min_volume)
                elif self.pos_volume[LONG] < last_volume:
                    self.traded_long_open_order_dict[min(self.traded_long_open_order_dict.keys())] = round_to(self.pos_volume[LONG], self.min_volume)
                elif self.pos_volume[LONG] == last_volume:
                    if self.long_pnl > 0:
                        self.traded_long_open_order_dict[self.entry_price[LONG] + self.extra_price] = round_to(self.pos_volume[LONG], self.min_volume)

            self.long_open_traded_min_price = min(self.traded_long_open_order_dict.keys())
            self.long_open_traded_max_price = max(self.traded_long_open_order_dict.keys())

        if self.pos_volume[SHORT] > 0:
            if len(self.traded_short_open_order_dict) == 0:
                returnValue = self.read_dict_from_file(SHORT)
                if returnValue == False:
                    self.traded_short_open_order_dict[self.entry_price[SHORT] - self.extra_price] = round_to(self.pos_volume[SHORT], self.min_volume)
            elif len(self.traded_short_open_order_dict) == 1:
                last_volume = self.traded_short_open_order_dict[min(self.traded_short_open_order_dict.keys())]
                if self.pos_volume[SHORT] > last_volume:
                    self.traded_short_open_order_dict[self.entry_price[SHORT] - self.extra_price] = round_to(self.pos_volume[SHORT] - last_volume, self.min_volume)
                elif self.pos_volume[SHORT] < last_volume:
                    self.traded_short_open_order_dict[min(self.traded_short_open_order_dict.keys())] = self.pos_volume[SHORT]
                elif self.pos_volume[SHORT] == last_volume:
                    if self.short_pnl > 0:
                        self.traded_short_open_order_dict[self.entry_price[SHORT] - self.extra_price] = round_to(self.pos_volume[SHORT], self.min_volume)

            self.short_open_traded_max_price = max(self.traded_short_open_order_dict.keys())
            self.short_open_traded_min_price = min(self.traded_short_open_order_dict.keys())

        if direction == LONG:
            price = tick.bid_price_1
            if offset == OPEN:
                if self.pos_volume[LONG] > self.max_pos_volume:
                    return 0

                if self.ma_status == 2:
                    return 0
            elif offset == CLOSE:
                if self.pos_volume[SHORT] > 0:
                    if self.close_price < self.fastest_ma:
                        price = tick.bid_price_5

                    if price > self.short_open_traded_max_price:
                        return 0
                else:
                    return 0
        elif direction == SHORT:
            price = tick.ask_price_1
            if offset == OPEN:
                if self.pos_volume[SHORT] > self.max_pos_volume:
                    return 0

                if self.ma_status == 1:
                    return 0
            elif offset == CLOSE:
                if self.pos_volume[LONG] > 0:
                    if self.close_price > self.fastest_ma:
                        price = tick.ask_price_5

                    if price < self.long_open_traded_min_price:
                        return 0
                else:
                    return 0

        return price


    """
    "   Desc: Calculate max_pos_volume
    """
    def calc_max_pos_and_init_volume(self):
        self.max_pos_volume = round_to((self.balance + self.pnl) * self.leverage / self.close_price, self.min_volume)
        self.open_min_volume = round_to(self.open_order_min_price / self.close_price, self.min_volume)
        self.open_init_volume = round_to(self.max_pos_volume * self.open_volume_rate / self.close_price, self.min_volume)


    """
    "   Desc: Update traded open order dict when maker order has been processed
    """
    def update_order_dict_when_maker(self, direction, price, volume, status):
        price = round_to(price, self.pricetick)
        volume = round_to(volume, self.min_volume)

        if float(volume) <= 0.0:
            return

        if status == 0:
            if direction == LONG:
                end_price = 2 * price
                if len(self.traded_long_open_order_dict) > 0:
                    for x in np.arange(price, end_price, self.profit_pricetick * self.pricetick):
                        if x < self.entry_price[LONG] + self.extra_price:
                            if volume < self.open_init_volume:
                                v = round_to(volume, self.min_volume)
                            else:
                                v = round_to(self.open_init_volume * (1 + ((x - price)) * self.volume_step_percent / 100), self.min_volume)

                            if float(v) > 0.0:
                                if x in self.traded_long_open_order_dict:
                                    self.traded_long_open_order_dict[x] += v
                                else:
                                    self.traded_long_open_order_dict[x] = v

                            volume -= v
                        else:
                            v = round_to(volume, self.min_volume)
                            if float(v) > 0.0:
                                if x in self.traded_long_open_order_dict:
                                    self.traded_long_open_order_dict[x] += v
                                else:
                                    self.traded_long_open_order_dict[x] = v

                            volume = 0

                        if float(volume) <= 0.0:
                            break
                else:
                    self.traded_long_open_order_dict[price] = volume

                self.write_dict_to_file(LONG)
            elif direction == SHORT:
                end_price = 1
                if len(self.traded_short_open_order_dict) > 0:
                    for x in np.arange(price, end_price, -self.profit_pricetick * self.pricetick):
                        if x > self.entry_price[SHORT] - self.extra_price:
                            if volume < self.open_init_volume:
                                v = round_to(volume, self.min_volume)
                            else:
                                v = round_to(self.open_init_volume * (1 + ((price - x)) * self.volume_step_percent / 100), self.min_volume)

                            if float(v) > 0.0:
                                if x in self.traded_short_open_order_dict:
                                    self.traded_short_open_order_dict[x] += v
                                else:
                                    self.traded_short_open_order_dict[x] = v

                            volume -= v
                        else:
                            v = round_to(volume, self.min_volume)
                            if float(v) > 0.0:
                                if x in self.traded_short_open_order_dict:
                                    self.traded_short_open_order_dict[x] += v
                                else:
                                    self.traded_short_open_order_dict[x] = v

                            volume = 0

                        if float(volume) <= 0.0:
                            break
                else:
                    self.traded_short_open_order_dict[price] = volume

                self.write_dict_to_file(SHORT)
        elif status == 1:
            if direction == LONG:
                if len(self.traded_short_open_order_dict) > 0:
                    key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                    for k in sorted(key_copy_short, reverse=True):
                        if k >= price and volume > 0:
                            if self.traded_short_open_order_dict[k] == 0.0:
                                del self.traded_short_open_order_dict[k]
                                continue

                            if volume > self.traded_short_open_order_dict[k]:
                                volume -= self.traded_short_open_order_dict[k]
                                del self.traded_short_open_order_dict[k]
                            elif volume == self.traded_short_open_order_dict[k]:
                                del self.traded_short_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_short_open_order_dict[k]
                                if float(k_v) > 0.0 and k_v > volume:
                                    self.traded_short_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break

                self.write_dict_to_file(SHORT)
            elif direction == SHORT:
                if len(self.traded_long_open_order_dict) > 0:
                    key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                    for k in sorted(key_copy_long):
                        if price >= k and volume > 0:
                            if self.traded_long_open_order_dict[k] == 0.0:
                                del self.traded_long_open_order_dict[k]
                                continue

                            if volume > self.traded_long_open_order_dict[k]:
                                volume -= self.traded_long_open_order_dict[k]
                                del self.traded_long_open_order_dict[k]
                            elif volume == self.traded_long_open_order_dict[k]:
                                del self.traded_long_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_long_open_order_dict[k]
                                if float(k_v) > 0.0 and k_v > volume:
                                    self.traded_long_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break

                self.write_dict_to_file(LONG)


    """
    "   Desc: Get close voluem from an open order dict
    """
    def get_close_volume_from_dict(self, direction, price):
        close_volume = 0
        if direction == LONG:
            if len(self.traded_short_open_order_dict) > 0:
                key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                for k in sorted(key_copy_short, reverse=True):
                    if k >= price:
                        if self.traded_short_open_order_dict[k] == 0.0:
                            del self.traded_short_open_order_dict[k]
                        else:
                            close_volume += self.traded_short_open_order_dict[k]
        elif direction == SHORT:
            if len(self.traded_long_open_order_dict) > 0:
                key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                for k in sorted(key_copy_long):
                    if price >= k:
                        if self.traded_long_open_order_dict[k] == 0.0:
                            del self.traded_long_open_order_dict[k]
                        else:
                            close_volume += self.traded_long_open_order_dict[k]

        return round_to(close_volume, self.min_volume)


    """
    "   Desc: Calc a maker fee price with several price range
    """
    def calc_maker_fee_price(self):
        if self.maker_fee_percent > 0:
            if self.close_price <= 1000:
                self.maker_fee_price = round_to(2 * 1000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 1500:
                self.maker_fee_price = round_to(2 * 1500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 2000:
                self.maker_fee_price = round_to(2 * 2000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 2500:
                self.maker_fee_price = round_to(2 * 2500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 3000:
                self.maker_fee_price = round_to(2 * 3000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 3500:
                self.maker_fee_price = round_to(2 * 3500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 4000:
                self.maker_fee_price = round_to(2 * 4000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 4500:
                self.maker_fee_price = round_to(2 * 4500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 5000:
                self.maker_fee_price = round_to(2 * 5000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 5500:
                self.maker_fee_price = round_to(2 * 5500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 6000:
                self.maker_fee_price = round_to(2 * 6000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 6500:
                self.maker_fee_price = round_to(2 * 6500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 7000:
                self.maker_fee_price = round_to(2 * 7000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 7500:
                self.maker_fee_price = round_to(2 * 7500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 8000:
                self.maker_fee_price = round_to(2 * 8000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 8500:
                self.maker_fee_price = round_to(2 * 8500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 9000:
                self.maker_fee_price = round_to(2 * 9000 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 9500:
                self.maker_fee_price = round_to(2 * 9500 * self.maker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 10000:
                self.maker_fee_price = round_to(2 * 10000 * self.maker_fee_percent / 100, self.pricetick)
            else:
                self.maker_fee_price = round_to(2 * self.close_price * self.maker_fee_percent / 100, self.pricetick)
        else:
            self.maker_fee_price = 0

        self.extra_price = round_to(self.maker_fee_price + self.profit_pricetick * self.pricetick, self.pricetick)


    """
    "   Desc: Calc a taker fee price per unit volume according to several price range
    """
    def calc_taker_fee_price(self):
        if self.taker_fee_percent > 0:
            if self.close_price <= 1000:
                self.taker_fee_price = round_to(2 * 1000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 1500:
                self.taker_fee_price = round_to(2 * 1500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 2000:
                self.taker_fee_price = round_to(2 * 2000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 2500:
                self.taker_fee_price = round_to(2 * 2500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 3000:
                self.taker_fee_price = round_to(2 * 3000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 3500:
                self.taker_fee_price = round_to(2 * 3500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 4000:
                self.taker_fee_price = round_to(2 * 4000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 4500:
                self.taker_fee_price = round_to(2 * 4500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 5000:
                self.taker_fee_price = round_to(2 * 5000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 5500:
                self.taker_fee_price = round_to(2 * 5500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 6000:
                self.taker_fee_price = round_to(2 * 6000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 6500:
                self.taker_fee_price = round_to(2 * 6500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 7000:
                self.taker_fee_price = round_to(2 * 7000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 7500:
                self.taker_fee_price = round_to(2 * 7500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 8000:
                self.taker_fee_price = round_to(2 * 8000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 8500:
                self.taker_fee_price = round_to(2 * 8500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 9000:
                self.taker_fee_price = round_to(2 * 9000 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 9500:
                self.taker_fee_price = round_to(2 * 9500 * self.taker_fee_percent / 100, self.pricetick)
            elif self.close_price <= 10000:
                self.taker_fee_price = round_to(2 * 10000 * self.taker_fee_percent / 100, self.pricetick)
            else:
                self.taker_fee_price = round_to(2 * self.close_price * self.taker_fee_percent / 100, self.pricetick)
        else:
            self.taker_fee_price = 0


    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            if account.accountid in self.symbol:
                self.balance = account.balance


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.traded_long_open_order_dict = {}
                    if self.long_update_pnl == 1:
                        self.long_pnl = 0
                        self.long_update_pnl = 0

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.traded_short_open_order_dict = {}
                    if self.short_update_pnl == 1:
                        self.short_pnl = 0
                        self.short_update_pnl = 0

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price


    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.current_traded_volume += round_to(order.volume, self.min_volume)
                self.total_volume += round_to(order.volume, self.min_volume)

                if order.type == OrderType.LIMIT:
                    self.current_traded_amount += round(order.price * order.volume, 5)
                    self.total_amount += round(order.price * order.volume, 5)

                    direction = self.order_info_queue[vt_orderid]['direction']
                    offset = self.order_info_queue[vt_orderid]['offset']
                    direction_offset = self.get_order_direction_offset_str(direction, offset)

                    self.traded_summary['maker'] += 1
                    self.rebate -= round(order.price * order.volume * self.maker_fee_percent / 100, 5)

                    if direction == LONG:
                        if offset == OPEN:
                            long_open_order_price = round_to(order.price + self.extra_price, self.pricetick)
                            long_open_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(LONG, long_open_order_price, long_open_volume, 0)

                            if self.maker_fee_percent > 0:
                                self.long_update_pnl = 2
                        elif offset == CLOSE:
                            long_close_order_price = round_to(order.price, self.pricetick)
                            long_close_order_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(LONG, long_close_order_price, long_close_order_volume, 1)

                            if self.maker_fee_percent < 0:
                                self.short_maker_rebate = round(order.price * order.volume * self.maker_fee_percent / 100, 5)

                            self.short_update_pnl = 2
                    elif direction == SHORT:
                        if offset == OPEN:
                            short_open_order_price = round_to(order.price - self.extra_price, self.pricetick)
                            short_open_order_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(SHORT, short_open_order_price, short_open_order_volume, 0)

                            if self.maker_fee_percent > 0:
                                self.short_update_pnl = 2
                        elif offset == CLOSE:
                            short_close_order_price = round_to(order.price, self.pricetick)
                            short_close_order_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(SHORT, short_close_order_price, short_close_order_volume, 1)

                            if self.maker_fee_percent < 0:
                                self.long_maker_rebate = round(order.price * order.volume * self.maker_fee_percent / 100, 5)

                            self.long_update_pnl = 2

                    self.write_tradedinfo_to_file()
                elif order.type == OrderType.MARKET:
                    direction = order.direction
                    self.current_traded_amount += round(self.close_price * order.volume, 5)
                    self.total_amount += round(self.close_price * order.volume, 5)

                    self.traded_summary['taker'] += 1
                    self.commission -= round(self.close_price * order.volume * self.taker_fee_percent / 100, 5)

                # current date and time
                now = datetime.now()
                date_time = now.strftime("%Y-%m-%d %H:%M:%S")

                long_entry_price = round_to(self.entry_price[LONG], self.pricetick)
                short_entry_price = round_to(self.entry_price[SHORT], self.pricetick)

                long_max_price = 0
                long_min_price = 0
                if len(self.traded_long_open_order_dict) > 0:
                    long_max_price = round_to(max(self.traded_long_open_order_dict.keys()), self.pricetick)
                    long_min_price = round_to(min(self.traded_long_open_order_dict.keys()), self.pricetick)

                short_min_price = 0
                short_max_price = 0
                if len(self.traded_short_open_order_dict) > 0:
                    short_min_price = round_to(min(self.traded_short_open_order_dict.keys()), self.pricetick)
                    short_max_price = round_to(max(self.traded_short_open_order_dict.keys()), self.pricetick)

                if order.type == OrderType.LIMIT:
                    if direction == LONG:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')
                    elif direction == SHORT:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')
                elif order.type == OrderType.MARKET:
                    if direction == LONG:
                        print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{"LONG": >9}{long_entry_price: >10}{self.close_price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')
                    elif direction == SHORT:
                        print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <5}{PRICE_TRENDING[self.ma_status]: >6}{"SHORT": >9}{short_entry_price: >10}{self.close_price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 3): >15}{date_time: >27}')
            except:
                pass
        elif order.status == CANCELLED:
            self.traded_summary['cancelled'] += 1
        elif order.status == REJECTED:
            self.traded_summary['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")


    """
    "   Desc: Write a dict to a txt file
    """
    def write_dict_to_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\root\\strategies\\long_dict_binance.txt"
        else:
            log_file = "C:\\Users\\root\\strategies\\short_dict_binance.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            if direction == SHORT:
                f.write(str(self.traded_short_open_order_dict).replace("{", "").replace("}", ""))
            else:
                f.write(str(self.traded_long_open_order_dict).replace("{", "").replace("}", ""))


    """
    "   Desc: Read dict from a txt file
    """
    def read_dict_from_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\root\\strategies\\long_dict_binance.txt"
        else:
            log_file = "C:\\Users\\root\\strategies\\short_dict_binance.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                return False
            else:
                if direction == SHORT:
                    self.traded_short_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                else:
                    self.traded_long_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                return True


    """
    "   Desc: Write a traded info to a log file
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\root\\strategies\\log_mt_binance.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{round(self.start_balance, 5)}, {self.total_runtime}, {round_to(self.total_volume, self.min_volume)}, {round(self.total_amount, 5)}, {round(self.rebate, 5)}, {round(self.commission, 5)}, {round(self.long_pnl, 5)}, {round(self.short_pnl, 5)}'
            f.write(traded_info)


    """
    "   Desc: Read a traded info from a log file
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\root\\strategies\\log_mt_binance.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.start_balance = 0
                self.total_runtime = 0
                self.total_volume = 0
                self.total_amount = 0
                self.rebate = 0
                self.commission = 0
                self.long_pnl = 0
                self.short_pnl = 0
            else:
                self.start_balance = float(data.split(', ')[0].strip())
                self.total_runtime = float(data.split(', ')[1].strip())
                self.total_volume = float(data.split(', ')[2].strip())
                self.total_amount = float(data.split(', ')[3].strip())
                self.rebate = float(data.split(', ')[4].strip())
                self.commission = float(data.split(', ')[5].strip())
                self.long_pnl = float(data.split(', ')[6].strip())
                self.short_pnl = float(data.split(', ')[7].strip())
