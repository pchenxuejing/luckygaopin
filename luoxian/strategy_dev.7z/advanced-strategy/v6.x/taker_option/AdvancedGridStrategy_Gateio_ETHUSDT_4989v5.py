from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}
TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(Days)", 1: "Earned($)", 2: "D/M/Y(%)", 3: "Trade Volume($)", 4: "Maker/Taker Fee($)", 5: "Max.($)", 6: "Min.($)"}

class AdvancedGridStrategy_Gateio_ETHUSDT_4989v5(CtaTemplate):

    author = "AdvancedGridStrategy(Gateio Futures)_ETHUSDT_4989v5"

    # Parameters
    start_balance = 0.0                     # a start balance (funded amount at first time)
    leverage = 100                          # a leverage
    profit_tick = 2                         # a profit pricetick
    fast_period = 5                         # a fast_period of moving average
    slow_period = 20                        # a slow_period of moving average
    maker_fee_percent = 0.012               # a maker fee, it depends on exchange policy
    taker_fee_percent = 0.03                # a taker fee, it depends on exchange policy
    open_order_min_price = 10               # an open order min price, it depends on exchange policy
    max_close_volume = 200                  # a max close volume of one time, it depends on exchange policy
    option = 0                              # 0: default, 1: do not send open order when position is 0, 2: close all positions with market price, 3: do not send long open order, 4: do not send short open order

    # Variables
    balance = 0                             # an wallet balance of account
    fixed_balance = 0                       # a fixed balance (min of start_balance and current balance)
    max_balance = 0                         # maximium value of balance when trading
    min_balance = 0                         # minimium value of balance when trading
    rebate = 0                              # a rebate till now (for a maker)
    commission = 0                          # a commission till now (for a taker)
    max_pos_volume = 0                      # a max pos volume
    open_min_volume = 0                     # an open min volume, will be calculated by open_order_min_price (it depends on exchange policy)
    open_init_volume = 0                    # an opne init volume per a 1$
    strategy_min_volume = 0                 # a min volume of strategy
    extra_price = 0                         # a plus of maker_fee and profit
    market_price = 0                        # a market price

    # k-line
    fast_ma = 0                             # a ma value of fast period
    slow_ma = 0                             # a ma value of slow period
    ma_status = 0                           # 0: None, 1: Bullish, 2: Bearish

    traded_long_open_order_dict = {}        # a dict for traded long_open price and volume
    traded_short_open_order_dict = {}       # a dict for traded short_open price and volume

    long_open_traded_min_max_price = {}     # a min/max price of traded_long_open_order_dict
    short_open_traded_min_max_price = {}    # a min/max price of traded_short_open_order_dict

    # un/realizedPNL
    realized_pnl = {}                       # an realizedPNL of long/short position
    unrealized_pnl = {}                     # an unrealizedPNL of long/short position
    traded_open_volume = {}                 # a volume of traded long/short open

    # Statistic data
    start_time = 0                          # a start time when strategy is started
    last_runtime = 0                        # a last runtime
    total_runtime = 0                       # a total runtime
    total_volume = 0                        # a total traded volume
    total_amount = 0                        # a total traded amount
    current_runtime = 0                     # a current runtime
    current_traded_volume = 0               # a current traded volume
    current_traded_amount = 0               # a current traded amount

    pos_volume = {LONG: 0, SHORT: 0}        # a position volume
    last_pos_volume = {LONG: 0, SHORT: 0}   # a last position volume before closing all positoins
    entry_price = {LONG: 0, SHORT: 0}       # an entry price of position

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['start_balance', 'leverage', 'profit_tick', 'fast_period', 'slow_period', 'maker_fee_percent', 'taker_fee_percent', 'max_close_volume', 'open_order_min_price', 'option']
    variables = ['fixed_balance', 'max_balance', 'min_balance', 'strategy_min_volume', 'open_init_volume', 'open_min_volume', 'max_pos_volume']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # k-line
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume = contract.min_volume

        # symbol (removed '.ExchangeName')
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.main_process_thread = None
        self.dict_filtering_thread = None

        self.order_info_queue = {}
        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.last_pos_volume = {LONG: 0, SHORT: 0}

        self.traded_long_open_order_dict = {}
        self.traded_short_open_order_dict = {}

        self.long_open_traded_min_max_price = {'min': 0, 'max': 0}
        self.short_open_traded_min_max_price = {'min': 0, 'max': 0}

        self.realized_pnl = {LONG: 0, SHORT: 0}
        self.unrealized_pnl = {LONG: 0, SHORT: 0}
        self.traded_open_volume = {LONG: 0, SHORT: 0}


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('GATEIOS')

        # k-line
        self.load_bar(2)


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.stop_main_process = False

        # main thread
        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.main_process_thread.start()

        # filtering dict file in order to remove an unnecessary key/value
        self.dict_filtering_thread = Thread(target = self.dict_filtering)
        self.dict_filtering_thread.setDaemon(True)
        self.dict_filtering_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        # k-line
        self.bargenerator.update_tick(tick)

        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        am = self.arraymanager
        am.update_bar(bar)
        if not am.inited:
            return

        self.fast_ma = am.ema(self.fast_period)
        self.slow_ma = am.ema(self.slow_period)

        self.put_event()


    """
    "   Desc: filtering thread
    """
    def dict_filtering(self):
        while True:
            if len(self.traded_long_open_order_dict) > 0 and len(self.traded_short_open_order_dict) > 0:
                if self.market_price > self.short_open_traded_min_max_price['max']:
                    key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                    for k in sorted(key_copy_long):
                        if self.traded_long_open_order_dict[k] == 0.0:
                            del self.traded_long_open_order_dict[k]
                        else:
                            if len(str(k)) > 9:
                                v = self.traded_long_open_order_dict[k]
                                r_k = round_to(k, self.pricetick)
                                del self.traded_long_open_order_dict[k]
                                self.traded_long_open_order_dict[r_k] = v

                if self.market_price < self.long_open_traded_min_max_price['min']:
                    key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                    for k in sorted(key_copy_short, reverse=True):
                        if self.traded_short_open_order_dict[k] == 0.0:
                            del self.traded_short_open_order_dict[k]
                        else:
                            if len(str(k)) > 9:
                                v = self.traded_short_open_order_dict[k]
                                r_k = round_to(k, self.pricetick)
                                del self.traded_short_open_order_dict[k]
                                self.traded_short_open_order_dict[r_k] = v

            sleep(10)


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        self.read_tradedinfo_from_file()
        self.read_dict_from_file(LONG)
        self.read_dict_from_file(SHORT)

        if self.start_time == 0:
            self.start_time = time()

        if self.last_runtime == 0:
            self.last_runtime = self.total_runtime

        if self.min_balance == 0:
            self.min_balance = self.balance

        # main process daemon
        print_count = 0
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            if self.balance > self.max_balance:
                self.max_balance = self.balance

            if self.balance < self.min_balance:
                self.min_balance = self.balance

            if print_count == 333 or print_count == 0:
                print(f'==')
                print(f'|{TRADED_INFO_TITLE[0]: >15}{TRADED_INFO_TITLE[1]: >24}{TRADED_INFO_TITLE[2]: >24}{TRADED_INFO_TITLE[3]: >24}{TRADED_INFO_TITLE[4]: >24}{TRADED_INFO_TITLE[5]: >16}{TRADED_INFO_TITLE[6]: >16} |')
                print(f'--------------------------------------------------------------------------------------------------------------------------------------------------')
                runtime_days = round(self.total_runtime / 1440, 2)
                profit = round(self.balance - self.start_balance, 2)
                profit_percent = f'{round((profit / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (self.start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0
                total_amount = round(self.total_amount, 2)
                rebate_commission = f'{round(self.rebate, 2)}/{round(self.commission, 2)}'
                max_balance = round(self.max_balance, 2)
                min_balance = round(self.min_balance, 2)
                print(f'|{runtime_days: >14}{profit: >24}{profit_percent: >24}{total_amount: >24}{rebate_commission: >24}{max_balance: >16}{min_balance: >16}  |')
                print(f'==')
                print_count = 1
            print_count += 1

            self.current_runtime = round((time() - self.start_time) / 60)
            self.total_runtime = self.last_runtime + self.current_runtime

            self.unrealized_pnl[LONG] = round((self.market_price - self.entry_price[LONG]) * self.pos_volume[LONG], 2) if self.pos_volume[LONG] > 0 else 0
            self.unrealized_pnl[SHORT] = round((self.entry_price[SHORT] - self.market_price) * self.pos_volume[SHORT], 2) if self.pos_volume[SHORT] > 0 else 0

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        del self.order_info_queue[open_orderid]
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.registered_order_info[direction][OPEN] = ''
                        del self.order_info_queue[open_orderid]
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            del self.order_info_queue[close_orderid]
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.registered_order_info[direction][CLOSE] = ''
                            del self.order_info_queue[close_orderid]
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)

        sleep(2)

        # cancel all long/short open/close orders
        for direction in (LONG, SHORT):
            open_orderid = self.registered_order_info[direction][OPEN]
            if open_orderid != '':
                if open_orderid in self.order_info_queue and (self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED):
                    self.cancel_order(open_orderid)

            close_orderid = self.registered_order_info[direction][CLOSE]
            if close_orderid != '':
                if close_orderid in self.order_info_queue and (self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED):
                    self.cancel_order(close_orderid)

        self.write_dict_to_file(LONG)
        self.write_dict_to_file(SHORT)
        self.write_tradedinfo_to_file()

        sleep(2)

        self.stop_main_process = False


    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1):
        if self.stop_main_process == True:
            return

        # calc a max_pos, open_init_volume and strategy_min_volume
        self.calc_max_pos_and_init_volume()

        new_price = self.get_order_price(direction, offset)
        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get previous vt_orderid
        previous_vt_orderid = self.registered_order_info[direction][offset]
        if previous_vt_orderid != '':
            if previous_vt_orderid not in self.order_info_queue or self.order_info_queue[previous_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[previous_vt_orderid]['status'] == REJECTED:
                return
            elif self.order_info_queue[previous_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[previous_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(previous_vt_orderid)

            self.registered_order_info[direction][offset] = ''
            del self.order_info_queue[previous_vt_orderid]

        if new_price == 0:
            return

        # calculate the new volume
        if offset == OPEN:
            if self.option == 2:
                return

            new_volume = self.strategy_min_volume
            if direction == LONG:
                if self.pos_volume[LONG] > 0:
                    if self.pos_volume[LONG] > self.max_pos_volume:
                        return
                    else:
                        rate_with_max_price = min(round(self.long_open_traded_min_max_price['max'] / new_price, 2), 2)
                        volume_rate = 1 / round(self.fast_ma - new_price + 2) if new_price < self.fast_ma else 1
                        new_volume = volume_rate * rate_with_max_price * self.open_init_volume * (self.long_open_traded_min_max_price['min'] - new_price - self.extra_price)
                        if self.long_open_traded_min_max_price['min'] > self.entry_price[LONG]:
                            if self.entry_price[LONG] > new_price:
                                new_volume = volume_rate * rate_with_max_price * self.open_init_volume * (self.entry_price[LONG] - new_price - self.extra_price)
                            else:
                                new_volume = min(0.5 * volume_rate * rate_with_max_price * self.open_init_volume * (self.long_open_traded_min_max_price['min'] - new_price - self.extra_price), self.open_init_volume)

                        if new_volume + self.pos_volume[LONG] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[LONG]
            elif direction == SHORT:
                if self.pos_volume[SHORT] > 0:
                    if self.pos_volume[SHORT] > self.max_pos_volume:
                        return
                    else:
                        rate_with_min_price = min(round(new_price / self.short_open_traded_min_max_price['min'], 2), 2)
                        volume_rate = 1 / round(new_price - self.fast_ma + 2) if new_price > self.fast_ma else 1
                        new_volume = volume_rate * rate_with_min_price * self.open_init_volume * (new_price - self.short_open_traded_min_max_price['max'] - self.extra_price)
                        if self.short_open_traded_min_max_price['max'] < self.entry_price[SHORT]:
                            if new_price > self.entry_price[SHORT]:
                                new_volume = volume_rate * rate_with_min_price * self.open_init_volume * (new_price - self.entry_price[SHORT] - self.extra_price)
                            else:
                                new_volume = min(0.5 * volume_rate * rate_with_min_price * self.open_init_volume * (new_price - self.short_open_traded_min_max_price['max'] - self.extra_price), self.open_init_volume)

                        if new_volume + self.pos_volume[SHORT] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[SHORT]

            new_volume = round_to(new_volume, self.min_volume)
            if new_volume < self.strategy_min_volume:
                return
        elif offset == CLOSE:
            if direction == LONG:
                if self.pos_volume[SHORT] > 0:
                    if self.option == 2:
                        new_volume = self.pos_volume[SHORT]
                    else:
                        self.unrealized_pnl[SHORT] = round((self.entry_price[SHORT] - new_price) * self.pos_volume[SHORT], 2)
                        pos_fee = self.pos_volume[SHORT] * new_price * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
                        if self.unrealized_pnl[SHORT] >= 0 and self.realized_pnl[SHORT] + self.unrealized_pnl[SHORT] - self.traded_open_volume[SHORT] * self.profit_tick * self.pricetick - pos_fee > 0:
                            new_volume = self.pos_volume[SHORT]
                        else:
                            new_volume = self.get_close_volume_from_dict(LONG, new_price)

                        if new_volume > self.pos_volume[SHORT]:
                            new_volume = self.pos_volume[SHORT]
                else:
                    return
            elif direction == SHORT:
                if self.pos_volume[LONG] > 0:
                    if self.option == 2:
                        new_volume = self.pos_volume[LONG]
                    else:
                        self.unrealized_pnl[LONG] = round((new_price - self.entry_price[LONG]) * self.pos_volume[LONG], 2)
                        pos_fee = self.pos_volume[LONG] * new_price * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
                        if self.unrealized_pnl[LONG] >= 0 and self.realized_pnl[LONG] + self.unrealized_pnl[LONG] - self.traded_open_volume[LONG] * self.profit_tick * self.pricetick - pos_fee > 0:
                            new_volume = self.pos_volume[LONG]
                        else:
                            new_volume = self.get_close_volume_from_dict(SHORT, new_price)

                        if new_volume > self.pos_volume[LONG]:
                            new_volume = self.pos_volume[LONG]
                else:
                    return

            new_volume = round_to(new_volume, self.min_volume)
            if new_volume < self.open_min_volume:
                return

        if new_volume > self.max_close_volume:
            new_volume = self.max_close_volume

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return
        else:
            return


    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        if len(self.traded_long_open_order_dict) > 0:
            self.long_open_traded_min_max_price['min'] = min(self.traded_long_open_order_dict.keys())
            self.long_open_traded_min_max_price['max'] = max(self.traded_long_open_order_dict.keys())

        if len(self.traded_short_open_order_dict) > 0:
            self.short_open_traded_min_max_price['max'] = max(self.traded_short_open_order_dict.keys())
            self.short_open_traded_min_max_price['min'] = min(self.traded_short_open_order_dict.keys())

        if self.fast_ma > self.slow_ma:
            self.ma_status = 1
        elif self.fast_ma < self.slow_ma:
            self.ma_status = 2

        if direction == LONG:
            price = tick.bid_price_1
            if offset == OPEN:
                if self.option == 1 and self.pos_volume[LONG] == 0:
                    return 0
                elif self.option == 3:
                    return 0
                else:
                    if self.ma_status == 2:
                        if self.unrealized_pnl[LONG] <= 0:
                            return 0
                    else:
                        if self.unrealized_pnl[SHORT] > 0 and self.unrealized_pnl[LONG] < 0:
                            return 0

                    if self.pos_volume[LONG] > self.max_pos_volume:
                        return 0

                    if tick.bid_volume_1 < tick.ask_volume_1:
                        price = tick.bid_price_3 - self.pricetick
        elif direction == SHORT:
            price = tick.ask_price_1
            if offset == OPEN:
                if self.option == 1 and self.pos_volume[SHORT] == 0:
                    return 0
                elif self.option == 4:
                    return 0
                else:
                    if self.ma_status == 1:
                        if self.unrealized_pnl[SHORT] <= 0:
                            return 0
                    else:
                        if self.unrealized_pnl[LONG] > 0 and self.unrealized_pnl[SHORT] < 0:
                            return 0

                    if self.pos_volume[SHORT] > self.max_pos_volume:
                        return 0

                    if tick.ask_volume_1 < tick.bid_volume_1:
                        price = tick.ask_price_3 + self.pricetick

        price = round_to(price, self.pricetick)

        return price


    """
    "   Desc: Calculate max_pos_volume
    """
    def calc_max_pos_and_init_volume(self):
        self.fixed_balance = round(min(self.start_balance, self.balance), 2)
        self.max_pos_volume = round_to(self.fixed_balance * self.leverage / self.market_price, self.min_volume)
        self.open_min_volume = round_to(self.open_order_min_price / self.market_price, self.min_volume)
        self.open_init_volume = round_to(0.5 * self.max_pos_volume / self.market_price, self.min_volume)

        maker_fee_price = 2 * self.market_price * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
        self.extra_price = round_to(maker_fee_price + self.profit_tick * self.pricetick, self.pricetick)
        self.strategy_min_volume = round_to(max(0.5 * self.open_init_volume, self.open_min_volume), self.min_volume)


    """
    "   Desc: Update traded open order dict when maker order has been processed
    """
    def update_order_dict_when_maker(self, direction, price, volume, status):
        price = round_to(price, self.pricetick)
        volume = round_to(volume, self.min_volume)
        if float(volume) <= 0.0:
            return

        if status == 0:
            if direction == LONG:
                if len(self.traded_long_open_order_dict) > 0:
                    if volume > 2 * self.strategy_min_volume and price < self.entry_price[LONG]:
                        rate = round(5 * round(self.long_open_traded_min_max_price['max'] / price, 2), 1)
                        first_price = round_to(self.long_open_traded_min_max_price['min'] - (volume / self.open_init_volume) / rate, self.pricetick)
                        first_volume = round_to(volume / rate, self.min_volume)
                        if first_volume >= self.open_min_volume:
                            if first_price in self.traded_long_open_order_dict:
                                self.traded_long_open_order_dict[first_price] += first_volume
                            else:
                                self.traded_long_open_order_dict[first_price] = first_volume

                            second_volume = round_to(volume - first_volume, self.min_volume)
                            if price in self.traded_long_open_order_dict:
                                self.traded_long_open_order_dict[price] += second_volume
                            else:
                                self.traded_long_open_order_dict[price] = second_volume
                        else:
                            if price in self.traded_long_open_order_dict:
                                self.traded_long_open_order_dict[price] += volume
                            else:
                                self.traded_long_open_order_dict[price] = volume
                    else:
                        if price in self.traded_long_open_order_dict:
                            self.traded_long_open_order_dict[price] += volume
                        else:
                            self.traded_long_open_order_dict[price] = volume
                else:
                    self.traded_long_open_order_dict[price] = volume
                self.write_dict_to_file(LONG)
            elif direction == SHORT:
                if len(self.traded_short_open_order_dict) > 0:
                    if volume > 2 * self.strategy_min_volume and price > self.entry_price[SHORT]:
                        rate = round(5 * round(price / self.short_open_traded_min_max_price['min'], 2), 1)
                        first_price = round_to(self.short_open_traded_min_max_price['max'] + (volume / self.open_init_volume) / rate, self.pricetick)
                        first_volume = round_to(volume / rate, self.min_volume)
                        if first_volume >= self.open_min_volume:
                            if price in self.traded_short_open_order_dict:
                                self.traded_short_open_order_dict[first_price] += first_volume
                            else:
                                self.traded_short_open_order_dict[first_price] = first_volume

                            second_volume = round_to(volume - first_volume, self.min_volume)
                            if price in self.traded_short_open_order_dict:
                                self.traded_short_open_order_dict[price] += second_volume
                            else:
                                self.traded_short_open_order_dict[price] = second_volume
                        else:
                            if price in self.traded_short_open_order_dict:
                                self.traded_short_open_order_dict[price] += volume
                            else:
                                self.traded_short_open_order_dict[price] = volume
                    else:
                        if price in self.traded_short_open_order_dict:
                            self.traded_short_open_order_dict[price] += volume
                        else:
                            self.traded_short_open_order_dict[price] = volume
                else:
                    self.traded_short_open_order_dict[price] = volume
                self.write_dict_to_file(SHORT)
        elif status == 1:
            if direction == LONG:
                if len(self.traded_short_open_order_dict) > 0:
                    key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                    for k in sorted(key_copy_short, reverse=True):
                        if k >= price and volume > 0:
                            if self.traded_short_open_order_dict[k] == 0.0:
                                del self.traded_short_open_order_dict[k]
                                continue

                            if volume > self.traded_short_open_order_dict[k]:
                                volume -= self.traded_short_open_order_dict[k]
                                del self.traded_short_open_order_dict[k]
                            elif volume == self.traded_short_open_order_dict[k]:
                                del self.traded_short_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_short_open_order_dict[k]
                                if float(k_v) > 0.0 and k_v > volume:
                                    self.traded_short_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break
                    self.write_dict_to_file(SHORT)
            elif direction == SHORT:
                if len(self.traded_long_open_order_dict) > 0:
                    key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                    for k in sorted(key_copy_long):
                        if price >= k and volume > 0:
                            if self.traded_long_open_order_dict[k] == 0.0:
                                del self.traded_long_open_order_dict[k]
                                continue

                            if volume > self.traded_long_open_order_dict[k]:
                                volume -= self.traded_long_open_order_dict[k]
                                del self.traded_long_open_order_dict[k]
                            elif volume == self.traded_long_open_order_dict[k]:
                                del self.traded_long_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_long_open_order_dict[k]
                                if float(k_v) > 0.0 and k_v > volume:
                                    self.traded_long_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break
                    self.write_dict_to_file(LONG)


    """
    "   Desc: Get close voluem from an open order dict
    """
    def get_close_volume_from_dict(self, direction, price):
        close_volume = 0
        if direction == LONG:
            if len(self.traded_short_open_order_dict) > 0:
                key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                for k in sorted(key_copy_short, reverse=True):
                    if k >= price:
                        if self.traded_short_open_order_dict[k] == 0.0:
                            del self.traded_short_open_order_dict[k]
                        else:
                            close_volume += self.traded_short_open_order_dict[k]
        elif direction == SHORT:
            if len(self.traded_long_open_order_dict) > 0:
                key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                for k in sorted(key_copy_long):
                    if price >= k:
                        if self.traded_long_open_order_dict[k] == 0.0:
                            del self.traded_long_open_order_dict[k]
                        else:
                            close_volume += self.traded_long_open_order_dict[k]

        return round_to(close_volume, self.min_volume)


    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'GATEIOS':
            if account.accountid in self.symbol:
                self.balance = account.available


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.traded_long_open_order_dict = {}
                    self.realized_pnl[LONG] = 0
                    self.unrealized_pnl[LONG] = 0
                    self.traded_open_volume[LONG] = 0

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.traded_short_open_order_dict = {}
                    self.realized_pnl[SHORT] = 0
                    self.unrealized_pnl[SHORT] = 0
                    self.traded_open_volume[SHORT] = 0

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price


    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.current_traded_volume += round_to(order.volume, self.min_volume)
                self.total_volume += round_to(order.volume, self.min_volume)

                if order.type == OrderType.LIMIT:
                    self.current_traded_amount += round(order.price * order.volume, 2)
                    self.total_amount += round(order.price * order.volume, 2)

                    direction = self.order_info_queue[vt_orderid]['direction']
                    offset = self.order_info_queue[vt_orderid]['offset']
                    direction_offset = self.get_order_direction_offset_str(direction, offset)

                    self.traded_summary['maker'] += 1
                    self.rebate -= round(order.price * order.volume * self.maker_fee_percent / 100, 2)

                    if direction == LONG:
                        if offset == OPEN:
                            long_open_order_price = round_to(order.price + self.extra_price, self.pricetick)
                            long_open_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(LONG, long_open_order_price, long_open_volume, 0)

                            # calc long_pnl
                            self.traded_open_volume[LONG] += long_open_volume

                            if self.maker_fee_percent > 0:
                                self.realized_pnl[LONG] -= order.price * order.volume * self.maker_fee_percent / 100
                        elif offset == CLOSE:
                            long_close_order_price = round_to(order.price, self.pricetick)
                            long_close_order_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(LONG, long_close_order_price, long_close_order_volume, 1)

                            # calc short_pnl
                            if self.maker_fee_percent > 0:
                                self.realized_pnl[SHORT] -= order.price * order.volume * self.maker_fee_percent / 100

                            if self.pos_volume[SHORT] > 0:
                                loss_amount = round((self.entry_price[SHORT] - order.price) * order.volume, 2)
                                self.realized_pnl[SHORT] += loss_amount
                    elif direction == SHORT:
                        if offset == OPEN:
                            short_open_order_price = round_to(order.price - self.extra_price, self.pricetick)
                            short_open_order_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(SHORT, short_open_order_price, short_open_order_volume, 0)

                            # calc short_pnl
                            self.traded_open_volume[SHORT] += short_open_order_volume

                            if self.maker_fee_percent > 0:
                                self.realized_pnl[SHORT] -= order.price * order.volume * self.maker_fee_percent / 100
                        elif offset == CLOSE:
                            short_close_order_price = round_to(order.price, self.pricetick)
                            short_close_order_volume = round_to(order.volume, self.min_volume)
                            self.update_order_dict_when_maker(SHORT, short_close_order_price, short_close_order_volume, 1)

                            # calc long_pnl
                            if self.maker_fee_percent > 0:
                                self.realized_pnl[LONG] -= order.price * order.volume * self.maker_fee_percent / 100

                            if self.pos_volume[LONG] > 0:
                                loss_amount = round((order.price - self.entry_price[LONG]) * order.volume, 2)
                                self.realized_pnl[LONG] += loss_amount
                    self.write_tradedinfo_to_file()
                elif order.type == OrderType.MARKET:
                    direction = order.direction
                    self.current_traded_amount += round(self.market_price * order.volume, 2)
                    self.total_amount += round(self.market_price * order.volume, 2)

                    self.traded_summary['taker'] += 1
                    self.commission -= round(self.market_price * order.volume * self.taker_fee_percent / 100, 2)

                long_entry_price = round_to(self.entry_price[LONG], self.pricetick)
                short_entry_price = round_to(self.entry_price[SHORT], self.pricetick)

                long_max_price = 0
                long_min_price = 0
                if len(self.traded_long_open_order_dict) > 0:
                    long_max_price = round_to(max(self.traded_long_open_order_dict.keys()), self.pricetick)
                    long_min_price = round_to(min(self.traded_long_open_order_dict.keys()), self.pricetick)

                short_min_price = 0
                short_max_price = 0
                if len(self.traded_short_open_order_dict) > 0:
                    short_min_price = round_to(min(self.traded_short_open_order_dict.keys()), self.pricetick)
                    short_max_price = round_to(max(self.traded_short_open_order_dict.keys()), self.pricetick)

                # current date and time
                now = datetime.now()
                date_time = now.strftime("%Y-%m-%d %H:%M:%S")

                if order.type == OrderType.LIMIT:
                    if direction == LONG:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <3}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >10}{short_min_price: >12}{short_max_price: >9}{long_min_price: >12}{long_max_price: >9}{round_to(self.traded_open_volume[LONG], self.min_volume): >15}/{round(self.realized_pnl[LONG], 2): <10}{round(self.unrealized_pnl[LONG], 2): <10}{round_to(self.traded_open_volume[SHORT], self.min_volume): >12}/{round(self.realized_pnl[SHORT], 2): <10}{round(self.unrealized_pnl[SHORT], 2): <10}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 2): >15}{date_time: >27}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <3}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >10}{short_min_price: >12}{short_max_price: >9}{long_min_price: >12}{long_max_price: >9}{round_to(self.traded_open_volume[LONG], self.min_volume): >15}/{round(self.realized_pnl[LONG], 2): <10}{round(self.unrealized_pnl[LONG], 2): <10}{round_to(self.traded_open_volume[SHORT], self.min_volume): >12}/{round(self.realized_pnl[SHORT], 2): <10}{round(self.unrealized_pnl[SHORT], 2): <10}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 2): >15}{date_time: >27}')
                    elif direction == SHORT:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <3}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >10}{short_min_price: >12}{short_max_price: >9}{long_min_price: >12}{long_max_price: >9}{round_to(self.traded_open_volume[LONG], self.min_volume): >15}/{round(self.realized_pnl[LONG], 2): <10}{round(self.unrealized_pnl[LONG], 2): <10}{round_to(self.traded_open_volume[SHORT], self.min_volume): >12}/{round(self.realized_pnl[SHORT], 2): <10}{round(self.unrealized_pnl[SHORT], 2): <10}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 2): >15}{date_time: >27}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <3}{PRICE_TRENDING[self.ma_status]: >6}{direction_offset: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >10}{short_min_price: >12}{short_max_price: >9}{long_min_price: >12}{long_max_price: >9}{round_to(self.traded_open_volume[LONG], self.min_volume): >15}/{round(self.realized_pnl[LONG], 2): <10}{round(self.unrealized_pnl[LONG], 2): <10}{round_to(self.traded_open_volume[SHORT], self.min_volume): >12}/{round(self.realized_pnl[SHORT], 2): <10}{round(self.unrealized_pnl[SHORT], 2): <10}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 2): >15}{date_time: >27}')
                elif order.type == OrderType.MARKET:
                    if direction == LONG:
                        print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <3}{PRICE_TRENDING[self.ma_status]: >6}{"LONG": >9}{long_entry_price: >10}{self.market_price: >12}{order.volume: >10}{short_min_price: >12}{short_max_price: >9}{long_min_price: >12}{long_max_price: >9}{round_to(self.traded_open_volume[LONG], self.min_volume): >15}/{round(self.realized_pnl[LONG], 2): <10}{round(self.unrealized_pnl[LONG], 2): <10}{round_to(self.traded_open_volume[SHORT], self.min_volume): >12}/{round(self.realized_pnl[SHORT], 2): <10}{round(self.unrealized_pnl[SHORT], 2): <10}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 2): >15}{date_time: >27}')
                    elif direction == SHORT:
                        print(f'{self.traded_summary["maker"]: >7}/{self.traded_summary["taker"]: <3}{PRICE_TRENDING[self.ma_status]: >6}{"SHORT": >9}{short_entry_price: >10}{self.market_price: >12}{order.volume: >10}{short_min_price: >12}{short_max_price: >9}{long_min_price: >12}{long_max_price: >9}{round_to(self.traded_open_volume[LONG], self.min_volume): >15}/{round(self.realized_pnl[LONG], 2): <10}{round(self.unrealized_pnl[LONG], 2): <10}{round_to(self.traded_open_volume[SHORT], self.min_volume): >12}/{round(self.realized_pnl[SHORT], 2): <10}{round(self.unrealized_pnl[SHORT], 2): <10}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{round(self.current_traded_amount, 2): >15}{date_time: >27}')
            except:
                pass
        elif order.status == CANCELLED:
            self.traded_summary['cancelled'] += 1
        elif order.status == REJECTED:
            self.traded_summary['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")


    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   Desc: Write a dict to a txt file
    """
    def write_dict_to_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\long_dict.txt"
        else:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\short_dict.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            if direction == SHORT:
                f.write(str(self.traded_short_open_order_dict).replace("{", "").replace("}", ""))
            else:
                f.write(str(self.traded_long_open_order_dict).replace("{", "").replace("}", ""))


    """
    "   Desc: Read dict from a txt file
    """
    def read_dict_from_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\long_dict.txt"
        else:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\short_dict.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                return False
            else:
                if direction == SHORT:
                    self.traded_short_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                else:
                    self.traded_long_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                return True


    """
    "   Desc: Write a traded info to a log file
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\gateio\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{self.total_runtime}, {round_to(self.total_volume, self.min_volume)}, {round(self.total_amount, 2)}, {round(self.rebate, 2)}, {round(self.commission, 2)}, {round(self.realized_pnl[LONG], 2)}, {round(self.realized_pnl[SHORT], 2)}, {round_to(self.traded_open_volume[LONG], self.min_volume)}, {round_to(self.traded_open_volume[SHORT], self.min_volume)}, {round(self.max_balance, 2)}, {round(self.min_balance, 2)}'
            f.write(traded_info)


    """
    "   Desc: Read a traded info from a log file
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\gateio\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.total_runtime = 0
                self.total_volume = 0
                self.total_amount = 0
                self.rebate = 0
                self.commission = 0
                self.realized_pnl[LONG] = 0
                self.realized_pnl[SHORT] = 0
                self.traded_open_volume[LONG] = 0
                self.traded_open_volume[SHORT] = 0
                self.max_balance = 0
                self.min_balance = 0
            else:
                self.total_runtime = float(data.split(', ')[0].strip())
                self.total_volume = float(data.split(', ')[1].strip())
                self.total_amount = float(data.split(', ')[2].strip())
                self.rebate = float(data.split(', ')[3].strip())
                self.commission = float(data.split(', ')[4].strip())
                self.realized_pnl[LONG] = float(data.split(', ')[5].strip())
                self.realized_pnl[SHORT] = float(data.split(', ')[6].strip())
                self.traded_open_volume[LONG] = float(data.split(', ')[7].strip())
                self.traded_open_volume[SHORT] = float(data.split(', ')[8].strip())
                self.max_balance = float(data.split(', ')[9].strip())
                self.min_balance = float(data.split(', ')[10].strip())
