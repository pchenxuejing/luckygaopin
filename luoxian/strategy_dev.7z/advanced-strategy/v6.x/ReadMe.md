======= 4989vx =======
- Main Logic
o removed a grid_gap
o open_init_volume means a volume amount per 1$

- 4989v2
o modifed a open volume logic (post_rate, rate)
o added a trend logic according to entry_price of long and short
o removed a fastest_ma parameter (using ask1/bid1_volume instead of ma value)

- 4989v3
This is a upgraded version of 4989v2.
o removed all lines related with k-line
o added a long/short_pnl logic in order to close all positions with the current market price
o added a long/short_traded_volume in order to calculate a pnl
o sending an open order according to comparing result with two positions size

- 4989v4
o sending an open order according to unrealized pnl and open_price/market_price

- 4989v5
o modified a update_order_dict function
o close all positions according to un/realizePNL and max_balance


- 4989v6
o sending an open order aoccording to compare of long/short position size

- 4989v8
o open order
last_traded_open_price

o close
according to unrealizedPNL compare result

- 4989v9 (Main version)
key point: trying to keep both positions as same size
o open order
last_traded_open_price

o close
according to position size

=== calc a unrealized/realized PNL ===
- Short
current entry_price[SHORT] is p1, v1
current price is p2(= p1 + delta), v2

At this time, entry_price[SHORT] = p1 + delta * v2 / (v1 + v2)

Therefore, when close p2 open order with p2 price, p2 - entry_price[SHORT] = delta * v1 / (v1 + v2), and realizedPNL = delta * v1 * v2 / (v1 + v2), unrealizedPNL = delta * v1 * v1 / (v1 + v2)

Hence, totalPNL = delta * v1 * v2 / (v1 + v2) + delta * v1 * v1 / (v1 + v2) = delta * v1


case v2=0.5 * v1:   realizedPNL = 1/3 * delta * v1, unrealizedPNL = 2/3 * delta * v1, totalPNL = delta * v1
case v2=1 * v1:     realizedPNL = 1/2 * delta * v1, unrealizedPNL = 1/2 * delta * v1, totalPNL = delta * v1
case v2=2 * v1:     realizedPNL = 2/3 * delta * v1, unrealizedPNL = 1/3 * delta * v1, totalPNL = delta * v1
case v2=3 * v1:     realizedPNL = 3/4 * delta * v1, unrealizedPNL = 1/4 * delta * v1, totalPNL = delta * v1
... ... ...

- Long
current entry_price[LONG] is p1, v1
current price is p2(= p1 - delta), v2

At this time, entry_price[LONG] = p1 - delta * v2 / (v1 + v2)

Therefore, when close p2 open order with p2 price, entry_price[LONG] - p2 = delta * v1 / (v1 + v2), and realizedPNL = delta * v1 * v2 / (v1 + v2), unrealizedPNL = delta * v1 * v1 / (v1 + v2)

Hence, totalPNL = delta * v1 * v2 / (v1 + v2) + delta * v1 * v1 / (v1 + v2) = delta * v1

case v2=0.5 * v1:   realizedPNL = 1/3 * delta * v1, unrealizedPNL = 2/3 * delta * v1, totalPNL = delta * v1
case v2=1 * v1:     realizedPNL = 1/2 * delta * v1, unrealizedPNL = 1/2 * delta * v1, totalPNL = delta * v1
case v2=2 * v1:     realizedPNL = 2/3 * delta * v1, unrealizedPNL = 1/3 * delta * v1, totalPNL = delta * v1
case v2=3 * v1:     realizedPNL = 3/4 * delta * v1, unrealizedPNL = 1/4 * delta * v1, totalPNL = delta * v1
... ... ...

That is, unrealizePNL and realizedPNL is in trade-off relation.

*** Afer all, when long/short open order is traded, the loss amount that close all positions with the p2 price will be detal * pos_volume.
market price: p
delta: 1$
unit_volume, v = (balance * leverage) / power(p, 2)

Therefore, PNL = delta * v = (balance * leverage) / power(p, 2)
Through above formulation, market price is higher, then pnl is lower. Otherwise, market price is lower, then pnl is higher.
In my strategy, short open order always has been sent when market price is going up, and long open order always has been sent when market price is going down.
Therefore, volume of long open order has to be lower than short open order.


=== make a long/short.txt file ===
import numpy as np

volume = 12804
start = 1483.85
end = 1604

result = ''
for p in np.arange(start + 1, end, 1.5):
    if volume <= 0:
        break
    v = 90 * (p - start)
    volume -= v
    start = p
    result += f'{p}:{v}, '

print(result)


=== checking total volume from a text file ===
from typing import Dict

order = {1203.3: 17.0, 1202.9: 5.0, 1202.4: 9.0, 1202.3: 2.0, 1202.05: 4.0, 1201.95: 2.0, 1201.5: 8.0, 1201.0: 8.0, 1200.15: 14.0, 1199.8: 6.0, 1199.55: 4.0}
v = 0
key_copy_short = tuple(order.keys())
for k in sorted(key_copy_short, reverse=True):
    v += order[k]

print(v)