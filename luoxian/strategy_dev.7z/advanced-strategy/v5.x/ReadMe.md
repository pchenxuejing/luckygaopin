======= v5.x =======
1. v5.5 (Advanced version of v4.8)

- New main variables
o pnl_percent
o update_pnl
o long/short_pnl calc method
o long/short_closed_volume
o when bullish, send only a long_open order. when bearish, send only a short_open order
o increase a grid_gap according to max and min price of traded open dictionary
o send a long/short_open order when price is larger(less) than entry_price with grid_gap
o a specific calc of open volume when position is 0

2. v5.5.5 (Advanced version of v5.5)

- Differences with v5.5
o removed a taker open order
o removed a logic of close all position according to pnl (in this version, close all position with taker order when 10% is larger than loss amount)
