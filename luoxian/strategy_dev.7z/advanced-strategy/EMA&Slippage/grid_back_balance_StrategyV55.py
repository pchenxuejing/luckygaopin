from vnpy.app.cta_strategy import (
    CtaTemplate,
    StopOrder,
    TickData,
    BarData,
    TradeData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset,Direction,Status,Interval
import datetime,time
from vnpy.trader.object import PositionData,AccountData
from copy import deepcopy
from vnpy.trader.event import EVENT_TIMER, EVENT_ACCOUNT, EVENT_POSITION
import talib

class GridBackBalanceStrategyV55(CtaTemplate):


    author = "回调插针网格v5"
    #策略控制开关
    grid_balance_status=1
    ama_status=0

    AMA_N = 15
    AMA_Length = 30
    AMA_Order_Pst = 0.01

    grid_num = 10 #上下 10个
    grid_gap_tick_count = 2
    
    lerver_rate=100
    big_percent=0.0011
    balance=0 #账户余额
    long_pos = 0  # 多头持仓
    short_pos = 0  # 空头持仓

    target_pos=0

    long_short_open = 0
    long_short_close = 0

    pos_num=0.2

    ama=0

    parameters = ['grid_balance_status','ama_status',"grid_num", "grid_gap_tick_count", "lerver_rate",'pos_num','AMA_N', 'AMA_Length', 'AMA_Order_Pst']
    variables = ['balance','long_pos','short_pos','target_pos','big_percent','long_short_open','long_short_close','ama']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        self.bg=BarGenerator(self.on_bar)
        self.am = ArrayManager()
        self.pricetick = self.get_pricetick()
        contract=self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume=contract.min_volume

        self.symbol=self.vt_symbol.split('.')[0]

        self.init()
    
    def init(self):
        self.grid_id={}
        self.close_grid_id={}
        self.close_grid_volume={}
        self.grid_price={}
        self.num_tick=0
        self.ma_direction=0
        self.last_trading=False
        self.ama_orders={'long_open':'','long_close':'','short_open':'','short_close':''}
        # self.id_balance={}
        
        self.last_tick=None
        self.last_ama_position = 0

        self.grid_gap = self.grid_gap_tick_count * self.pricetick

        self.break_num = 0
        self.break_direction = None

        self.last_long_pos = 0
        self.last_short_pos = 0
        self.market_price = 0

    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('BINANCES')

        # self.load_bar(int(self.AMA_Length*10/1440) + 2)
        self.write_log("策略初始化")
        
    def on_start(self):
        """
        Callback when strategy is started.
        """

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()
        
        self.init()

        self.write_log("策略启动")

    def on_stop(self):
        """
        Callback when strategy is stopped.
        """
        
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        # self.cancel_all()
        self.write_log("策略停止")

    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.bg.update_tick(tick)
        self.num_tick += 1

        self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

        if self.balance > 0:

            if not self.last_trading and self.trading:
                price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)
                self.process_grid_price(price)

                if "1" in self.grid_price and "-1" in self.grid_price:
                    if self.ama > self.grid_price["1"]:
                        self.last_ama_position = 1
                    elif self.ama <= self.grid_price["1"] and self.ama >= self.grid_price["-1"]:
                        self.last_ama_position = 0
                    elif self.ama < self.grid_price["-1"]:
                        self.last_ama_position = -1
            
            if self.trading:
                if self.grid_balance_status>0:
                    self.grid_balance_init() #网格平衡策略初始化
                
                if self.ama_status > 0 and self.ama > 0:

                    if "1" in self.grid_price and self.grid_price["1"] < self.ama and self.last_ama_position < 1:
                        print("AMA signal in Up:", self.ama)

                        short_close_volume = 0
                        for i in range(1,self.grid_num+1):
                            if str(i) in self.close_grid_volume and self.close_grid_volume[str(i)] != 0:
                                short_close_volume += self.close_grid_volume[str(i)]

                        if self.long_pos > 0 and self.long_pos > short_close_volume:
                            if self.ama_orders['short_close'] != '':
                                vt_orderid = self.ama_orders['short_close']
                                self.cancel_order(vt_orderid)

                            close_volume = round_to(self.long_pos - short_close_volume, self.min_volume)

                            if close_volume >= self.min_volume:
                                order_ids = self.sell(self.grid_price["1"], close_volume)
                                self.ama_orders['short_close'] = order_ids[-1]
                        
                        if self.ama_orders['short_open'] != '':
                            vt_orderid = self.ama_orders['short_open']
                            self.cancel_order(vt_orderid)

                        #     self.gateway.modify_order_price(self.symbol, vt_orderid.split('.')[-1], self.grid_price["1"])
                        # else:
                        order_ids = self.short(self.grid_price["1"], self.target_pos * self.AMA_Order_Pst)
                        self.ama_orders['short_open'] = order_ids[-1]
                    
                    elif "-1" in self.grid_price and self.grid_price["-1"] > self.ama and self.last_ama_position > -1:
                        print("AMA signal in Down:", self.ama)
 
                        long_close_volume = 0
                        for i in range(1,self.grid_num+1):
                            if str(-i) in self.close_grid_volume and self.close_grid_volume[str(-i)] != 0:
                                long_close_volume += self.close_grid_volume[str(-i)]

                        if self.short_pos > 0 and self.short_pos > long_close_volume:
                            if self.ama_orders['long_close'] != '':
                                vt_orderid = self.ama_orders['long_close']
                                self.cancel_order(vt_orderid)

                            close_volume = round_to(self.short_pos - long_close_volume, self.min_volume)

                            if close_volume >= self.min_volume:
                                order_ids = self.cover(self.grid_price["-1"], close_volume)
                                self.ama_orders['long_close'] = order_ids[-1]
                        
                        if self.ama_orders['long_open'] != '':
                            vt_orderid = self.ama_orders['long_open']
                            self.cancel_order(vt_orderid)

                        #     self.gateway.modify_order_price(self.symbol, vt_orderid.split('.')[-1], self.grid_price["-1"])
                        # else:
                        order_ids = self.buy(self.grid_price["-1"], self.target_pos * self.AMA_Order_Pst)
                        self.ama_orders['long_open'] = order_ids[-1]
                    
                    if "1" in self.grid_price and "-1" in self.grid_price:
                        if self.ama > self.grid_price["1"]:
                            self.last_ama_position = 1
                        elif self.ama <= self.grid_price["1"] and self.ama >= self.grid_price["-1"]:
                            self.last_ama_position = 0
                        elif self.ama < self.grid_price["-1"]:
                            self.last_ama_position = -1

                    if self.grid_balance_status == 0:
                        if "1" in self.grid_price and tick.bid_price_1 >= self.grid_price['1']:
                            self.break_direction = 'up'
                            self.break_num = self.grid_num
                            
                        elif "-1" in self.grid_price and tick.ask_price_1 <= self.grid_price['-1']:
                            self.break_direction = 'down'
                            self.break_num = self.grid_num
            
                if self.break_direction != None and self.break_num != 0:
                    if self.grid_balance_status > 0:
                        if self.last_long_pos == self.long_pos and self.last_short_pos == self.short_pos:
                            return
                        else:
                            restart = False
                            if self.last_long_pos > 0 and self.long_pos == 0:
                                restart = True
                            elif self.last_short_pos > 0 and self.short_pos == 0:
                                restart = True
                            
                            self.last_long_pos = self.long_pos
                            self.last_short_pos = self.short_pos
                            
                            if restart == True:
                                print("Position is all closed. Restart now.")
                                self.cancel_all()
                                self.close_grid_id={}
                                self.close_grid_volume={}
                                self.grid_id={}

                                self.break_num = 0
                                self.break_direction = None
                                
                                self.init_grid()

                    price = 0
                    if self.break_num < self.grid_num:
                        if self.break_direction == 'up':
                            price=self.grid_price[str(self.break_num)]
                        elif self.break_direction == 'down':
                            price=self.grid_price[str(-1 * self.break_num)]
                    else:
                        price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)
                    
                    if price == 0:
                        return

                    self.process_grid_price(price)
                    
                    break_direction = self.break_direction
                    break_num = self.break_num
                    self.break_num = 0
                    self.break_direction == None

                    if self.grid_balance_status > 0:
                        self.grid_balance_tick(break_direction, break_num) 
                    
                    if break_direction == 'up':
                        if self.ama_orders['long_close'] != '':
                            
                            long_close_volume = 0
                            for i in range(1,self.grid_num+1):
                                if str(-i) in self.close_grid_volume and self.close_grid_volume[str(-i)] != 0:
                                    long_close_volume += self.close_grid_volume[str(-i)]

                            if self.short_pos > 0 and self.short_pos > long_close_volume:
                                vt_orderid = self.ama_orders['long_close']
                                self.cancel_order(vt_orderid)

                                close_volume = round_to(self.short_pos - long_close_volume, self.min_volume)

                                if close_volume >= self.min_volume:
                                    order_ids = self.cover(self.grid_price["-1"], close_volume)
                                    self.ama_orders['long_close'] = order_ids[-1]

                                    print("AMA long close order moved to B1:", self.grid_price["-1"])
                        
                        if self.ama_orders['long_open'] != '':
                            print("AMA long open order moved to B1:", self.grid_price["-1"])

                            vt_orderid = self.ama_orders['long_open']
                            self.cancel_order(vt_orderid)

                            # self.gateway.modify_order_price(self.symbol, vt_orderid.split('.')[-1], self.grid_price["-1"])

                            order_ids = self.buy(self.grid_price["-1"], self.target_pos * self.AMA_Order_Pst)
                            self.ama_orders['long_open'] = order_ids[-1]

                    elif break_direction == 'down':
                        if self.ama_orders['short_close'] != '':
                            
                            short_close_volume = 0
                            for i in range(1,self.grid_num+1):
                                if str(i) in self.close_grid_volume and self.close_grid_volume[str(i)] != 0:
                                    short_close_volume += self.close_grid_volume[str(i)]

                            if self.long_pos > 0 and self.long_pos > short_close_volume:
                                vt_orderid = self.ama_orders['short_close']
                                self.cancel_order(vt_orderid)

                                close_volume = round_to(self.long_pos - short_close_volume, self.min_volume)

                                if close_volume >= self.min_volume:

                                    order_ids = self.sell(self.grid_price["1"], close_volume)
                                    self.ama_orders['short_close'] = order_ids[-1]

                                    print("AMA short close order moved to A1:", self.grid_price["1"])
                        
                        if self.ama_orders['short_open'] != '':
                            print("AMA short open order moved to A1:", self.grid_price["1"])

                            vt_orderid = self.ama_orders['short_open']
                            self.cancel_order(vt_orderid)

                            # self.gateway.modify_order_price(self.symbol, vt_orderid.split('.')[-1], self.grid_price["1"])

                            order_ids = self.short (self.grid_price["1"], self.target_pos * self.AMA_Order_Pst)
                            self.ama_orders['short_open'] = order_ids[-1]
            
            self.last_trading=self.trading

        
        self.last_tick=tick
        self.put_event()
    
    def on_bar(self, bar: BarData):
        """
        Callback of new bar data update.
        """
        self.am.update_bar(bar)
        if not self.am.inited:
            return
        
        self.ama = self.am.kama(self.AMA_N)

        if self.trading:
            print("AMA valaue:", self.ama)

        self.put_event()


    def on_order(self, order: OrderData):
        """
        Callback of new order data update.
        """
        vt_orderid=order.vt_orderid

        if order.status==Status.ALLTRADED and self.grid_balance_status > 0:
            up = 0
            down = 0
            for i in range(1,self.grid_num+1):
                if order.price == self.grid_price[str(i)]:
                    up = i
                    break
                elif order.price == self.grid_price[str(-i)]:
                    down = -i
                    break

            if up > 0:
                self.break_num = up
                self.break_direction = 'up'

            elif down < 0:
                self.break_num = abs(down)
                self.break_direction = 'down'

            else:
                self.break_num = 0
                self.break_direction = None

            print("on_order:", self.break_direction, self.break_num)

        if order.status == Status.CANCELLED or order.status == Status.REJECTED or order.status == Status.ALLTRADED:
            if vt_orderid == self.ama_orders['long_open']:
                self.ama_orders['long_open'] = ''
            elif vt_orderid == self.ama_orders['long_close']:
                self.ama_orders['long_close'] = ''
            elif vt_orderid == self.ama_orders['short_open']:
                self.ama_orders['short_open'] = ''
            elif vt_orderid == self.ama_orders['short_close']:
                self.ama_orders['short_close'] = ''

            if order.status != Status.ALLTRADED:
                for i in range(1,self.grid_num+1):
                    if str(i) in self.grid_id and self.grid_id[str(i)] == vt_orderid:
                        self.grid_id[str(i)] = ''
                    if str(-i) in self.grid_id and self.grid_id[str(-i)] == vt_orderid:
                        self.grid_id[str(-i)] = ''

                    if str(i) in self.close_grid_id and self.close_grid_id[str(i)] == vt_orderid:
                        self.close_grid_id[str(i)] = ''
                        self.close_grid_volume[str(i)] = 0
                    if str(-i) in self.close_grid_id and self.close_grid_id[str(-i)] == vt_orderid:
                        self.close_grid_id[str(-i)] = ''
                        self.close_grid_volume[str(-i)] = 0
    
    def on_position(self, event):

        position = event.data
        if hasattr(position, 'symbol'):

            if position.symbol==self.symbol:
                if position.direction==Direction.LONG:
                    self.long_pos=position.volume
                elif position.direction==Direction.SHORT:
                    self.short_pos=position.volume

    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data
        if hasattr(account, 'gateway_name'):
            if account.gateway_name == 'BINANCES':
                self.balance = account.balance

    def process_grid_price(self,price):
        # 下面是固定网格价差的代码
        self.grid_price['1']=round_to(price + self.grid_gap, self.pricetick)
        self.grid_price['-1']=round_to(price - self.grid_gap, self.pricetick)
        for i in range(2,self.grid_num+1):
            self.grid_price[str(i)]=round_to(self.grid_price[str(i-1)] + self.grid_gap, self.pricetick)
            self.grid_price[str(-1*i)]=round_to(self.grid_price[str(-i+1)] - self.grid_gap, self.pricetick)
        
        price = 0.5*(self.grid_price['1']+self.grid_price['-1'])

        self.target_pos = round_to(self.balance * self.lerver_rate, self.min_volume)
        #网格突破后，重新计算big_percent
        self.big_percent = (1 + (abs(self.long_pos - self.short_pos) / (self.target_pos * self.pos_num)))

        grid_base_pos_pst = self.grid_gap
        self.long_short_open = round_to(40 / self.market_price, self.min_volume)
        self.long_short_close = self.min_volume

    def grid_balance_init(self):
        self.init_grid()

    def grid_balance_tick(self,direction,break_num):
        #用于网格平衡策略的逻辑处理
        if direction=='up':
            if break_num<self.grid_num:
                self.grid_move_grid('up',break_num)
            else:
                self.cancel_all()
                self.close_grid_id={}
                self.close_grid_volume={}
                self.grid_id={}

                self.init_grid()

        elif direction=='down':
            if break_num<self.grid_num:
                self.grid_move_grid('down',break_num)
            else:
                self.cancel_all()
                self.close_grid_id={}
                self.close_grid_volume={}
                self.grid_id={}

                self.init_grid()

    def break_num(self,direction,price):

        num=0
        if direction=='up':
            for i in range(1,self.grid_num+1):
                if price>self.grid_price[str(i)]:
                    num=i
                else:
                    break
            return num
        elif direction=='down':
            for i in range(1,self.grid_num+1):
                if price<self.grid_price[str(-1*i)]:
                    num=i
                else:
                    break
            return num
                
    def init_grid(self):
        if self.target_pos > 0 and len(self.grid_id)==0:

            total_short_close = 0
            for up in range(1,self.grid_num+1):
                if self.long_short_open > 0 and self.long_pos < self.min_volume:
                    short_ids = self.short(self.grid_price[str(up)], self.long_short_open)
                    self.grid_id[str(up)] = short_ids[-1]
                else:
                    self.grid_id[str(up)]=''

                if self.long_short_close > 0 and self.long_pos > total_short_close:
                    if self.long_pos >= total_short_close + self.long_short_close:
                        close_volume = self.long_short_close
                    else:
                        close_volume = self.long_pos - total_short_close

                    close_volume = round_to(close_volume, self.min_volume)

                    if close_volume >= self.min_volume:
                        sell_ids=self.sell(self.grid_price[str(up)], close_volume)
                        self.close_grid_id[str(up)]=sell_ids[-1]
                        self.close_grid_volume[str(up)] = close_volume

                        total_short_close += close_volume
                else:
                    self.close_grid_id[str(up)]=''
                    self.close_grid_volume[str(up)] = 0

            total_long_close = 0
            for i in range(1,self.grid_num+1):
                down = -i
                if self.long_short_open>0 and self.short_pos<self.min_volume:
                    long_ids=self.buy(self.grid_price[str(down)],self.long_short_open)
                    self.grid_id[str(down)] = long_ids[-1]
                else:
                    self.grid_id[str(down)] = ''
                    
                if self.long_short_close>0 and self.short_pos > total_long_close:
                    if self.short_pos >= total_long_close + self.long_short_close:
                        close_volume = self.long_short_close
                    else:
                        close_volume = self.short_pos - total_long_close

                    close_volume = round_to(close_volume, self.min_volume)

                    if close_volume >= self.min_volume:
                        cover_ids=self.cover(self.grid_price[str(down)], close_volume)
                        self.close_grid_id[str(down)] = cover_ids[-1]
                        self.close_grid_volume[str(down)] = close_volume

                        total_long_close += close_volume
                else:
                    self.close_grid_id[str(down)] = ''
                    self.close_grid_volume[str(down)] = 0

    def grid_move_grid(self,direction,break_num):
        if len(self.grid_id)>0:

            print("grid_move_grid:", direction, break_num)
            # print(self.grid_id)
            # print(self.close_grid_id)
        
            temp_dict={}
            close_temp_dict={}
            close_volume_dict={}
            if direction=='up':
                for key,value in self.grid_id.items():
                  
                    if 0 < eval(key) <= break_num:
                        temp_dict[str(eval(key)-break_num-1)]=''
                        close_temp_dict[str(eval(key)-break_num-1)]=''
                        close_volume_dict[str(eval(key)-break_num-1)] = 0
                    else:
                        temp_dict[str(eval(key)-break_num)]=value
                        close_temp_dict[str(eval(key)-break_num)]=self.close_grid_id[key]
                        close_volume_dict[str(eval(key)-break_num)] = self.close_grid_volume[key]

                for i in range(break_num):

                    temp_dict[str(self.grid_num-i)]=''

                    if temp_dict[str(-1*self.grid_num-i-1)]!='':
                        self.cancel_order(temp_dict[str(-1*self.grid_num-i-1)])
                    del temp_dict[str(-1*self.grid_num-i-1)]

                    close_temp_dict[str(self.grid_num-i)]=''
                    if close_temp_dict[str(-1*self.grid_num-i-1)]!='':
                        self.cancel_order(close_temp_dict[str(-1*self.grid_num-i-1)])
                    del close_temp_dict[str(-1*self.grid_num-i-1)]

                    del close_volume_dict[str(-1*self.grid_num-i-1)]
                
                long_close_volume = 0
                short_close_volume = 0
                for i in range(1,self.grid_num+1):
                    if str(i) in close_volume_dict and close_volume_dict[str(i)] != 0:
                        short_close_volume += close_volume_dict[str(i)]
                    if str(-i) in close_volume_dict and close_volume_dict[str(-i)] != 0:
                        long_close_volume += close_volume_dict[str(-i)]
                
                for i in range(break_num):
                    if self.long_short_open > 0 and self.long_pos < self.min_volume:
                        short_ids=self.short(self.grid_price[str(self.grid_num-i)],self.long_short_open)
                        temp_dict[str(self.grid_num-i)]=short_ids[-1]
                    else:
                        temp_dict[str(self.grid_num-i)]=''

                    if self.long_short_close > 0 and self.short_pos > long_close_volume:
                        if self.short_pos >= long_close_volume + self.long_short_close:
                            close_volume = self.long_short_close
                        else:
                            close_volume = self.short_pos - long_close_volume

                        close_volume = round_to(close_volume, self.min_volume)

                        if close_volume >= self.min_volume:
                            cover_ids=self.cover(self.grid_price[str(-1*(i+1))], close_volume)
                            close_temp_dict[str(-1*(i+1))]=cover_ids[-1]
                            close_volume_dict[str(-1*(i+1))] = close_volume
                            long_close_volume += close_volume
                    else:
                        close_temp_dict[str(-1*(i+1))]=''
                        close_volume_dict[str(-1*(i+1))] = 0

                    if self.long_short_open>0 and self.short_pos<self.min_volume:
                        long_ids=self.buy(self.grid_price[str(-1*(i+1))],self.long_short_open)
                        temp_dict[str(-1*(i+1))]=long_ids[-1]
                    else:
                        temp_dict[str(-1*(i+1))]=''

                    if self.long_short_close>0 and self.long_pos > short_close_volume:
                        if self.long_pos >= short_close_volume + self.long_short_close:
                            close_volume = self.long_short_close
                        else:
                            close_volume = self.long_pos - short_close_volume

                        close_volume = round_to(close_volume, self.min_volume)

                        if close_volume >= self.min_volume:
                            sell_ids=self.sell(self.grid_price[str(self.grid_num-i)], close_volume)
                            close_temp_dict[str(self.grid_num-i)]=sell_ids[-1]
                            close_volume_dict[str(self.grid_num-i)] = close_volume
                            short_close_volume += close_volume
                    else:
                        close_temp_dict[str(self.grid_num-i)]=''
                        close_volume_dict[str(self.grid_num-i)] = 0
                        

                for i in range(1,self.grid_num+1):
                    if temp_dict[str(i)]=='':
                        if self.long_short_open>0 and self.long_pos<self.min_volume:
                            short_ids=self.short(self.grid_price[str(i)],self.long_short_open)
                            temp_dict[str(i)]=short_ids[-1]
                        else:
                            temp_dict[str(i)]=''

                    if close_temp_dict[str(i)]=='':
                        if self.long_short_close>0 and self.long_pos > short_close_volume:
                            if self.long_pos >= short_close_volume + self.long_short_close:
                                close_volume = self.long_short_close
                            else:
                                close_volume = self.long_pos - short_close_volume

                            close_volume = round_to(close_volume, self.min_volume)

                            if close_volume >= self.min_volume:
                                sell_ids=self.sell(self.grid_price[str(i)], close_volume)
                                close_temp_dict[str(i)]=sell_ids[-1]
                                close_volume_dict[str(i)] = close_volume
                                short_close_volume += close_volume
                        else:
                            close_temp_dict[str(i)]=''
                            close_volume_dict[str(i)] = 0

                    if temp_dict[str(-1*i)]=='':
                        if self.long_short_open>0 and self.short_pos<self.min_volume:
                            long_ids=self.buy(self.grid_price[str(-1*i)],self.long_short_open)
                            temp_dict[str(-1*i)]=long_ids[-1]
                        else:
                            temp_dict[str(-1*i)]=''

                    if close_temp_dict[str(-1*i)]=='':
                        if self.long_short_close>0 and self.short_pos > long_close_volume:
                            if self.short_pos >= long_close_volume + self.long_short_close:
                                close_volume = self.long_short_close
                            else:
                                close_volume = self.short_pos - long_close_volume

                            close_volume = round_to(close_volume, self.min_volume)

                            if close_volume >= self.min_volume:
                                cover_ids=self.cover(self.grid_price[str(-1*i)], close_volume)
                                close_temp_dict[str(-1*i)]=cover_ids[-1]
                                close_volume_dict[str(-1*i)] = close_volume
                                long_close_volume += close_volume
                        else:
                            close_temp_dict[str(-1*i)]=''
                            close_volume_dict[str(-1*i)] = 0

                self.grid_id=deepcopy(temp_dict)
                self.close_grid_id=deepcopy(close_temp_dict)
                self.close_grid_volume = deepcopy(close_volume_dict)

            elif direction=='down':
                for key,value in self.grid_id.items():
                    if (-1*break_num)<=eval(key)<0:
                        temp_dict[str(eval(key)+break_num+1)]=''
                        close_temp_dict[str(eval(key)+break_num+1)]=''
                        close_volume_dict[str(eval(key)+break_num+1)] = 0
                    else:
                        temp_dict[str(eval(key)+break_num)]=value
                        close_temp_dict[str(eval(key)+break_num)]=self.close_grid_id[key]
                        close_volume_dict[str(eval(key)+break_num)] = self.close_grid_volume[key]

                for i in range(break_num):
                    temp_dict[str(-1*self.grid_num+i)]=''
                    if temp_dict[str(self.grid_num+i+1)]!='':
                        self.cancel_order(temp_dict[str(self.grid_num+i+1)])
                    del temp_dict[str(self.grid_num+i+1)]

                    close_temp_dict[str(-1*self.grid_num+i)]=''
                    if close_temp_dict[str(self.grid_num+i+1)]!='':
                        self.cancel_order(close_temp_dict[str(self.grid_num+i+1)])
                    del close_temp_dict[str(self.grid_num+i+1)]

                    del close_volume_dict[str(self.grid_num+i+1)]
                
                long_close_volume = 0
                short_close_volume = 0
                for i in range(1,self.grid_num+1):
                    if str(i) in close_volume_dict and close_volume_dict[str(i)] != 0:
                        short_close_volume += close_volume_dict[str(i)]
                    if str(-i) in close_volume_dict and close_volume_dict[str(-i)] != 0:
                        long_close_volume += close_volume_dict[str(-i)]

                for i in range(break_num):
                    if self.long_short_open>0 and self.short_pos<self.min_volume:
                        long_ids=self.buy(self.grid_price[str(-1*self.grid_num+i)],self.long_short_open)
                        temp_dict[str(-1*self.grid_num+i)]=long_ids[-1]
                    else:
                        temp_dict[str(-1*self.grid_num+i)]=''

                    if self.long_short_close>0 and self.long_pos > short_close_volume:
                        if self.long_pos>= short_close_volume + self.long_short_close:
                            close_volume = self.long_short_close
                        else:
                            close_volume = self.long_pos - short_close_volume
                        
                        close_volume = round_to(close_volume, self.min_volume)

                        if close_volume >= self.min_volume:
                            sell_ids=self.sell(self.grid_price[str(i+1)] ,close_volume)
                            close_temp_dict[str(i+1)]=sell_ids[-1]
                            close_volume_dict[str(i+1)] = close_volume
                            short_close_volume += close_volume
                    else:
                        close_temp_dict[str(i+1)] = ''
                        close_volume_dict[str(i+1)] = 0

                    if self.long_short_open>0 and self.long_pos<self.min_volume:
                        short_ids=self.short(self.grid_price[str(i+1)],self.long_short_open)
                        temp_dict[str(i+1)]=short_ids[-1]
                    else:
                        temp_dict[str(i+1)]=''

                    if self.long_short_close>0 and self.short_pos > long_close_volume:
                        if self.short_pos >= long_close_volume + self.long_short_close:
                            close_volume = self.long_short_close
                        else:
                            close_volume = self.short_pos - long_close_volume

                        close_volume = round_to(close_volume, self.min_volume)

                        if close_volume >= self.min_volume:
                            cover_ids=self.cover(self.grid_price[str(-1*self.grid_num+i)], close_volume)
                            close_temp_dict[str(-1*self.grid_num+i)]=cover_ids[-1]
                            close_volume_dict[str(-1*self.grid_num+i)] = close_volume
                            long_close_volume += close_volume
                    else:
                        close_temp_dict[str(-1*self.grid_num+i)]=''
                        close_volume_dict[str(-1*self.grid_num+i)] = 0
                        
                for i in range(1,self.grid_num+1):
                    if temp_dict[str(i)]=='':
                        if self.long_short_open>0 and self.long_pos<self.min_volume:
                            short_ids=self.short(self.grid_price[str(i)],self.long_short_open)
                            temp_dict[str(i)]=short_ids[-1]
                        else:
                            temp_dict[str(i)]=''

                    if close_temp_dict[str(i)]=='':
                        if self.long_short_close>0 and self.long_pos > short_close_volume:
                            if self.long_pos >= short_close_volume + self.long_short_close:
                                close_volume = self.long_short_close
                            else:
                                close_volume = self.long_pos - short_close_volume

                            close_volume = round_to(close_volume, self.min_volume)

                            if close_volume >= self.min_volume:
                                sell_ids=self.sell(self.grid_price[str(i)], close_volume)
                                close_temp_dict[str(i)]=sell_ids[-1]
                                close_volume_dict[str(i)] = close_volume
                                short_close_volume += close_volume
                        else:
                            close_temp_dict[str(i)]=''
                            close_volume_dict[str(i)] = 0

                    if temp_dict[str(-1*i)]=='':
                        if self.long_short_open>0 and self.short_pos<self.min_volume:
                            long_ids=self.buy(self.grid_price[str(-1*i)],self.long_short_open)
                            temp_dict[str(-1*i)]=long_ids[-1]
                        else:
                            temp_dict[str(-1*i)]=''

                    if close_temp_dict[str(-1*i)]=='':
                        if self.long_short_close>0 and self.short_pos > long_close_volume:
                            if self.short_pos >= long_close_volume + self.long_short_close:
                                close_volume = self.long_short_close
                            else:
                                close_volume = self.short_pos - long_close_volume

                            close_volume = round_to(close_volume, self.min_volume)

                            if close_volume >= self.min_volume:
                                cover_ids=self.cover(self.grid_price[str(-1*i)], close_volume)
                                close_temp_dict[str(-1*i)]=cover_ids[-1]
                                close_volume_dict[str(-1*i)] = close_volume
                                long_close_volume += close_volume
                        else:
                            close_temp_dict[str(-1*i)]=''
                            close_volume_dict[str(-1*i)] = 0
                            
                self.grid_id=deepcopy(temp_dict)
                self.close_grid_id=deepcopy(close_temp_dict)
                self.close_grid_volume = deepcopy(close_volume_dict)
