from vnpy.app.cta_strategy import (
    CtaTemplate,
    StopOrder,
    TickData,
    BarData,
    TradeData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset,Direction,Status,Interval
import datetime,time
from vnpy.trader.object import PositionData,AccountData
from copy import deepcopy
class GridBackBalanceStrategyV5(CtaTemplate):
    """
    网格部分：
        1、向上突破网格后，如果持仓有多仓，则只平多不开空，没有多仓，则开空；反向同理
    插针部分
        1、满足开空条件后，如果持仓有多仓，则只平多不开空，不够部分开空处理；反向同理
        2、单方向突破但为达到突破数量，出现反向突破时，不重新计数，按照累计的规则处理。比如当前正向突破8个网格，反向突破1个网格，当前的数量为7
        3、满足买入条件后，重新计数
    新增仓位管理部分：
        1、实际多仓位大于目标仓位的时候多仓目标仓位全平开空仓目标仓位;
        2、实际空仓位大于目标仓位的时候空仓目标仓位全屏开多目标仓位
    """

    author = "回调插针网格v5"
    #策略控制开关
    grid_balance_status=1
    grid_back_status=1

    grid_num = 5 #上下 10个
    # grid_gap = 10 #网格间距
    grid_gap_pst=0.0015 #网格间距百分比
    lerver_rate=100
    duo_percent = 0.03
    kong_percent = 0.03
    big_percent=0.011
    small_percent=0.009
    ma_window=180
    balance=0 #账户余额
    long_pos = 0  # 多头持仓
    short_pos = 0  # 空头持仓

    rate_limit_status=100
    target_long_pos=0
    target_short_pos=0

    pos_num=2
    pos_pst=0.01

    contiune_grid_limit=6
    continue_break_gird_num=0

    parameters = ['grid_balance_status','grid_back_status',"grid_num", "grid_gap_pst", "lerver_rate", "ma_window",'duo_percent','kong_percent','pos_num','pos_pst','contiune_grid_limit']
    variables = ['balance','long_pos','short_pos','continue_break_gird_num','rate_limit_status','target_long_pos','target_short_pos','big_percent','small_percent']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        self.bg=BarGenerator(self.on_bar)
        self.am = ArrayManager(self.ma_window*3)
        self.pricetick = self.get_pricetick()
        contract=self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume=contract.min_volume

        self.symbol=self.vt_symbol.split('.')[0]
        self.grid_id={}
        self.close_grid_id={}
        self.grid_price={}
        self.num_tick=0
        self.ma_direction=0
        self.last_trading=False
        self.balance_id={'open_long':'','open_short':'','close_long':'','close_short':''}
        self.id_balance={}
        
        self.last_tick=None
        self.pos_delay_num=0
        self.ma_value=0

    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('BYBIT')
        self.gateway.query_account()
        self.gateway.query_position()
        self.load_bar(int(self.ma_window*3/1440)+2)
        self.write_log("策略初始化")
        
    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status=100
        self.continue_break_gird_num=0
        self.write_log("策略启动")

    def on_stop(self):
        """
        Callback when strategy is stopped.
        """
        self.write_log("策略停止")

    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.bg.update_tick(tick)
        self.num_tick+=1
        if self.num_tick%50==0:
            self.gateway.query_account()
            self.gateway.query_position()
        if self.num_tick%30==0:
            self.get_rate_limit_status()
        if not self.last_trading and self.trading:
            price=tick.last_price
            self.process_grid_price(price)

        if self.trading:
            if self.rate_limit_status>=(self.grid_num*2):
                if self.grid_balance_status>0:
                    self.grid_balance_init() #网格平衡策略初始化
            
            if tick.last_price>self.grid_price['1']:
                break_num=self.break_num('up',tick.last_price)
                
                #价格突破后维护网格字典
                if break_num<self.grid_num:
                    price=self.grid_price[str(break_num)]
                else:
                    price=tick.last_price
                self.process_grid_price(price)
                
                if self.grid_balance_status>0:
                    self.grid_balance_tick('up',break_num) #处理网格平衡策略
                if self.grid_back_status>0:
                    self.grid_back_tick('up',break_num,tick) #回调网格处理

            elif tick.last_price<self.grid_price['-1']:
                break_num=self.break_num('down',tick.last_price)

                #价格突破后维护网格字典
                if break_num<self.grid_num:
                    price=self.grid_price[str(-1*break_num)]
                else:
                    price=tick.last_price
                self.process_grid_price(price)

                if self.grid_balance_status>0:
                    self.grid_balance_tick('down',break_num) #处理网格平衡策略
                if self.grid_back_status>0:
                    self.grid_back_tick('down',break_num,tick) #回调网格处理

        self.last_trading=self.trading
        self.last_tick=tick
        if self.pos_delay_num>0:
            self.pos_delay_num-=1
        self.put_event()
    
    def on_bar(self, bar: BarData):
        """
        Callback of new bar data update.
        """
        self.am.update_bar(bar)
        if not self.am.inited:
            return
        
        self.ma_value=self.am.sma(self.ma_window)

        if bar.close_price>self.ma_value:
            self.ma_direction=1
        elif bar.close_price<self.ma_value:
            self.ma_direction=-1
        
        if self.trading:
            self.rate_limit_status=100
            self.gateway.init_rate_limit_status(self.symbol)

        self.put_event()

    def on_order(self, order: OrderData):
        """
        Callback of new order data update.
        """
        vt_orderid=order.vt_orderid
        if order.status==Status.ALLTRADED:
            pass

    def on_position(self,position:PositionData):
        if position.vt_symbol==self.vt_symbol:
            if position.direction==Direction.LONG:
                self.long_pos=position.volume
            elif position.direction==Direction.SHORT:
                self.short_pos=position.volume
            
            if self.last_tick and self.pos_delay_num==0:
                if position.direction==Direction.LONG:
                    if self.long_pos>self.target_long_pos:
                        self.pos_delay_num=20
                        self.sell(self.last_tick.bid_price_1*0.99,self.long_pos)
                        volume=round_to(self.target_short_pos*0.8,self.min_volume)
                        if self.short_pos>=self.min_volume and (volume-self.short_pos)>self.min_volume:
                            self.short(self.last_tick.bid_price_1*0.99,(volume-self.short_pos))
                        elif self.short_pos<self.min_volume:
                            self.short(self.last_tick.bid_price_1*0.99,volume)
                elif position.direction==Direction.SHORT:
                    if self.short_pos>self.target_short_pos:
                        self.pos_delay_num=20
                        self.cover(self.last_tick.ask_price_1*1.01,self.short_pos)
                        volume=round_to(self.target_long_pos*0.8,self.min_volume)
                        if self.long_pos>=self.min_volume and (volume-self.long_pos)>self.min_volume:
                            self.buy(self.last_tick.ask_price_1*1.01,(volume-self.long_pos))
                        elif self.long_pos<self.min_volume:
                            self.buy(self.last_tick.ask_price_1*1.01,volume)

    def on_account(self, account: AccountData):
        """
        Callback of new trade data update.
        """
        if account.accountid=='USDT':
            self.balance=account.balance
    
    def process_grid_price(self,price):
        # 下面是固定网格价差的代码
        # for i in range(1,self.grid_num+1):
        #     self.grid_price[str(i)]=price+i*self.grid_gap
        #     self.grid_price[str(-1*i)]=price-i*self.grid_gap
        self.grid_price['1']=round_to(price*(1+self.grid_gap_pst),self.pricetick)
        self.grid_price['-1']=round_to(price*(1-self.grid_gap_pst),self.pricetick)
        for i in range(2,self.grid_num+1):
            self.grid_price[str(i)]=round_to(self.grid_price[str(i-1)]*(1+self.grid_gap_pst),self.pricetick)
            self.grid_price[str(-1*i)]=round_to(self.grid_price[str(-i+1)]*(1-self.grid_gap_pst),self.pricetick)
        
        self.grid_move_ma() #计算多空目标仓位
        #网格突破后，重新计算big_percent和small_percent
        self.big_percent=(1+(abs(self.long_pos-self.short_pos)/((self.target_long_pos+self.target_short_pos)*self.pos_num)))*self.pos_pst
        self.small_percent=(1-(abs(self.long_pos-self.short_pos)/((self.target_long_pos+self.target_short_pos)*self.pos_num)))*self.pos_pst

    def grid_balance_init(self):
        self.init_grid()

    def grid_balance_tick(self,direction,break_num):
        #用于网格平衡策略的逻辑处理
        if direction=='up':
            if break_num<self.grid_num:
                self.grid_move_grid('up',break_num)
            else:
                self.cancel_all()
                self.close_grid_id={}
                self.grid_id={}
                if self.rate_limit_status>=(self.grid_num*5):
                    self.init_grid()
                else:
                    return

        elif direction=='down':
            if break_num<self.grid_num:
                self.grid_move_grid('down',break_num)
            else:
                self.cancel_all()
                self.close_grid_id={}
                self.grid_id={}
                if self.rate_limit_status>=(self.grid_num*5):
                    self.init_grid()
                else:
                    return

    def grid_back_tick(self,direction,break_num,tick: TickData):
        if direction=='up':
            #向上突破网格
            if self.continue_break_gird_num>=0:
                self.continue_break_gird_num+=break_num
            else:
                if abs(self.continue_break_gird_num)>=self.contiune_grid_limit:
                    plan_long_pos=round_to(self.target_long_pos*self.pos_pst*abs(self.continue_break_gird_num),self.min_volume)
                    if self.short_pos>=plan_long_pos:
                        self.cover(tick.last_price*1.005,plan_long_pos)
                    else:
                        self.cover(tick.last_price*1.005,self.short_pos)
                        self.buy(tick.last_price*1.005,(plan_long_pos-self.short_pos))
                    self.continue_break_gird_num=break_num
                else:
                    self.continue_break_gird_num+=break_num
        elif direction=='down':
            if self.continue_break_gird_num<=0:
                self.continue_break_gird_num-=break_num
            else:
                if self.continue_break_gird_num>=self.contiune_grid_limit:
                    plan_short_pos=round_to(self.target_short_pos*self.pos_pst*self.continue_break_gird_num,self.min_volume)
                    if self.long_pos>=plan_short_pos:
                        self.sell(tick.last_price*0.995,plan_short_pos)
                    else:
                        self.sell(tick.last_price*0.995,self.long_pos)
                        self.short(tick.last_price*0.995,(plan_short_pos-self.long_pos))
                    self.continue_break_gird_num=-1*break_num
                else:
                    self.continue_break_gird_num-=break_num

    def break_num(self,direction,price):
        #突破了几个网格
        num=0
        if direction=='up':
            for i in range(1,self.grid_num+1):
                if price>self.grid_price[str(i)]:
                    num=i
                else:
                    break
            return num
        elif direction=='down':
            for i in range(1,self.grid_num+1):
                if price<self.grid_price[str(-1*i)]:
                    num=i
                else:
                    break
            return num
    
    def grid_move_ma(self):
        #网格移动或刚形成网格时，计算多空目标仓位
        orderids=self.balance_id.values()
        for orderid in orderids:
            if orderid!='':
                self.cancel_order(orderid)
        self.get_rate_limit_status()
        self.gateway.query_account()
        self.gateway.query_position()

        if self.balance>0:
            if self.ma_direction>0:
                long_usdt_use=self.balance*self.lerver_rate*self.duo_percent
                short_usdt_use=self.balance*self.lerver_rate*self.kong_percent
            elif self.ma_direction<0:
                long_usdt_use=self.balance*self.lerver_rate*self.kong_percent
                short_usdt_use=self.balance*self.lerver_rate*self.duo_percent
            else:
                long_usdt_use=0
                short_usdt_use=0
            price=0.5*(self.grid_price['1']+self.grid_price['-1'])
            self.target_long_pos=round_to(long_usdt_use/price,self.min_volume)
            self.target_short_pos=round_to(short_usdt_use/price,self.min_volume)
            
            # self.balance_id={'open_long':'','open_short':'','close_long':'','close_short':''}
            # self.id_balance={}
            # if self.ma_direction>0:
            #     if self.long_pos<self.target_short_pos:
            #         open_long=round_to((self.target_short_pos-self.long_pos),self.min_volume)
            #         open_long_ids=self.buy(self.grid_price['-1'],open_long)
            #         self.balance_id['open_long']=open_long_ids[-1]
            #         self.id_balance[open_long_ids[-1]]='open_long'
            #     if self.short_pos>self.target_long_pos:
            #         close_short=round_to((self.short_pos-self.target_long_pos),self.min_volume)
            #         close_short_ids=self.cover(self.grid_price['-1'],close_short)
            #         self.balance_id['close_short']=close_short_ids[-1]
            #         self.id_balance[close_short_ids[-1]]='close_short'
            # elif self.ma_direction<0:
            #     if self.long_pos>self.target_short_pos:
            #         close_long=round_to((self.long_pos-self.target_short_pos),self.min_volume)
            #         close_long_ids=self.sell(self.grid_price['1'],close_long)
            #         self.balance_id['close_long']=close_long_ids[-1]
            #         self.id_balance[close_long_ids[-1]]='close_long'
            #     if self.short_pos<self.target_long_pos:
            #         open_short=round_to((self.target_long_pos-self.short_pos),self.min_volume)
            #         open_short_ids=self.short(self.grid_price['1'],open_short)
            #         self.balance_id['open_short']=open_short_ids[-1]
            #         self.id_balance[open_short_ids[-1]]='open_short'
                
    def init_grid(self):
        if (self.target_long_pos>0 or self.target_short_pos>0) and len(self.grid_id)==0:#初始建立起网格挂单
            # if self.long_pos<self.min_volume:
            if self.last_tick.last_price>self.ma_value:
                long_open=round_to((self.target_long_pos)/1*self.big_percent,self.min_volume)
                long_close=round_to((self.target_long_pos)/1*self.small_percent,self.min_volume)
            else:
                long_open=round_to((self.target_long_pos)/1*self.small_percent,self.min_volume)
                long_close=round_to((self.target_long_pos)/1*self.big_percent,self.min_volume)
            # if self.short_pos<self.min_volume:
            if self.last_tick.last_price<self.ma_value:
                short_open=round_to((self.target_short_pos)/1*self.big_percent,self.min_volume)
                short_close=round_to((self.target_short_pos)/1*self.small_percent,self.min_volume)
            else:
                short_open=round_to((self.target_short_pos)/1*self.small_percent,self.min_volume)
                short_close=round_to((self.target_short_pos)/1*self.big_percent,self.min_volume)

            for up in range(1,self.grid_num+1):
                if short_open>0 and self.long_pos<self.min_volume:
                    short_ids=self.short(self.grid_price[str(up)],short_open)
                    self.grid_id[str(up)]=short_ids[-1]
                else:
                    self.grid_id[str(up)]=''
                if long_close>0 and self.long_pos>=long_close:
                    sell_ids=self.sell(self.grid_price[str(up)],long_close)
                    self.close_grid_id[str(up)]=sell_ids[-1]
                else:
                    self.close_grid_id[str(up)]=''
            for down in range(-1*self.grid_num,0):
                if long_open>0 and self.short_pos<self.min_volume:
                    long_ids=self.buy(self.grid_price[str(down)],long_open)
                    self.grid_id[str(down)]=long_ids[-1]
                else:
                    self.grid_id[str(down)]=''
                if short_close>0 and self.short_pos>=short_close:
                    cover_ids=self.cover(self.grid_price[str(down)],short_close)
                    self.close_grid_id[str(down)]=cover_ids[-1]
                else:
                    self.close_grid_id[str(down)]=''

    def grid_move_grid(self,direction,break_num):
        if len(self.grid_id)>0 and self.rate_limit_status>20:
            # if self.long_pos<self.min_volume:
            if self.last_tick.last_price>self.ma_value:
                long_open=round_to((self.target_long_pos)/1*self.big_percent,self.min_volume)
                long_close=round_to((self.target_long_pos)/1*self.small_percent,self.min_volume)
            else:
                long_open=round_to((self.target_long_pos)/1*self.small_percent,self.min_volume)
                long_close=round_to((self.target_long_pos)/1*self.big_percent,self.min_volume)
            # if self.short_pos<self.min_volume:
            if self.last_tick.last_price<self.ma_value:
                short_open=round_to((self.target_short_pos)/1*self.big_percent,self.min_volume)
                short_close=round_to((self.target_short_pos)/1*self.small_percent,self.min_volume)
            else:
                short_open=round_to((self.target_short_pos)/1*self.small_percent,self.min_volume)
                short_close=round_to((self.target_short_pos)/1*self.big_percent,self.min_volume)
            temp_dict={}
            close_temp_dict={}
            if direction=='up':#价格向上突破A1
                for key,value in self.grid_id.items():
                    #整体向下移动网格，网格标号变为减去break_num，原被突破的网格向下移动到负向网格
                    if 0<eval(key)<=break_num:
                        temp_dict[str(eval(key)-break_num-1)]=''
                        close_temp_dict[str(eval(key)-break_num-1)]=''
                    else:
                        temp_dict[str(eval(key)-break_num)]=value
                        close_temp_dict[str(eval(key)-break_num)]=self.close_grid_id[key]
                for i in range(break_num):
                    #把向下移动后正向网格不足的部分新增进去
                    temp_dict[str(self.grid_num-i)]=''
                    #把向下移动后超出网格数量的部分撤销删除掉
                    if temp_dict[str(-1*self.grid_num-i-1)]!='':
                        self.cancel_order(temp_dict[str(-1*self.grid_num-i-1)])
                    del temp_dict[str(-1*self.grid_num-i-1)]

                    close_temp_dict[str(self.grid_num-i)]=''
                    if close_temp_dict[str(-1*self.grid_num-i-1)]!='':
                        self.cancel_order(close_temp_dict[str(-1*self.grid_num-i-1)])
                    del close_temp_dict[str(-1*self.grid_num-i-1)]
                    
                    if short_open>0 and self.long_pos<self.min_volume:
                        short_ids=self.short(self.grid_price[str(self.grid_num-i)],short_open)
                        temp_dict[str(self.grid_num-i)]=short_ids[-1]
                    else:
                        temp_dict[str(self.grid_num-i)]=''
                    if short_close>0 and self.short_pos>=short_close:
                        cover_ids=self.cover(self.grid_price[str(-1*(i+1))],short_close)
                        close_temp_dict[str(-1*(i+1))]=cover_ids[-1]
                    else:
                        close_temp_dict[str(-1*(i+1))]=''
                    if long_open>0 and self.short_pos<self.min_volume:
                        long_ids=self.buy(self.grid_price[str(-1*(i+1))],long_open)
                        temp_dict[str(-1*(i+1))]=long_ids[-1]
                    else:
                        temp_dict[str(-1*(i+1))]=''
                    if long_close>0 and self.long_pos>=long_close:
                        sell_ids=self.sell(self.grid_price[str(self.grid_num-i)],long_close)
                        close_temp_dict[str(self.grid_num-i)]=sell_ids[-1]
                    else:
                        close_temp_dict[str(self.grid_num-i)]=''
                        
                #检查网格挂单部分，是否有遗漏的位置没有挂单，挂入相应的单子
                for i in range(1,self.grid_num+1):
                    if temp_dict[str(i)]=='':
                        if short_open>0 and self.long_pos<self.min_volume:
                            short_ids=self.short(self.grid_price[str(i)],short_open)
                            temp_dict[str(i)]=short_ids[-1]
                        else:
                            temp_dict[str(i)]=''
                    if close_temp_dict[str(i)]=='':
                        if long_close>0 and self.long_pos>=long_close:
                            sell_ids=self.sell(self.grid_price[str(i)],long_close)
                            close_temp_dict[str(i)]=sell_ids[-1]
                        else:
                            close_temp_dict[str(i)]=''
                    if temp_dict[str(-1*i)]=='':
                        if long_open>0 and self.short_pos<self.min_volume:
                            long_ids=self.buy(self.grid_price[str(-1*i)],long_open)
                            temp_dict[str(-1*i)]=long_ids[-1]
                        else:
                            temp_dict[str(-1*i)]=''
                    if close_temp_dict[str(-1*i)]=='':
                        if short_close>0 and self.short_pos>=short_close:
                            cover_ids=self.cover(self.grid_price[str(-1*i)],short_close)
                            close_temp_dict[str(-1*i)]=cover_ids[-1]
                        else:
                            close_temp_dict[str(-1*i)]=''

                self.grid_id=deepcopy(temp_dict)
                self.close_grid_id=deepcopy(close_temp_dict)
            elif direction=='down':#价格向下突破B1
                for key,value in self.grid_id.items():
                    if (-1*break_num)<=eval(key)<0:
                        temp_dict[str(eval(key)+break_num+1)]=''
                        close_temp_dict[str(eval(key)+break_num+1)]=''
                    else:
                        temp_dict[str(eval(key)+break_num)]=value
                        close_temp_dict[str(eval(key)+break_num)]=self.close_grid_id[key]
                for i in range(break_num):
                    temp_dict[str(-1*self.grid_num+i)]=''
                    if temp_dict[str(self.grid_num+i+1)]!='':
                        self.cancel_order(temp_dict[str(self.grid_num+i+1)])
                    del temp_dict[str(self.grid_num+i+1)]

                    close_temp_dict[str(-1*self.grid_num+i)]=''
                    if close_temp_dict[str(self.grid_num+i+1)]!='':
                        self.cancel_order(close_temp_dict[str(self.grid_num+i+1)])
                    del close_temp_dict[str(self.grid_num+i+1)]

                    if long_open>0 and self.short_pos<self.min_volume:
                        long_ids=self.buy(self.grid_price[str(-1*self.grid_num+i)],long_open)
                        temp_dict[str(-1*self.grid_num+i)]=long_ids[-1]
                    else:
                        temp_dict[str(-1*self.grid_num+i)]=''
                    if long_close>0 and self.long_pos>=long_close:
                        sell_ids=self.sell(self.grid_price[str(i+1)],long_close)
                        close_temp_dict[str(i+1)]=sell_ids[-1]
                    else:
                        close_temp_dict[str(i+1)]=''
                    if short_open>0 and self.long_pos<self.min_volume:
                        short_ids=self.short(self.grid_price[str(i+1)],short_open)
                        temp_dict[str(i+1)]=short_ids[-1]
                    else:
                        temp_dict[str(i+1)]=''
                    if short_close>0 and self.short_pos>=short_close:
                        cover_ids=self.cover(self.grid_price[str(-1*self.grid_num+i)],short_close)
                        close_temp_dict[str(-1*self.grid_num+i)]=cover_ids[-1]
                    else:
                        close_temp_dict[str(-1*self.grid_num+i)]=''
                        
                
                for i in range(1,self.grid_num+1):
                    if temp_dict[str(i)]=='':
                        if short_open>0 and self.long_pos<self.min_volume:
                            short_ids=self.short(self.grid_price[str(i)],short_open)
                            temp_dict[str(i)]=short_ids[-1]
                        else:
                            temp_dict[str(i)]=''
                    if close_temp_dict[str(i)]=='':
                        if long_close>0 and self.long_pos>=long_close:
                            sell_ids=self.sell(self.grid_price[str(i)],long_close)
                            close_temp_dict[str(i)]=sell_ids[-1]
                        else:
                            close_temp_dict[str(i)]=''
                    if temp_dict[str(-1*i)]=='':
                        if long_open>0 and self.short_pos<self.min_volume:
                            long_ids=self.buy(self.grid_price[str(-1*i)],long_open)
                            temp_dict[str(-1*i)]=long_ids[-1]
                        else:
                            temp_dict[str(-1*i)]=''
                    if close_temp_dict[str(-1*i)]=='':
                        if short_close>0 and self.short_pos>=short_close:
                            cover_ids=self.cover(self.grid_price[str(-1*i)],short_close)
                            close_temp_dict[str(-1*i)]=cover_ids[-1]
                        else:
                            close_temp_dict[str(-1*i)]=''
                            
                self.grid_id=deepcopy(temp_dict)
                self.close_grid_id=deepcopy(close_temp_dict)
            self.get_rate_limit_status()

    def get_rate_limit_status(self):
        status=self.gateway.get_rate_limit_status(self.symbol)
        if status>0:
            self.rate_limit_status=status

