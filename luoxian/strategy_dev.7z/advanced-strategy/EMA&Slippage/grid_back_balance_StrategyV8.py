from vnpy.app.cta_strategy import (
    CtaTemplate,
    StopOrder,
    TickData,
    BarData,
    TradeData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset,Direction,Status,Interval
from datetime import time
from vnpy.trader.object import PositionData,AccountData
from copy import deepcopy
from collections import defaultdict
import numpy as np
from vnpy.trader.event import EVENT_TIMER, EVENT_ACCOUNT, EVENT_POSITION

class GridBackBalanceStrategyV8(CtaTemplate):
    """
    网格部分：
        1、向上突破网格后，如果持仓有多仓，则只平多不开空，没有多仓，则开空；反向同理
    插针部分
        1、满足开空条件后，如果持仓有多仓，则只平多不开空，不够部分开空处理；反向同理
        2、单方向突破但为达到突破数量，出现反向突破时，不重新计数，按照累计的规则处理。比如当前正向突破8个网格，反向突破1个网格，当前的数量为7
        3、满足买入条件后，重新计数
    新增仓位管理部分：
        1、实际多仓位大于目标仓位的时候多仓目标仓位全平开空仓目标仓位;
        2、实际空仓位大于目标仓位的时候空仓目标仓位全屏开多目标仓位
    顺势插针部分：
        1、初始化的第一次突破，进行方向判断，此时无论突破几个网格，都按照只突破一个处理
        2、以向上突破为例，第一次触发时，在上方两个网格位置处挂两个单位的开空单，等触发后向下以网格形式分别挂两个平空单，同时在触发价格上3个网格挂入三个单位的开空单，每同向触发一次，超价网格数量和单位同时加1
        3、每触发一个平空单，都会在原开空位置挂入开空单，进行挂单恢复
        4、当self.grid_forward_info['foward_num']从正转为0或者负时，撤销挂单并重新初始化
    修正仓位管理：
        1、RSV超过900时，卖出手里所有空单，并进行记录；
        2、RSV降回890时，重开卖出的空单，其中一半的仓位在每分钟结束前根据剩余可挂单量，按照动态网格间距和数量向下挂出
        3、RSV在495到505区间时，重新初始化顺势网格
    """

    author = "回调/顺势插针网格v8"
    #策略控制开关
    grid_balance_status=0 #资金平衡网格
    grid_back_status=0 #回调插针网格
    grid_forward_status=1 #顺势插针网格
    grid_forward_num_limit=20 #顺势插针网格最多挂单量

    grid_num = 10 #上下 10个
    # grid_gap = 10 #网格间距
    grid_gap_pst=0.00025 #网格间距百分比
    lerver_rate=100
    duo_percent = 0.1
    kong_percent = 0.1
    big_percent=0.011
    small_percent=0.009
    ma_window=180
    balance=0 #账户余额
    long_pos = 0  # 多头持仓
    short_pos = 0  # 空头持仓

    rate_limit_status=100
    target_long_pos=0
    target_short_pos=0

    pos_num=10
    pos_pst=1

    contiune_grid_limit=5
    continue_break_gird_num=0

    k_length_day=1
    forward_base_pos_pst_num=2.0
    back_base_pos_pst_num=2.0
    grid_base_pos_pst_num=1.0
    rsv=0
    base_grid_delta=0
    forward_base_pos_pst=0
    back_base_pos_pst=0
    grid_base_pos_pst=0
    dynamic_grid_delta=0
    forward_dynamic_single_volume=0
    back_dynamic_single_volume=0
    grid_dynamic_single_volume=0

    parameters = ['grid_balance_status','grid_forward_status','grid_back_status',"grid_forward_num_limit","grid_num","grid_gap_pst","pos_pst", "lerver_rate", "ma_window",'duo_percent','kong_percent','pos_num','contiune_grid_limit','k_length_day','forward_base_pos_pst_num','back_base_pos_pst_num','grid_base_pos_pst_num']
    variables = ['balance','long_pos','short_pos','continue_break_gird_num','rate_limit_status','target_long_pos','target_short_pos','big_percent','small_percent','rsv','base_grid_delta','forward_base_pos_pst','back_base_pos_pst','dynamic_grid_delta','forward_dynamic_single_volume','back_dynamic_single_volume','grid_dynamic_single_volume']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        self.bg=BarGenerator(self.on_bar)
        self.am = ArrayManager(self.ma_window*3)
        self.pricetick = self.get_pricetick()
        contract=self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume=contract.min_volume

        self.symbol=self.vt_symbol.split('.')[0]
        self.grid_id={}
        self.close_grid_id={}
        self.grid_price={}
        self.num_tick=0
        self.ma_direction=0
        self.last_trading=False
        self.balance_id={'open_long':'','open_short':'','close_long':'','close_short':''}
        self.id_balance={}
        
        self.last_tick=None
        self.pos_delay_num=0
        self.ma_value=0

        self.long_open=0
        self.long_close=0
        self.short_open=0
        self.short_close=0

        self.forward_long_open=0
        self.forward_short_open=0
        self.forward_long_close=0
        self.forward_short_close=0
        self.back_long_open=0
        self.back_short_open=0

        self.grid_forward_info={'direction':0,'foward_num':0,'target_price':0,'target_foward_basic_volume':0,'step':1,'target_foward_basic_grid':0} #记录顺势插针网格所有信息
        self.grid_forward_info_dict={} #str_step:self.grid_forward_info,记录所有str_step对应的grid_forward_info.#记录顺势插针网格所有信息,当向下一个目标价挂出开仓单时，记录本目标价挂单时的信息，用以：在本目标价的某一个平仓单成交，又挂在本目标价的开仓单成交时，重新挂回原平仓位置
        self.grid_forward_step_orderids_open=defaultdict(list) #开仓时，step与目标开仓orderids匹配，按照单位开仓量分别开仓
        self.grid_forward_orderid_step_open={} #开仓时，每个开仓orderid与step匹配，方便查找
        self.grid_forward_step_orderids_close=defaultdict(list) #平仓时，step与平仓orderids匹配
        self.grid_forward_orderid_step_close={} #平仓时，每个平仓orderid与step匹配，方便查找
        self.grid_forward_step_delta_targetprice=defaultdict(dict)

        self.day_high=0
        self.day_low=0
        self.day_closes=np.array([])
        self.day_highs=np.array([])
        self.day_lows=np.array([])

        self.hhv=0
        self.llv=0

        self.position_managed=False
        self.position_manage_dict={'status':0,'volume':0,'left_volume':0,'left_price':0}  #status，-1：代表rsv大于900已平空，-2代表rsv回落890，重新开空；volume，平空和开空的量；left_volume:代表剩余未挂单量;left_price:最后挂单的价格
        self.position_manage_started=False #每分钟59秒的时候启动
        self.forward_pos_num_rate=self.forward_base_pos_pst_num/(self.forward_base_pos_pst_num+self.back_base_pos_pst_num+self.grid_base_pos_pst_num)

        self.last_long_pos=0
        self.last_short_pos=0

        self.new_position_manage_pos=0

    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('BYBIT')
        self.gateway.query_account()
        self.gateway.query_position()
        day_length=max(int(self.ma_window/1440),self.k_length_day)+3
        self.load_bar(day_length)
        self.write_log("策略初始化")
        
    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status=100
        self.continue_break_gird_num=0

        self.rsv=0
        self.base_grid_delta=0
        self.forward_base_pos_pst=0
        self.back_base_pos_pst=0
        self.grid_base_pos_pst=0
        self.dynamic_grid_delta=0
        self.forward_dynamic_single_volume=0
        self.back_dynamic_single_volume=0
        self.grid_dynamic_single_volume=0

        self.cta_engine.event_engine.register(EVENT_ACCOUNT + self.vt_symbol, self.process_account_event)
        self.write_log("策略启动")
    
    def process_account_event(self, event):
        account= event.data
        print(account)

    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT + self.vt_symbol, self.process_account_event)
        self.write_log("策略停止")
    
    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.last_tick=tick
        self.bg.update_tick(tick)
        self.num_tick+=1
        if self.num_tick%30==0:
            self.get_rate_limit_status()
            self.num_tick=0
        if not self.last_trading and self.trading:
            price=tick.last_price
            self.process_grid_price(price)
            if self.grid_forward_status>0:
                if self.grid_balance_status==0:
                    self.calculate_trade_volume()
                self.grid_forward_init()

        if self.llv>0:
            self.hhv=max(self.hhv,tick.last_price)
            self.llv=min(self.llv,tick.last_price)
        if self.trading:
            if self.rate_limit_status>=(self.grid_num*2):
                if self.grid_balance_status>0:
                    self.grid_balance_init() #网格平衡策略初始化
            
            if tick.last_price>self.grid_price['1']:
                break_num=self.break_num('up',tick.last_price)
                
                #价格突破后维护网格字典
                if break_num<self.grid_num:
                    price=self.grid_price[str(break_num)]
                else:
                    price=tick.last_price
                self.process_grid_price(price)
                
                if self.grid_balance_status>0:
                    self.grid_balance_tick('up',break_num) #处理网格平衡策略
                if self.grid_back_status>0:
                    if self.grid_balance_status==0:
                        self.calculate_trade_volume()
                    self.grid_back_tick('up',break_num,tick) #回调网格处理
                if self.grid_forward_status>0:
                    if self.grid_balance_status==0:
                        self.calculate_trade_volume()
                    self.grid_forward_tick('up',break_num) #顺势插针网格处理

            elif tick.last_price<self.grid_price['-1']:
                break_num=self.break_num('down',tick.last_price)

                #价格突破后维护网格字典
                if break_num<self.grid_num:
                    price=self.grid_price[str(-1*break_num)]
                else:
                    price=tick.last_price
                self.process_grid_price(price)

                if self.grid_balance_status>0:
                    self.grid_balance_tick('down',break_num) #处理网格平衡策略
                if self.grid_back_status>0:
                    if self.grid_balance_status==0:
                        self.calculate_trade_volume()
                    self.grid_back_tick('down',break_num,tick) #回调网格处理
                if self.grid_forward_status>0:
                    if self.grid_balance_status==0:
                        self.calculate_trade_volume()
                    self.grid_forward_tick('down',break_num) #顺势插针网格处理

        self.last_trading=self.trading
        self.last_tick=tick
        if self.pos_delay_num>0:
            self.pos_delay_num-=1
        
        #仓位管理部分
        if tick.datetime.second==58 and not self.position_manage_started:
            self.position_manage_started=True
            # self.position_manage_put_order()

        self.put_event()
    
    def on_bar(self, bar: BarData):
        """
        Callback of new bar data update.
        """
        self.am.update_bar(bar)
        if self.day_high==0:
            self.day_high=bar.high_price
            self.day_low=bar.low_price
        if bar.datetime.time()==time(8,0):
            self.day_high=bar.high_price
            self.day_low=bar.low_price
        else:
            self.day_high=max(bar.high_price,self.day_high)
            self.day_low=min(bar.low_price,self.day_low)
            if bar.datetime.time()==time(7,59):#一天结束
                self.day_closes=np.append(self.day_closes,bar.close_price)
                self.day_lows=np.append(self.day_lows,self.day_low)
                self.day_highs=np.append(self.day_highs,self.day_high)

                if len(self.day_highs)>self.k_length_day:
                    self.hhv=self.day_highs[-self.k_length_day:].max()
                    self.llv=self.day_lows[-self.k_length_day:].min()
            
        
        if not self.am.inited:
            return
        
        self.ma_value=self.am.sma(self.ma_window)

        if bar.close_price>self.ma_value:
            self.ma_direction=1
        elif bar.close_price<self.ma_value:
            self.ma_direction=-1
        
        if self.trading:
            self.gateway.query_account()
            self.gateway.query_position()
            self.rate_limit_status=100
            self.gateway.init_rate_limit_status(self.symbol)

        self.position_manage_started=False
        self.put_event()

    def on_order(self, order: OrderData):
        """
        Callback of new order data update.
        """
        if self.grid_forward_status>0:
            self.grid_forward_order_triggered(order)
    
    def on_position(self, event):
        position = event.data
        if position.vt_symbol==self.vt_symbol:
            if position.direction==Direction.LONG:
                self.long_pos=position.volume
                if self.grid_forward_status>0 and self.last_long_pos>0 and self.long_pos==0:
                    self.write_log(f"多仓全平，顺势插针初始化")
                    self.grid_forward_init()
                self.last_long_pos=self.long_pos
            elif position.direction==Direction.SHORT:
                self.short_pos=position.volume
                if self.grid_forward_status>0 and self.last_short_pos>0 and self.short_pos==0:
                    self.write_log(f"空仓全平，顺势插针初始化")
                    self.grid_forward_init()
                self.last_short_pos=self.short_pos
            
    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data

        if account.gateway_name == 'BYBIT':
            self.balance = account.balance
            self.usedMargin = account.frozen
        # if account.accountid=='USDT':
        #     self.balance=account.balance
    
    def position_manage_init(self):
        self.position_manage_dict={'status':0,'volume':0,'left_volume':0,'left_price':0}

    def position_manage(self):
        if self.rsv>990 and not self.position_managed and self.pos_delay_num==0:
            self.write_log(f"{self.last_tick.datetime}，rsv>900,平空仓，量：{self.short_pos}")
            self.position_managed=True
            self.cancel_all()
            self.grid_id={}
            self.close_grid_id={}
            self.grid_forward_init()
            self.grid_back_init()
            self.pos_delay_num=20
            if self.short_pos>0:
                self.cover(self.last_tick.ask_price_1*1.01,self.short_pos)
            self.position_manage_init()
            self.position_manage_dict['status']=-1
            self.position_manage_dict['volume']=self.short_pos
        elif self.rsv<770 and self.position_managed and self.pos_delay_num==0 and self.position_manage_dict['status']<0:
            self.write_log(f"{self.last_tick.datetime}，rsv<890,重新开空仓，量：{self.position_manage_dict['volume']}")
            self.grid_back_init()
            self.position_managed=False
            self.pos_delay_num=20
            if self.position_manage_dict['volume']>0:
                self.short(self.last_tick.bid_price_1*0.99,self.position_manage_dict['volume'])
            self.position_manage_dict['status']=-2
            self.position_manage_dict['left_volume']=round_to(self.position_manage_dict['volume']*self.forward_pos_num_rate,self.min_volume)
        elif self.rsv<10 and not self.position_managed and self.pos_delay_num==0:
            self.write_log(f"{self.last_tick.datetime}，rsv<100,平多仓，量：{self.long_pos}")
            self.position_managed=True
            self.cancel_all()
            self.grid_id={}
            self.close_grid_id={}
            self.grid_forward_init()
            self.grid_back_init()
            self.pos_delay_num=20
            if self.long_pos>0:
                self.sell(self.last_tick.bid_price_1*0.99,self.long_pos)
            self.position_manage_init()
            self.position_manage_dict['status']=1
            self.position_manage_dict['volume']=self.long_pos
        elif self.rsv>250 and self.position_managed and self.pos_delay_num==0 and self.position_manage_dict['status']>0:
            self.write_log(f"{self.last_tick.datetime}，rsv>110,重新开多仓，量：{self.position_manage_dict['volume']}")
            self.grid_back_init()
            self.position_managed=False
            self.pos_delay_num=20
            if self.position_manage_dict['volume']>0:
                self.buy(self.last_tick.ask_price_1*1.01,self.position_manage_dict['volume'])
            self.position_manage_dict['status']=2
            self.position_manage_dict['left_volume']=round_to(self.position_manage_dict['volume']*self.forward_pos_num_rate,self.min_volume)
        elif 495<self.rsv<505:
            self.grid_forward_init()
    
    def new_position_manage(self):
        if self.rsv>990 and self.new_position_manage_pos==0 and self.pos_delay_num==0:
            self.pos_delay_num=20
            if self.short_pos>0:
                self.buy(self.last_tick.ask_price_1*1.01,(1+1))
                self.new_position_manage_pos=self.short_pos+self.target_long_pos
                self.write_log(f"{self.last_tick.datetime}，rsv>990,开多仓对冲，量：{self.short_pos+self.target_long_pos}")
        elif self.rsv<850 and self.pos_delay_num==0 and self.new_position_manage_pos>0:
            if self.new_position_manage_pos<self.long_pos:
                new_position_pos_close=self.new_position_manage_pos
            else:
                new_position_pos_close=self.long_pos
            self.sell(self.last_tick.bid_price_1*0.99,new_position_pos_close)
            self.new_position_manage_pos=0
            self.write_log(f"{self.last_tick.datetime}，rsv<750,平对冲仓位的多仓，量：{new_position_pos_close}")
        elif self.rsv<10 and self.new_position_manage_pos==0 and self.pos_delay_num==0:
            self.pos_delay_num=20
            if self.long_pos>0:
                self.short(self.last_tick.bid_price_1*0.99,(1+1))
                self.new_position_manage_pos=-self.long_pos
                self.write_log(f"{self.last_tick.datetime}，rsv<10,开空仓对冲，量：{self.target_short_pos+self.long_pos}")
        elif self.rsv>150 and self.new_position_manage_pos<0 and self.pos_delay_num==0:
            if abs(self.new_position_manage_pos)<self.short_pos:
                new_position_pos_close=abs(self.new_position_manage_pos)
            else:
                new_position_pos_close=self.short_pos
            self.cover(self.last_tick.ask_price_1*1.01,new_position_pos_close)
            self.new_position_manage_pos=0
            self.write_log(f"{self.last_tick.datetime}，rsv>250,平对冲仓位的空仓，量：{new_position_pos_close}")

    def position_manage_put_order(self):
        """通过position_manage函数平仓又开仓后，在每分钟的59秒时，根据剩余可挂单数量挂出新开仓位"""
        if self.position_manage_dict['left_volume']>0:
            self.get_rate_limit_status()
            left_num=self.rate_limit_status-10
            
            if left_num>0:
                if self.position_manage_dict['left_price']>0:
                    start_price=self.position_manage_dict['left_price']
                else:
                    start_price=(self.last_tick.ask_price_1+self.last_tick.bid_price_1)*0.5

                for i in range(1,left_num+1):
                    if self.position_manage_dict['status']==-2:
                        put_volume=self.forward_short_open
                        start_price=round_to(start_price-self.dynamic_grid_delta,self.pricetick)
                        self.cover(start_price,put_volume)
                        self.position_manage_dict['left_price']=start_price
                        self.position_manage_dict['left_volume']-=put_volume
                        self.write_log(f"{self.last_tick.datetime}，铺平空单，价：{self.position_manage_dict['left_price']}，量：{put_volume}")
                    elif self.position_manage_dict['status']==2:
                        put_volume=self.forward_long_open
                        start_price=round_to(start_price+self.dynamic_grid_delta,self.pricetick)
                        self.sell(start_price,put_volume)
                        self.position_manage_dict['left_price']=start_price
                        self.position_manage_dict['left_volume']-=put_volume
                        self.write_log(f"{self.last_tick.datetime}，铺平多单，价：{self.position_manage_dict['left_price']}，量：{put_volume}")
                    
                    if self.position_manage_dict['left_volume']<=0:
                        self.write_log(f"{self.last_tick.datetime}，平仓单全部铺货完成！")
                        self.position_manage_init()
                        break

    def process_grid_price(self,price):
        """计算网格价格"""
        # 下面是固定网格价差的代码
        # for i in range(1,self.grid_num+1):
        #     self.grid_price[str(i)]=price+i*self.grid_gap
        #     self.grid_price[str(-1*i)]=price-i*self.grid_gap
        M=1000
        S=M*0.5
        self.base_grid_delta=max((self.hhv-self.llv)/100000,price*self.grid_gap_pst)
        self.forward_base_pos_pst=(self.base_grid_delta/self.last_tick.last_price)*self.forward_base_pos_pst_num
        self.back_base_pos_pst=(self.base_grid_delta/self.last_tick.last_price)*self.back_base_pos_pst_num
        self.grid_base_pos_pst=(self.base_grid_delta/self.last_tick.last_price)*self.grid_base_pos_pst_num
        self.rsv=(self.last_tick.last_price-self.llv)/(self.hhv-self.llv)*M
        self.dynamic_grid_delta=self.base_grid_delta
        self.forward_dynamic_single_volume=self.forward_base_pos_pst
        self.back_dynamic_single_volume=self.back_base_pos_pst
        self.grid_dynamic_single_volume=self.grid_base_pos_pst

        self.grid_price['1']=round_to(price+self.dynamic_grid_delta,self.pricetick)
        self.grid_price['-1']=round_to(price-self.dynamic_grid_delta,self.pricetick)
        for i in range(2,self.grid_num+1):
            self.grid_price[str(i)]=round_to(self.grid_price[str(i-1)]+self.dynamic_grid_delta,self.pricetick)
            self.grid_price[str(-1*i)]=round_to(self.grid_price[str(-i+1)]-self.dynamic_grid_delta,self.pricetick)
        
        self.grid_move_ma() #计算多空目标仓位
        #网格突破后，重新计算big_percent和small_percent
        self.big_percent=(1+(abs(self.long_pos-self.short_pos)/((self.target_long_pos+self.target_short_pos)*self.pos_num)))*self.pos_pst
        self.small_percent=(1-(abs(self.long_pos-self.short_pos)/((self.target_long_pos+self.target_short_pos)*self.pos_num)))*self.pos_pst

        #仓位管理
        # self.position_manage()
        # self.new_position_manage()

    def grid_balance_init(self):
        self.init_grid()

    def grid_balance_tick(self,direction,break_num):
        #用于网格平衡策略的逻辑处理
        if direction=='up':
            if break_num<self.grid_num:
                self.grid_move_grid('up',break_num)
            else:
                for orderid in self.grid_id.values():
                    if orderid!='':
                        self.cancel_order(orderid)
                for orderid in self.close_grid_id.values():
                    if orderid!='':
                        self.cancel_order(orderid)
                self.close_grid_id={}
                self.grid_id={}
                if self.rate_limit_status>=(self.grid_num*5):
                    self.init_grid()
                else:
                    return

        elif direction=='down':
            if break_num<self.grid_num:
                self.grid_move_grid('down',break_num)
            else:
                for orderid in self.grid_id.values():
                    if orderid!='':
                        self.cancel_order(orderid)
                for orderid in self.close_grid_id.values():
                    if orderid!='':
                        self.cancel_order(orderid)
                self.close_grid_id={}
                self.grid_id={}
                if self.rate_limit_status>=(self.grid_num*5):
                    self.init_grid()
                else:
                    return

    def grid_back_init(self):
        self.continue_break_gird_num=0

    def grid_back_tick(self,direction,break_num,tick: TickData):
        if direction=='up':
            #向上突破网格
            if self.continue_break_gird_num>=0:
                self.continue_break_gird_num+=break_num
            else:
                if abs(self.continue_break_gird_num)>=self.contiune_grid_limit:
                    # plan_long_pos=round_to(self.target_long_pos*self.pos_pst*abs(self.continue_break_gird_num),self.min_volume)
                    plan_long_pos=round_to(self.back_long_open*abs(self.continue_break_gird_num),self.min_volume)
                    if self.short_pos>=plan_long_pos:
                        self.cover(tick.last_price*1.005,plan_long_pos)
                    else:
                        self.cover(tick.last_price*1.005,self.short_pos)
                        self.buy(tick.last_price*1.005,(plan_long_pos-self.short_pos))
                    self.continue_break_gird_num=break_num
                else:
                    self.continue_break_gird_num+=break_num
        elif direction=='down':
            if self.continue_break_gird_num<=0:
                self.continue_break_gird_num-=break_num
            else:
                if self.continue_break_gird_num>=self.contiune_grid_limit:
                    # plan_short_pos=round_to(self.target_short_pos*self.pos_pst*self.continue_break_gird_num,self.min_volume)
                    plan_short_pos=round_to(self.back_short_open*self.continue_break_gird_num,self.min_volume)
                    if self.long_pos>=plan_short_pos:
                        self.sell(tick.last_price*0.995,plan_short_pos)
                    else:
                        self.sell(tick.last_price*0.995,self.long_pos)
                        self.short(tick.last_price*0.995,(plan_short_pos-self.long_pos))
                    self.continue_break_gird_num=-break_num
                else:
                    self.continue_break_gird_num-=break_num

    def grid_forward_order_triggered(self,order: OrderData):
        vt_orderid=order.vt_orderid
        if order.status==Status.ALLTRADED:
            if vt_orderid in self.grid_forward_orderid_step_open:
                str_step=self.grid_forward_orderid_step_open[vt_orderid]
                forward_target_open_orderids=self.grid_forward_step_orderids_open[str_step]
                if vt_orderid in forward_target_open_orderids:
                    forward_target_open_orderids.remove(vt_orderid)
                del self.grid_forward_orderid_step_open[vt_orderid]
                if len(forward_target_open_orderids)==0: #目标开仓位置的挂单全部成交
                    if len(self.grid_forward_step_orderids_open[str(eval(str_step)+1)])==0: #在下一个目标价格位置没有挂单的情况，代表是第一次开仓位置的挂单全部成交
                        delta_targetprice=self.grid_forward_step_delta_targetprice[str(self.grid_forward_info['step'])]
                        delta_targetprice['delta']=self.grid_forward_info['target_foward_basic_grid']
                        delta_targetprice['targetprice']=self.grid_forward_info['target_price']
                        delta_targetprice['target_foward_basic_volume']=self.grid_forward_info['target_foward_basic_volume']
                        if self.grid_forward_info['direction']>0:
                            #先挂平空单，后挂开空单
                            close_price=self.grid_forward_info['target_price']
                            # close_volume=self.grid_forward_info['target_foward_basic_volume']
                            close_volume=self.forward_short_close
                            self.grid_forward_step_orderids_close[str(self.grid_forward_info['step'])]=[]
                            for i in range(self.grid_forward_info['step']):
                                close_price=round_to(close_price-self.grid_forward_info['target_foward_basic_grid'],self.pricetick)
                                orderids=self.cover(close_price,close_volume) #向下以网格方式拆单挂出
                                if len(orderids)>0:
                                    self.grid_forward_step_orderids_close[str(self.grid_forward_info['step'])].extend(orderids)
                                    self.grid_forward_orderid_step_close[orderids[-1]]=str(self.grid_forward_info['step'])
                            self.grid_forward_info_dict[str(self.grid_forward_info['step'])]=deepcopy(self.grid_forward_info)

                            # if self.grid_forward_info['step']<self.grid_forward_num_limit:
                            self.grid_forward_info['step']+=1
                            self.grid_forward_info['target_foward_basic_volume']=self.forward_short_open
                            self.grid_forward_info['target_foward_basic_grid']=self.dynamic_grid_delta
                            str_step=str(self.grid_forward_info['step'])
                            self.grid_forward_info['target_price']=round_to(self.grid_forward_info['target_price']+self.dynamic_grid_delta*self.grid_forward_info['step'],self.pricetick)
                            self.grid_forward_info_dict[str_step]=deepcopy(self.grid_forward_info)
                            for i in range(self.grid_forward_info['step']):
                                orderids=self.short(self.grid_forward_info['target_price'],self.grid_forward_info['target_foward_basic_volume'])
                                if len(orderids)>0:
                                    self.grid_forward_step_orderids_open[str_step].extend(orderids)
                                    self.grid_forward_orderid_step_open[orderids[-1]]=str_step
                            
                        elif self.grid_forward_info['direction']<0:
                            #先挂平多单，后挂开多单
                            close_price=self.grid_forward_info['target_price']
                            # close_volume=self.grid_forward_info['target_foward_basic_volume']
                            close_volume=self.forward_long_close
                            self.grid_forward_step_orderids_close[str(self.grid_forward_info['step'])]=[]
                            for i in range(self.grid_forward_info['step']):
                                close_price=round_to(close_price+self.grid_forward_info['target_foward_basic_grid'],self.pricetick)
                                orderids=self.sell(close_price,close_volume) #向上以网格方式拆单挂出
                                if len(orderids)>0:
                                    self.grid_forward_step_orderids_close[str(self.grid_forward_info['step'])].extend(orderids)
                                    self.grid_forward_orderid_step_close[orderids[-1]]=str(self.grid_forward_info['step'])
                            self.grid_forward_info_dict[str(self.grid_forward_info['step'])]=deepcopy(self.grid_forward_info)

                            # if self.grid_forward_info['step']<self.grid_forward_num_limit:
                            self.grid_forward_info['step']+=1
                            self.grid_forward_info['target_foward_basic_volume']=self.forward_long_open
                            self.grid_forward_info['target_foward_basic_grid']=self.dynamic_grid_delta
                            str_step=str(self.grid_forward_info['step'])
                            self.grid_forward_info['target_price']=round_to(self.grid_forward_info['target_price']-self.dynamic_grid_delta*self.grid_forward_info['step'],self.pricetick)
                            self.grid_forward_info_dict[str_step]=deepcopy(self.grid_forward_info)
                            for i in range(self.grid_forward_info['step']):
                                orderids=self.buy(self.grid_forward_info['target_price'],self.grid_forward_info['target_foward_basic_volume'])
                                if len(orderids)>0:
                                    self.grid_forward_step_orderids_open[str_step].extend(orderids)
                                    self.grid_forward_orderid_step_open[orderids[-1]]=str_step
                    elif len(self.grid_forward_step_orderids_open[str(eval(str_step)+1)])>0:#当前目标位置的挂单又重新成交，在平仓位置挂出平仓单
                        len_close_order_num=len(self.grid_forward_step_orderids_close[str_step]) #该str_step对应的平仓单数量
                        grid_forward_info_old=self.grid_forward_info_dict[str_step]
                        if grid_forward_info_old['direction']>0:
                            close_price=grid_forward_info_old['target_price']
                            # close_volume=grid_forward_info_old['target_foward_basic_volume']
                            close_volume=self.forward_short_close
                            for i in range(eval(str_step)-len_close_order_num):
                                close_price=round_to(close_price-grid_forward_info_old['target_foward_basic_grid'],self.pricetick)
                                orderids=self.cover(close_price,close_volume) #向下以网格方式拆单挂出
                                if len(orderids)>0:
                                    self.grid_forward_step_orderids_close[str(grid_forward_info_old['step'])].extend(orderids)
                                    self.grid_forward_orderid_step_close[orderids[-1]]=str(grid_forward_info_old['step'])
                        elif grid_forward_info_old['direction']<0:
                            close_price=grid_forward_info_old['target_price']
                            # close_volume=grid_forward_info_old['target_foward_basic_volume']
                            close_volume=self.forward_long_close
                            for i in range(eval(str_step)-len_close_order_num):
                                close_price=round_to(close_price+grid_forward_info_old['target_foward_basic_grid'],self.pricetick)
                                orderids=self.sell(close_price,close_volume) #向上以网格方式拆单挂出
                                if len(orderids)>0:
                                    self.grid_forward_step_orderids_close[str(grid_forward_info_old['step'])].extend(orderids)
                                    self.grid_forward_orderid_step_close[orderids[-1]]=str(grid_forward_info_old['step'])
            
            elif vt_orderid in self.grid_forward_orderid_step_close:
                str_step=self.grid_forward_orderid_step_close[vt_orderid]
                step_orderids=self.grid_forward_step_orderids_close[str_step]
                if vt_orderid in step_orderids:
                    step_orderids.remove(vt_orderid)
                del self.grid_forward_orderid_step_close[vt_orderid]

                #平出去一个挂单后，继续在原目标位置重新挂单
                if self.grid_forward_info['direction']>0:
                    #重新在上方target_price处挂开空单
                    orderids=self.short(self.grid_forward_step_delta_targetprice[str_step]['targetprice'],self.grid_forward_step_delta_targetprice[str_step]['target_foward_basic_volume'])
                    if len(orderids)>0:
                        self.grid_forward_step_orderids_open[str_step].extend(orderids)
                        self.grid_forward_orderid_step_open[orderids[-1]]=str_step

                elif self.grid_forward_info['direction']<0:
                    #重新在下方step网格处挂开多单
                    orderids=self.buy(self.grid_forward_step_delta_targetprice[str_step]['targetprice'],self.grid_forward_step_delta_targetprice[str_step]['target_foward_basic_volume'])
                    if len(orderids)>0:
                        self.grid_forward_step_orderids_open[str_step].extend(orderids)
                        self.grid_forward_orderid_step_open[orderids[-1]]=str_step

                if len(step_orderids)==0: #该step对应的挂出的平仓单已全部平完
                    #先平掉已挂出的开仓单
                    old_str_step=str(eval(str_step)+1) #已挂出开仓单处对应的str_step
                    if len(self.grid_forward_step_orderids_open[old_str_step])>0:
                        for orderid in self.grid_forward_step_orderids_open[old_str_step]:
                            self.cancel_order(orderid)
                        self.grid_forward_step_orderids_open[old_str_step].clear()
                    # 恢复参数至挂单前状态
                    self.grid_forward_info['step']=eval(str_step) #把step重新恢复到本平仓单对应的挂单时一致
                    self.grid_forward_info['target_foward_basic_volume']=self.grid_forward_step_delta_targetprice[str_step]['target_foward_basic_volume']
                    self.grid_forward_info['target_foward_basic_grid']=self.grid_forward_step_delta_targetprice[str_step]['delta']
                    self.grid_forward_info['target_price']=self.grid_forward_step_delta_targetprice[str_step]['targetprice']

    def grid_forward_init(self):
        #初始化时不挂单，等分辨出方向后开始挂单，即出现突破后       
        self.grid_forward_info={'direction':0,'foward_num':0,'target_price':0,'target_foward_basic_volume':0,'step':1,'target_foward_basic_grid':0} #记录顺势插针网格所有信息
        self.grid_forward_info_dict={}
        if len(self.grid_forward_orderid_step_close)>0:
            for orderid in self.grid_forward_orderid_step_close.keys():
                self.cancel_order(orderid)
        self.grid_forward_orderid_step_close={}
        self.grid_forward_step_orderids_close=defaultdict(list)
        if len(self.grid_forward_orderid_step_open)>0:
            for orderid in self.grid_forward_orderid_step_open.keys():
                self.cancel_order(orderid)
        self.grid_forward_orderid_step_open={}
        self.grid_forward_step_orderids_open=defaultdict(list)
        self.grid_forward_step_delta_targetprice=defaultdict(dict)

    def grid_forward_tick(self,direction,break_num):
        if direction=='up':
            if self.grid_forward_info['direction']==0:
                self.grid_forward_info['direction']=1
                self.grid_forward_info['foward_num']=1
                self.grid_forward_info['step']=1+self.grid_forward_info['step']
                self.grid_forward_info['target_foward_basic_volume']=self.forward_short_open
                self.grid_forward_info['target_foward_basic_grid']=self.dynamic_grid_delta
                #计算目标挂单价
                self.grid_forward_info['target_price']=round_to(self.grid_price['1'],self.pricetick)
                str_step=str(self.grid_forward_info['step'])
                self.grid_forward_step_orderids_open[str_step]=[]
                for i in range(self.grid_forward_info['step']):
                    orderids=self.short(self.grid_forward_info['target_price'],self.grid_forward_info['target_foward_basic_volume'])
                    self.grid_forward_step_orderids_open[str_step].extend(orderids)
                    self.grid_forward_orderid_step_open[orderids[-1]]=str_step
            elif self.grid_forward_info['direction']>0:
                self.grid_forward_info['foward_num']+=break_num
            elif self.grid_forward_info['direction']<0:
                self.grid_forward_info['foward_num']-=break_num
                if self.grid_forward_info['foward_num']<=0:
                    self.grid_forward_init()

        elif direction=='down':
            if self.grid_forward_info['direction']==0:
                self.grid_forward_info['direction']=-1
                self.grid_forward_info['foward_num']=1
                self.grid_forward_info['step']=1+self.grid_forward_info['step']
                self.grid_forward_info['target_foward_basic_volume']=self.forward_long_open
                self.grid_forward_info['target_foward_basic_grid']=self.dynamic_grid_delta
                #计算目标挂单价
                self.grid_forward_info['target_price']=round_to(self.grid_price['-1'],self.pricetick)
                str_step=str(self.grid_forward_info['step'])
                self.grid_forward_step_orderids_open[str_step]=[]
                for i in range(self.grid_forward_info['step']):
                    orderids=self.buy(self.grid_forward_info['target_price'],self.grid_forward_info['target_foward_basic_volume'])
                    self.grid_forward_step_orderids_open[str_step].extend(orderids)
                    self.grid_forward_orderid_step_open[orderids[-1]]=str_step
            elif self.grid_forward_info['direction']<0:
                self.grid_forward_info['foward_num']+=break_num
            elif self.grid_forward_info['direction']>0:
                self.grid_forward_info['foward_num']-=break_num
                if self.grid_forward_info['foward_num']<=0:
                    self.grid_forward_init()

    def break_num(self,direction,price):
        #突破了几个网格
        num=0
        if direction=='up':
            for i in range(1,self.grid_num+1):
                if price>self.grid_price[str(i)]:
                    num=i
                else:
                    break
            return num
        elif direction=='down':
            for i in range(1,self.grid_num+1):
                if price<self.grid_price[str(-1*i)]:
                    num=i
                else:
                    break
            return num
    
    def grid_move_ma(self):
        #网格移动或刚形成网格时，计算多空目标仓位
        orderids=self.balance_id.values()
        for orderid in orderids:
            if orderid!='':
                self.cancel_order(orderid)
        self.get_rate_limit_status()
        # self.gateway.query_account()
        # self.gateway.query_position()

        if self.balance>0:
            if self.ma_direction>0:
                long_usdt_use=self.balance*self.lerver_rate*self.duo_percent
                short_usdt_use=self.balance*self.lerver_rate*self.kong_percent
            elif self.ma_direction<0:
                long_usdt_use=self.balance*self.lerver_rate*self.kong_percent
                short_usdt_use=self.balance*self.lerver_rate*self.duo_percent
            else:
                long_usdt_use=0
                short_usdt_use=0
            price=0.5*(self.grid_price['1']+self.grid_price['-1'])
            self.target_long_pos=long_usdt_use/price
            self.target_short_pos=short_usdt_use/price
            
            # self.balance_id={'open_long':'','open_short':'','close_long':'','close_short':''}
            # self.id_balance={}
            # if self.ma_direction>0:
            #     if self.long_pos<self.target_short_pos:
            #         open_long=round_to((self.target_short_pos-self.long_pos),self.min_volume)
            #         open_long_ids=self.buy(self.grid_price['-1'],open_long)
            #         self.balance_id['open_long']=open_long_ids[-1]
            #         self.id_balance[open_long_ids[-1]]='open_long'
            #     if self.short_pos>self.target_long_pos:
            #         close_short=round_to((self.short_pos-self.target_long_pos),self.min_volume)
            #         close_short_ids=self.cover(self.grid_price['-1'],close_short)
            #         self.balance_id['close_short']=close_short_ids[-1]
            #         self.id_balance[close_short_ids[-1]]='close_short'
            # elif self.ma_direction<0:
            #     if self.long_pos>self.target_short_pos:
            #         close_long=round_to((self.long_pos-self.target_short_pos),self.min_volume)
            #         close_long_ids=self.sell(self.grid_price['1'],close_long)
            #         self.balance_id['close_long']=close_long_ids[-1]
            #         self.id_balance[close_long_ids[-1]]='close_long'
            #     if self.short_pos<self.target_long_pos:
            #         open_short=round_to((self.target_long_pos-self.short_pos),self.min_volume)
            #         open_short_ids=self.short(self.grid_price['1'],open_short)
            #         self.balance_id['open_short']=open_short_ids[-1]
            #         self.id_balance[open_short_ids[-1]]='open_short'
                
    def calculate_trade_volume(self):
        #顺势插针网格挂单量计算
        self.forward_long_open=max(round_to(self.forward_dynamic_single_volume*self.target_long_pos*self.small_percent,self.min_volume),self.min_volume)
        self.forward_long_close=max(round_to(self.forward_dynamic_single_volume*self.target_long_pos*self.big_percent,self.min_volume),self.min_volume)
        self.forward_short_open=max(round_to(self.forward_dynamic_single_volume*self.target_short_pos*self.small_percent,self.min_volume),self.min_volume)
        self.forward_short_close=max(round_to(self.forward_dynamic_single_volume*self.target_short_pos*self.big_percent,self.min_volume),self.min_volume)
        
        #回调插针网格挂单量计算
        if self.long_pos<self.min_volume:
            self.back_long_open=max(round_to(self.back_dynamic_single_volume*self.target_long_pos*self.small_percent,self.min_volume),self.min_volume)
        else:
            self.back_long_open=max(round_to(self.back_dynamic_single_volume*self.target_long_pos*self.small_percent,self.min_volume),self.min_volume)
        if self.short_pos<self.min_volume:
            self.back_short_open=max(round_to(self.back_dynamic_single_volume*self.target_short_pos*self.small_percent,self.min_volume),self.min_volume)
        else:
            self.back_short_open=max(round_to(self.back_dynamic_single_volume*self.target_short_pos*self.small_percent,self.min_volume),self.min_volume)

        #动态网格挂单量计算
        if self.long_pos<self.min_volume:
            self.long_open=max(round_to(self.grid_dynamic_single_volume*self.target_long_pos*self.small_percent,self.min_volume),self.min_volume)
            self.long_close=max(round_to(self.grid_dynamic_single_volume*self.target_long_pos*self.big_percent,self.min_volume),self.min_volume)
        else:
            self.long_open=max(round_to(self.grid_dynamic_single_volume*self.target_long_pos*self.small_percent,self.min_volume),self.min_volume)
            self.long_close=max(round_to(self.grid_dynamic_single_volume*self.target_long_pos*self.big_percent,self.min_volume),self.min_volume)
        if self.short_pos<self.min_volume:
            self.short_open=max(round_to(self.grid_dynamic_single_volume*self.target_short_pos*self.small_percent,self.min_volume),self.min_volume)
            self.short_close=max(round_to(self.grid_dynamic_single_volume*self.target_short_pos*self.big_percent,self.min_volume),self.min_volume)
        else:
            self.short_open=max(round_to(self.grid_dynamic_single_volume*self.target_short_pos*self.small_percent,self.min_volume),self.min_volume)
            self.short_close=max(round_to(self.grid_dynamic_single_volume*self.target_short_pos*self.big_percent,self.min_volume),self.min_volume)

    def init_grid(self):
        if (self.target_long_pos>0 or self.target_short_pos>0) and len(self.grid_id)==0:#初始建立起网格挂单
            self.calculate_trade_volume()

            for up in range(1,self.grid_num+1):
                if self.short_open>0 and self.long_pos<self.min_volume:
                    short_ids=self.short(self.grid_price[str(up)],self.short_open)
                    self.grid_id[str(up)]=short_ids[-1]
                else:
                    self.grid_id[str(up)]=''
                if self.long_close>0 and self.long_pos>=self.long_close:
                    sell_ids=self.sell(self.grid_price[str(up)],self.long_close)
                    self.close_grid_id[str(up)]=sell_ids[-1]
                else:
                    self.close_grid_id[str(up)]=''
            for down in range(-1*self.grid_num,0):
                if self.long_open>0 and self.short_pos<self.min_volume:
                    long_ids=self.buy(self.grid_price[str(down)],self.long_open)
                    self.grid_id[str(down)]=long_ids[-1]
                else:
                    self.grid_id[str(down)]=''
                if self.short_close>0 and self.short_pos>=self.short_close:
                    cover_ids=self.cover(self.grid_price[str(down)],self.short_close)
                    self.close_grid_id[str(down)]=cover_ids[-1]
                else:
                    self.close_grid_id[str(down)]=''

    def grid_move_grid(self,direction,break_num):
        if len(self.grid_id)>0 and self.rate_limit_status>20:
            self.calculate_trade_volume()

            temp_dict=defaultdict(str)
            close_temp_dict=defaultdict(str)
            if direction=='up':#价格向上突破A1
                for key,value in self.grid_id.items():
                    #整体向下移动网格，网格标号变为减去break_num，原被突破的网格向下移动到负向网格
                    if 0<eval(key)<=break_num:
                        temp_dict[str(eval(key)-break_num-1)]=''
                        close_temp_dict[str(eval(key)-break_num-1)]=''
                    else:
                        temp_dict[str(eval(key)-break_num)]=value
                        close_temp_dict[str(eval(key)-break_num)]=self.close_grid_id[key]
                for i in range(break_num):
                    #把向下移动后正向网格不足的部分新增进去
                    temp_dict[str(self.grid_num-i)]=''
                    #把向下移动后超出网格数量的部分撤销删除掉
                    if temp_dict[str(-1*self.grid_num-i-1)]!='':
                        self.cancel_order(temp_dict[str(-1*self.grid_num-i-1)])
                    del temp_dict[str(-1*self.grid_num-i-1)]

                    close_temp_dict[str(self.grid_num-i)]=''
                    if close_temp_dict[str(-1*self.grid_num-i-1)]!='':
                        self.cancel_order(close_temp_dict[str(-1*self.grid_num-i-1)])
                    del close_temp_dict[str(-1*self.grid_num-i-1)]
                    
                    if self.short_open>0 and self.long_pos<self.min_volume:
                        short_ids=self.short(self.grid_price[str(self.grid_num-i)],self.short_open)
                        temp_dict[str(self.grid_num-i)]=short_ids[-1]
                    else:
                        temp_dict[str(self.grid_num-i)]=''
                    if self.short_close>0 and self.short_pos>=self.short_close:
                        cover_ids=self.cover(self.grid_price[str(-1*(i+1))],self.short_close)
                        close_temp_dict[str(-1*(i+1))]=cover_ids[-1]
                    else:
                        close_temp_dict[str(-1*(i+1))]=''
                    if self.long_open>0 and self.short_pos<self.min_volume:
                        long_ids=self.buy(self.grid_price[str(-1*(i+1))],self.long_open)
                        temp_dict[str(-1*(i+1))]=long_ids[-1]
                    else:
                        temp_dict[str(-1*(i+1))]=''
                    if self.long_close>0 and self.long_pos>=self.long_close:
                        sell_ids=self.sell(self.grid_price[str(self.grid_num-i)],self.long_close)
                        close_temp_dict[str(self.grid_num-i)]=sell_ids[-1]
                    else:
                        close_temp_dict[str(self.grid_num-i)]=''
                        
                #检查网格挂单部分，是否有遗漏的位置没有挂单，挂入相应的单子
                for i in range(1,self.grid_num+1):
                    if temp_dict[str(i)]=='':
                        if self.short_open>0 and self.long_pos<self.min_volume:
                            short_ids=self.short(self.grid_price[str(i)],self.short_open)
                            temp_dict[str(i)]=short_ids[-1]
                        else:
                            temp_dict[str(i)]=''
                    if close_temp_dict[str(i)]=='':
                        if self.long_close>0 and self.long_pos>=self.long_close:
                            sell_ids=self.sell(self.grid_price[str(i)],self.long_close)
                            close_temp_dict[str(i)]=sell_ids[-1]
                        else:
                            close_temp_dict[str(i)]=''
                    if temp_dict[str(-1*i)]=='':
                        if self.long_open>0 and self.short_pos<self.min_volume:
                            long_ids=self.buy(self.grid_price[str(-1*i)],self.long_open)
                            temp_dict[str(-1*i)]=long_ids[-1]
                        else:
                            temp_dict[str(-1*i)]=''
                    if close_temp_dict[str(-1*i)]=='':
                        if self.short_close>0 and self.short_pos>=self.short_close:
                            cover_ids=self.cover(self.grid_price[str(-1*i)],self.short_close)
                            close_temp_dict[str(-1*i)]=cover_ids[-1]
                        else:
                            close_temp_dict[str(-1*i)]=''

                self.grid_id=deepcopy(temp_dict)
                self.close_grid_id=deepcopy(close_temp_dict)
            elif direction=='down':#价格向下突破B1
                for key,value in self.grid_id.items():
                    if (-1*break_num)<=eval(key)<0:
                        temp_dict[str(eval(key)+break_num+1)]=''
                        close_temp_dict[str(eval(key)+break_num+1)]=''
                    else:
                        temp_dict[str(eval(key)+break_num)]=value
                        close_temp_dict[str(eval(key)+break_num)]=self.close_grid_id[key]
                for i in range(break_num):
                    temp_dict[str(-1*self.grid_num+i)]=''
                    if temp_dict[str(self.grid_num+i+1)]!='':
                        self.cancel_order(temp_dict[str(self.grid_num+i+1)])
                    del temp_dict[str(self.grid_num+i+1)]

                    close_temp_dict[str(-1*self.grid_num+i)]=''
                    if close_temp_dict[str(self.grid_num+i+1)]!='':
                        self.cancel_order(close_temp_dict[str(self.grid_num+i+1)])
                    del close_temp_dict[str(self.grid_num+i+1)]

                    if self.long_open>0 and self.short_pos<self.min_volume:
                        long_ids=self.buy(self.grid_price[str(-1*self.grid_num+i)],self.long_open)
                        temp_dict[str(-1*self.grid_num+i)]=long_ids[-1]
                    else:
                        temp_dict[str(-1*self.grid_num+i)]=''
                    if self.long_close>0 and self.long_pos>=self.long_close:
                        sell_ids=self.sell(self.grid_price[str(i+1)],self.long_close)
                        close_temp_dict[str(i+1)]=sell_ids[-1]
                    else:
                        close_temp_dict[str(i+1)]=''
                    if self.short_open>0 and self.long_pos<self.min_volume:
                        short_ids=self.short(self.grid_price[str(i+1)],self.short_open)
                        temp_dict[str(i+1)]=short_ids[-1]
                    else:
                        temp_dict[str(i+1)]=''
                    if self.short_close>0 and self.short_pos>=self.short_close:
                        cover_ids=self.cover(self.grid_price[str(-1*self.grid_num+i)],self.short_close)
                        close_temp_dict[str(-1*self.grid_num+i)]=cover_ids[-1]
                    else:
                        close_temp_dict[str(-1*self.grid_num+i)]=''
                        
                
                for i in range(1,self.grid_num+1):
                    if temp_dict[str(i)]=='':
                        if self.short_open>0 and self.long_pos<self.min_volume:
                            short_ids=self.short(self.grid_price[str(i)],self.short_open)
                            temp_dict[str(i)]=short_ids[-1]
                        else:
                            temp_dict[str(i)]=''
                    if close_temp_dict[str(i)]=='':
                        if self.long_close>0 and self.long_pos>=self.long_close:
                            sell_ids=self.sell(self.grid_price[str(i)],self.long_close)
                            close_temp_dict[str(i)]=sell_ids[-1]
                        else:
                            close_temp_dict[str(i)]=''
                    if temp_dict[str(-1*i)]=='':
                        if self.long_open>0 and self.short_pos<self.min_volume:
                            long_ids=self.buy(self.grid_price[str(-1*i)],self.long_open)
                            temp_dict[str(-1*i)]=long_ids[-1]
                        else:
                            temp_dict[str(-1*i)]=''
                    if close_temp_dict[str(-1*i)]=='':
                        if self.short_close>0 and self.short_pos>=self.short_close:
                            cover_ids=self.cover(self.grid_price[str(-1*i)],self.short_close)
                            close_temp_dict[str(-1*i)]=cover_ids[-1]
                        else:
                            close_temp_dict[str(-1*i)]=''
                            
                self.grid_id=deepcopy(temp_dict)
                self.close_grid_id=deepcopy(close_temp_dict)
            self.get_rate_limit_status()

    def get_rate_limit_status(self):
        status=self.gateway.get_rate_limit_status(self.symbol)
        if status>0:
            self.rate_limit_status=status

