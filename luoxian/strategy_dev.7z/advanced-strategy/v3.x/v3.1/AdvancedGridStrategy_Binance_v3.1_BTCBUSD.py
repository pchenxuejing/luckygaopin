from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    BarData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from datetime import time
from time import sleep, time
from typing import Dict

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED 

OPPOSITE_DIRECTION: Dict[Direction, Direction] = {LONG: SHORT, SHORT: LONG}
OPPOSITE_OFFSET: Dict[Offset, Offset] = {OPEN: CLOSE, CLOSE: OPEN}

class AdvancedGridStrategy_Binances_v31_BTCBUSD(CtaTemplate):

    author = "Advanced Grid Strategy v3.1(BTCBUSD)"

    leverage_rate = 4                   # leverage [10, 20]
    close_volume_rate = 0.5             # close volume rate
    close_min_volume = 0.1              # close minimum volume
    min_price_tick = 100                # minimum distance pricetick
    max_price_tick = 500                # maximium distance pricetick
    profit_pricetick = 100              # price tick from entry_price
    open_order_min_price = 50           # it depends on exchange policy

    balance = 0                         # account balance
    long_pos_volume = 0                 # long position volume
    short_pos_volume = 0                # short position volume
    max_pos_volume = 0                  # maximium positon volume with current balance
    open_init_volume = 0                # initial volume of open order
    open_min_volume = 0
    open_volume_rate = 1
    current_pos_direction = None

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    entry_price = {
        LONG: 0,
        SHORT: 0
    }

    liq_price = {
        LONG: 0,
        SHORT: 0
    }

    parameters = ['leverage_rate', 'close_volume_rate', 'close_min_volume', 'min_price_tick', 'max_price_tick', 'profit_pricetick', 'open_order_min_price']
    variables = ['balance', 'max_pos_volume', 'open_init_volume', 'open_min_volume', 'open_volume_rate']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_long_pos_volume = 0
        self.last_short_pos_volume = 0

        self.main_process_thread = None
        self.restart_strategy_thread = None
        self.clear_order_thread = None

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.order_info_queue = {}

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')
        # self.write_log("策略初始化")

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()
        # self.write_log("策略启动")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

        # clear unnecessary orders
        self.clear_order_thread = Thread(target = self.clear_orders)
        self.clear_order_thread.setDaemon(True)
        self.clear_order_thread.start()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)
        # self.write_log("策略停止")

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

    def clear_orders(self):
        while True:
            direction = self.current_pos_direction
            if direction != None:
                opposite_direction = OPPOSITE_DIRECTION[direction]
                try:
                    order_info_queue = deepcopy(self.order_info_queue)
                except:
                    order_info_queue = deepcopy(self.order_info_queue)

                for vt_orderid in order_info_queue:
                    if vt_orderid == self.registered_order_info[direction][OPEN] or vt_orderid == self.registered_order_info[direction][CLOSE] or vt_orderid == self.registered_order_info[opposite_direction][CLOSE]:
                        continue

                    try:
                        if self.order_info_queue[vt_orderid]['status'] == NOTTRADED or self.order_info_queue[vt_orderid]['status'] == PARTTRADED:
                            sleep(0.5)
                        else:
                            del self.order_info_queue[vt_orderid]
                    except:
                        pass

                sleep(60)

    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        print("Restarting succeed")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance: ", self.balance)

        # main process daemon
        while self.stop_main_process == False:
            sleep(1)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                print("Tick is invalid.")
                continue

            if self.last_tick.last_price > self.last_tick.bid_price_1:
                self.current_pos_direction = LONG
            elif self.last_tick.last_price < self.last_tick.bid_price_1:
                self.current_pos_direction = SHORT
            else:
                self.current_pos_direction = None

            # check long and short open order which is placed when starts
            if self.current_pos_direction == None:
                for direction in (LONG, SHORT):
                    vt_orderid = self.registered_order_info[direction][OPEN]
                    if vt_orderid == '':
                        self.send_new_order(direction, OPEN)
                        continue

                    if vt_orderid not in self.order_info_queue:
                        if self.order_info_queue[vt_orderid]['status'] == ALLTRADED:
                            opposite_direction = OPPOSITE_DIRECTION[direction]
                            opposite_orderid = self.registered_order_info[opposite_direction][OPEN]
                            self.cancel_order(opposite_orderid)
                            self.registered_order_info[opposite_direction][OPEN] = ''

                            break
            elif self.current_pos_direction != None:
                direction = self.current_pos_direction
                opposite_direction = OPPOSITE_DIRECTION[direction]

                # opposite_direction open
                opposite_direction_orderid = self.registered_order_info[opposite_direction][OPEN]
                if opposite_direction_orderid != '':
                    if opposite_direction_orderid in self.order_info_queue and (self.order_info_queue[opposite_direction_orderid]['status'] == NOTTRADED or self.order_info_queue[opposite_direction_orderid]['status'] == PARTTRADED):
                        self.cancel_order(opposite_direction_orderid)
                    self.registered_order_info[opposite_direction][OPEN] = ''

                # direction open
                direction_open_orderid = self.registered_order_info[direction][OPEN]
                if direction_open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if direction_open_orderid in self.order_info_queue:
                        # send new order when order is rejected
                        if self.order_info_queue[direction_open_orderid]['status'] == REJECTED or self.order_info_queue[direction_open_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][OPEN] = ''
                            self.send_new_order(direction, OPEN)
                        # send new order when order is filled
                        elif self.order_info_queue[direction_open_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, OPEN)
                        # send new order when order is not traded or part traded
                        elif self.order_info_queue[direction_open_orderid]['status'] == NOTTRADED or self.order_info_queue[direction_open_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[direction_open_orderid]['price']
                            self.send_new_order(direction, OPEN, price)

                # close
                if self.long_pos_volume > 0:
                    short_close_orderid = self.registered_order_info[SHORT][CLOSE]
                    if short_close_orderid == '':
                        self.send_new_order(SHORT, CLOSE)
                    else:
                        if short_close_orderid in self.order_info_queue:
                            # send new order when order is rejected
                            if self.order_info_queue[short_close_orderid]['status'] == REJECTED or self.order_info_queue[short_close_orderid]['status'] == CANCELLED:
                                self.registered_order_info[SHORT][CLOSE] = ''
                                self.send_new_order(SHORT, CLOSE)
                            # send new order when order is filled
                            elif self.order_info_queue[short_close_orderid]['status'] == ALLTRADED:
                                self.send_new_order(SHORT, CLOSE)
                            # send new order when order is not traded or part traded
                            elif self.order_info_queue[short_close_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_orderid]['status'] == PARTTRADED:
                                price = self.order_info_queue[short_close_orderid]['price']
                                self.send_new_order(SHORT, CLOSE, price)

                if self.short_pos_volume > 0:
                    long_close_orderid = self.registered_order_info[LONG][CLOSE]
                    if long_close_orderid == '':
                        self.send_new_order(LONG, CLOSE)
                    else:
                        if long_close_orderid in self.order_info_queue:
                            # send new order when order is rejected
                            if self.order_info_queue[long_close_orderid]['status'] == REJECTED or self.order_info_queue[long_close_orderid]['status'] == CANCELLED:
                                self.registered_order_info[LONG][CLOSE] = ''
                                self.send_new_order(LONG, CLOSE)
                            # send new order when order is filled
                            elif self.order_info_queue[long_close_orderid]['status'] == ALLTRADED:
                                self.send_new_order(LONG, CLOSE)
                            # send new order when order is not traded or part traded
                            elif self.order_info_queue[long_close_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_orderid]['status'] == PARTTRADED:
                                price = self.order_info_queue[long_close_orderid]['price']
                                self.send_new_order(LONG, CLOSE, price)

        sleep(2)

        # cancel all orders when strategy stop
        direction = self.current_pos_direction
        if direction != None:
            opposite_direction = OPPOSITE_DIRECTION[direction]
            open_id = self.registered_order_info[direction][OPEN]
            if open_id != '':
                if open_id in self.order_info_queue and (self.order_info_queue[open_id]['status'] == NOTTRADED or self.order_info_queue[open_id]['status'] == PARTTRADED):
                    self.cancel_order(open_id)

            opposite_open_id = self.registered_order_info[opposite_direction][OPEN]
            if opposite_open_id != '':
                if opposite_open_id in self.order_info_queue and (self.order_info_queue[opposite_open_id]['status'] == NOTTRADED or self.order_info_queue[opposite_open_id]['status'] == PARTTRADED):
                    self.cancel_order(opposite_open_id)

            close_id = self.registered_order_info[direction][CLOSE]
            if close_id != '':
                if close_id in self.order_info_queue and (self.order_info_queue[close_id]['status'] == NOTTRADED or self.order_info_queue[close_id]['status'] == PARTTRADED):
                    self.cancel_order(close_id)

            opposite_close_id = self.registered_order_info[opposite_direction][CLOSE]
            if opposite_close_id != '':
                if opposite_close_id in self.order_info_queue and (self.order_info_queue[opposite_close_id]['status'] == NOTTRADED or self.order_info_queue[opposite_close_id]['status'] == PARTTRADED):
                    self.cancel_order(opposite_close_id)

        sleep(2)

        self.stop_main_process = False

    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, old_price = -1):
        self.calc_max_pos_and_init_volume()

        # calculate price based on AS model
        new_price = self.get_order_price(direction, offset, old_price)
        if new_price == 0:
            return

        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        new_volume = 0
        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        # calculate the new volume when offset is open
        if offset == OPEN:
            # calculate new volume
            new_volume = self.open_init_volume
            if direction == LONG:
                if self.long_pos_volume > 0:
                    new_volume = max(self.open_init_volume * abs(new_price - self.entry_price[LONG]) * self.open_volume_rate, self.open_init_volume)
                    if self.long_pos_volume >= self.max_pos_volume / 2:
                        new_volume = self.open_min_volume
                    else:
                        if new_volume + self.long_pos_volume >= self.max_pos_volume / 2:
                            new_volume = self.max_pos_volume / 2 - self.long_pos_volume
            elif direction == SHORT:
                if self.short_pos_volume > 0:
                    new_volume = max(self.open_init_volume * abs(new_price - self.entry_price[SHORT]) * self.open_volume_rate, self.open_init_volume)
                    if self.short_pos_volume >= self.max_pos_volume / 2:
                        new_volume = self.open_min_volume
                    else:
                        if new_volume + self.short_pos_volume >= self.max_pos_volume / 2:
                            new_volume = self.max_pos_volume / 2 - self.short_pos_volume

            if new_volume < self.open_min_volume:
                new_volume =  self.open_min_volume
        elif offset == CLOSE:
            if direction == LONG:
                if self.short_pos_volume > 0:
                    rate = max(round_to(abs(new_price - self.entry_price[SHORT]) + 0.5, 1), 1)
                    new_volume = self.short_pos_volume * self.close_volume_rate * rate
                    if self.short_pos_volume < self.close_min_volume:
                        new_volume = self.short_pos_volume
                else:
                    return False
            elif direction == SHORT:
                if self.long_pos_volume > 0:
                    rate = max(round_to(abs(new_price - self.entry_price[LONG]) + 0.5, 1), 1)
                    new_volume = self.long_pos_volume * self.close_volume_rate * rate
                    if self.long_pos_volume < self.close_min_volume:
                        new_volume = self.long_pos_volume
                else:
                    return False

            if new_volume < self.min_volume:
                new_volume =  self.min_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False

    """
    "   desc:   Get ask/bid price based on AS model
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_order_price(self, direction, offset, old_price):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        if direction == LONG:
            price = tick.bid_price_1 + ask1_bid1_pricetick
            if offset == OPEN:
                if self.long_pos_volume > 0:
                    dist_price_tick_num = min(max(round_to(abs(tick.bid_price_1 - self.entry_price[LONG]) / (2 * self.pricetick), 1), self.min_price_tick), self.max_price_tick)
                    if price > self.entry_price[LONG]:
                        price = tick.bid_price_5 - dist_price_tick_num * self.pricetick
                    else:
                        price = tick.bid_price_1 - dist_price_tick_num * self.pricetick
            elif offset == CLOSE:
                if price > self.entry_price[SHORT] - self.profit_pricetick * self.pricetick:
                    price = self.entry_price[SHORT] - self.profit_pricetick * self.pricetick
        elif direction == SHORT:
            price = tick.ask_price_1 - ask1_bid1_pricetick
            if offset == OPEN:
                if self.short_pos_volume > 0:
                    dist_price_tick_num = min(max(round_to(abs(tick.ask_price_1 - self.entry_price[SHORT]) / (2 * self.pricetick), 1), self.min_price_tick), self.max_price_tick)
                    if price < self.entry_price[SHORT]:
                        price = tick.ask_price_5 + dist_price_tick_num * self.pricetick
                    else:
                        price = tick.ask_price_1 + dist_price_tick_num * self.pricetick
            elif offset == CLOSE:
                if price < self.entry_price[LONG] + self.profit_pricetick * self.pricetick:
                    price = self.entry_price[LONG] + self.profit_pricetick * self.pricetick

        price = round_to(price, self.pricetick)

        return price

    """
    "   desc:   Calculate max_pos_volume
    "   input:  market_price
    """
    def calc_max_pos_and_init_volume(self):
        self.max_pos_volume = self.balance * self.leverage_rate / self.market_price
        self.open_min_volume = round_to(self.open_order_min_price / self.market_price, self.min_volume)
        self.open_init_volume = max(round_to(self.max_pos_volume * self.pricetick / self.market_price, self.min_volume), self.open_min_volume)
        if self.max_pos_volume * self.pricetick / self.market_price < self.open_min_volume:
            self.open_volume_rate = (self.max_pos_volume * self.pricetick / self.market_price) / self.open_min_volume

    """
    "   desc: Get order type as string
    "   input: direction, offset
    """
    def get_order_type_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'LONG_OPEN'
            else:
                return 'LONG_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'SHORT_OPEN'
            else:
                return 'SHORT_CLOSE'

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.long_pos_volume = abs(position.volume)
                # closed all long pos
                if self.last_long_pos_volume > 0 and self.long_pos_volume == 0:
                    # self.write_log(f"多仓全平")
                    # print('Restarting because all long position are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_long_pos_volume = self.long_pos_volume
            elif direction == SHORT:
                self.short_pos_volume = abs(position.volume)
                # closed all short pos
                if self.last_short_pos_volume > 0 and self.short_pos_volume == 0:
                    # self.write_log(f"空仓全平")
                    # print('Restarting because all short position are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_short_pos_volume = self.short_pos_volume

            self.entry_price[direction] = position.price
            self.liq_price[direction] = position.liq_price

    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            self.summary_count['total'] += order.volume
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)

                if direction == LONG:
                    if offset == OPEN:
                        print("ALLTRADED:", f'{self.current_pos_direction: >12}{order_type_str: >12}{self.liq_price[LONG]: >12}{self.entry_price[LONG]: >12}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
                    else:
                        print("ALLTRADED:", f'{self.current_pos_direction: >12}{order_type_str: >12}{self.liq_price[SHORT]: >12}{self.entry_price[SHORT]: >12}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
                elif direction == SHORT:
                    if offset == OPEN:
                        print("ALLTRADED:", f'{self.current_pos_direction: >12}{order_type_str: >12}{self.liq_price[SHORT]: >12}{self.entry_price[SHORT]: >12}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
                    else:
                        print("ALLTRADED:", f'{self.current_pos_direction: >12}{order_type_str: >12}{self.liq_price[LONG]: >12}{self.entry_price[LONG]: >12}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
