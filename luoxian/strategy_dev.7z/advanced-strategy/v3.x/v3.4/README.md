# advanced-strategy
Version 3.3

=========== How to calucate the best parameters? ===========

1. Leverage Setup
  balance / 1000 = pos_num (in ETHBUSD)
  leverage = balance / (market_price * pos_num)

2. Others
    open_volume_rate = 1000             # open_init_volume = max_pos_volume / this value
    close_volume_rate = 0.1             # close volume rate
    close_min_volume = 0.1              # close minimum volume
    dist_pricetick = 0.1                # distance with ask1/bid1_price
    profit_pricetick = 1.0              # because of maker fee
    max_close_order_volume = 10.0       # it depends on exchange policy
    intentional_add_price = 100         # new_volume = open_init_volume * (new_price +/- this value) / entry_price
    KAMA_Period = 3

=========== Main goals ===========

1. Price Trending
    Using KAMA
    When price is up by kama_value, then send only long_opne order, otherwise send only short_open order.

2. Price Calculation of New Order

- LONG_OPEN Order
    if abs(price - self.entry_price[LONG]) > 100:
        price = tick.bid_price_1 - self.dist_pricetick
    elif abs(price - self.entry_price[LONG]) > 80:
        price = tick.bid_price_2 - self.dist_pricetick
    elif abs(price - self.entry_price[LONG]) > 50:
        price = tick.bid_price_3 - self.dist_pricetick
    elif abs(price - self.entry_price[LONG]) > 20:
        price = tick.bid_price_4 - self.dist_pricetick
    else:
        price = tick.bid_price_5 - self.dist_pricetick

- SHORT_OPEN Order
    if abs(price - self.entry_price[SHORT]) > 100:
        price = tick.ask_price_1 + self.dist_pricetick
    elif abs(price - self.entry_price[SHORT]) > 80:
        price = tick.ask_price_2 + self.dist_pricetick
    elif abs(price - self.entry_price[SHORT]) > 50:
        price = tick.ask_price_3 + self.dist_pricetick
    elif abs(price - self.entry_price[SHORT]) > 20:
        price = tick.ask_price_4 + self.dist_pricetick
    else:
        price = tick.ask_price_5 + self.dist_pricetick

3. Volume Calculation of New Order

- Open Order
    new_volume = self.open_init_volume * (self.entry_price[LONG] / (new_price - self.intentional_add_price))   ... (Long)

    new_volume = self.open_init_volume * ((new_price + self.intentional_add_price) / self.entry_price[SHORT])  ... (Short)

- Close Order
    new_volume = long(short)_pos_volume * 0.1 (* dist_pricetick_rate)