from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    BarData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from datetime import time
from time import sleep, time
from typing import Dict

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

OPPOSITE_DIRECTION: Dict[Direction, Direction] = {LONG: SHORT, SHORT: LONG}
OPPOSITE_OFFSET: Dict[Offset, Offset] = {OPEN: CLOSE, CLOSE: OPEN}
PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bullish", 2: "Bearish"}

class AdvancedGridStrategy_Bybit_v34_ETHUSDT(CtaTemplate):

    author = "Advanced Grid Strategy v3.4(ETHUSDT)"

    leverage_rate = 5.0                 # leverage [10, 20]
    open_volume_rate = 1000             # open_init_volume = max_pos_volume / this value
    close_volume_rate = 1.0             # close volume rate
    close_min_volume = 1.0              # close minimum volume
    profit_pricetick = 1.0              # because of maker fee
    max_close_order_volume = 100.0      # it depends on exchange policy

    balance = 0                         # account balance
    long_pos_volume = 0                 # long position volume
    short_pos_volume = 0                # short position volume
    max_pos_volume = 0                  # maximium positon volume with current balance
    open_init_volume = 0                # initial volume of open order
    current_pos_direction = None

    # kama method
    kama = 0
    kama_status = 0                     # 0: long/short open, 1: long open (market price is up), 2: short open (market price is down)
    KAMA_Period = 10

    rate_limit_status = 300             # limit of request count on bybit, [100/min, 300/min, 600/min]

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    entry_price = {
        LONG: 0,
        SHORT: 0
    }

    liq_price = {
        LONG: 0,
        SHORT: 0
    }

    open_lp = {
        LONG: 0,
        SHORT: 0
    }

    parameters = ['leverage_rate', 'open_volume_rate', 'close_volume_rate', 'close_min_volume', 'profit_pricetick', 'max_close_order_volume', 'KAMA_Period']
    variables = ['balance', 'max_pos_volume', 'open_init_volume', 'kama', 'kama_status', 'rate_limit_status']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # kama
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_long_pos_volume = 0
        self.last_short_pos_volume = 0

        self.main_process_thread = None
        self.restart_strategy_thread = None
        self.clear_order_thread = None

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.order_info_queue = {}

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BYBIT')
        # kama
        self.load_bar(2)
        # self.write_log("策略初始化")

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.rate_limit_status = 300

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()
        # self.write_log("策略启动")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

        # clear unnecessary orders
        self.clear_order_thread = Thread(target = self.clear_orders)
        self.clear_order_thread.setDaemon(True)
        self.clear_order_thread.start()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)
        # self.write_log("策略停止")

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        # kama
        self.bargenerator.update_tick(tick)
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

    def on_bar(self, bar: BarData):
        """
        Callback of new bar data update.
        """
        self.arraymanager.update_bar(bar)
        if not self.arraymanager.inited:
            return

        self.kama = self.arraymanager.kama(self.KAMA_Period)
        self.put_event()

    def clear_orders(self):
        while True:
            direction = self.current_pos_direction
            if direction != None:
                opposite_direction = OPPOSITE_DIRECTION[direction]
                try:
                    order_info_queue = deepcopy(self.order_info_queue)
                except:
                    order_info_queue = deepcopy(self.order_info_queue)

                for vt_orderid in order_info_queue:
                    if vt_orderid == self.registered_order_info[direction][OPEN] or vt_orderid == self.registered_order_info[direction][CLOSE] or vt_orderid == self.registered_order_info[opposite_direction][CLOSE]:
                        continue

                    try:
                        if self.order_info_queue[vt_orderid]['status'] == NOTTRADED or self.order_info_queue[vt_orderid]['status'] == PARTTRADED:
                            sleep(0.5)
                        else:
                            del self.order_info_queue[vt_orderid]
                    except:
                        pass

                sleep(60)

    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        print("Restarting succeed")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance: ", self.balance)

        self.calc_max_pos_and_init_volume(self.leverage_rate)

        # main process daemon
        start = time()
        while self.stop_main_process == False:
            sleep(1)

            end = time()
            if (end- start) > 2:
                self.get_rate_limit_status()
                start = end

            if self.rate_limit_status <= 10:
                print("rate limit status: ", self.rate_limit_status)
                continue

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                print("Tick is invalid.")
                continue

            if self.last_tick.last_price > self.kama:
                self.kama_status = 1
                self.current_pos_direction = LONG
            elif self.last_tick.last_price < self.kama:
                self.kama_status = 2
                self.current_pos_direction = SHORT
            else:
                self.kama_status = 0
                self.current_pos_direction = None

            # check long and short open order which is placed when starts
            if self.current_pos_direction == None:
                print('================ !!! None Trending !!! ================')
                # long open
                long_open_orderid = self.registered_order_info[LONG][OPEN]
                if long_open_orderid != '':
                    if long_open_orderid in self.order_info_queue and (self.order_info_queue[long_open_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_orderid]['status'] == PARTTRADED):
                        self.cancel_order(long_open_orderid)
                    self.registered_order_info[LONG][OPEN] = ''

                # short open
                short_open_orderid = self.registered_order_info[SHORT][OPEN]
                if short_open_orderid != '':
                    if short_open_orderid in self.order_info_queue and (self.order_info_queue[short_open_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_orderid]['status'] == PARTTRADED):
                        self.cancel_order(short_open_orderid)
                    self.registered_order_info[SHORT][OPEN] = ''

                # short close
                if self.long_pos_volume > 0:
                    short_close_orderid = self.registered_order_info[SHORT][CLOSE]
                    if short_close_orderid != '':
                        if short_close_orderid in self.order_info_queue and (self.order_info_queue[short_close_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_orderid]['status'] == PARTTRADED):
                            self.cancel_order(short_close_orderid)
                        self.registered_order_info[SHORT][CLOSE] = ''

                # long close
                if self.short_pos_volume > 0:
                    long_close_orderid = self.registered_order_info[LONG][CLOSE]
                    if long_close_orderid != '':
                        if long_close_orderid in self.order_info_queue and (self.order_info_queue[long_close_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_orderid]['status'] == PARTTRADED):
                            self.cancel_order(long_close_orderid)
                        self.registered_order_info[LONG][CLOSE] = ''
            elif self.current_pos_direction != None:
                direction = self.current_pos_direction
                opposite_direction = OPPOSITE_DIRECTION[direction]

                # opposite_direction open
                opposite_direction_orderid = self.registered_order_info[opposite_direction][OPEN]
                if opposite_direction_orderid != '':
                    if opposite_direction_orderid in self.order_info_queue and (self.order_info_queue[opposite_direction_orderid]['status'] == NOTTRADED or self.order_info_queue[opposite_direction_orderid]['status'] == PARTTRADED):
                        self.cancel_order(opposite_direction_orderid)
                    self.registered_order_info[opposite_direction][OPEN] = ''

                # direction open
                direction_open_orderid = self.registered_order_info[direction][OPEN]
                if direction_open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if direction_open_orderid in self.order_info_queue:
                        # send new order when order is rejected
                        if self.order_info_queue[direction_open_orderid]['status'] == REJECTED or self.order_info_queue[direction_open_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][OPEN] = ''
                            self.send_new_order(direction, OPEN)
                        # send new order when order is filled
                        elif self.order_info_queue[direction_open_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, OPEN)
                        # send new order when order is not traded or part traded
                        elif self.order_info_queue[direction_open_orderid]['status'] == NOTTRADED or self.order_info_queue[direction_open_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[direction_open_orderid]['price']
                            self.send_new_order(direction, OPEN, price)

                # close
                if self.long_pos_volume > 0:
                    short_close_orderid = self.registered_order_info[SHORT][CLOSE]
                    if short_close_orderid == '':
                        self.send_new_order(SHORT, CLOSE)
                    else:
                        if short_close_orderid in self.order_info_queue:
                            # send new order when order is rejected
                            if self.order_info_queue[short_close_orderid]['status'] == REJECTED or self.order_info_queue[short_close_orderid]['status'] == CANCELLED:
                                self.registered_order_info[SHORT][CLOSE] = ''
                                self.send_new_order(SHORT, CLOSE)
                            # send new order when order is filled
                            elif self.order_info_queue[short_close_orderid]['status'] == ALLTRADED:
                                self.send_new_order(SHORT, CLOSE)
                            # send new order when order is not traded or part traded
                            elif self.order_info_queue[short_close_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_orderid]['status'] == PARTTRADED:
                                price = self.order_info_queue[short_close_orderid]['price']
                                self.send_new_order(SHORT, CLOSE, price)

                if self.short_pos_volume > 0:
                    long_close_orderid = self.registered_order_info[LONG][CLOSE]
                    if long_close_orderid == '':
                        self.send_new_order(LONG, CLOSE)
                    else:
                        if long_close_orderid in self.order_info_queue:
                            # send new order when order is rejected
                            if self.order_info_queue[long_close_orderid]['status'] == REJECTED or self.order_info_queue[long_close_orderid]['status'] == CANCELLED:
                                self.registered_order_info[LONG][CLOSE] = ''
                                self.send_new_order(LONG, CLOSE)
                            # send new order when order is filled
                            elif self.order_info_queue[long_close_orderid]['status'] == ALLTRADED:
                                self.send_new_order(LONG, CLOSE)
                            # send new order when order is not traded or part traded
                            elif self.order_info_queue[long_close_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_orderid]['status'] == PARTTRADED:
                                price = self.order_info_queue[long_close_orderid]['price']
                                self.send_new_order(LONG, CLOSE, price)

        sleep(2)

        # cancel all orders when strategy stop
        direction = self.current_pos_direction
        if direction != None:
            opposite_direction = OPPOSITE_DIRECTION[direction]
            open_id = self.registered_order_info[direction][OPEN]
            if open_id != '':
                if open_id in self.order_info_queue and (self.order_info_queue[open_id]['status'] == NOTTRADED or self.order_info_queue[open_id]['status'] == PARTTRADED):
                    self.cancel_order(open_id)

            opposite_open_id = self.registered_order_info[opposite_direction][OPEN]
            if opposite_open_id != '':
                if opposite_open_id in self.order_info_queue and (self.order_info_queue[opposite_open_id]['status'] == NOTTRADED or self.order_info_queue[opposite_open_id]['status'] == PARTTRADED):
                    self.cancel_order(opposite_open_id)

            close_id = self.registered_order_info[direction][CLOSE]
            if close_id != '':
                if close_id in self.order_info_queue and (self.order_info_queue[close_id]['status'] == NOTTRADED or self.order_info_queue[close_id]['status'] == PARTTRADED):
                    self.cancel_order(close_id)

            opposite_close_id = self.registered_order_info[opposite_direction][CLOSE]
            if opposite_close_id != '':
                if opposite_close_id in self.order_info_queue and (self.order_info_queue[opposite_close_id]['status'] == NOTTRADED or self.order_info_queue[opposite_close_id]['status'] == PARTTRADED):
                    self.cancel_order(opposite_close_id)

        sleep(2)

        self.stop_main_process = False

    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, old_price = -1):
        self.calc_max_pos_and_init_volume(self.leverage_rate)

        # calculate price based on AS model
        new_price = self.get_order_price(direction, offset, old_price)
        if new_price == 0:
            return

        # calculate the new volume when offset is open
        new_volume = 0
        if offset == OPEN:
            # calculate new volume
            new_volume = abs(self.kama - new_price) * self.pricetick
            if direction == LONG:
                if self.kama > new_price:
                    return
            elif direction == SHORT:
                if self.kama < new_price:
                    return

            if new_volume < self.min_volume:
                new_volume = self.min_volume
        elif offset == CLOSE:
            if direction == LONG:
                if self.short_pos_volume > 0:
                    if self.short_pos_volume <= self.close_min_volume:
                        new_volume = self.short_pos_volume
                    else:
                        if self.current_pos_direction == LONG:
                            new_volume = self.short_pos_volume
                        else:
                            rate = min(max(round_to(abs(new_price - self.entry_price[SHORT]), 1), 1), 1 / self.close_volume_rate)
                            new_volume = self.short_pos_volume * self.close_volume_rate * rate
                        if new_volume > self.max_close_order_volume:
                            new_volume = self.max_close_order_volume
                else:
                    return False
            elif direction == SHORT:
                if self.long_pos_volume > 0:
                    if self.long_pos_volume <= self.close_min_volume:
                        new_volume = self.long_pos_volume
                    else:
                        if self.current_pos_direction == SHORT:
                            new_volume = self.long_pos_volume
                        else:
                            rate = min(max(round_to(abs(new_price - self.entry_price[LONG]), 1), 1), 1 / self.close_volume_rate)
                            new_volume = self.long_pos_volume * self.close_volume_rate * rate
                        if new_volume > self.max_close_order_volume:
                            new_volume = self.max_close_order_volume
                else:
                    return False

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        if self.stop_main_process == True:
            return False

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.gateway.modify_order_price(self.symbol, origin_vt_orderid.split('.')[-1], new_price, new_volume)
                self.set_order_info_queue(origin_vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
                return True

            self.registered_order_info[direction][offset] = ''

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False

    """
    "   desc:   Get ask/bid price based on AS model
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_order_price(self, direction, offset, old_price):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        if direction == LONG:
            price = tick.bid_price_1 + ask1_bid1_pricetick
            if offset == OPEN:
                if self.long_pos_volume > 0:
                    if price < self.entry_price[LONG] + self.profit_pricetick:
                        return 0
            elif offset == CLOSE:
                if self.current_pos_direction == SHORT:
                    if price > self.entry_price[SHORT] - self.profit_pricetick:
                        price = self.entry_price[SHORT] - self.profit_pricetick
        elif direction == SHORT:
            price = tick.ask_price_1 - ask1_bid1_pricetick
            if offset == OPEN:
                if self.short_pos_volume > 0:
                    if price > self.entry_price[SHORT] - self.profit_pricetick:
                        return 0
            elif offset == CLOSE:
                if self.current_pos_direction == LONG:
                    if price < self.entry_price[LONG] + self.profit_pricetick:
                        price = self.entry_price[LONG] + self.profit_pricetick

        price = round_to(price, self.pricetick)

        return price

    """
    "   desc:   Calculate max_pos_volume
    "   input:  market_price
    """
    def calc_max_pos_and_init_volume(self, leverage):
        self.max_pos_volume = self.balance * leverage / self.market_price

    """
    "   desc:   Calculate rate_limit
    """
    def get_rate_limit_status(self):
        status = self.gateway.get_rate_limit_status(self.symbol)
        if status > 0:
            self.rate_limit_status = status

    """
    "   desc: Get order type as string
    "   input: direction, offset
    """
    def get_order_type_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'LONG_OPEN'
            else:
                return 'LONG_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'SHORT_OPEN'
            else:
                return 'SHORT_CLOSE'

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BYBIT':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.long_pos_volume = abs(position.volume)
                # closed all long pos
                if self.last_long_pos_volume > 0 and self.long_pos_volume == 0:
                    # self.write_log(f"多仓全平")
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_long_pos_volume = self.long_pos_volume
            elif direction == SHORT:
                self.short_pos_volume = abs(position.volume)
                # closed all short pos
                if self.last_short_pos_volume > 0 and self.short_pos_volume == 0:
                    # self.write_log(f"空仓全平")
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_short_pos_volume = self.short_pos_volume

            self.entry_price[direction] = position.price
            self.liq_price[direction] = position.liq_price

    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            self.summary_count['total'] += round_to(order.price * order.volume, 1)
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)

                if direction == LONG:
                    if offset == OPEN:
                        print("ALLTRADED:", f'{PRICE_TRENDING[self.kama_status]: >10}{order_type_str: >16}{self.liq_price[LONG]: >16}{self.entry_price[LONG]: >16}{order.price: >16}{order.volume: >16}{self.summary_count["maker"]: >12}{self.summary_count["traded"]: >12}{self.summary_count["total"]: >18}')
                    else:
                        print("ALLTRADED:", f'{PRICE_TRENDING[self.kama_status]: >10}{order_type_str: >16}{self.liq_price[SHORT]: >16}{self.entry_price[SHORT]: >16}{order.price: >16}{order.volume: >16}{self.summary_count["maker"]: >12}{self.summary_count["traded"]: >12}{self.summary_count["total"]: >18}')
                elif direction == SHORT:
                    if offset == OPEN:
                        print("ALLTRADED:", f'{PRICE_TRENDING[self.kama_status]: >10}{order_type_str: >16}{self.liq_price[SHORT]: >16}{self.entry_price[SHORT]: >16}{order.price: >16}{order.volume: >16}{self.summary_count["maker"]: >12}{self.summary_count["traded"]: >12}{self.summary_count["total"]: >18}')
                    else:
                        print("ALLTRADED:", f'{PRICE_TRENDING[self.kama_status]: >10}{order_type_str: >16}{self.liq_price[LONG]: >16}{self.entry_price[LONG]: >16}{order.price: >16}{order.volume: >16}{self.summary_count["maker"]: >12}{self.summary_count["traded"]: >12}{self.summary_count["total"]: >18}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
