# advanced-strategy
Version 3.6

=========== How to calucate the best parameters? ===========

1. Leverage Setup
  leverage_rate = 5.0                 # leverage [10, 20]

2. Others
    open_volume_rate = 4000             # open_init_volume = max_pos_volume / this value
    *** maximium difference price between current market price and long(short) entry price *** 
    open_volume_rate / 2 = 2000 (when long/short_pos_volume is around max_pos_volume.)
    (formula) price*vol + (price+1)*vol + ... + (price+n)*vol = total_amount (=(n+1)*price*vol + vol*n(n+1)/2), entry_price = total_amount/vol*(n+1) = price + n/2

    close_volume_rate = 0.5             # close volume rate
    close_min_volume = 1.0              # close minimum volume
    max_close_volume = 100.0            # it depends on exchange policy
    fee_rate = 0.00012                  # it depends on exchange policy
    KAMA_Period = 5

=========== Main goals ===========
1. Price Trending
    Using KAMA
    When price is up by kama_value, then send only short_opne order, otherwise send only long_open order.

2. Price Calculation of New Order
    long_open_price always should be smaller than last_traded_open_price[LONG]
    short_open_price always should be larger than last_traded_open_price[SHORT]

3. Volume Calculation of New Order
- Open Order
    new_volume = self.open_init_volume * (new_price - self.last_traded_open_price[LONG(SHORT)])

- Close Order
    new_volume = long(short)_pos_volume * 0.1 (* dist_pricetick_rate)
