from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    OrderData,
    BarData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

OPPOSITE_DIRECTION: Dict[Direction, Direction] = {LONG: SHORT, SHORT: LONG}
OPPOSITE_OFFSET: Dict[Offset, Offset] = {OPEN: CLOSE, CLOSE: OPEN}

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bull", 2: "Bear"}
TRADED_INFO_TITLE: Dict[int, str] = {0: "Initial(BUSD): ", 1: "Current(BUSD): ", 2: "RunTime(Minute): ", 3: "Volume(ETH): ", 4: "Amount(BUSD): "}

class AdvancedGridStrategy_Binances_v381_ETHBUSD(CtaTemplate):

    author = "Advanced Grid Strategy v3.8.1(ETHBUSD)"

    fixed_balance = 0                   # fixed balance
    leverage = 10.0                     # leverage
    grid_gap = 10                       # grid gap (pricetick)
    profit_tick = 10                    # profit pricetick count
    max_close_volume = 100.0            # it depends on exchange policy
    fee_rate = 0.00012                  # it depends on exchange policy
    open_order_min_price = 6.0          # it depends on exchange policy

    balance = 0                         # account balance
    pnl = 0                             # PNL
    profit = 0                          # profit till now
    rebate = 0                          # fee till now
    max_pos_volume = 0                  # max pos volume
    open_init_volume = 0                # opne init volume
    open_min_volume = 0                 # calculated by open_order_min_price (depends on exchange policy)

    start_time = 0                      # start time
    prev_runtime = 0                    # recorded total runtime
    start_balance = 0                   # start balance (funded amount at first time)
    total_runtime = 0.0                 # total runtime
    total_volume = 0.0                  # total traded volume
    total_amount = 0.0                  # total traded amount

    current_runtime = 0                 # current runtime
    current_traded_volume = 0           # current traded volume
    current_traded_amount = 0           # current traded amount

    traded_long_open_order_dict = {}
    traded_short_open_order_dict = {}

    long_profit_count = 0
    short_profit_count = 0

    # kama method
    kama = 0
    kama_status = 0                     # 0: long/short open, 1: long open (Bullish), 2: short open (Bearish)
    KAMA_Period = 3

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    pos_volume = {
        LONG: 0,
        SHORT: 0
    }

    entry_price = {
        LONG: 0,
        SHORT: 0
    }

    last_pos_volume = {
        LONG: 0,
        SHORT: 0
    }

    last_open_traded_price = {
        LONG: 0,
        SHORT: 0
    }

    parameters = ['fixed_balance', 'leverage', 'grid_gap', 'profit_tick', 'KAMA_Period', 'fee_rate', 'max_close_volume', 'open_order_min_price']
    variables = ['pnl', 'profit', 'rebate', 'max_pos_volume', 'open_init_volume']

    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # kama
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    """
    "   desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_pos_volume[LONG] = 0
        self.last_pos_volume[SHORT] = 0

        self.main_process_thread = None

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.order_info_queue = {}

        self.read_tradedinfo_from_file()

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')
        # kama
        self.load_bar(2)

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        # kama
        self.bargenerator.update_tick(tick)

        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        self.arraymanager.update_bar(bar)
        if not self.arraymanager.inited:
            return

        self.kama = self.arraymanager.kama(self.KAMA_Period)

        self.put_event()

    """
    desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        if self.start_time == 0:
            self.start_time = time()

        if self.prev_runtime == 0:
            self.prev_runtime = self.total_runtime

        print_count = 0
        # main process daemon
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            self.current_runtime = round_to((time() - self.start_time) / 60, 1)
            self.total_runtime = self.prev_runtime + self.current_runtime
            if print_count == 300 or print_count == 0:
                print(f'{TRADED_INFO_TITLE[0]: >16}{self.start_balance: <12}{TRADED_INFO_TITLE[1]: >16}{round_to(self.balance, self.pricetick): <12}{TRADED_INFO_TITLE[2]: >18}{self.total_runtime: <12}{TRADED_INFO_TITLE[3]: >15}{round_to(self.total_volume, self.min_volume): <18}{TRADED_INFO_TITLE[4]: >15}{round_to(self.total_amount, self.pricetick): <24}')
                print_count = 1
            print_count += 1

            self.profit = self.balance - self.start_balance
            if self.fee_rate == 0:
                self.profit -= self.rebate

            for direction in (LONG, SHORT):
                # if strategy is stopped
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    # send new order when order is rejected
                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    # send new order when order is filled
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    # send new order when order is not traded or part traded
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        # send new order when order is rejected
                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is filled
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is not traded or part traded
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)

        sleep(2)

        # cancel all orders when strategy stop
        long_open_cancel_orderid = self.registered_order_info[LONG][OPEN]
        if long_open_cancel_orderid != '':
            if long_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_open_cancel_orderid)

        short_open_cancel_orderid = self.registered_order_info[SHORT][OPEN]
        if short_open_cancel_orderid != '':
            if short_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_open_cancel_orderid)

        long_close_cancel_orderid = self.registered_order_info[LONG][CLOSE]
        if long_close_cancel_orderid != '':
            if long_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_close_cancel_orderid)

        short_close_cancel_orderid = self.registered_order_info[SHORT][CLOSE]
        if short_close_cancel_orderid != '':
            if short_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_close_cancel_orderid)

        sleep(2)

        self.stop_main_process = False

    """
    "   desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1):
        if offset == OPEN:
            self.calc_max_pos_and_init_volume(direction, offset)

        new_price = self.get_order_price(direction, offset)
        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        if new_price == 0:
            return

        # calculate the new volume
        if offset == OPEN:
            new_volume = self.open_init_volume
            if direction == LONG:
                if self.pos_volume[LONG] > 0:
                    if self.pos_volume[LONG] > self.max_pos_volume:
                        return
                    else:
                        if self.last_open_traded_price[LONG] > 0:
                            new_volume = self.open_init_volume * (self.last_open_traded_price[LONG] - new_price)

                        if new_volume + self.pos_volume[LONG] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[LONG]
            elif direction == SHORT:
                if self.pos_volume[SHORT] > 0:
                    if self.pos_volume[SHORT] > self.max_pos_volume:
                        return
                    else:
                        if self.last_open_traded_price[SHORT] > 0:
                            new_volume = self.open_init_volume * (new_price - self.last_open_traded_price[SHORT])

                        if new_volume + self.pos_volume[SHORT] > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.pos_volume[SHORT]

            if new_volume < self.open_min_volume:
                new_volume = self.open_min_volume
        elif offset == CLOSE:
            if direction == LONG:
                if self.pos_volume[SHORT] > 0:
                    if self.profit > 0 and new_price < self.entry_price[SHORT] - 2 * self.entry_price[SHORT] * self.fee_rate:
                        new_volume = self.pos_volume[SHORT]
                    else:
                        new_volume = self.get_close_volume_from_dict(LONG, new_price)
                else:
                    return
            elif direction == SHORT:
                if self.pos_volume[LONG] > 0:
                    if self.profit > 0 and new_price > self.entry_price[LONG] + 2 * self.entry_price[LONG] * self.fee_rate:
                        new_volume = self.pos_volume[LONG]
                    else:
                        new_volume = self.get_close_volume_from_dict(SHORT, new_price)
                else:
                    return

            if new_volume <= 0 or new_volume <= 0.0:
                return
            elif new_volume > self.max_close_volume:
                new_volume = self.max_close_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        if offset == CLOSE and new_volume == 0.0:
            return

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False

    """
    "   desc:   Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        if tick.last_price > self.kama:
            # Bullish
            self.kama_status = 1
            self.last_open_traded_price[SHORT] = 0
        elif tick.last_price < self.kama:
            # Bearish
            self.kama_status = 2
            self.last_open_traded_price[LONG] = 0
        else:
            self.kama_status = 0

        if direction == LONG:
            price = tick.bid_price_1 + ask1_bid1_pricetick
            if offset == OPEN:
                if self.kama_status == 2:
                    return 0
                else:
                    if self.last_open_traded_price[LONG] > 0:
                        if abs(price - self.last_open_traded_price[LONG]) < self.grid_gap * self.pricetick:
                            return 0
            elif offset == CLOSE:
                if self.profit > 0 and price < self.entry_price[SHORT] - 2 * self.entry_price[SHORT] * self.fee_rate:
                    return price
                else:
                    if len(self.traded_short_open_order_dict) == 0:
                        returnValue = self.read_dict_from_file(SHORT)
                        if returnValue == False:
                            self.traded_short_open_order_dict[self.entry_price[SHORT] - self.profit_tick * self.pricetick] = round_to(self.pos_volume[SHORT], self.min_volume)
                    elif len(self.traded_short_open_order_dict) == 1:
                        last_volume = self.traded_short_open_order_dict[min(self.traded_short_open_order_dict.keys())]
                        if self.pos_volume[SHORT] > last_volume:
                            self.traded_short_open_order_dict[self.entry_price[SHORT] - self.profit_tick * self.pricetick] = round_to(self.pos_volume[SHORT] - last_volume, self.min_volume)
                        elif self.pos_volume[SHORT] < last_volume:
                            self.traded_short_open_order_dict[min(self.traded_short_open_order_dict.keys())] = self.pos_volume[SHORT]

                    if len(self.traded_short_open_order_dict) > 0:
                        max_price = max(self.traded_short_open_order_dict.keys())
                        if price > max_price:
                            price = max_price
                    else:
                        return 0
        elif direction == SHORT:
            price = tick.ask_price_1 - ask1_bid1_pricetick
            if offset == OPEN:
                if self.kama_status == 1:
                    return 0
                else:
                    if self.last_open_traded_price[SHORT] > 0:
                        if abs(price - self.last_open_traded_price[SHORT]) < self.grid_gap * self.pricetick:
                            return 0
            elif offset == CLOSE:
                if self.profit > 0 and price > self.entry_price[LONG] + 2 * self.entry_price[LONG] * self.fee_rate:
                    return price
                else:
                    if len(self.traded_long_open_order_dict) == 0:
                        returnValue = self.read_dict_from_file(LONG)
                        if returnValue == False:
                            self.traded_long_open_order_dict[self.entry_price[LONG] + self.profit_tick * self.pricetick] = round_to(self.pos_volume[LONG], self.min_volume)
                    elif len(self.traded_long_open_order_dict) == 1:
                        last_volume = self.traded_long_open_order_dict[min(self.traded_long_open_order_dict.keys())]
                        if self.pos_volume[LONG] > last_volume:
                            self.traded_long_open_order_dict[self.entry_price[LONG] + self.profit_tick * self.pricetick] = round_to(self.pos_volume[LONG] - last_volume, self.min_volume)
                        elif self.pos_volume[LONG] < last_volume:
                            self.traded_long_open_order_dict[min(self.traded_long_open_order_dict.keys())] = round_to(self.pos_volume[LONG], self.min_volume)

                    if len(self.traded_long_open_order_dict) > 0:
                        min_price = min(self.traded_long_open_order_dict.keys())
                        if price < min_price:
                            price = min_price
                    else:
                        return 0

        price = round_to(price, self.pricetick)

        return price

    """
    "   desc:   Calculate max_pos_volume
    "   input:  market_price
    """
    def calc_max_pos_and_init_volume(self, direction, offset):
        self.open_min_volume = round_to(self.open_order_min_price / self.market_price, self.min_volume)
        long_pnl = 0
        if self.pos_volume[LONG] > 0:
            long_pnl = (self.market_price - self.entry_price[LONG]) * self.pos_volume[LONG]

        short_pnl = 0
        if self.pos_volume[SHORT] > 0:
            short_pnl = (self.entry_price[SHORT] - self.market_price) * self.pos_volume[SHORT]

        self.pnl = long_pnl + short_pnl
        if self.fixed_balance > 0:
            self.max_pos_volume = round_to((self.fixed_balance + self.pnl) * self.leverage / self.market_price, self.min_volume)
        else:
            self.max_pos_volume = round_to((self.balance + self.pnl) * self.leverage / self.market_price, self.min_volume)

        self.open_init_volume = max(round_to(self.max_pos_volume / self.market_price, self.min_volume), self.open_min_volume)

    """
    "   desc:   Update traded open order dict
    "   input:  price, volume, status(0: add, 1: reduce)
    """
    def update_traded_open_order_dict(self, direction, price, volume, status):
        price = round_to(price, self.pricetick)
        volume = round_to(volume, self.min_volume)
        if status == 0:
            if direction == LONG:
                if price in self.traded_long_open_order_dict:
                    self.traded_long_open_order_dict[price] += volume
                else:
                    self.traded_long_open_order_dict[price] = volume

                self.write_dict_to_file(LONG)
            elif direction == SHORT:
                if price in self.traded_short_open_order_dict:
                    self.traded_short_open_order_dict[price] += volume
                else:
                    self.traded_short_open_order_dict[price] = volume

                self.write_dict_to_file(SHORT)
        elif status == 1:
            if direction == LONG:
                if len(self.traded_short_open_order_dict) > 0:
                    key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                    short_profit = self.profit_tick * self.pricetick * volume
                    for k in sorted(key_copy_short, reverse=True):
                        if k >= price and volume > 0:
                            if self.traded_short_open_order_dict[k] == 0.0:
                                del self.traded_short_open_order_dict[k]
                                continue

                            if volume > self.traded_short_open_order_dict[k]:
                                volume -= self.traded_short_open_order_dict[k]
                                del self.traded_short_open_order_dict[k]
                            elif volume == self.traded_short_open_order_dict[k]:
                                del self.traded_short_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_short_open_order_dict[k]
                                if k_v > volume:
                                    self.traded_short_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break

                if len(self.traded_short_open_order_dict) > 0:
                    updated_key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                    for k in sorted(updated_key_copy_short):
                        min_key = min(self.traded_short_open_order_dict.keys())
                        s_v = self.traded_short_open_order_dict[min_key]
                        if s_v == 0.0:
                            del self.traded_short_open_order_dict[min_key]
                            continue
                        elif s_v > 0:
                            if self.short_profit_count == 2:
                                update_key = round_to(min_key + short_profit / s_v, self.pricetick)
                                del self.traded_short_open_order_dict[min_key]
                                self.traded_short_open_order_dict[update_key] = s_v
                                self.short_profit_count = 0
                            self.short_profit_count += 1
                            break

                self.write_dict_to_file(SHORT)
            elif direction == SHORT:
                if len(self.traded_long_open_order_dict) > 0:
                    key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                    long_profit = self.profit_tick * self.pricetick * volume
                    for k in sorted(key_copy_long):
                        if price >= k and volume > 0:
                            if self.traded_long_open_order_dict[k] == 0.0:
                                del self.traded_long_open_order_dict[k]
                                continue

                            if volume > self.traded_long_open_order_dict[k]:
                                volume -= self.traded_long_open_order_dict[k]
                                del self.traded_long_open_order_dict[k]
                            elif volume == self.traded_long_open_order_dict[k]:
                                del self.traded_long_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_long_open_order_dict[k]
                                if k_v > volume:
                                    self.traded_long_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break

                if len(self.traded_long_open_order_dict) > 0:
                    updated_key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                    for k in sorted(updated_key_copy_long):
                        max_key = max(self.traded_long_open_order_dict.keys())
                        l_v = self.traded_long_open_order_dict[max_key]
                        if l_v == 0.0:
                            del self.traded_long_open_order_dict[max_key]
                            continue
                        elif l_v > 0:
                            if self.long_profit_count == 2:
                                update_key = round_to(max_key - long_profit / l_v, self.pricetick)
                                del self.traded_long_open_order_dict[max_key]
                                self.traded_long_open_order_dict[update_key] = l_v
                                self.long_profit_count = 0
                            self.long_profit_count += 1
                            break

                self.write_dict_to_file(LONG)

    """
    "   desc:   Update traded open order dict
    "   input:  price, volume, status(0: add, 1: del)
    "   return: close volume
    """
    def get_close_volume_from_dict(self, direction, price):
        close_volume = 0
        if direction == LONG:
            if len(self.traded_short_open_order_dict) > 0:
                key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                for k in sorted(key_copy_short, reverse=True):
                    if k >= price:
                        if self.traded_short_open_order_dict[k] == 0.0:
                            del self.traded_short_open_order_dict[k]
                        else:
                            close_volume += self.traded_short_open_order_dict[k]
        elif direction == SHORT:
            if len(self.traded_long_open_order_dict) > 0:
                key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                for k in sorted(key_copy_long):
                    if price >= k:
                        if self.traded_long_open_order_dict[k] == 0.0:
                            del self.traded_long_open_order_dict[k]
                        else:
                            close_volume += self.traded_long_open_order_dict[k]

        return round_to(close_volume, self.min_volume)

    """
    "   desc: Get order type as string
    """
    def get_order_type_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            else:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            else:
                return 'S_CLOSE'

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.traded_long_open_order_dict = {}
                    self.last_open_traded_price[LONG] = 0

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.traded_short_open_order_dict = {}
                    self.last_open_traded_price[SHORT] = 0

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price

    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.current_traded_volume += round_to(order.volume, self.min_volume)
                self.total_volume += round_to(order.volume, self.min_volume)
                self.current_traded_amount += round_to(order.price * order.volume, 1)
                self.total_amount += round_to(order.price * order.volume, self.pricetick)
                self.write_tradedinfo_to_file()

                if self.fee_rate > 0:
                    self.rebate = -self.total_amount * self.fee_rate
                else:
                    self.rebate = self.total_amount * self.fee_rate

                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)

                if direction == LONG:
                    if offset == OPEN:
                        self.last_open_traded_price[LONG] = order.price
                        long_open_order_price = round_to(order.price + 2 * order.price * self.fee_rate + self.profit_tick * self.pricetick, self.pricetick)
                        long_open_volume = round_to(order.volume, self.min_volume)
                        self.update_traded_open_order_dict(LONG, long_open_order_price, long_open_volume, 0)
                    elif offset == CLOSE:
                        long_close_order_price = round_to(order.price, self.pricetick)
                        long_close_order_volume = round_to(order.volume, self.min_volume)
                        self.update_traded_open_order_dict(LONG, long_close_order_price, long_close_order_volume, 1)
                elif direction == SHORT:
                    if offset == OPEN:
                        self.last_open_traded_price[SHORT] = order.price
                        short_open_order_price = round_to(order.price - 2 * order.price * self.fee_rate - self.profit_tick * self.pricetick, self.pricetick)
                        short_open_order_volume = round_to(order.volume, self.min_volume)
                        self.update_traded_open_order_dict(SHORT, short_open_order_price, short_open_order_volume, 0)
                    elif offset == CLOSE:
                        short_close_order_price = round_to(order.price, self.pricetick)
                        short_close_order_volume = round_to(order.volume, self.min_volume)
                        self.update_traded_open_order_dict(SHORT, short_close_order_price, short_close_order_volume, 1)

                long_max_price = 0
                long_min_price = 0
                if len(self.traded_long_open_order_dict) > 0:
                    long_max_price = round_to(max(self.traded_long_open_order_dict.keys()), self.pricetick)
                    long_min_price = round_to(min(self.traded_long_open_order_dict.keys()), self.pricetick)

                short_min_price = 0
                short_max_price = 0
                if len(self.traded_short_open_order_dict) > 0:
                    short_min_price = round_to(min(self.traded_short_open_order_dict.keys()), self.pricetick)
                    short_max_price = round_to(max(self.traded_short_open_order_dict.keys()), self.pricetick)

                # current date and time
                now = datetime.now()
                date_time = now.strftime("%m-%d %H:%M:%S")

                long_entry_price = round_to(self.entry_price[LONG], self.pricetick)
                short_entry_price = round_to(self.entry_price[SHORT], self.pricetick)
                if direction == LONG:
                    if offset == OPEN:
                        print(f'{self.summary_count["maker"]: >7}{PRICE_TRENDING[self.kama_status]: >6}{order_type_str: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{self.current_traded_amount: >15}{date_time: >18}')
                    elif offset == CLOSE:
                        print(f'{self.summary_count["maker"]: >7}{PRICE_TRENDING[self.kama_status]: >6}{order_type_str: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{self.current_traded_amount: >15}{date_time: >18}')
                elif direction == SHORT:
                    if offset == OPEN:
                        print(f'{self.summary_count["maker"]: >7}{PRICE_TRENDING[self.kama_status]: >6}{order_type_str: >9}{short_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{self.current_traded_amount: >15}{date_time: >18}')
                    elif offset == CLOSE:
                        print(f'{self.summary_count["maker"]: >7}{PRICE_TRENDING[self.kama_status]: >6}{order_type_str: >9}{long_entry_price: >10}{order.price: >12}{order.volume: >7}{short_max_price: >12}{short_min_price: >9}{long_min_price: >12}{long_max_price: >9}{self.current_runtime: >9}{round_to(self.current_traded_volume, self.min_volume): >12}{self.current_traded_amount: >15}{date_time: >18}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")

    """
    "   desc:   Write a dict to file
    "   Dict File Path: C:/Users/Administrator/strategies, /home/users/
    """
    def write_dict_to_file(self, direction):
        if direction == LONG:
            log_path = "C:\\Users\\Administrator\\strategies\\long_dict.txt"
        else:
            log_path = "C:\\Users\\Administrator\\strategies\\short_dict.txt"

        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path , "w") as f:
            if direction == SHORT:
                f.write(str(self.traded_short_open_order_dict).replace("{", "").replace("}", ""))
            else:
                f.write(str(self.traded_long_open_order_dict).replace("{", "").replace("}", ""))

    """
    "   desc:   Read dict from file
    "   Dict File Path: C:/Users/Administrator/strategies, /home/users/
    """
    def read_dict_from_file(self, direction):
        if direction == LONG:
            log_path = "C:\\Users\\Administrator\\strategies\\long_dict.txt"
        else:
            log_path = "C:\\Users\\Administrator\\strategies\\short_dict.txt"

        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path , "r") as f:
            data = f.read().rstrip()
            if data == "":
                return False
            else:
                if direction == SHORT:
                    self.traded_short_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                else:
                    self.traded_long_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                return True

    """
    "   desc:   Write a traded info to log file
    "   Log File Path: C:/Users/Administrator/strategies, /home/users/
    """
    def write_tradedinfo_to_file(self):
        log_path = "C:\\Users\\Administrator\\strategies\\log.txt"

        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path , "w") as f:
            traded_info = f'{self.start_balance}, {self.total_runtime}, {round_to(self.total_volume, self.min_volume)}, {round_to(self.total_amount, self.pricetick)}'
            f.write(traded_info)

    """
    "   desc:   Read a traded info from log file
    "   Log File Path: C:/Users/Administrator/strategies, /home/users/
    """
    def read_tradedinfo_from_file(self):
        log_path = "C:\\Users\\Administrator\\strategies\\log.txt"

        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        with open(log_path , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.start_balance = 0.0
                self.total_runtime = 0.0
                self.total_volume = 0.0
                self.total_amount = 0.0
            else:
                self.start_balance = float(data.split(', ')[0].strip())
                self.total_runtime = float(data.split(', ')[1].strip())
                self.total_volume = float(data.split(', ')[2].strip())
                self.total_amount = float(data.split(', ')[3].strip())
