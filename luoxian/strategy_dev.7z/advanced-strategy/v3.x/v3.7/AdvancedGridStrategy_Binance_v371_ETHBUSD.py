from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    BarData,
    OrderData,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from typing import Dict

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

OPPOSITE_DIRECTION: Dict[Direction, Direction] = {LONG: SHORT, SHORT: LONG}
OPPOSITE_OFFSET: Dict[Offset, Offset] = {OPEN: CLOSE, CLOSE: OPEN}

class AdvancedGridStrategy_Binances_v371_ETHBUSD(CtaTemplate):

    author = "Advanced Grid Strategy v3.7.1(ETHBUSD)"

    leverage_rate = 5.0                 # leverage [10, 20]
    open_volume_rate = 4000             # open_init_volume = max_pos_volume / this value
    close_volume_rate = 0.5             # close volume rate
    close_min_volume = 1.0              # close minimum volume
    max_close_volume = 100.0            # it depends on exchange policy
    fee_rate = 0.00012                  # it depends on exchange policy
    profit_pricetick = 100              # for profit
    step_pricetick = 100                # last_traded_price+/-this value
    init_duration = 5                   # initialize last_traded_price during this time (minute)
    open_order_min_price = 6.0          # it depends on exchange policy

    balance = 0                         # account balance
    open_init_volume = 0
    open_min_volume = 0
    long_pos_volume = 0                 # long position volume
    short_pos_volume = 0                # short position volume
    max_pos_volume = 0                  # maximium positon volume with current balance
    current_time = 0

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    entry_price = {
        LONG: 0,
        SHORT: 0
    }

    liq_price = {
        LONG: 0,
        SHORT: 0
    }

    last_traded_price = {
        LONG: 0,
        SHORT: 0
    }

    last_traded_time = {
        LONG: 0,
        SHORT: 0
    }

    fee_pricetick = {
        LONG: 0,
        SHORT: 0
    }

    parameters = ['leverage_rate', 'open_volume_rate', 'close_volume_rate', 'close_min_volume', 'max_close_volume', 'fee_rate', 'profit_pricetick', 'step_pricetick', 'init_duration', 'open_order_min_price']
    variables = ['current_time', 'balance', 'max_pos_volume', 'open_min_volume', 'open_init_volume']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_long_pos_volume = 0
        self.last_short_pos_volume = 0        

        self.main_process_thread = None
        self.restart_strategy_thread = None

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.order_info_queue = {}

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')
        # self.write_log("策略初始化")

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance: ", self.balance)

        self.calc_max_pos_and_init_volume(self.leverage_rate)

        # main process daemon
        while self.stop_main_process == False:
            sleep(1)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                print("Tick is invalid.")
                continue

            for direction in (LONG, SHORT):

                if self.stop_main_process == True:
                    break

                now = time()
                self.current_time = round_to(now / 60, 1)
                if direction == LONG:
                    if self.last_traded_time[LONG] > 0 and (now - self.last_traded_time[LONG]) > self.init_duration * 60:
                        if self.last_traded_price[LONG] > 0:
                            self.last_traded_price[LONG] = 0
                elif direction == SHORT:
                    if self.last_traded_time[SHORT] > 0 and (now - self.last_traded_time[SHORT]) > self.init_duration * 60:
                        if self.last_traded_price[SHORT] > 0:
                            self.last_traded_price[SHORT] = 0

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    # send new order when order is rejected
                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    # send new order when order is filled
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    # send new order when order is not traded or part traded
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)

                # close
                if (direction == LONG and self.short_pos_volume > 0) or (direction == SHORT and self.long_pos_volume > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        # send new order when order is rejected
                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is filled
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is not traded or part traded
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)

        sleep(3)

        # cancel all orders when strategy stop
        long_open_cancel_orderid = self.registered_order_info[LONG][OPEN]
        if long_open_cancel_orderid != '':
            if long_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_open_cancel_orderid)

        short_open_cancel_orderid = self.registered_order_info[SHORT][OPEN]
        if short_open_cancel_orderid != '':
            if short_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_open_cancel_orderid)

        long_close_cancel_orderid = self.registered_order_info[LONG][CLOSE]
        if long_close_cancel_orderid != '':
            if long_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_close_cancel_orderid)

        short_close_cancel_orderid = self.registered_order_info[SHORT][CLOSE]
        if short_close_cancel_orderid != '':
            if short_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_close_cancel_orderid)

        sleep(3)

        self.stop_main_process = False

    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, old_price = -1):
        self.calc_max_pos_and_init_volume(self.leverage_rate)

        # calculate price based on AS model
        new_price = self.get_order_price(direction, offset)
        if new_price == 0:
            return

        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        # calculate the new volume when offset is open
        new_volume = self.open_init_volume
        if offset == OPEN:
            # calculate new volume
            if direction == LONG:
                if self.last_traded_price[LONG] > 0 and new_price >= self.last_traded_price[LONG] - self.step_pricetick * self.pricetick:
                    return
                if self.long_pos_volume > 0:
                    if self.long_pos_volume > self.max_pos_volume:
                        return
                    else:
                        if self.last_traded_price[LONG] > 0:
                            new_volume = self.open_init_volume * abs(new_price - self.last_traded_price[LONG])
                        elif self.last_traded_price[LONG] == 0:
                            if new_price > self.entry_price[LONG] and abs(new_price - self.entry_price[LONG]) < self.fee_pricetick[LONG]:
                                return
                        if new_volume + self.long_pos_volume > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.long_pos_volume
            elif direction == SHORT:
                if self.last_traded_price[SHORT] > 0 and new_price <= self.last_traded_price[SHORT] + self.step_pricetick * self.pricetick:
                    return
                if self.short_pos_volume > 0:
                    if self.short_pos_volume > self.max_pos_volume:
                        return
                    else:
                        if self.last_traded_price[SHORT] > 0:
                            new_volume = self.open_init_volume * abs(new_price - self.last_traded_price[SHORT])
                        elif self.last_traded_price[SHORT] == 0:
                            if new_price < self.entry_price[SHORT] and abs(new_price - self.entry_price[SHORT]) < self.fee_pricetick[SHORT]:
                                return
                        if new_volume + self.short_pos_volume > self.max_pos_volume:
                            new_volume = self.max_pos_volume - self.short_pos_volume

            if new_volume < self.open_min_volume:
                new_volume = self.open_min_volume
        elif offset == CLOSE:
            if direction == LONG:
                if self.short_pos_volume > 0:
                    if self.short_pos_volume <= self.close_min_volume:
                        new_volume = self.short_pos_volume
                    else:
                        rate = min(max(round_to(abs(new_price - self.entry_price[SHORT]), 1), 1), 1 / self.close_volume_rate)
                        new_volume = self.short_pos_volume * self.close_volume_rate * rate
                else:
                    return False
            elif direction == SHORT:
                if self.long_pos_volume > 0:
                    if self.long_pos_volume <= self.close_min_volume:
                        new_volume = self.long_pos_volume
                    else:
                        rate = min(max(round_to(abs(new_price - self.entry_price[LONG]), 1), 1), 1 / self.close_volume_rate)
                        new_volume = self.long_pos_volume * self.close_volume_rate * rate
                else:
                    return False

            if new_volume > self.max_close_volume:
                new_volume = self.max_close_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False

    """
    "   desc:   Get ask/bid price based on AS model
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        if direction == LONG:
            price = tick.bid_price_1 + ask1_bid1_pricetick
            if offset == CLOSE:
                if price > self.entry_price[SHORT] - self.fee_pricetick[SHORT]:
                    price = self.entry_price[SHORT] - self.fee_pricetick[SHORT]
        elif direction == SHORT:
            price = tick.ask_price_1 - ask1_bid1_pricetick
            if offset == CLOSE:
                if price < self.entry_price[LONG] + self.fee_pricetick[LONG]:
                    price = self.entry_price[LONG] + self.fee_pricetick[LONG]

        price = round_to(price, self.pricetick)

        return price

    """
    "   desc:   Calculate max_pos_volume
    "   input:  market_price
    """
    def calc_max_pos_and_init_volume(self, leverage):
        self.max_pos_volume = self.balance * leverage / self.market_price
        self.open_min_volume = round_to(self.open_order_min_price / self.market_price, self.min_volume)
        self.open_init_volume = max(round_to(self.max_pos_volume / self.open_volume_rate, self.min_volume), self.open_min_volume)

    """
    "   desc: Get order type as string
    "   input: direction, offset
    """
    def get_order_type_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'LONG_OPEN'
            else:
                return 'LONG_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'SHORT_OPEN'
            else:
                return 'SHORT_CLOSE'

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.long_pos_volume = abs(position.volume)
                # all long pos are closed
                if self.last_long_pos_volume > 0 and self.long_pos_volume == 0:
                    self.last_traded_price[LONG] = 0
                    self.last_traded_time[LONG] = 0
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_long_pos_volume = self.long_pos_volume
            elif direction == SHORT:
                self.short_pos_volume = abs(position.volume)
                # all short pos closed
                if self.last_short_pos_volume > 0 and self.short_pos_volume == 0:
                    self.last_traded_price[SHORT] = 0
                    self.last_traded_time[SHORT] = 0
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_short_pos_volume = self.short_pos_volume

            self.entry_price[direction] = position.price
            self.fee_pricetick[direction] = round_to(2 * position.price * self.fee_rate + self.profit_pricetick * self.pricetick, self.pricetick)
            # self.liq_price[direction] = position.liq_price

    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.summary_count['total'] += round_to(order.price * order.volume, 1)
                self.summary_count['traded'] += order.volume
                traded_volume = round_to(self.summary_count['traded'], self.min_volume)
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)
                long_pos_entry_price = round_to(self.entry_price[LONG], self.pricetick)
                short_pos_entry_price = round_to(self.entry_price[SHORT], self.pricetick)

                if direction == LONG:
                    if offset == OPEN:
                        self.last_traded_price[LONG] = order.price
                        self.last_traded_time[LONG] = time()
                        long_last_traded_time_minute = round_to(self.last_traded_time[LONG] / 60, 1)
                        print(f'{self.summary_count["maker"]: >8}{order_type_str: >14}{long_last_traded_time_minute: >12}{long_pos_entry_price: >10}{self.fee_pricetick[LONG]: >7}{order.volume: >10}{traded_volume: >15}{self.summary_count["total"]: >16}{self.last_traded_price[SHORT]: >12}{self.last_traded_price[LONG]: >12}')
                    else:
                        print(f'{self.summary_count["maker"]: >8}{order_type_str: >14}{short_pos_entry_price: >10}{self.fee_pricetick[SHORT]: >7}{order.volume: >10}{traded_volume: >15}{self.summary_count["total"]: >16}{self.last_traded_price[SHORT]: >12}{self.last_traded_price[LONG]: >12}')
                elif direction == SHORT:
                    if offset == OPEN:
                        self.last_traded_price[SHORT] = order.price
                        self.last_traded_time[SHORT] = time()
                        short_last_traded_time_minute = round_to(self.last_traded_time[SHORT] / 60, 1)
                        print(f'{self.summary_count["maker"]: >8}{order_type_str: >14}{short_last_traded_time_minute: >12}{short_pos_entry_price: >10}{self.fee_pricetick[SHORT]: >7}{order.volume: >10}{traded_volume: >15}{self.summary_count["total"]: >16}{self.last_traded_price[SHORT]: >12}{self.last_traded_price[LONG]: >12}')
                    else:
                        print(f'{self.summary_count["maker"]: >8}{order_type_str: >14}{long_pos_entry_price: >10}{self.fee_pricetick[LONG]: >7}{order.volume: >10}{traded_volume: >15}{self.summary_count["total"]: >16}{self.last_traded_price[SHORT]: >12}{self.last_traded_price[LONG]: >12}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
