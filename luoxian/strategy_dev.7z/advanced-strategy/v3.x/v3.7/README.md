# advanced-strategy
Version 3.7.6

=========== How to calucate the best parameters? ===========

1. Leverage Setup
  leverage_rate = 5.0                   # leverage [10, 20]

2. Others
    open_volume_rate = 1                # open_init_volume = this value * max_pos_volume / market_price
    close_volume_rate = 0.3             # close volume rate
    close_min_volume = 0.5              # close minimum volume
    volatility_price = 1.0              # volatility price range (ETH:1, 1.5, 2, BTC: 3, 3.5, 4, 4.5, 5)
    profit_tick = 2                     # profit pricetick count

=========== Main goals ===========
1. Price Trending
    Sending both long and short open order in any case

2. Price Calculation of New Order
    long_open_price always should be smaller than last_traded_open_price[LONG]
    short_open_price always should be larger than last_traded_open_price[SHORT]

    And, always trying to send with bid1/ask1 price

3. Volume Calculation of New Order
    long(short)_volatility_price_step
    if self.pos_volume[LONG] == 0:
        new_volume = self.open_init_volume
    elif self.pos_volume[LONG] > 0:
        if self.open_option == 5:
            new_volume = self.pos_volume[LONG]
        else:
            self.long_dist_price = 0  (long(short)_dist_price logic)
            new_volume = (self.long_volatility_price_step + 1) * self.volatility_price * self.open_init_volume
            if self.last_open_traded_price[LONG] > 0:
                if new_price > self.last_open_traded_price[LONG] - self.volatility_price:
                    if abs(new_price - self.entry_price[LONG]) > 5  * self.long_volatility_price_step:
                        self.long_dist_price = 1
                    else:
                        return

These parameter is important for calculating an open volume
When close order is traded continously, then these values will be increased.

3. Other parameter
open_option = 0 (default)
    0: send open order
    1: not send long open order 
    2: not send short open order
    3: not send long and short open order
    404: not send open order and close positions with ask1/bid1 price
    5: new_volume = self.long_pos_volume
    6: new_volume = self.short_pos_volume
