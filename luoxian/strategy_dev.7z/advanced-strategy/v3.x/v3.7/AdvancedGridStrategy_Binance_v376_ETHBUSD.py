from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    OrderData,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

OPPOSITE_DIRECTION: Dict[Direction, Direction] = {LONG: SHORT, SHORT: LONG}
OPPOSITE_OFFSET: Dict[Offset, Offset] = {OPEN: CLOSE, CLOSE: OPEN}

class AdvancedGridStrategy_Binances_v376_ETHBUSD(CtaTemplate):

    author = "Advanced Grid Strategy v3.7.6(ETHBUSD)"

    wallet_balance = 0                  # wallet balance
    leverage = 4.0                      # leverage [10, 20]
    real_leverage = 1.0                 # real leverage [1.0 ~ 2.0]
    open_volume_rate = 0.5              # open_init_volume = this value * max_pos_volume / market_price
    close_volume_rate = 0.3             # close volume rate
    close_min_volume = 0.5              # close minimum volume
    volatility_price = 2.0              # volatility price range
    profit_tick = 10                    # profit pricetick count
    max_close_volume = 100.0            # it depends on exchange policy
    fee_rate = 0.00012                  # it depends on exchange policy
    open_order_min_price = 6.0          # it depends on exchange policy
    open_option = 0                     # 0: send open order, 1: not send long open order, 2: not send short open order, 3: not send long and short open order, 404: not send open order and close positions with ask1/bid1 price, 5: new_volume = self.long_pos_volume, 6: new_volume = self.short_pos_volume

    balance = 0                         # account balance
    max_pos_volume = 0                  # max pos volume
    limit_pos_volume = 0                # real max pos volume
    open_init_volume = 0                # opne init volume
    open_min_volume = 0                 # calculated by open_order_min_price (depends on exchange policy)
    start_time = 0                      # start time
    runtime = 0                         # run time (minute)
    profit = 0                          # profit till now
    pnl = 0                             # PNL
    start_balance = 0                   # start balance
    rebate = 0                          # fee till now

    long_dist_price = 0
    long_volatility_price_step = 2

    short_dist_price = 0
    short_volatility_price_step = 2

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    pos_volume = {
        LONG: 0,
        SHORT: 0
    }

    entry_price = {
        LONG: 0,
        SHORT: 0
    }

    last_open_traded_price = {
        LONG: 0,
        SHORT: 0
    }

    profit_pricetick = {
        LONG: 0,
        SHORT: 0
    }

    last_pos_volume = {
        LONG: 0,
        SHORT: 0
    }

    parameters = ['wallet_balance', 'leverage', 'real_leverage', 'open_volume_rate', 'close_volume_rate', 'close_min_volume', 'volatility_price', 'profit_tick', 'max_close_volume', 'fee_rate', 'open_order_min_price', 'open_option']
    variables = ['runtime', 'pnl', 'profit', 'rebate', 'balance', 'max_pos_volume', 'limit_pos_volume', 'open_init_volume', 'open_min_volume']

    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    """
    "   desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_pos_volume[LONG] = 0
        self.last_pos_volume[SHORT] = 0

        self.main_process_thread = None

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.order_info_queue = {}

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    """
    desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance: ", self.balance)
        if self.start_balance == 0:
            self.start_balance = self.balance

        if self.start_time == 0:
            self.start_time = time()

        # main process daemon
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            self.runtime = round_to((time() - self.start_time) / 60, 1)
            self.profit = self.balance - self.start_balance

            for direction in (LONG, SHORT):

                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    # send new order when order is rejected
                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    # send new order when order is filled
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    # send new order when order is not traded or part traded
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        # send new order when order is rejected
                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is filled
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is not traded or part traded
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)

        sleep(2)

        # cancel all orders when strategy stop
        long_open_cancel_orderid = self.registered_order_info[LONG][OPEN]
        if long_open_cancel_orderid != '':
            if long_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_open_cancel_orderid)

        short_open_cancel_orderid = self.registered_order_info[SHORT][OPEN]
        if short_open_cancel_orderid != '':
            if short_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_open_cancel_orderid)

        long_close_cancel_orderid = self.registered_order_info[LONG][CLOSE]
        if long_close_cancel_orderid != '':
            if long_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_close_cancel_orderid)

        short_close_cancel_orderid = self.registered_order_info[SHORT][CLOSE]
        if short_close_cancel_orderid != '':
            if short_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_close_cancel_orderid)

        sleep(2)

        self.stop_main_process = False

    """
    "   desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1):
        if offset == OPEN:
            self.calc_max_pos_and_init_volume(direction, offset)

        new_price = self.get_order_price(direction, offset)
        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        if new_price == 0:
            return

        # calculate the new volume when offset is open
        if offset == OPEN:
            # calculate new volume
            if direction == LONG:
                if self.pos_volume[LONG] == 0:
                    new_volume = self.open_init_volume
                elif self.pos_volume[LONG] > 0:
                    if self.open_option == 5:
                        new_volume = self.pos_volume[LONG]
                    else:
                        self.long_dist_price = 0
                        new_volume = self.open_init_volume
                        if self.last_open_traded_price[LONG] > 0:
                            if new_price > self.last_open_traded_price[LONG] - self.volatility_price:
                                if abs(new_price - self.entry_price[LONG]) > self.volatility_price * self.long_volatility_price_step:
                                    self.long_dist_price = 1
                                    new_volume = self.long_volatility_price_step * self.open_init_volume
                                else:
                                    return
                if self.open_option != 5 or self.open_option != 6:
                    if new_volume + self.pos_volume[LONG] > self.limit_pos_volume:
                        return
            elif direction == SHORT:
                if self.pos_volume[SHORT] == 0:
                    new_volume = self.open_init_volume
                elif self.pos_volume[SHORT] > 0:
                    if self.open_option == 6:
                        new_volume = self.pos_volume[SHORT]
                    else:
                        self.short_dist_price = 0
                        new_volume = self.open_init_volume
                        if self.last_open_traded_price[SHORT] > 0:
                            if new_price < self.last_open_traded_price[SHORT] + self.volatility_price:
                                if abs(new_price - self.entry_price[SHORT]) > self.volatility_price * self.short_volatility_price_step:
                                    self.short_dist_price = 1
                                    new_volume = self.short_volatility_price_step * self.open_init_volume
                                else:
                                    return

                if self.open_option != 5 or self.open_option != 6:
                    if new_volume + self.pos_volume[SHORT] > self.limit_pos_volume:
                        return

            if new_volume < self.open_min_volume:
                return
        elif offset == CLOSE:
            if direction == LONG:
                if self.pos_volume[SHORT] > 0:
                    if self.pos_volume[SHORT] <= self.close_min_volume:
                        new_volume = self.pos_volume[SHORT]
                    else:
                        rate = min(max(round_to(abs(new_price - self.entry_price[SHORT]), 1), 1), 1 / self.close_volume_rate)
                        new_volume = self.pos_volume[SHORT] * self.close_volume_rate * rate
                else:
                    return False
            elif direction == SHORT:
                if self.pos_volume[LONG] > 0:
                    if self.pos_volume[LONG] <= self.close_min_volume:
                        new_volume = self.pos_volume[LONG]
                    else:
                        rate = min(max(round_to(abs(new_price - self.entry_price[LONG]), 1), 1), 1 / self.close_volume_rate)
                        new_volume = self.pos_volume[LONG] * self.close_volume_rate * rate
                else:
                    return False

            if new_volume > self.max_close_volume:
                new_volume = self.max_close_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        if self.open_option == 1:
            if direction == LONG and offset == OPEN:
                return
        elif self.open_option == 2:
            if direction == SHORT and offset == OPEN:
                return
        elif self.open_option == 3:
            if offset == OPEN:
                return
        elif self.open_option == 404:
            if offset == OPEN:
                return
            elif offset == CLOSE:
                new_volume = 1
                if direction == LONG:
                    if new_volume > self.pos_volume[SHORT]:
                        new_volume = self.pos_volume[SHORT]
                elif direction == SHORT:
                    if new_volume > self.pos_volume[LONG]:
                        new_volume = self.pos_volume[LONG]

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False

    """
    "   desc:   Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        if direction == LONG:
            price = tick.bid_price_1 + ask1_bid1_pricetick
            if offset == OPEN:
                if self.pos_volume[LONG] > 0:
                    if price > self.entry_price[LONG] + self.profit_pricetick[LONG]:
                        return 0
            elif offset == CLOSE:
                if self.open_option != 404:
                    if price > self.entry_price[SHORT] - self.profit_pricetick[SHORT]:
                        price = self.entry_price[SHORT] - self.profit_pricetick[SHORT]
        elif direction == SHORT:
            price = tick.ask_price_1 - ask1_bid1_pricetick
            if offset == OPEN:
                if self.pos_volume[SHORT] > 0:
                    if price < self.entry_price[SHORT] - self.profit_pricetick[SHORT]:
                        return 0
            elif offset == CLOSE:
                if self.open_option != 404:
                    if price < self.entry_price[LONG] + self.profit_pricetick[LONG]:
                        price = self.entry_price[LONG] + self.profit_pricetick[LONG]

        price = round_to(price, self.pricetick)

        return price

    """
    "   desc:   Calculate max_pos_volume
    "   input:  market_price
    """
    def calc_max_pos_and_init_volume(self, direction, offset):
        self.open_min_volume = round_to(self.open_order_min_price / self.market_price, self.min_volume)
        long_pnl = 0
        if self.pos_volume[LONG] > 0:
            long_pnl = (self.market_price - self.entry_price[LONG]) * self.pos_volume[LONG]

        short_pnl = 0
        if self.pos_volume[SHORT] > 0:
            short_pnl = (self.entry_price[SHORT] - self.market_price) * self.pos_volume[SHORT]

        self.pnl = long_pnl + short_pnl

        if direction == LONG and offset == OPEN:
            if self.long_volatility_price_step >= 200:
                self.real_leverage = 2.0
            elif self.long_volatility_price_step >= 180:
                self.real_leverage = 1.9
            elif self.long_volatility_price_step >= 160:
                self.real_leverage = 1.8
            elif self.long_volatility_price_step >= 140:
                self.real_leverage = 1.7
            elif self.long_volatility_price_step >= 120:
                self.real_leverage = 1.6
            elif self.long_volatility_price_step >= 100:
                self.real_leverage = 1.5
            elif self.long_volatility_price_step >= 80:
                self.real_leverage = 1.4
            elif self.long_volatility_price_step >= 60:
                self.real_leverage = 1.3
            elif self.long_volatility_price_step >= 40:
                self.real_leverage = 1.2
            elif self.long_volatility_price_step >= 20:
                self.real_leverage = 1.1
            else:
                self.real_leverage = 1.0

        if direction == SHORT and offset == OPEN:
            if self.short_volatility_price_step >= 200:
                self.real_leverage = 2.0
            elif self.short_volatility_price_step >= 180:
                self.real_leverage = 1.9
            elif self.short_volatility_price_step >= 160:
                self.real_leverage = 1.8
            elif self.short_volatility_price_step >= 140:
                self.real_leverage = 1.7
            elif self.short_volatility_price_step >= 120:
                self.real_leverage = 1.6
            elif self.short_volatility_price_step >= 100:
                self.real_leverage = 1.5
            elif self.short_volatility_price_step >= 80:
                self.real_leverage = 1.4
            elif self.short_volatility_price_step >= 60:
                self.real_leverage = 1.3
            elif self.short_volatility_price_step >= 40:
                self.real_leverage = 1.2
            elif self.short_volatility_price_step >= 20:
                self.real_leverage = 1.1
            else:
                self.real_leverage = 1.0

        if self.wallet_balance == 0:
            self.max_pos_volume = round_to((self.balance + self.pnl) * self.leverage / self.market_price, self.min_volume)
            self.limit_pos_volume = round_to((self.balance + self.pnl) * self.real_leverage / self.market_price, self.min_volume)
        else:
            self.max_pos_volume = round_to((self.wallet_balance + self.pnl) * self.leverage / self.market_price, self.min_volume)
            self.limit_pos_volume = round_to((self.wallet_balance + self.pnl) * self.real_leverage / self.market_price, self.min_volume)

        self.open_init_volume = max(round_to(self.open_volume_rate * self.max_pos_volume / self.market_price, self.min_volume), self.open_min_volume)

    """
    "   desc: Get order type as string
    """
    def get_order_type_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'LONG_OPEN'
            else:
                return 'LONG_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'SHORT_OPEN'
            else:
                return 'SHORT_CLOSE'

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.last_open_traded_price[LONG] = 0

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.last_open_traded_price[SHORT] = 0

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price
            self.profit_pricetick[direction] = round_to(2 * position.price * self.fee_rate + self.profit_tick * self.pricetick, self.pricetick)

    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.summary_count['total'] += round_to(order.price * order.volume, 1)
                self.summary_count['traded'] += order.volume
                traded_volume = round_to(self.summary_count['traded'], self.min_volume)
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                self.rebate += order.price * order.volume * self.fee_rate
                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)

                if direction == LONG:
                    if offset == OPEN:
                        self.last_open_traded_price[LONG] = order.price
                        if self.long_dist_price == 1:
                            self.long_volatility_price_step += 1
                    elif offset == CLOSE:
                        self.short_volatility_price_step = 2
                elif direction == SHORT:
                    if offset == OPEN:
                        self.last_open_traded_price[SHORT] = order.price
                        if self.short_dist_price == 1:
                            self.short_volatility_price_step += 1
                    elif offset == CLOSE:
                        self.long_volatility_price_step = 2
                balance_display = round_to(self.balance, self.pricetick)

                # current date and time
                now = datetime.now()

                # current date and time
                date_time = now.strftime("%Y-%m-%d %H:%M:%S")
                print(f'{self.summary_count["maker"]: >9}{balance_display: >12}{order_type_str: >14}{order.price: >9}{order.volume: >9}{self.short_volatility_price_step: >3}{self.long_volatility_price_step: >3}{traded_volume: >15}{self.summary_count["total"]: >18}{date_time: >24}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
