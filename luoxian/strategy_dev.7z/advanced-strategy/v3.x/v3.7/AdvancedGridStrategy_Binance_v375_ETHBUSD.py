from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    BarData,
    OrderData,
    BarGenerator,
    ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from time import sleep, time
from typing import Dict

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

OPPOSITE_DIRECTION: Dict[Direction, Direction] = {LONG: SHORT, SHORT: LONG}
OPPOSITE_OFFSET: Dict[Offset, Offset] = {OPEN: CLOSE, CLOSE: OPEN}

PRICE_TRENDING: Dict[int, str] = {0: "None", 1: "Bullish", 2: "Bearish"}

class AdvancedGridStrategy_Binances_v375_ETHBUSD(CtaTemplate):

    author = "Advanced Grid Strategy v3.7.5(ETHBUSD)"

    leverage = 5.0                      # leverage [10, 20]
    open_volume_rate = 2.0              # open_init_volume = this value * max_pos_volume / market_price
    init_volume_double_rate = 0.1       # open_volume * (1 + this value)
    close_volume_rate = 0.3             # close volume rate
    close_min_volume = 0.5              # close minimum volume
    volatility_price = 2.0              # volatility price range
    max_close_volume = 100.0            # it depends on exchange policy
    fee_rate = 0.00012                  # it depends on exchange policy
    open_order_min_price = 6.0          # it depends on exchange policy
    open_option = 0                     # 0: send open order, 1: not send long open order, 2: not send short open order, 3: not send long and short open order, 404: not send open order and close positions with ask1/bid1 price, 5: new_volume = self.long_pos_volume, 6: new_volume = self.short_pos_volume

    balance = 0                         # account balance
    max_pos_volume = 0
    open_init_volume = 0
    open_min_volume = 0                 # calculated by open_order_min_price (depends on exchange policy)

    long_close_count = 0
    short_close_count = 0

    long_volatility_price_step = 0
    short_volatility_price_step = 0

    # kama method
    kama = 0
    kama_status = 0                     # 0: long/short open, 1: long open (market price is up), 2: short open (market price is down)
    KAMA_Period = 3
    prev_kama_status = 0

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    pos_volume = {
        LONG: 0,
        SHORT: 0
    }

    entry_price = {
        LONG: 0,
        SHORT: 0
    }

    last_entry_price = {
        LONG: 0,
        SHORT: 0
    }

    last_open_traded_price = {
        LONG: 0,
        SHORT: 0
    }

    last_close_traded_price = {
        LONG: 0,
        SHORT: 0
    }

    profit_pricetick = {
        LONG: 0,
        SHORT: 0
    }

    last_pos_volume = {
        LONG: 0,
        SHORT: 0
    }

    parameters = ['leverage', 'open_volume_rate', 'init_volume_double_rate', 'close_volume_rate', 'close_min_volume', 'volatility_price', 'KAMA_Period', 'max_close_volume', 'fee_rate', 'open_order_min_price', 'open_option']
    variables = ['balance', 'max_pos_volume', 'open_init_volume', 'kama', 'open_min_volume']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # kama
        self.bargenerator = BarGenerator(self.on_bar)
        self.arraymanager = ArrayManager()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_pos_volume[LONG] = 0
        self.last_pos_volume[SHORT] = 0

        self.main_process_thread = None
        self.restart_strategy_thread = None

        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.order_info_queue = {}

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')
        # kama
        self.load_bar(2)

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        # kama
        self.bargenerator.update_tick(tick)
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

    """
    Callback of new bar data update.
    """
    def on_bar(self, bar: BarData):
        self.arraymanager.update_bar(bar)
        if not self.arraymanager.inited:
            return

        self.kama = self.arraymanager.kama(self.KAMA_Period)
        self.put_event()

    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance: ", self.balance)

        # main process daemon
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                print("Tick is invalid.")
                continue

            for direction in (LONG, SHORT):

                if self.stop_main_process == True:
                    break
                
                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    # send new order when order is rejected
                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    # send new order when order is filled
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        self.send_new_order(direction, OPEN)
                    # send new order when order is not traded or part traded
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        self.send_new_order(direction, OPEN, price)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        # send new order when order is rejected
                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is filled
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            self.send_new_order(direction, CLOSE)
                        # send new order when order is not traded or part traded
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            self.send_new_order(direction, CLOSE, price)

        sleep(2)

        # cancel all orders when strategy stop
        long_open_cancel_orderid = self.registered_order_info[LONG][OPEN]
        if long_open_cancel_orderid != '':
            if long_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_open_cancel_orderid)

        short_open_cancel_orderid = self.registered_order_info[SHORT][OPEN]
        if short_open_cancel_orderid != '':
            if short_open_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_open_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_open_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_open_cancel_orderid)

        long_close_cancel_orderid = self.registered_order_info[LONG][CLOSE]
        if long_close_cancel_orderid != '':
            if long_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[long_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[long_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(long_close_cancel_orderid)

        short_close_cancel_orderid = self.registered_order_info[SHORT][CLOSE]
        if short_close_cancel_orderid != '':
            if short_close_cancel_orderid in self.order_info_queue and (self.order_info_queue[short_close_cancel_orderid]['status'] == NOTTRADED or self.order_info_queue[short_close_cancel_orderid]['status'] == PARTTRADED):
                self.cancel_order(short_close_cancel_orderid)

        sleep(2)

        self.stop_main_process = False

    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, old_price = -1):
        self.calc_max_pos_and_init_volume(direction, offset)

        # calculate price based on AS model
        new_price = self.get_order_price(direction, offset, old_price)

        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(origin_vt_orderid)
            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        if new_price == 0:
            return        

        # calculate the new volume when offset is open
        if offset == OPEN:
            # calculate new volume
            if direction == LONG:
                if self.pos_volume[LONG] == 0:
                    new_volume = self.open_init_volume * (1 + self.init_volume_double_rate * self.short_close_count)
                    if self.last_close_traded_price[SHORT] > 0:
                        if new_price < self.last_close_traded_price[SHORT]:
                            new_volume = self.open_min_volume
                    else:
                        if self.short_close_count == 0:
                            new_volume = self.open_min_volume
                elif self.pos_volume[LONG] > 0:
                    if self.open_option == 5:
                        new_volume = self.pos_volume[LONG]
                    else:
                        new_volume = self.volatility_price * self.open_init_volume
                        if self.last_open_traded_price[LONG] == 0:
                            if abs(new_price - self.entry_price[LONG]) < self.volatility_price + self.long_volatility_price_step:
                                return
                        else:
                            if abs(new_price - self.last_open_traded_price[LONG]) < self.volatility_price + self.long_volatility_price_step:
                                return
                            else:
                                if abs(new_price - self.entry_price[LONG]) < self.volatility_price + self.long_volatility_price_step:
                                    return

                if self.pos_volume[LONG] > self.max_pos_volume / self.leverage:
                    return
            elif direction == SHORT:
                if self.pos_volume[SHORT] == 0:
                    new_volume = self.open_init_volume * (1 + self.init_volume_double_rate * self.long_close_count)
                    if self.last_close_traded_price[LONG] > 0:
                        if new_price > self.last_close_traded_price[LONG]:
                            new_volume = self.open_min_volume
                    else:
                        if self.long_close_count == 0:
                            new_volume = self.open_min_volume
                elif self.pos_volume[SHORT] > 0:
                    if self.open_option == 6:
                        new_volume = self.pos_volume[SHORT]
                    else:
                        new_volume = self.volatility_price * self.open_init_volume
                        if self.last_open_traded_price[SHORT] == 0:
                            if abs(new_price - self.entry_price[SHORT]) < self.volatility_price + self.short_volatility_price_step:
                                return
                        else:
                            if abs(new_price - self.last_open_traded_price[SHORT]) < self.volatility_price + self.short_volatility_price_step:
                                return
                            else:
                                if abs(new_price - self.entry_price[SHORT]) < self.volatility_price + self.short_volatility_price_step:
                                    return

                if self.pos_volume[SHORT] > self.max_pos_volume / self.leverage:
                    return

            if new_volume < self.open_min_volume:
                return
        elif offset == CLOSE:
            if direction == LONG:
                if self.pos_volume[SHORT] > 0:
                    if self.pos_volume[SHORT] <= self.close_min_volume:
                        new_volume = self.pos_volume[SHORT]
                    else:
                        rate = min(max(round_to(abs(new_price - self.entry_price[SHORT]), 1), 1), 1 / self.close_volume_rate)
                        new_volume = self.pos_volume[SHORT] * self.close_volume_rate * rate
                else:
                    return False
            elif direction == SHORT:
                if self.pos_volume[LONG] > 0:
                    if self.pos_volume[LONG] <= self.close_min_volume:
                        new_volume = self.pos_volume[LONG]
                    else:
                        rate = min(max(round_to(abs(new_price - self.entry_price[LONG]), 1), 1), 1 / self.close_volume_rate)
                        new_volume = self.pos_volume[LONG] * self.close_volume_rate * rate
                else:
                    return False

            if new_volume > self.max_close_volume:
                new_volume = self.max_close_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        if self.open_option == 1:
            if direction == LONG and offset == OPEN:
                return
        elif self.open_option == 2:
            if direction == SHORT and offset == OPEN:
                return
        elif self.open_option == 3:
            if offset == OPEN:
                return
        elif self.open_option == 404:
            if offset == OPEN:
                return
            if offset == CLOSE:
                new_volume = 1
                if direction == LONG:
                    if new_volume > self.pos_volume[SHORT]:
                        new_volume = self.pos_volume[SHORT]
                elif direction == SHORT:
                    if new_volume > self.pos_volume[LONG]:
                        new_volume = self.pos_volume[LONG]

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return True
        else:
            return False

    """
    "   desc:   Get ask/bid price based on AS model
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_order_price(self, direction, offset, old_price):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        if tick.last_price > self.kama + 0.5:
            self.kama_status = 1
        elif tick.last_price < self.kama - 0.5:
            self.kama_status = 2
        else:
            self.kama_status = 0

        if direction == LONG:
            price = tick.bid_price_1 + ask1_bid1_pricetick
            if offset == OPEN:
                if self.kama_status == 2 or self.kama_status == 0:
                    return 0
                else:
                    if self.prev_kama_status == 2:
                        self.prev_kama_status = 1
                        return 0

                    self.prev_kama_status = 1
                    self.short_volatility_price_step = 0
                    self.long_close_count = 0

                    if self.pos_volume[LONG] > 0:
                        if price >= self.entry_price[LONG]:
                            return 0

                    if self.last_open_traded_price[LONG] > 0:
                        if price < self.last_open_traded_price[LONG]:
                            return 0
            elif offset == CLOSE:
                if self.open_option != 404:
                    if price > self.entry_price[SHORT] - self.profit_pricetick[SHORT]:
                        price = self.entry_price[SHORT] - self.profit_pricetick[SHORT]
        elif direction == SHORT:
            price = tick.ask_price_1 - ask1_bid1_pricetick
            if offset == OPEN:
                if self.kama_status == 1 or self.kama_status == 0:
                    return 0
                else:
                    if self.prev_kama_status == 1:
                        self.prev_kama_status = 2
                        return 0

                    self.prev_kama_status = 2
                    self.long_volatility_price_step = 0
                    self.short_close_count = 0

                    if self.pos_volume[SHORT] > 0:
                        if price <= self.entry_price[SHORT]:
                            return 0

                    if self.last_open_traded_price[SHORT] > 0:
                        if price > self.last_open_traded_price[SHORT]:
                            return 0
            elif offset == CLOSE:
                if self.open_option != 404:
                    if price < self.entry_price[LONG] + self.profit_pricetick[LONG]:
                        price = self.entry_price[LONG] + self.profit_pricetick[LONG]

        price = round_to(price, self.pricetick)

        return price

    """
    "   desc:   Calculate max_pos_volume
    "   input:  market_price
    """
    def calc_max_pos_and_init_volume(self, direction, offset):
        self.open_min_volume = round_to(self.open_order_min_price / self.market_price, self.min_volume)
        self.max_pos_volume = round_to(self.balance * self.leverage / self.market_price, self.min_volume)
        self.open_init_volume = max(round_to(self.open_volume_rate * self.max_pos_volume / self.market_price, self.min_volume), self.open_min_volume)

    """
    "   desc: Get order type as string
    "   input: direction, offset
    """
    def get_order_type_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'LONG_OPEN'
            else:
                return 'LONG_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'SHORT_OPEN'
            else:
                return 'SHORT_CLOSE'

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.last_open_traded_price[LONG] = 0
                    self.last_entry_price[LONG] = 0
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.last_open_traded_price[SHORT] = 0
                    self.last_entry_price[SHORT] = 0
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price
            self.profit_pricetick[direction] = round_to(2 * position.price * self.fee_rate + 3 * self.pricetick, self.pricetick)

    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.summary_count['total'] += round_to(order.price * order.volume, 1)
                self.summary_count['traded'] += order.volume
                traded_volume = round_to(self.summary_count['traded'], self.min_volume)
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)

                long_entry_price_decrease = 0
                short_entry_price_increase = 0
                if direction == LONG:
                    if offset == OPEN:
                        self.last_open_traded_price[LONG] = order.price
                        self.last_open_traded_price[SHORT] = 0
                        self.last_close_traded_price[LONG] = 0
                        if self.pos_volume[LONG] > 0:
                            self.long_volatility_price_step += 1
                            if self.long_volatility_price_step > self.volatility_price:
                                self.long_volatility_price_step = self.volatility_price

                        if self.last_entry_price[LONG] > 0:
                            long_entry_price_decrease = round_to(self.last_entry_price[LONG] - self.entry_price[LONG], self.pricetick)
                        self.last_entry_price[LONG] = self.entry_price[LONG]
                    else:
                        self.long_close_count += 1
                        self.last_close_traded_price[LONG] = order.price
                        self.short_volatility_price_step = 0
                elif direction == SHORT:
                    if offset == OPEN:
                        self.last_open_traded_price[SHORT] = order.price
                        self.last_open_traded_price[LONG] = 0
                        self.last_close_traded_price[SHORT] = 0
                        if self.pos_volume[SHORT] > 0:
                            self.short_volatility_price_step += 1
                            if self.short_volatility_price_step > self.volatility_price:
                                self.short_volatility_price_step = self.volatility_price

                        if self.last_entry_price[SHORT] > 0:
                            short_entry_price_increase = round_to(self.entry_price[SHORT] - self.last_entry_price[SHORT], self.pricetick)
                        self.last_entry_price[SHORT] = self.entry_price[SHORT]
                    else:
                        self.short_close_count += 1
                        self.last_close_traded_price[SHORT] = order.price
                        self.long_volatility_price_step = 0
                print(f'{self.summary_count["maker"]: >8}{PRICE_TRENDING[self.kama_status]: >10}{order_type_str: >14}{order.price: >10}{order.volume: >10}{self.short_close_count: >3}{self.long_close_count: >3}{short_entry_price_increase: >6}{long_entry_price_decrease: >6}{self.short_volatility_price_step: >3}{self.long_volatility_price_step: >3}{traded_volume: >16}{self.summary_count["total"]: >16}')
            except:
                pass
        elif order.status == CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
