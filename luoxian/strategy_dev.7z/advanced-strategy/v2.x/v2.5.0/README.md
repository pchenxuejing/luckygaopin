# advanced-strategy
Version 2.4.6

- Best parameter values
    reservation_spread = 12
    open_volume_double_rate = 6
    min_tick_count = 2
    leverage = 50
    max_pos_percent = 0.6
    max_diff_price_rate = 4.0
    risk_limit_value = 200000
    risk_limit_volume_rate = 0.5
    init_pos_volume = 3000
    max_order_volume = 1000
