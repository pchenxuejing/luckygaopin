from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    OrderData,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
from threading import Thread
from datetime import time
from time import sleep, time

class AdvancedGridStrategy_Binances_v254_ETHBUSD(CtaTemplate):

    author = "Advanced Grid Strategy v2.5.4(ETHBUSD)"

    leverage_rate = 5                   # leverage [10, 20]
    open_order_dict_len = 3             # if this value increas, then the loss will be increased. But managing inventory risk will be good.
    open_volume_rate = 1.0              # open volume rate (will be applied to open_init_volume caculation) calculation: open_volume_rate * min_volume = 0.001
    close_volume_rate = 0.1             # close volume rate
    close_min_volume = 0.1              # close minimum volume
    close_volume_max_rate = 5           # close volume max rate
    min_dist_price_tick = 20            # minimum dist price tick
    pos_priority = 0                    # if it's 0, then process long positions, and is 1 then will process short position.
    open_order_min_price = 5            # it depends on exchange policy
    sleep_time = 1.0                    # sleep time (especially for bybit testnet and maninnet)

    balance = 0                         # account balance
    long_pos_volume = 0                 # long position volume
    short_pos_volume = 0                # short position volume
    max_pos_volume = 0                  # maximium positon volume with current balance
    open_init_volume = 0                # initial volume of open order
    open_min_volume = 0
    dist_price_tick = 0.0
    traded_long_open_order_dict = {}
    traded_short_open_order_dict = {}

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    entry_price = {
        Direction.LONG: 0,
        Direction.SHORT: 0
    }

    parameters = ['leverage_rate', 'open_order_dict_len', 'open_volume_rate', 'close_volume_rate', 'close_min_volume', 'close_volume_max_rate', 'min_dist_price_tick', 'pos_priority', 'open_order_min_price', 'sleep_time']
    variables = ['balance', 'max_pos_volume', 'open_init_volume', 'open_min_volume', 'dist_price_tick']

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()

    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_long_pos_volume = 0
        self.last_short_pos_volume = 0

        self.main_process_thread = None
        self.restart_strategy_thread = None
        self.clear_order_thread = None

        self.current_pos_direction = None
        self.price_trending_direction = None

        self.registered_order_info = {
            Direction.LONG: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            },
            Direction.SHORT: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            }
        }

        self.order_info_queue = {}

        self.modified_order_info = {
            Offset.OPEN: {
                'changed': False,
                'price': 0
            },
            Offset.CLOSE: {
                'changed': False,
                'price': 0
            }
        }

    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')
        self.write_log("策略初始化")

    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.write_log("策略启动")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

        # clear unnecessary orders
        self.clear_order_thread = Thread(target = self.clear_orders)
        self.clear_order_thread.setDaemon(True)
        self.clear_order_thread.start()

    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.write_log("策略停止")

    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)

    def clear_orders(self):
        while True:
            direction = self.current_pos_direction
            if direction == Direction.LONG:
                opposite_direction = Direction.SHORT
            else:
                opposite_direction = Direction.LONG

            if direction != None:
                try:
                    order_info_queue = deepcopy(self.order_info_queue)
                except:
                    order_info_queue = deepcopy(self.order_info_queue)

                for vt_orderid in order_info_queue:
                    if vt_orderid == self.registered_order_info[direction][Offset.OPEN] or vt_orderid == self.registered_order_info[opposite_direction][Offset.CLOSE]:
                        continue

                    try:
                        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                            sleep(0.5)
                        else:
                            del self.order_info_queue[vt_orderid]
                    except:
                        pass

                sleep(60)

    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        print("Restarting succeed")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()

    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True

    def main_process(self):
        LONG = Direction.LONG
        SHORT = Direction.SHORT
        OPEN = Offset.OPEN
        CLOSE = Offset.CLOSE

        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance: ", self.balance)

        # send long_open order and short_open order when strategy start
        self.send_order_when_start()

        # main process daemon
        while self.stop_main_process == False:
            sleep(self.sleep_time)

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                print("Tick is invalid.")
                continue

            # check long and short open order which is placed when starts
            if self.current_pos_direction == None:
                for direction in (LONG, SHORT):
                    vt_orderid = self.registered_order_info[direction][OPEN]
                    if vt_orderid == '':
                        self.send_new_order(direction, OPEN)
                        continue
                    else:
                        if vt_orderid not in self.order_info_queue:
                            self.send_new_order(direction, OPEN)
                            continue

                    # resend rejected order
                    if self.order_info_queue[vt_orderid]['status'] == Status.REJECTED or self.order_info_queue[vt_orderid]['status'] == Status.CANCELLED:
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    # resend not traded order
                    elif self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED:
                        price = self.order_info_queue[vt_orderid]['price']
                        self.send_new_order(direction, OPEN, price)
                    # cancel order when all order is traded
                    elif self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                        if direction == LONG:
                            cancel_direction = SHORT
                        else:
                            cancel_direction = LONG

                        cancel_orderid = self.registered_order_info[cancel_direction][OPEN]
                        self.cancel_order(cancel_orderid)
                        self.registered_order_info[cancel_direction][OPEN] = ''
                        self.current_pos_direction = direction

                        break

            if self.current_pos_direction != None:
                for direction in (LONG, SHORT):
                    if self.stop_main_process == True:
                        break

                    if direction == self.current_pos_direction:
                        offset = OPEN
                    else:
                        offset = CLOSE

                    vt_orderid = self.registered_order_info[direction][offset]
                    if vt_orderid == '':
                        self.send_new_order(direction, offset)
                        continue
                    else:
                        if vt_orderid not in self.order_info_queue:
                            self.send_new_order(direction, offset)
                            continue
                    # send new order when order is rejected
                    if self.order_info_queue[vt_orderid]['status'] == Status.REJECTED or self.order_info_queue[vt_orderid]['status'] == Status.CANCELLED:
                        self.registered_order_info[direction][offset] = ''
                        self.send_new_order(direction, offset)
                    # send new order when order is filled
                    elif self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:
                        self.send_new_order(direction, offset)
                    # send new order when order is not traded or part traded
                    elif self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                        price = self.order_info_queue[vt_orderid]['price']
                        self.send_new_order(direction, offset, price)

        sleep(2)

        # cancel all orders when strategy stop
        direction = self.current_pos_direction
        if direction != None:
            if direction == LONG:
                opposite_direction = SHORT
            else:
                opposite_direction = LONG

            open_id = self.registered_order_info[direction][OPEN]
            if open_id in self.order_info_queue and (self.order_info_queue[open_id]['status'] == Status.NOTTRADED or self.order_info_queue[open_id]['status'] == Status.PARTTRADED):
                self.cancel_order(open_id)

            close_id = self.registered_order_info[opposite_direction][CLOSE]
            if close_id in self.order_info_queue and (self.order_info_queue[close_id]['status'] == Status.NOTTRADED or self.order_info_queue[close_id]['status'] == Status.PARTTRADED):
                self.cancel_order(close_id)

        sleep(2)

        self.stop_main_process = False

    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == Offset.NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == Status.SUBMITTING and self.order_info_queue[vt_orderid]['status'] != Status.SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }

    """
    "   desc:   Send long and short open order when trading is started
    "   output: new_order_volume: default => 0
    """
    def send_order_when_start(self):
        if self.long_pos_volume > 0:
            if len(self.traded_long_open_order_dict) == 0:
                self.traded_long_open_order_dict[self.entry_price[Direction.LONG]] = self.long_pos_volume
        if self.short_pos_volume > 0:
            if len(self.traded_short_open_order_dict) == 0:
                self.traded_short_open_order_dict[self.entry_price[Direction.SHORT]] = self.short_pos_volume

        if self.long_pos_volume > 0 and self.short_pos_volume > 0:
            if self.pos_priority == 0:
                self.current_pos_direction = Direction.LONG
                self.send_new_order(Direction.SHORT, Offset.CLOSE)
                self.send_new_order(Direction.LONG, Offset.OPEN)
            elif self.pos_priority == 1:
                self.current_pos_direction = Direction.SHORT
                self.send_new_order(Direction.LONG, Offset.CLOSE)
                self.send_new_order(Direction.SHORT, Offset.OPEN)
        elif self.long_pos_volume > 0:
            self.current_pos_direction = Direction.LONG
            self.send_new_order(Direction.SHORT, Offset.CLOSE)
            self.send_new_order(Direction.LONG, Offset.OPEN)
        elif self.short_pos_volume > 0:
            self.current_pos_direction = Direction.SHORT
            self.send_new_order(Direction.LONG, Offset.CLOSE)
            self.send_new_order(Direction.SHORT, Offset.OPEN)
        else:
            self.current_pos_direction = None
            self.send_new_order(Direction.LONG, Offset.OPEN)
            self.send_new_order(Direction.SHORT, Offset.OPEN)

    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, old_price = -1):
        self.calc_max_pos_and_init_volume()

        # calculate price based on AS model
        new_price = self.get_order_price_based_on_asmodel(direction, offset, old_price)
        if new_price == 0:
            return

        if round(abs((new_price - old_price) / self.pricetick)) == 0:
            return

        new_volume = 0
        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == Status.SUBMITTING or self.order_info_queue[origin_vt_orderid]['status'] == Status.REJECTED:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == Status.PARTTRADED:
                self.cancel_order(origin_vt_orderid)

            self.registered_order_info[direction][offset] = ''

        if self.stop_main_process == True:
            return False

        # calculate the new volume when offset is open
        if offset == Offset.OPEN:
            # calculate new volume
            new_volume = self.open_init_volume
            if direction == Direction.LONG:
                if self.long_pos_volume > 0:
                    new_volume += self.open_init_volume * abs(new_price - self.entry_price[Direction.LONG])
                    if new_volume + self.long_pos_volume >= self.max_pos_volume:
                        new_volume = self.open_min_volume
            elif direction == Direction.SHORT:
                if self.short_pos_volume > 0:
                    new_volume += self.open_init_volume * abs(new_price - self.entry_price[Direction.SHORT])
                    if new_volume + self.short_pos_volume >= self.max_pos_volume:
                        new_volume = self.open_min_volume

            if new_volume < self.open_min_volume:
                new_volume =  self.open_min_volume
        elif offset == Offset.CLOSE:
            if direction == Direction.LONG:
                if new_price > self.entry_price[Direction.SHORT]:
                    close_volume_from_dict = self.get_close_volume_from_dict(direction, new_price)
                    if close_volume_from_dict > (self.open_order_dict_len - 1) * self.open_init_volume:
                        new_volume = close_volume_from_dict / (self.open_order_dict_len - 1)
                    else:
                        new_volume = self.min_volume
                else:
                    rate = max(round_to(abs(new_price - self.entry_price[Direction.SHORT]) + 0.5, 1), 1)
                    new_volume = self.short_pos_volume * self.close_volume_rate * rate
                    if self.short_pos_volume < self.close_min_volume:
                        new_volume = self.short_pos_volume
            elif direction == Direction.SHORT:
                if new_price < self.entry_price[Direction.LONG]:
                    close_volume_from_dict = self.get_close_volume_from_dict(direction, new_price)
                    if close_volume_from_dict > (self.open_order_dict_len - 1) * self.open_init_volume:
                        new_volume = close_volume_from_dict / (self.open_order_dict_len - 1)
                    else:
                        new_volume = self.min_volume
                else:
                    rate = max(round_to(abs(new_price - self.entry_price[Direction.LONG]) + 0.5, 1), 1)
                    new_volume = self.long_pos_volume * self.close_volume_rate * rate
                    if self.long_pos_volume < self.close_min_volume:
                        new_volume = self.long_pos_volume
            if new_volume < self.min_volume:
                new_volume =  self.min_volume

        new_price = round_to(new_price, self.pricetick)
        new_volume = round_to(new_volume, self.min_volume)

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, Status.SUBMITTING)
            return True
        else:
            return False

    """
    "   desc:   Get ask/bid price based on AS model
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_order_price_based_on_asmodel(self, direction, offset, old_price):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        ask1_bid1_pricetick = 0
        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)
        if tick_gap >= 2:
            ask1_bid1_pricetick = self.pricetick

        if direction == Direction.LONG:
            if offset == Offset.OPEN:
                price = tick.bid_price_1
                if self.long_pos_volume > 0:
                    self.dist_price_tick = min(max(round_to(abs(tick.bid_price_1 - self.entry_price[Direction.LONG]) * 10, 1), self.min_dist_price_tick), 100)
                    price = tick.bid_price_1 - self.dist_price_tick * self.pricetick
                    if price > self.entry_price[Direction.LONG]:
                        price = tick.bid_price_5 - self.dist_price_tick * self.pricetick
            elif offset == Offset.CLOSE:
                self.dist_price_tick = min(max(round_to(abs(tick.bid_price_1 - self.entry_price[Direction.SHORT]) * 10, 1), self.min_dist_price_tick), 100)
                price = tick.bid_price_1 + ask1_bid1_pricetick
                if len(self.traded_short_open_order_dict) > 0 and price > self.entry_price[Direction.SHORT]:
                    traded_short_open_max_price = max(self.traded_short_open_order_dict.keys())
                    if price >= traded_short_open_max_price:
                        price = traded_short_open_max_price - self.dist_price_tick * self.pricetick / 2
                    else:
                        price = tick.bid_price_1 - self.dist_price_tick * self.pricetick / 2

                    if price < self.entry_price[Direction.SHORT]:
                        price = self.entry_price[Direction.SHORT] - self.pricetick
        elif direction == Direction.SHORT:
            if offset == Offset.OPEN:
                price = tick.ask_price_1
                if self.short_pos_volume > 0:
                    self.dist_price_tick = min(max(round_to(abs(tick.ask_price_1 - self.entry_price[Direction.SHORT]) * 10, 1), self.min_dist_price_tick), 100)
                    price = tick.ask_price_1 + self.dist_price_tick * self.pricetick
                    if price < self.entry_price[Direction.SHORT]:
                        price = tick.ask_price_5 + self.dist_price_tick * self.pricetick
            elif offset == Offset.CLOSE:
                self.dist_price_tick = min(max(round_to(abs(tick.ask_price_1 - self.entry_price[Direction.LONG]) * 10, 1), self.min_dist_price_tick), 100)
                price = tick.ask_price_1 - ask1_bid1_pricetick
                if len(self.traded_long_open_order_dict) > 0 and price < self.entry_price[Direction.LONG]:
                    traded_long_open_min_price = min(self.traded_long_open_order_dict.keys())
                    if price <= traded_long_open_min_price:
                        price = traded_long_open_min_price + self.dist_price_tick * self.pricetick / 2
                    else:
                        price = tick.ask_price_1 + self.dist_price_tick * self.pricetick / 2

                    if price > self.entry_price[Direction.LONG]:
                        price = self.entry_price[Direction.LONG] + self.pricetick

        price = round_to(price, self.pricetick)

        return price

    """
    "   desc:   Calculate max_pos_volume
    "   input:  market_price
    """
    def calc_max_pos_and_init_volume(self):
        self.max_pos_volume = self.balance * self.leverage_rate / self.market_price
        self.open_init_volume = max(round_to(self.max_pos_volume * self.open_volume_rate * self.min_volume, self.min_volume), self.min_volume)
        self.open_min_volume = round_to(self.open_order_min_price / self.market_price, self.min_volume)

    """
    "   desc: Get order type as string
    "   input: direction, offset
    """
    def get_order_type_str(self, direction, offset):
        if direction == Direction.LONG:
            if offset == Offset.OPEN:
                return 'long_open'
            else:
                return 'long_close'
        elif direction == Direction.SHORT:
            if offset == Offset.OPEN:
                return 'short_open'
            else:
                return 'short_close'

    """
    "   desc:   Update traded open order dict
    "   input:  price, volume, status(0: add, 1: reduce)
    """
    def update_traded_open_order_dict(self, direction, price, volume, status):
        if status == 0:
            if direction == Direction.LONG:
                if price in self.traded_long_open_order_dict:
                    self.traded_long_open_order_dict[price] += volume
                else:
                    self.traded_long_open_order_dict[price] = volume
            elif direction == Direction.SHORT:
                if price in self.traded_short_open_order_dict:
                    self.traded_short_open_order_dict[price] += volume
                else:
                    self.traded_short_open_order_dict[price] = volume
        elif status == 1:
            if direction == Direction.LONG:
                key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                for k in sorted(key_copy_short, reverse=True):
                    if k > price and volume > 0:
                        if volume > self.traded_short_open_order_dict[k]:
                            volume -= self.traded_short_open_order_dict[k]
                            del self.traded_short_open_order_dict[k]
                        elif volume == self.traded_short_open_order_dict[k]:
                            del self.traded_short_open_order_dict[k]
                            volume = 0
                            break
                        else:
                            self.traded_short_open_order_dict[k] -= volume
                            volume = 0
                            break
            elif direction == Direction.SHORT:
                key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                for k in sorted(key_copy_long):
                    if price > k and volume > 0:
                        if volume > self.traded_long_open_order_dict[k]:
                            volume -= self.traded_long_open_order_dict[k]
                            del self.traded_long_open_order_dict[k]
                        elif volume == self.traded_long_open_order_dict[k]:
                            del self.traded_long_open_order_dict[k]
                            volume = 0
                            break
                        else:
                            self.traded_long_open_order_dict[k] -= volume
                            volume = 0
                            break

    """
    "   desc:   Update traded open order dict
    "   input:  price, volume, status(0: add, 1: del)
    "   return: close volume
    """
    def get_close_volume_from_dict(self, direction, price):
        close_volume = 0
        if direction == Direction.LONG:
            key_copy_short = tuple(self.traded_short_open_order_dict.keys())
            for k in sorted(key_copy_short, reverse=True):
                if k > price:
                    close_volume += self.traded_short_open_order_dict[k]
        elif direction == Direction.SHORT:
            key_copy_long = tuple(self.traded_long_open_order_dict.keys())
            for k in sorted(key_copy_long):
                if price > k:
                    close_volume += self.traded_long_open_order_dict[k]

        return close_volume

    """
    "   desc:   Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            self.balance = account.balance

    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == Direction.LONG:
                self.long_pos_volume = abs(position.volume)
                # closed all long pos
                if self.last_long_pos_volume > 0 and self.long_pos_volume == 0:
                    self.write_log(f"多仓全平")
                    print('Restarting because all long position are closed.')
                    self.traded_long_open_order_dict = {}
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_long_pos_volume = self.long_pos_volume
            elif direction == Direction.SHORT:
                self.short_pos_volume = abs(position.volume)
                # closed all short pos
                if self.last_short_pos_volume > 0 and self.short_pos_volume == 0:
                    self.write_log(f"空仓全平")
                    self.traded_short_open_order_dict = {}
                    print('Restarting because all short position are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)
                    self.restart_strategy_thread.start()

                self.last_short_pos_volume = self.short_pos_volume

            self.entry_price[direction] = position.price

    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == Status.SUBMITTING:
            self.summary_count['total'] += order.volume
        elif order.status == Status.NOTTRADED:
            order_type = 'maker'
        elif order.status == Status.PARTTRADED:
            pass
        elif order.status == Status.ALLTRADED:
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1

                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)

                if offset == Offset.OPEN:
                    if direction == Direction.LONG:
                        if self.long_pos_volume > 0:
                            if len(self.traded_long_open_order_dict) < self.open_order_dict_len:
                                self.update_traded_open_order_dict(direction, order.price, order.volume, 0)
                            else:
                                self.traded_long_open_order_dict = {}
                                self.traded_long_open_order_dict[self.entry_price[Direction.LONG]] = self.long_pos_volume
                        else:
                            self.update_traded_open_order_dict(direction, order.price, order.volume, 0)
                    else:
                        if self.short_pos_volume > 0:
                            if len(self.traded_short_open_order_dict) < self.open_order_dict_len:
                                self.update_traded_open_order_dict(direction, order.price, order.volume, 0)
                            else:
                                self.traded_short_open_order_dict = {}
                                self.traded_short_open_order_dict[self.entry_price[Direction.SHORT]] = self.short_pos_volume
                        else:
                            self.update_traded_open_order_dict(direction, order.price, order.volume, 0)
                elif offset == Offset.CLOSE:
                    self.update_traded_open_order_dict(direction, order.price, order.volume, 1)

                if offset == Offset.OPEN:
                    if direction == Direction.LONG:
                        print("ALLTRADED:  ", f'{order_type_str: >12}{len(self.traded_long_open_order_dict): >5}{self.entry_price[Direction.LONG]: >15}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
                    elif direction == Direction.SHORT:
                        print("ALLTRADED:  ", f'{order_type_str: >12}{len(self.traded_short_open_order_dict): >5}{self.entry_price[Direction.SHORT]: >15}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
                else:
                    if direction == Direction.LONG:
                        print("ALLTRADED:  ", f'{order_type_str: >12}{len(self.traded_short_open_order_dict): >5}{self.entry_price[Direction.SHORT]: >15}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
                    elif direction == Direction.SHORT:
                        print("ALLTRADED:  ", f'{order_type_str: >12}{len(self.traded_long_open_order_dict): >5}{self.entry_price[Direction.LONG]: >15}{order.price: >12}{order.volume: >10}{self.summary_count["maker"]: >10}')
                # {self.summary_count["traded"]: >10}{self.summary_count["total"]: >10}
            except:
                pass
        elif order.status == Status.CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == Status.REJECTED:
            self.summary_count['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
