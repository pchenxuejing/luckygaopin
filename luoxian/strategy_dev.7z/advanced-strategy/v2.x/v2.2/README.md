# advanced-strategy
- Version 2.2
[non-linear factors]
	sigma = self.usedMargin / useable_margin_max_value
	self.open_volume_increase_percent = np.exp(-sigma) / (10 * self.available_margin_rate) (open order, sigma >= self.available_margin_rate)
	gamma = self.entry_price[Direction.SHORT] / price (LONG_CLOSE)
	gamma = price / self.entry_price[Direction.LONG] (SHORT_CLOSE)
	self.close_volume_increase_percent = np.exp(gamma) * np.exp(sigma)

if balance < 1000


- Available functions
modify_limit_volume
price_change
entry_price limit