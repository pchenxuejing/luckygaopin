# advanced-strategy
Version 2.5.3

- Parameters
    open_order_dict_len = 3             # if this value increas, then the loss will be increased. But managing inventory risk will be good.
    open_volume_rate = 1.0              # open volume rate (will be applied to open_init_volume caculation) calculation: open_volume_rate * min_volume = 0.001
    close_volume_rate = 0.16            # the rate of long_short_position
    close_min_volume = 0.016            # minimum close_volume
    dist_price_tick = 30                # close price distance tick from min or max open order price
    pos_priority = 0                    # if it's 0, then process long positions, and is 1 then will process short position.
    dict_len_useable = 1                # if it's 0, then do not use open_order_dict_len parameter
