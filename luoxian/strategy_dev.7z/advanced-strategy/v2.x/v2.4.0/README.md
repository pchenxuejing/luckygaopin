# advanced-strategy
- Version 2.4
[non-linear factors]
		sigma = self.usedMargin / useable_margin_max_value
        gamma = 0
        theta = 1
        
        # calculate open/close volume increasing factor - non-linear
        if offset == Offset.OPEN:
            # increasing/decreasing the size of inventory
            if sigma >= 1:
                self.stop_loss_order = 1
            else:
                self.stop_loss_order = 0
                if sigma >= self.margin_limit_rate:
                    self.open_volume_increase_percent = np.exp(-sigma) / (10 * self.margin_limit_rate)
                else:
                    self.open_volume_increase_percent = np.exp(sigma)
        if offset == Offset.CLOSE:
            # maximizing profit and decreasing the size of inventory
            if direction == Direction.LONG:
                if price != 0:
                    gamma = self.entry_price[Direction.SHORT] / price
                    theta = (self.entry_price[Direction.SHORT] - price) / self.grid_gap
            else:
                if self.entry_price[Direction.LONG] != 0:
                    gamma = price / self.entry_price[Direction.LONG]
                    theta = (price - self.entry_price[Direction.LONG]) / self.grid_gap
            if theta < 3:
                self.close_volume_increase_percent = np.exp(gamma)
            else:
                self.close_volume_increase_percent = np.exp(gamma) *  np.log(theta)
        
        if self.stop_loss_order == 1:
             self.open_init_volume = self.min_volume
        else:
            self.open_init_volume = max(round_to(self.grid_gap * self.target_pos_volume, self.min_volume), self.min_volume)
        
        # calculate close_init_volume
        self.close_init_volume = max(round_to(self.grid_gap * self.target_pos_volume * self.big_percent, self.min_volume), self.min_volume)

- Logic
	removed a modify_limit_volume logic
	sending our order as ask1 and bid1 always
	entry_price limit

- Best parameter values
	margin_limit_rate = 0.4
    allow_tick_limit_rate = 5
    additional_close_volume_rate = 10

In a nutshell, this strategy can be called "Weekly Trading Strategy" for weekly trader.

Thank you

Notice: it's a bit dangerous, so please be careful when use this.
