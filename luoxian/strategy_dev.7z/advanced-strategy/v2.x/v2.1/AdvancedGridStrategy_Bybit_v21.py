from vnpy.app.cta_strategy import (
    CtaTemplate,
    # StopOrder,
    TickData,
    # BarData,
    # TradeData,
    OrderData,
    # BarGenerator,
    # ArrayManager,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status #, Interval
from datetime import time, datetime
from vnpy.trader.object import PositionData,AccountData
from copy import deepcopy
import os
# from collections import defaultdict
import numpy as np
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION #, EVEN_TIMER
from threading import Thread
from time import sleep, time

class AdvancedGridStrategy_Bybit_v21(CtaTemplate):
    
    author = "最新网格交易策略v2.1"

    grid_gap_tick_count = 1       # 网格间距
    leverage_rate = 100   # 杠杆比例
    max_pos_percent = 0.1
    modify_limit_volume = 100
    modify_pricetick_n = 1
    nonlinear_factor = 2
    entry_price_diff_rate = 3

    balance = 0         # 账户余额
    long_pos = 0        # 多头持仓
    short_pos = 0       # 空头持仓

    target_pos = 0

    long_short_open = 0
    long_short_close = 0
    
    open_volume_increase_percent = 0
    close_volume_increase_percent = 0
    
    rate_limit_status = 0
    max_pos_volume = 0

    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    entry_price = {
        Direction.LONG: 0,
        Direction.SHORT: 0
    }
    
    pos_volume = {
        Direction.LONG: 0,
        Direction.SHORT: 0
    }

    parameters = ['grid_gap_tick_count', 'max_pos_percent', 'leverage_rate', 'modify_limit_volume', 'modify_pricetick_n', 'nonlinear_factor', 'entry_price_diff_rate']

    variables = ['balance', 'long_pos', 'short_pos', 'rate_limit_status', 'target_pos', 'long_short_open', 'long_short_close', 'max_pos_volume'] 

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume

        self.symbol = self.vt_symbol.split('.')[0]
        
        self.init()


    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_long_pos = 0
        self.last_short_pos = 0

        self.grid_gap = self.pricetick * self.grid_gap_tick_count

        self.main_process_thread = None
        self.restart_strategy_thread = None
        self.clear_order_thread = None

        self.trading_direction = None

        self.registered_order_info = {
            Direction.LONG: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            },
            Direction.SHORT: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            }
        }

        self.order_info_queue = {}
		
        self.modified_order_info = {
            Offset.OPEN: {
                'changed': False,
                'price': 0
            },
            Offset.CLOSE: {
                'changed': False,
                'price': 0
            }
        }
		

    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('BYBIT')

        self.write_log("策略初始化")

    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status=300

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.write_log("策略启动")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

        # clear unnecessary orders
        self.clear_order_thread = Thread(target = self.clear_orders)
        self.clear_order_thread.setDaemon(True)

        self.clear_order_thread.start()

        # self.write_log_to_file('Strategy is started.')
    

    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.stop_main_process = True
        
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)
        self.write_log("策略停止")

        # self.cancel_all()

        # self.write_log_to_file('Strategy is stopped.')
    

    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.last_last_tick = self.last_tick
        self.last_tick = tick
        
        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)
    

    def clear_orders(self):
        while True:
            direction = self.trading_direction

            if direction == Direction.LONG:
                opposite_direction = Direction.SHORT
            else:
                opposite_direction = Direction.LONG

            if direction != None:

                try:
                    order_info_queue = deepcopy(self.order_info_queue)
                except:
                    order_info_queue = deepcopy(self.order_info_queue)
                    
                for vt_orderid in order_info_queue:

                    if vt_orderid == self.registered_order_info[direction][Offset.OPEN] or vt_orderid == self.registered_order_info[opposite_direction][Offset.CLOSE]:
                        continue
                    
                    try:
                        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                            sleep(0.5)
                        else:
                            del self.order_info_queue[vt_orderid]
                    except:
                        pass

                sleep(60)


    def restart_strategy(self):
        self.stop_main_process = True

        while self.stop_main_process == True:
            sleep(0.05)

        print("Restarted completely")
        
        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

    
    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    def main_process(self):

        LONG = Direction.LONG
        SHORT = Direction.SHORT
        OPEN = Offset.OPEN
        CLOSE = Offset.CLOSE

        print("Balance is ", self.balance)

        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance is ", self.balance)

        # send long_open order and short_open order when strategy start
        self.send_long_short_open_order_when_start()

        # main process deamon
        start = time()
        while self.stop_main_process == False:
            sleep(1)

            end = time()
            if (end- start) > 2:
                self.get_rate_limit_status()

                start = end
                print("rate limit status: ", self.rate_limit_status)
            
            if self.rate_limit_status <= 10:
                continue

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                print("Tick is invalid.")
                continue

            # check long and short open order which is placed when starts
            if self.trading_direction == None:

                for direction in (LONG, SHORT):

                    vt_orderid = self.registered_order_info[direction][OPEN]

                    if vt_orderid == '':
                        continue
                
                    if vt_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:

                        if direction == LONG:
                            cancel_direction = SHORT
                        else:
                            cancel_direction = LONG

                        cancel_orderid = self.registered_order_info[cancel_direction][OPEN]

                        self.cancel_order(cancel_orderid)
                        self.registered_order_info[cancel_direction][OPEN] = ''
                        
                        self.trading_direction = direction

                        break
            
            if self.trading_direction != None:
                trading_direction = self.trading_direction

                for direction in (LONG, SHORT):

                    if self.stop_main_process == True:
                        break
                    
                    if direction == LONG:
                        opposite_direction = SHORT
                    else:
                        opposite_direction = LONG

                    if direction == trading_direction:
                        offset = OPEN
                    else:
                        offset = CLOSE

                    if self.registered_order_info[direction][offset] == '':
                        price = self.get_maker_order_price(direction)
                        self.send_new_order(direction, offset, price)
                        continue
                    else:
                        vt_orderid = self.registered_order_info[direction][offset]

                        if vt_orderid not in self.order_info_queue:
                            continue
                        
                        # resend rejected order
                        if self.order_info_queue[vt_orderid]['status'] == Status.REJECTED or self.order_info_queue[vt_orderid]['status'] == Status.CANCELLED:
                            # print(self.order_info_queue[vt_orderid])
                            price = self.order_info_queue[vt_orderid]['price']
                            volume = self.order_info_queue[vt_orderid]['volume']

                            self.registered_order_info[direction][offset] = ''

                            self.send_new_order(direction, offset, price, volume)

                            continue
                        
                        # send new order when order is filled
                        if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:
                            price = self.get_maker_order_price(direction)
                            self.send_new_order(direction, offset, price)
                            continue
                        
                        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                            # change order based on modify limit volume
                            self.change_order_based_on_modify_limit_volume(direction, offset)

        sleep(5)
        
        # cancel all orders when strategy stop
        direction = self.trading_direction
        if direction != None:
            if direction == LONG:
                opposite_direction = SHORT
            else:
                opposite_direction = LONG
            
            open_id = self.registered_order_info[direction][OPEN]
            
            if open_id in self.order_info_queue and (self.order_info_queue[open_id]['status'] == Status.NOTTRADED or self.order_info_queue[open_id]['status'] == Status.PARTTRADED):
                self.cancel_order(open_id)
            
            close_id = self.registered_order_info[opposite_direction][CLOSE]

            if close_id in self.order_info_queue and (self.order_info_queue[close_id]['status'] == Status.NOTTRADED or self.order_info_queue[close_id]['status'] == Status.PARTTRADED):
                self.cancel_order(close_id)
        
        sleep(5)

        self.stop_main_process = False


    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == Offset.NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'
        
            if status == Status.SUBMITTING and self.order_info_queue[vt_orderid]['status'] != Status.SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   desc:   Check the modify_limit_volume logic and Change order
    "   input:  order_type, tick
    "   output: bool: True => changed, False => not changed
    """
    def change_order_based_on_modify_limit_volume(self, direction, offset):        

        # get order price and volume
        vt_orderid = self.registered_order_info[direction][offset]

        order_price = self.order_info_queue[vt_orderid]['price']
        order_volume = self.order_info_queue[vt_orderid]['volume']

        if order_price * order_volume == 0:
            return
        
        new_order_price = self.get_maker_order_price(direction)

        # self.gateway.query_position()

        entry_price = self.entry_price[self.trading_direction]
        
        if self.trading_direction != direction and entry_price != 0:

            if direction == Direction.LONG and new_order_price >= entry_price:
                new_order_price = entry_price - self.pricetick * self.entry_price_diff_rate
                
            elif direction == Direction.SHORT and new_order_price <= entry_price:
                new_order_price = entry_price + self.pricetick * self.entry_price_diff_rate
                
        if direction == Direction.LONG:
            if new_order_price <= order_price and abs((new_order_price - order_price) / self.pricetick) < self.modify_pricetick_n:
                return

        else:
            if new_order_price >= order_price and abs((new_order_price - order_price) / self.pricetick) < self.modify_pricetick_n:
                return

        if round(abs((new_order_price - order_price) / self.pricetick)) == 0:
            return
            
        new_order_price = round_to(new_order_price, self.pricetick)
        new_order_volume = self.calculate_volume_when_price_change(direction, offset, new_order_price, order_price, order_volume)
            
        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
            changed = self.send_new_order(direction, offset, new_order_price, new_order_volume)
            if changed == True:
                print(f'{"Change": >15}')
                print(f'{"": >15}{self.get_order_type_str(direction, offset): >15}{order_price: >15}{new_order_price: >15}{order_volume: >15}{new_order_volume: >15}')
                

    """
    "   desc:   Calculate volume when all of price change happen
    "   input:  order_type, new_order_price
    "   output: new_order_volume: default => 0
    """
    def calculate_volume_when_price_change(self, direction, offset, new_price, old_price, old_volume):

        if old_price * old_volume == 0:
            return 0

        if self.trading_direction == Direction.LONG:
            multiple = 1
        else:
            multiple = -1

        self.calculate_trade_volume(direction, offset, new_price)

        if offset == Offset.OPEN:
            new_volume = self.long_short_open + multiple * self.open_volume_increase_percent * (new_price - old_price) / self.grid_gap
            if new_volume < self.long_short_open:
                new_volume = self.long_short_open
        else:
            new_volume = self.long_short_close + multiple * self.open_volume_increase_percent * (new_price - old_price) / self.grid_gap
            if new_volume < self.long_short_close:
                new_volume = self.long_short_close
        new_volume = round(abs(new_volume))
        
        return new_volume


    """
    "   desc:   Send long and short open order when trading is started
    "   output: new_order_volume: default => 0
    """
    def send_long_short_open_order_when_start(self):
        
        bid_price = self.get_maker_order_price(Direction.LONG)
        ask_price = self.get_maker_order_price(Direction.SHORT)
        
        if self.long_pos != 0:
            # send long_open order to open long position
            self.send_new_order(Direction.LONG, Offset.OPEN, bid_price)

            # send short_close order to close long position
            self.send_new_order(Direction.SHORT, Offset.CLOSE, ask_price)

            self.trading_direction = Direction.LONG

        elif self.short_pos != 0:
            # send short_open order to open short position
            self.send_new_order(Direction.SHORT, Offset.OPEN, ask_price)

            # send long_close order to close short position
            self.send_new_order(Direction.LONG, Offset.CLOSE, bid_price)

            self.trading_direction = Direction.SHORT

        else:
            # send long_open order to open long position
            self.send_new_order(Direction.LONG, Offset.OPEN, bid_price)

            # send short_open order to open short position
            self.send_new_order(Direction.SHORT, Offset.OPEN, ask_price)

            self.trading_direction = None


    """
    "   desc:   Calculate long_short_open, long_short_close volume
    "   input:  market_price
    """
    def calculate_trade_volume(self, direction, offset, price):
        
        self.gateway.query_position()
        
        self.target_pos = self.balance * self.leverage_rate / self.market_price
        self.grid_base_pos_pst = self.grid_gap / self.market_price
        
        long_short_open_init_volume = self.grid_base_pos_pst * self.target_pos
        # long_short_close_init_volume = self.grid_base_pos_pst * self.target_pos
        
        if offset == Offset.OPEN:
            if direction == Direction.LONG:
                x = (self.entry_price[direction] - price)/price
                if self.long_pos != 0:
                    self.long_short_open = long_short_open_init_volume * np.exp((self.nonlinear_factor - x))
                else:
                    self.long_short_open = long_short_open_init_volume
            else:
                x = (price - self.entry_price[direction])/price
                if self.short_pos != 0:
                    self.long_short_open = long_short_open_init_volume * np.exp((self.nonlinear_factor - x))
                else:
                    self.long_short_open = long_short_open_init_volume
            self.open_volume_increase_percent = np.exp((self.nonlinear_factor - x))
            
        else:
            if direction == Direction.LONG:
                x = (self.entry_price[Direction.SHORT] - price)/price
                self.long_short_close = self.short_pos * (1 - 1/np.exp(1 + x))
            else:
                x = (price - self.entry_price[Direction.LONG])/price
                self.long_short_close = self.long_pos * (1 - 1/np.exp(1 + x))
            self.close_volume_increase_percent = np.exp(self.nonlinear_factor + x)
        

    """
    "   desc:   Change taker order to maker order
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_maker_order_price(self, direction):
        
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)

        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)

        if direction == Direction.LONG :

            if tick_gap < 3:
                price = tick.bid_price_1
            else:
                price = tick.bid_price_1 + self.pricetick

            total_volume = tick.bid_volume_1

            if total_volume < self.modify_limit_volume:
                price = tick.bid_price_2
                total_volume += tick.bid_volume_2 + self.pricetick

                if total_volume < self.modify_limit_volume:
                    price = tick.bid_price_3 + self.pricetick
                    total_volume += tick.bid_volume_3

                    if total_volume < self.modify_limit_volume:
                        price = tick.bid_price_4 + self.pricetick
                        total_volume += tick.bid_volume_4

                        if total_volume < self.modify_limit_volume:
                            price = tick.bid_price_5 + self.pricetick
                            total_volume += tick.bid_volume_4

                            if total_volume < self.modify_limit_volume:
                                price = tick.bid_price_5 + self.pricetick

        elif direction == Direction.SHORT:

            if tick_gap < 2:
                price = tick.ask_price_1
            else:
                price = tick.ask_price_1 - self.pricetick

            total_volume = tick.ask_volume_1

            if total_volume < self.modify_limit_volume:
                price = tick.ask_price_2 - self.pricetick
                total_volume += tick.ask_volume_2

                if total_volume < self.modify_limit_volume:
                    price = tick.ask_price_3 - self.pricetick
                    total_volume += tick.ask_volume_3

                    if total_volume < self.modify_limit_volume:
                        price = tick.ask_price_4 - self.pricetick
                        total_volume += tick.ask_volume_4

                        if total_volume < self.modify_limit_volume:
                            price = tick.ask_price_5 - self.pricetick
                            total_volume += tick.ask_volume_4

                            if total_volume < self.modify_limit_volume:
                                price = tick.ask_price_5 - self.pricetick

        price = round_to(price, self.pricetick)

        return price
    

    def check_if_maker_order(self, direction, offset, price, volume):

        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)
        
        new_price = price
        new_volume = volume
        if direction == Direction.LONG:
            if price > tick.bid_price_1:
                new_price = self.get_maker_order_price(direction)
                if new_price != price:
                    new_volume = self.calculate_volume_when_price_change(direction, offset, new_price, price, volume)
                
                    print(f'{"taker to maker": >20}{"order type": >15}{"bid_price_1": >15}{"old price": >15}{"old volume": >15}{"new price": >15}{"new volume": >15}')
                    print(f'{"": >20}{self.get_order_type_str(direction, offset): >15}{tick.bid_price_1: >15}{price: >15}{volume: >15}{new_price: >15}{new_volume: >15}')
        else:
            if price < tick.ask_price_1:
                new_price = self.get_maker_order_price(direction)
                if new_price != price:
                    new_volume = self.calculate_volume_when_price_change(direction, offset, new_price, price, volume)
                
                    print(f'{"taker to maker": >20}{"order type": >15}{"ask_price_1": >15}{"old price": >15}{"old volume": >15}{"new price": >15}{"new volume": >15}')
                    print(f'{"": >20}{self.get_order_type_str(direction, offset): >15}{tick.ask_price_1: >15}{price: >15}{volume: >15}{new_price: >15}{new_volume: >15}')
        
        return (new_price, new_volume)
    

    def get_order_type_str(self, direction, offset):
        if direction == Direction.LONG:
            if offset == Offset.OPEN:
                return 'long_open'
            else:
                return 'long_close'
        elif direction == Direction.SHORT:
            if offset == Offset.OPEN:
                return 'short_open'
            else:
                return 'short_close'


    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == Status.SUBMITTING:
            self.summary_count['total'] += 1
        
        elif order.status == Status.NOTTRADED:
            order_type = 'maker'
        
        elif order.status == Status.PARTTRADED:
            pass
        
        elif order.status == Status.ALLTRADED:
            
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1
                
                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)
                
                print(f'{"order type": >15}{"price": >10}{"volume": >10}{"taker": >10}{"maker": >10}{"traded": >10}{"total": >10}{"long pos": >15}{"short pos": >15}{"balance": >22}')
                print(f'{order_type_str: >15}{order.price: >10}{order.volume: >10}{self.summary_count["taker"]: >10}{self.summary_count["maker"]: >10}{self.summary_count["traded"]: >10}{self.summary_count["total"]: >10}{self.long_pos: >15}{self.short_pos: >15}{self.balance: >22}')
            except:
                pass
        
        elif order.status == Status.CANCELLED:
            self.summary_count['cancelled'] += 1
        
        elif order.status == Status.REJECTED:
            self.summary_count['rejected'] += 1
        
        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")


    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, price, volume = -1):
        
        price = round_to(price, self.pricetick)
        
        if volume <= 0:
            self.calculate_trade_volume(direction, offset, price)

            if offset == Offset.OPEN:
                volume = self.long_short_open
            else:
                volume = self.long_short_close

        volume = round_to(volume, self.min_volume)

        if price * volume == 0:
            return False
        
        (price, volume) = self.check_if_maker_order(direction, offset, price, volume)
                
        if direction == Direction.LONG and offset == Offset.OPEN or direction == Direction.SHORT and offset == Offset.CLOSE:
            pos = self.long_pos
        else:
            pos = self.short_pos

        if offset == Offset.OPEN:
            pass

        else:
            self.calculate_max_pos_volume()
            
            if self.max_pos_volume < pos - volume:
                volume = pos - self.max_pos_volume
            
            if pos <= 0:
                return False

            if pos < volume:
                volume = pos
        
        price = round_to(price, self.pricetick)
        volume = round(volume)
        
        if self.stop_main_process == True:
            return False
        
        # get orifin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == Status.SUBMITTING:
                return False

            elif self.order_info_queue[origin_vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == Status.PARTTRADED:
                self.gateway.modify_order_price(self.symbol, origin_vt_orderid.split('.')[-1], price, volume)
                self.set_order_info_queue(origin_vt_orderid, direction, offset, price, volume, Status.SUBMITTING)
                return True

            self.registered_order_info[direction][offset] = ''

        try:
            vt_orderid = self.send_order(direction, offset, price, volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, price, volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, price, volume, Status.SUBMITTING)

            return True
        else:
            return False
        

    """
    "   desc:   Calculate max position volume
    "   input:  price
    "   output: Set max_pos_volume
    """
    def calculate_max_pos_volume(self):
        self.target_pos = self.balance * self.leverage_rate / self.market_price
        self.max_pos_volume = self.target_pos * self.max_pos_percent


    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data

        if account.gateway_name == 'BYBIT':
            self.balance = account.balance


    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data

        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == Direction.LONG:
                self.long_pos = position.volume

                # closed all long pos
                if self.last_long_pos > 0 and self.long_pos == 0:
                    self.write_log(f"多仓全平")

                    print('Restart because all long pos are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_long_pos = self.long_pos

            elif direction == Direction.SHORT:
                self.short_pos = position.volume

                # closed all short pos
                if self.last_short_pos > 0 and self.short_pos == 0:
                    self.write_log(f"空仓全平")
                    
                    print('Restart because all short pos are closed.')
                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_short_pos = self.short_pos

            self.entry_price[direction] = position.price
            self.pos_volume[direction] = position.volume


    def get_rate_limit_status(self):
        status = self.gateway.get_rate_limit_status(self.symbol)
        if status > 0:
            self.rate_limit_status = status


    """
    "   desc:   Write log to file
    "   Log File Path: C:/trading_logs/[day]/[hour]
    """
    # def write_log_to_file(self, info, order_type = '', vt_orderid = '', price = 0, volume = 0):
    #     now = datetime.now()
    #     date_time = now.strftime("%m/%d/%Y, %H:%M:%S, %f")
    #     log_path = "C:\\trading_logs\\" + now.strftime("%Y-%m-%d") + "\\" + now.strftime("%H") + ".txt"
        
    #     os.makedirs(os.path.dirname(log_path), exist_ok=True)
    #     with open(log_path , "a") as f:
    #         f.write('##############\n')
    #         f.write("#  " +date_time + '\n')
    #         f.write("#  " + info + '\n')

    #         if len(order_type) > 0:
    #             f.write("#  order_type = " + order_type + ",  vt_orderid = " + vt_orderid + ",  price = " + str(price) + ",  volume = " + str(volume) + '\n')
    #             f.write("#  long_pos = " + str(self.long_pos) + ",  short_pos = " + str(self.short_pos) + ",  target_pos = " + str(self.target_pos) + ",  max_pos_volume = " + str(self.max_pos_volume) + '\n')
    #             f.write("#  long_short_open = " + str(self.long_short_open) + ",  long_short_close = " + str(self.long_short_close) + '\n')
            
    #         f.write('##############\n\n')