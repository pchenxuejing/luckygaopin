# advanced-strategy
- Version 2.4.1

- Logic
	removed a modify_limit_volume logic
    reservation_spread
    min_tick_count for maximizing profit
    init_pos_num_rate for double initial pos volume, it seems like leverage

    * the main goal is set close volume to long/short pos volume in order to make entry_price closely to long/short open price.


- Best parameter values
    reservation_spread = 12   # based on AS model
    profit_min_tick_count = 2 [1 to 10]
    init_pos_num_rate = 2     [1 to 5]

In a nutshell, this strategy can be called "Daily Trading Strategy" for daily trader. I think it's perfect strategy until now.

Thank you