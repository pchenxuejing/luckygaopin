from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    OrderData,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
# from vnpy.trader.object import PositionData, AccountData
from copy import deepcopy
# import os
import numpy as np
from threading import Thread
from datetime import time
from time import sleep, time

class AdvancedGridStrategy_Bybit_v241(CtaTemplate):
    
    author = "Advanced Grid Strategy v2.4.1"

    leverage_rate = 100                 # 杠杆比例 [10, 20, 50, 100]
    reservation_spread = 12             # reservation spread in as model [12, 14, 16, 18, 20, ..., 36]
    profit_min_tick_count = 5           # tick count from entry_price for maximizing profit [1, 2, ... , 10]
    init_pos_num_rate = 1.2             # double rate of initila position num [1.0, 1.1, 1.2, ..., 2]

    balance = 0                         # 账户余额
    usedMargin = 0                      # the amount of used margin
    long_pos_volume = 0                 # 多头持仓
    short_pos_volume = 0                # 空头持仓

    max_pos_volume = 0                  # maximium positon volume with current balance

    open_init_volume = 0                # initial volume of open order
    close_init_volume = 0               # initial volume of close order
    
    open_volume_increase_percent = 0    # the percent of increasing open order volume. It will be smaller when notice the inventory risk point
    close_volume_increase_percent = 0   # the percent of increasing close order volume
    stop_loss = 0
    
    rate_limit_status = 300             # limit of request count on bybit, [100/min, 300/min, 600/min]

    settle_time = 0                     # 24 hours later time of start trading
    ONE_DAY_IN_MS = 24 * 3600 * 1000    # milliseconds of a day
    
    summary_count = {
        'total': 0,
        'traded': 0,
        'maker': 0,
        'taker': 0,
        'cancelled': 0,
        'rejected': 0
    }

    entry_price = {
        Direction.LONG: 0,
        Direction.SHORT: 0
    }
    
    parameters = ['leverage_rate', 'reservation_spread', 'profit_min_tick_count', 'init_pos_num_rate']

    variables = ['balance', 'max_pos_volume', 'open_init_volume', 'close_init_volume', 'rate_limit_status'] 

    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)

        # market trading min volume
        self.min_volume = contract.min_volume

        self.symbol = self.vt_symbol.split('.')[0]
        
        self.init()


    def init(self):
        self.last_tick = None
        self.last_last_tick = None
        self.market_price = 0

        self.last_long_pos_volume = 0
        self.last_short_pos_volume = 0

        self.main_process_thread = None
        self.restart_strategy_thread = None
        self.clear_order_thread = None

        self.trading_direction = None

        self.registered_order_info = {
            Direction.LONG: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            },
            Direction.SHORT: {
                Offset.OPEN: '',
                Offset.CLOSE: ''
            }
        }

        self.order_info_queue = {}
		
        self.modified_order_info = {
            Offset.OPEN: {
                'changed': False,
                'price': 0
            },
            Offset.CLOSE: {
                'changed': False,
                'price': 0
            }
        }


    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('BYBIT')

        self.write_log("策略初始化")


    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status = 300

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.write_log("策略启动")

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

        # clear unnecessary orders
        self.clear_order_thread = Thread(target = self.clear_orders)
        self.clear_order_thread.setDaemon(True)

        self.clear_order_thread.start()

        # self.write_log_to_file('Strategy is started.')


    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.stop_main_process = True
        
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.write_log("策略停止")

        # self.write_log_to_file('Strategy is stopped.')


    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        self.last_last_tick = self.last_tick
        self.last_tick = tick
        
        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)
    

    def clear_orders(self):
        while True:
            direction = self.trading_direction

            if direction == Direction.LONG:
                opposite_direction = Direction.SHORT
            else:
                opposite_direction = Direction.LONG

            if direction != None:

                try:
                    order_info_queue = deepcopy(self.order_info_queue)
                except:
                    order_info_queue = deepcopy(self.order_info_queue)
                    
                for vt_orderid in order_info_queue:

                    if vt_orderid == self.registered_order_info[direction][Offset.OPEN] or vt_orderid == self.registered_order_info[opposite_direction][Offset.CLOSE]:
                        continue
                    
                    try:
                        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                            sleep(0.5)
                        else:
                            del self.order_info_queue[vt_orderid]
                    except:
                        pass

                sleep(60)


    def restart_strategy(self):
        self.stop_main_process = True

        while self.stop_main_process == True:
            sleep(0.05)

        print("Restarting succeed")
        
        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)

        self.stop_main_process = False
        self.main_process_thread.start()

    
    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    def main_process(self):

        LONG = Direction.LONG
        SHORT = Direction.SHORT
        OPEN = Offset.OPEN
        CLOSE = Offset.CLOSE

        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        print("Balance: ", self.balance)

        # send long_open order and short_open order when strategy start
        self.send_order_when_start()

        # main process deamon
        start = time()
        while self.stop_main_process == False:
            sleep(0.5)

            end = time()
            if (end- start) > 2:
                self.get_rate_limit_status()
                start = end
            
            if self.rate_limit_status <= 10:
                continue

            if self.trading == False or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                print("Tick is invalid.")
                continue
            
            # check long and short open order which is placed when starts
            if self.trading_direction == None:

                for direction in (LONG, SHORT):

                    vt_orderid = self.registered_order_info[direction][OPEN]

                    if vt_orderid == '':
                        continue
                
                    if vt_orderid not in self.order_info_queue:
                        continue

                    # resend rejected order
                    if self.order_info_queue[vt_orderid]['status'] == Status.REJECTED:                           
                        
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)

                        break

                    # cancel order when alltraded
                    if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:

                        if direction == LONG:
                            cancel_direction = SHORT
                        else:
                            cancel_direction = LONG

                        cancel_orderid = self.registered_order_info[cancel_direction][OPEN]

                        self.cancel_order(cancel_orderid)
                        self.registered_order_info[cancel_direction][OPEN] = ''
                        
                        self.trading_direction = direction

                        break
            
            if self.trading_direction != None:
                trading_direction = self.trading_direction

                for direction in (LONG, SHORT):

                    if self.stop_main_process == True:
                        break
                    
                    if direction == LONG:
                        opposite_direction = SHORT
                    else:
                        opposite_direction = LONG

                    if direction == trading_direction:
                        offset = OPEN
                    else:
                        offset = CLOSE

                    if self.registered_order_info[direction][offset] == '':
                        self.send_new_order(direction, offset)
                        continue
                    else:
                        vt_orderid = self.registered_order_info[direction][offset]

                        if vt_orderid not in self.order_info_queue:
                            continue
                        
                        # resend rejected order
                        if self.order_info_queue[vt_orderid]['status'] == Status.REJECTED or self.order_info_queue[vt_orderid]['status'] == Status.CANCELLED:
                            self.registered_order_info[direction][offset] = ''
                            self.send_new_order(direction, offset)

                            continue
                        
                        # send new order when order is filled
                        if self.order_info_queue[vt_orderid]['status'] == Status.ALLTRADED:
                            self.send_new_order(direction, offset)

                            continue
                        
                        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
                            # send order with updated price and volume
                            self.send_order_with_updated_price_and_volume(direction, offset)
        sleep(3)
        
        # cancel all orders when strategy stop
        direction = self.trading_direction
        if direction != None:
            if direction == LONG:
                opposite_direction = SHORT
            else:
                opposite_direction = LONG
            
            open_id = self.registered_order_info[direction][OPEN]
            
            if open_id in self.order_info_queue and (self.order_info_queue[open_id]['status'] == Status.NOTTRADED or self.order_info_queue[open_id]['status'] == Status.PARTTRADED):
                self.cancel_order(open_id)
            
            close_id = self.registered_order_info[opposite_direction][CLOSE]

            if close_id in self.order_info_queue and (self.order_info_queue[close_id]['status'] == Status.NOTTRADED or self.order_info_queue[close_id]['status'] == Status.PARTTRADED):
                self.cancel_order(close_id)
        
        sleep(3)

        self.stop_main_process = False


    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == Offset.NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'
        
            if status == Status.SUBMITTING and self.order_info_queue[vt_orderid]['status'] != Status.SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   desc:   Send long and short open order when trading is started
    "   output: new_order_volume: default => 0
    """
    def send_order_when_start(self):
        
        if self.long_pos_volume != 0:
            self.trading_direction = Direction.LONG
            self.send_new_order(Direction.LONG, Offset.OPEN)
            self.send_new_order(Direction.SHORT, Offset.CLOSE)
        elif self.short_pos_volume != 0:
            self.trading_direction = Direction.SHORT
            self.send_new_order(Direction.SHORT, Offset.OPEN)
            self.send_new_order(Direction.LONG, Offset.CLOSE)
        else:
            self.trading_direction = None
            self.send_new_order(Direction.LONG, Offset.OPEN)
            self.send_new_order(Direction.SHORT, Offset.OPEN)


    """
    "   desc: Send new order
    "   input:  order_type, price
    """
    def send_new_order(self, direction, offset, price = -1, volume = -1):

        if price <= 0:
            price = self.get_order_price_based_on_asmodel(direction, offset)
        
        self.calc_order_init_volume_and_rate(direction, offset, price)
        
        price = round_to(price, self.pricetick)
        
        if volume <= 0:
            if offset == Offset.OPEN:
                volume = self.open_init_volume
                if self.trading_direction == Direction.LONG and self.stop_loss == 0:
                    volume += abs(self.entry_price[Direction.LONG] - price) * np.power(self.init_pos_num_rate, 2) / self.pricetick
                elif self.trading_direction == Direction.SHORT and self.stop_loss == 0:
                    volume += abs(price - self.entry_price[Direction.SHORT]) * np.power(self.init_pos_num_rate, 2) / self.pricetick
            else:
                if direction == Direction.LONG:
                    volume = self.short_pos_volume
                elif direction == Direction.SHORT:
                    volume = self.long_pos_volume

        if price * volume == 0:
            return False
        
        if direction == Direction.LONG and offset == Offset.OPEN or direction == Direction.SHORT and offset == Offset.CLOSE:
            pos = self.long_pos_volume
        else:
            pos = self.short_pos_volume

        if offset == Offset.CLOSE:
            if direction == Direction.LONG:
                if price >= self.entry_price[Direction.SHORT]:
                    price = self.entry_price[Direction.SHORT] - self.profit_min_tick_count * self.pricetick
            elif direction == Direction.SHORT:
                if price <= self.entry_price[Direction.LONG] :
                    price = self.entry_price[Direction.LONG] + self.profit_min_tick_count * self.pricetick

            if pos <= 0:
                return False

            if pos < volume:
                volume = pos
        
        price = round_to(price, self.pricetick)
        volume = round_to(volume, self.min_volume)

        if self.stop_main_process == True:
            return False

        # get origin vt_orderid
        origin_vt_orderid = self.registered_order_info[direction][offset]
        
        if origin_vt_orderid != '':
            if origin_vt_orderid not in self.order_info_queue or self.order_info_queue[origin_vt_orderid]['status'] == Status.SUBMITTING:
                return False
            elif self.order_info_queue[origin_vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[origin_vt_orderid]['status'] == Status.PARTTRADED:
                self.gateway.modify_order_price(self.symbol, origin_vt_orderid.split('.')[-1], price, volume)
                self.set_order_info_queue(origin_vt_orderid, direction, offset, price, volume, Status.SUBMITTING)

                return True
            self.registered_order_info[direction][offset] = ''
        
        try:
            vt_orderid = self.send_order(direction, offset, price, volume)[-1]
        except:
            print("catched exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, price, volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, price, volume, Status.SUBMITTING)
            
            return True
        else:
            return False


    """
    "   desc:   Change order and send it when price changed
    "   input:  order_type, tick
    "   output: bool: True => changed, False => not changed
    """
    def send_order_with_updated_price_and_volume(self, direction, offset):

        # get order price and volume
        vt_orderid = self.registered_order_info[direction][offset]

        old_order_price = self.order_info_queue[vt_orderid]['price']
        old_order_volume = self.order_info_queue[vt_orderid]['volume']

        if old_order_price * old_order_volume == 0:
            return
        
        new_order_price = self.get_order_price_based_on_asmodel(direction, offset)

        entry_price = self.entry_price[self.trading_direction]

        if offset == Offset.CLOSE:
            if direction == Direction.LONG:
                if new_order_price >= entry_price:
                    new_order_price = entry_price - self.profit_min_tick_count * self.pricetick
                elif new_order_price <= old_order_price:
                    return
            elif direction == Direction.SHORT:
                if new_order_price <= entry_price:
                    new_order_price = entry_price + self.profit_min_tick_count * self.pricetick
                elif new_order_price >= old_order_price:
                    return
        else:
            if direction == Direction.LONG:
                if new_order_price <= old_order_price:
                    return
            elif direction == Direction.SHORT:
                if new_order_price >= old_order_price:
                    return

        if round(abs((new_order_price - old_order_price) / self.pricetick)) == 0:
            return
            
        new_order_price = round_to(new_order_price, self.pricetick)
        new_order_volume = self.calc_volume_when_price_changed(direction, offset, new_order_price, old_order_price, old_order_volume)

        if self.order_info_queue[vt_orderid]['status'] == Status.NOTTRADED or self.order_info_queue[vt_orderid]['status'] == Status.PARTTRADED:
            changed = self.send_new_order(direction, offset, new_order_price, new_order_volume)
            if changed == True:
                print(f'{"Change": >15}')
                print(f'{"": >15}{self.get_order_type_str(direction, offset): >15}{old_order_price: >15}{new_order_price: >15}{old_order_volume: >15}{new_order_volume: >15}')


    """
    "   desc:   Get ask/bid price based on AS model
    "   input:  order_type, tick
    "   output: bool, True => changed, False => not change
    """
    def get_order_price_based_on_asmodel(self, direction, offset):
        
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break
            
            if self.stop_main_process == True:
                return

            sleep(0.05)

        tick_gap = round((tick.ask_price_1 - tick.bid_price_1) / self.pricetick)

        if direction == Direction.LONG :
            # optimal bid quote
            # long_open
            if offset == Offset.OPEN:
                if self.long_pos_volume == 0:
                    if tick_gap < 2:
                        price = tick.bid_price_1
                    else:
                        price = tick.bid_price_1 + self.pricetick
                elif self.long_pos_volume > 0:
                    price = tick.bid_price_1 - self.reservation_spread * self.pricetick
            # long_close
            else:
                if tick_gap < 2:
                    price = tick.bid_price_1
                else:
                    price = tick.bid_price_1 + self.pricetick
        else:
            # optimal ask quote
            # short_open
            if offset == Offset.OPEN:
                if self.short_pos_volume == 0:
                    if tick_gap < 3:
                        price = tick.ask_price_1
                    else:
                        price = tick.ask_price_1 - self.pricetick
                elif self.short_pos_volume > 0:
                    price = tick.ask_price_1 + self.reservation_spread * self.pricetick
            # short_close
            else:
                if tick_gap < 3:
                    price = tick.ask_price_1
                else:
                    price = tick.ask_price_1 - self.pricetick

        price = round_to(price, self.pricetick)

        return price


    """
    "   desc:   Calculate volume when price changed
    "   input:  order_type, new_order_price
    "   output: new_order_volume: default => 0
    """
    def calc_volume_when_price_changed(self, direction, offset, new_price, old_price, old_volume):

        if old_price * old_volume == 0:
            return 0

        if self.trading_direction == Direction.LONG:
            multiple = 1
        else:
            multiple = -1

        self.calc_order_init_volume_and_rate(direction, offset, new_price)

        if offset == Offset.OPEN:
            new_volume = old_volume + multiple * self.init_pos_num_rate * ((old_price - new_price) / self.pricetick)
            if new_volume < self.open_init_volume:
                new_volume = self.open_init_volume
            elif self.stop_loss == 1:
                new_volume = self.open_init_volume
        else:
            if direction == Direction.LONG:
                new_volume = self.short_pos_volume
            elif direction == Direction.SHORT:
                new_volume = self.long_pos_volume

        new_volume = round_to(new_volume, self.min_volume)
        
        return new_volume


    """
    "   desc:   Calculate open_init_volume, close_init_volume
    "   input:  market_price
    """
    def calc_order_init_volume_and_rate(self, direction, offset, price):
        
        self.max_pos_volume = self.balance * self.leverage_rate / self.market_price

        # calculate open_init_volume
        self.open_init_volume = max(round_to(self.pricetick * self.max_pos_volume, self.min_volume), self.min_volume)
        
        # calculate close_init_volume
        self.close_init_volume = max(round_to(self.pricetick * self.max_pos_volume, self.min_volume), self.min_volume)
        
        theta = 1
        
        self.open_volume_increase_percent = 1

        # calculate close volume increasing factor - non-linear
        if offset == Offset.OPEN:
            if self.usedMargin / self.balance > 0.5:
                self.stop_loss = 1
                self.open_init_volume = self.min_volume
            else:
                self.stop_loss = 0
        if offset == Offset.CLOSE:
            # maximizing profit and decreasing the size of inventory
            if direction == Direction.LONG:
                if price != 0:
                    theta = self.entry_price[Direction.SHORT] / price
            else:
                if self.entry_price[Direction.LONG] != 0:
                    theta = price / self.entry_price[Direction.LONG]
            self.close_volume_increase_percent = np.exp(theta)


    def get_rate_limit_status(self):
        status = self.gateway.get_rate_limit_status(self.symbol)
        if status > 0:
            self.rate_limit_status = status


    def get_order_type_str(self, direction, offset):
        if direction == Direction.LONG:
            if offset == Offset.OPEN:
                return 'long_open'
            else:
                return 'long_close'
        elif direction == Direction.SHORT:
            if offset == Offset.OPEN:
                return 'short_open'
            else:
                return 'short_close'


    # daily trading
    def time_horizon(self):
        
        now = time()
        time_remain = self.settle_time - now
        
        if time_remain > 0:
            th = time_remain / self.ONE_DAY_IN_MS
        else:
            self.settle_time += self.ONE_DAY_IN_MS
            new_time_remain = self.settle_time - now
            th = new_time_remain / self.ONE_DAY_IN_MS
        
        return th

    """
    "   desc:   Write log to file
    "   Log File Path: C:/trading_logs/[day]/[hour]
    """
    # def write_log_to_file(self, info, order_type = '', vt_orderid = '', price = 0, volume = 0):
    #     now = datetime.now()
    #     date_time = now.strftime("%m/%d/%Y, %H:%M:%S, %f")
    #     log_path = "C:\\trading_logs\\" + now.strftime("%Y-%m-%d") + "\\" + now.strftime("%H") + ".txt"
        
    #     os.makedirs(os.path.dirname(log_path), exist_ok=True)
    #     with open(log_path , "a") as f:
    #         f.write('##############\n')
    #         f.write("#  " +date_time + '\n')
    #         f.write("#  " + info + '\n')

    #         if len(order_type) > 0:
    #             f.write("#  order_type = " + order_type + ",  vt_orderid = " + vt_orderid + ",  price = " + str(price) + ",  volume = " + str(volume) + '\n')
    #             f.write("#  long_pos_volume = " + str(self.long_pos_volume) + ",  short_pos_volume = " + str(self.short_pos_volume) + ",  max_pos_volume = " + str(self.max_pos_volume) + '\n')
    #             f.write("#  open_init_volume = " + str(self.open_init_volume) + ",  close_init_volume = " + str(self.close_init_volume) + '\n')
            
    #         f.write('##############\n\n')

    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data

        if account.gateway_name == 'BYBIT':
            self.balance = account.balance
            self.usedMargin = account.frozen


    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data

        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == Direction.LONG:
                self.long_pos_volume = position.volume

                # closed all long pos
                if self.last_long_pos_volume > 0 and self.long_pos_volume == 0:
                    self.write_log(f"多仓全平")
                    print('Restarting because all long_pos are closed.')

                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_long_pos_volume = self.long_pos_volume
            elif direction == Direction.SHORT:
                self.short_pos_volume = position.volume

                # closed all short pos
                if self.last_short_pos_volume > 0 and self.short_pos_volume == 0:

                    self.write_log(f"空仓全平")
                    print('Restarting because all short_pos are closed.')

                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_short_pos_volume = self.short_pos_volume

            self.entry_price[direction] = position.price


    """
    "   desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == Status.SUBMITTING:
            self.summary_count['total'] += 1
        elif order.status == Status.NOTTRADED:
            order_type = 'maker'
        elif order.status == Status.PARTTRADED:
            pass
        elif order.status == Status.ALLTRADED:
            try:
                self.summary_count['traded'] += 1
                if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                    self.summary_count['maker'] += 1
                else:
                    self.summary_count['taker'] += 1
                
                direction = self.order_info_queue[vt_orderid]['direction']
                offset = self.order_info_queue[vt_orderid]['offset']
                order_type_str = self.get_order_type_str(direction, offset)
                
                print(f'{"type": >15}{"price": >10}{"volume": >10}{"maker": >10}{"traded": >10}{"total": >10}')
                print(f'{order_type_str: >15}{order.price: >10}{order.volume: >10}{self.summary_count["maker"]: >10}{self.summary_count["traded"]: >10}{self.summary_count["total"]: >10}')
            except:
                pass
        elif order.status == Status.CANCELLED:
            self.summary_count['cancelled'] += 1
        elif order.status == Status.REJECTED:
            self.summary_count['rejected'] += 1
        
        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")
