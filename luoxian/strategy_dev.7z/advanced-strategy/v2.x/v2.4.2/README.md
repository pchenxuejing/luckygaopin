# advanced-strategy
- Version 2.4.1

- Logic
	removed a modify_limit_volume logic
    reservation_spread
    min_tick_count for maximizing profit
    init_pos_num_rate for double initial pos volume, it seems like leverage

    * the main goal is set close volume to long/short pos volume in order to make entry_price closely to long/short open price.

    * added a stop-loss order function


- Best parameter values
    max_pos_rate = 0.3
    real_max_pos_rate = 0.6
    reservation_spread = 16 or 24   # based on AS model
    pos_num_double_rate = 1.2 [1 to 10] balance is around 5k, it's 2~2.1, when 10k, it's 2~2.5
    open_init_volume = 2              balance is around 5k, it's 1 or 2, when 10k, it's 2~4
    middle_diff_with_entry_price = 160     [1 to 5]
    max_diff_rate = 2


- when balance is 5k ~ 10k
open_init_volume = 1
reservation_spread = 24
pos_num_double_rate = 1


In a nutshell, this strategy can be called "Daily Trading Strategy" for daily trader. I think it's perfect strategy until now.

Thank you