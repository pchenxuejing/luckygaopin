from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Direction
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread

class GetTickData(CtaTemplate):
    
    author = "GetTickData"

    leverage_rate = 100                 # 杠杆比例 [10, 20, 50, 100]
    balance = 0                         # 账户余额

    parameters = ['leverage_rate']
    variables = ['balance']


    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()
        print("pricetick: ", self.pricetick)

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)
        print("contract: ", contract)

        # market trading min volume
        self.min_volume = contract.min_volume
        print("min_volume: ", self.min_volume)

        self.symbol = self.vt_symbol.split('.')[0]
        print("symbol: ", self.symbol)


    def on_init(self):
        """
        Callback when strategy is inited.
        """
        self.gateway=self.cta_engine.main_engine.get_gateway('BYBIT')


    def on_start(self):
        """
        Callback when strategy is started.
        """
        self.rate_limit_status = 300

        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()


    def on_stop(self):
        """
        Callback when strategy is stopped
        """
        self.stop_main_process = True
        
        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.write_log("策略停止")


    def on_tick(self, tick: TickData):
        """
        Callback of new tick data update.
        """
        print("TickData: ", tick)
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round_to((tick.ask_price_1 + tick.bid_price_1) / 2, self.pricetick)
    

    def on_account(self, event):
        """
        Callback of new trade data update.
        """
        account = event.data

        if account.gateway_name == 'BYBIT':
            self.balance = account.balance


    """
    "   desc:   Callback function for position change event
    """
    def on_position(self, event):
        position = event.data

        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == Direction.LONG:
                self.long_pos_volume = position.volume

                # closed all long pos
                if self.last_long_pos_volume > 0 and self.long_pos_volume == 0:

                    self.write_log(f"多仓全平")
                    print('Restarting because of all long_pos are closed.')

                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()
                self.last_long_pos_volume = self.long_pos_volume
            elif direction == Direction.SHORT:
                self.short_pos_volume = position.volume

                # closed all short pos
                if self.last_short_pos_volume > 0 and self.short_pos_volume == 0:

                    self.write_log(f"空仓全平")
                    print('Restarting because of all short pos are closed.')

                    self.restart_strategy_thread = Thread(target = self.restart_strategy)
                    self.restart_strategy_thread.setDaemon(True)

                    self.restart_strategy_thread.start()

                self.last_short_pos_volume = self.short_pos_volume

            self.entry_price[direction] = position.price
