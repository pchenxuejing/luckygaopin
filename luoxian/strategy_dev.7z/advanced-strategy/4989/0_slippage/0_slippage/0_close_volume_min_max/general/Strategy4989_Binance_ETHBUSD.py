from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(D)", 1: "Earned($)", 2: "D/M/Y(%)", 3: "Trade Amount($)", 4: "Maker Rebate($)", 5: "Available($)", 6: "Max.($)", 7: "Min.($)"}

class Strategy4989_Binance_ETHBUSD(CtaTemplate):

    author = "4989 Strategy"

    # Parameters
    start_balance = 0.0                         # a start balance (funded amount at first time)
    leverage = 50                               # a leverage
    tick_volume = 0.01                          # a volume per tick
    grid_ticksize = 3                           # a big open tick size
    pnl_ticksize = 1                            # a pnl tick size
    maker_fee_percent = -0.014                  # a maker fee, it depends on exchange policy
    min_order_price = 5.5                       # an open order min price, it depends on exchange policy
    max_order_volume = 10                       # a max order volume, it depends on exchange policy
    option = 0                                  # 0: default, 1: close all positions with market price

    # Variables
    balance = 0                                 # an available balance of account
    max_balance = 0                             # a maximium value of balance when trading
    min_balance = 0                             # a minimium value of balance when trading
    rebate = 0                                  # a rebate till now (for a maker)
    max_pos_volume = 0                          # a max pos volume
    open_min_volume = 0                         # an open min volume, will be calculated by min_order_price (it depends on exchange policy)
    maker_fee = 0                               # a maker_fee
    market_price = 0                            # a market price
    close_ticksize = 0                          # a close tick size
    tick_v = 0                                  # a calculated tick volume with 100 leverage according to price up/down 100%

    last_traded_long_open_price = 0             # the latest traded long open price
    last_traded_long_open_volume = 0            # the latest traded long open volume

    last_traded_short_open_price = 0            # the latest traded short open price
    last_traded_short_open_volume = 0           # the latest traded short open volume

    last_traded_long_close_price = 0            # the latest traded long close price
    last_traded_long_close_volume = 0           # the latest traded long close volume

    last_traded_short_close_price = 0           # the latest traded short close price
    last_traded_short_close_volume = 0          # the latest traded short close volume

    long_open_count = 0                         # a long open count
    short_open_count = 0                        # a short open count

    long_close_count = 0                        # a long close count
    short_close_count = 0                       # a short close count

    long_close_volume = 0                       # a long close volume
    short_close_volume = 0                      # a shrot close volume

    long_open_ticksize = 0                      # a long open tick size
    short_open_ticksize = 0                     # a short open tick size

    # un/realizedPNL
    realized_pnl = {}                           # a realized PNL of long/short
    unrealized_pnl = {}                         # an unrealizedPNL of long/short
    traded_open_volume = {}                     # a volume of traded long/short open

    # Statistic data
    start_time = 0                              # a start time when strategy is started
    restart_time = 0                            # a restart time
    last_runtime = 0                            # a last runtime
    total_runtime = 0                           # a total runtime
    total_volume = 0                            # a total traded volume
    total_amount = 0                            # a total traded amount
    current_runtime = 0                         # a current runtime
    current_traded_volume = 0                   # a current traded volume
    current_traded_amount = 0                   # a current traded amount

    pos_volume = {LONG: 0, SHORT: 0}            # a position volume
    last_pos_volume = {LONG: 0, SHORT: 0}       # a last position volume before closing all positoins
    entry_price = {LONG: 0, SHORT: 0}           # an entry price of position
    close_entry_price = {LONG: 0, SHORT: 0}     # an entry price of position when send a close order

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['start_balance', 'leverage', 'tick_volume', 'grid_ticksize', 'pnl_ticksize', 'maker_fee_percent', 'min_order_price', 'max_order_volume', 'option']
    variables = ['open_min_volume', 'close_ticksize', 'tick_v', 'max_pos_volume']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume = contract.min_volume

        # symbol (removed '.ExchangeName')
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.main_process_thread = None
        self.restart_strategy_thread = None

        self.order_info_queue = {}
        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.restart_time = 0
        self.realized_pnl = {LONG: 0, SHORT: 0}
        self.unrealized_pnl = {LONG: 0, SHORT: 0}
        self.last_pos_volume = {LONG: 0, SHORT: 0}
        self.traded_open_volume = {LONG: 0, SHORT: 0}


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('BINANCES')


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.stop_main_process = False

        # main thread
        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.main_process_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round((tick.ask_price_1 + tick.bid_price_1) / 2, 2)

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    "   Desc: restart process
    """
    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        self.read_tradedinfo_from_file()

        if self.start_time == 0:
            self.start_time = time()

        if self.restart_time == 0:
            self.restart_time = time()

        if self.last_runtime == 0:
            self.last_runtime = self.total_runtime

        if self.min_balance == 0:
            self.min_balance = self.balance

        # main process daemon
        print_count = 0
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            if self.balance > self.max_balance:
                self.max_balance = self.balance

            if self.balance < self.min_balance:
                self.min_balance = self.balance

            if print_count == 333 or print_count == 0:
                print(f'==')
                print(f'|{TRADED_INFO_TITLE[0]: >15}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >32}{TRADED_INFO_TITLE[4]: >24}{TRADED_INFO_TITLE[5]: >18}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18} |')
                print(f'--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')
                runtime_days = round(self.total_runtime / 1440, 2)
                profit = round(self.balance - self.start_balance, 2)
                profit_percent = f'{round((profit / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (self.start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0
                total_amount = round(self.total_amount, 2)
                rebate = f'{round(self.rebate, 2)}'
                available = f'{round(self.balance, 2)}'
                max_balance = round(self.max_balance, 2)
                min_balance = round(self.min_balance, 2)
                print(f'|{runtime_days: >14}{profit: >27}{profit_percent: >27}{total_amount: >32}{rebate: >24}{available: >18}{max_balance: >18}{min_balance: >18}  |')
                print(f'==')
                print_count = 1
            print_count += 1

            self.current_runtime = round((time() - self.start_time) / 60)
            self.total_runtime = self.last_runtime + self.current_runtime

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        del self.order_info_queue[open_orderid]
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        del self.order_info_queue[open_orderid]
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        volume = self.order_info_queue[open_orderid]['volume']
                        self.send_new_order(direction, OPEN, price, volume)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            del self.order_info_queue[close_orderid]
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            del self.order_info_queue[close_orderid]
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            volume = self.order_info_queue[close_orderid]['volume']
                            self.send_new_order(direction, CLOSE, price, volume)

        sleep(2)

        # cancel all long/short open/close orders
        for direction in (LONG, SHORT):
            open_orderid = self.registered_order_info[direction][OPEN]
            if open_orderid != '':
                if open_orderid in self.order_info_queue and (self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED):
                    self.cancel_order(open_orderid)

            close_orderid = self.registered_order_info[direction][CLOSE]
            if close_orderid != '':
                if close_orderid in self.order_info_queue and (self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED):
                    self.cancel_order(close_orderid)

        self.write_tradedinfo_to_file()

        sleep(2)

        self.stop_main_process = False


    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1, old_volume = -1):
        if self.stop_main_process == True:
            return

        # calc a max pos, order min volume, position index
        self.calc_maxpos_minvolume_posindex()

        # get an order price and volume
        new_price = self.get_order_price(direction, offset)
        new_volume = self.get_order_volume(direction, offset, new_price)

        new_volume = round_to(new_volume, self.min_volume)
        if round(abs((new_price - old_price) / self.pricetick)) == 0 and new_volume == old_volume:
            return

        # get previous vt_orderid
        previous_vt_orderid = self.registered_order_info[direction][offset]
        if previous_vt_orderid != '':
            if previous_vt_orderid not in self.order_info_queue or self.order_info_queue[previous_vt_orderid]['status'] == SUBMITTING:
                return
            elif self.order_info_queue[previous_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[previous_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(previous_vt_orderid)

            self.registered_order_info[direction][offset] = ''

        if new_price == 0 or new_volume < self.min_volume:
            return

        if offset == OPEN and new_volume < self.open_min_volume:
            return

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return
        else:
            return


    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        self.unrealized_pnl[LONG] = (tick.ask_price_1 - self.entry_price[LONG]) * self.pos_volume[LONG] if self.pos_volume[LONG] > 0 else 0
        self.unrealized_pnl[SHORT] = (self.entry_price[SHORT] - tick.bid_price_1) * self.pos_volume[SHORT] if self.pos_volume[SHORT] > 0 else 0

        if direction == LONG:
            price = tick.bid_price_1
            if offset == OPEN:
                if self.option == 1 or self.pos_volume[LONG] > self.max_pos_volume:
                    return 0
                else:
                    if self.pos_volume[LONG] > 0:
                        if self.last_traded_long_open_price:
                            price = self.last_traded_long_open_price - (self.long_open_count + 1) * self.grid_ticksize * self.pricetick
                        elif self.last_traded_short_close_price:
                            price = self.last_traded_short_close_price - self.grid_ticksize * self.pricetick
            elif offset == CLOSE:
                if self.option == 1 or self.pos_volume[SHORT] > self.max_pos_volume or (self.unrealized_pnl[SHORT] > 0 and self.unrealized_pnl[SHORT] + self.realized_pnl[SHORT] > self.pnl_ticksize * self.pricetick * self.traded_open_volume[SHORT]):
                    pass
                else:
                    if self.last_traded_short_open_price:
                        price = self.last_traded_short_open_price - self.close_ticksize * self.pricetick
                    elif self.last_traded_long_close_price:
                        price = self.last_traded_long_close_price - self.close_ticksize * self.pricetick

            if price > tick.bid_price_1:
                price = tick.bid_price_1
        elif direction == SHORT:
            price = tick.ask_price_1
            if offset == OPEN:
                if self.option == 1 or self.pos_volume[SHORT] > self.max_pos_volume:
                    return 0
                else:
                    if self.pos_volume[SHORT] > 0:
                        if self.last_traded_short_open_price:
                            price = self.last_traded_short_open_price + (self.short_open_count + 1) * self.grid_ticksize * self.pricetick
                        elif self.last_traded_long_close_price:
                            price = self.last_traded_long_close_price + self.grid_ticksize * self.pricetick
            elif offset == CLOSE:
                if self.option == 1 or self.pos_volume[LONG] > self.max_pos_volume or (self.unrealized_pnl[LONG] > 0 and self.unrealized_pnl[LONG] + self.realized_pnl[LONG] > self.pnl_ticksize * self.pricetick * self.traded_open_volume[LONG]):
                    pass
                else:
                    if self.last_traded_long_open_price:
                        price = self.last_traded_long_open_price + self.close_ticksize * self.pricetick
                    elif self.last_traded_short_close_price:
                        price = self.last_traded_short_close_price + self.close_ticksize * self.pricetick

            if price < tick.ask_price_1:
                price = tick.ask_price_1

        price = round_to(price, self.pricetick)

        return price


    """
    "   Desc: Get an order volume
    """
    def get_order_volume(self, direction, offset, price):
        if price == 0:
            return 0

        volume = 0
        if direction == LONG:
            if offset == OPEN:
                if self.pos_volume[LONG] == 0:
                    volume = self.tick_volume
                else:
                    if self.last_traded_long_open_price:
                        volume = self.tick_volume * (self.last_traded_long_open_price - price) / (self.grid_ticksize * self.pricetick)
                    else:
                        volume = self.tick_volume
            elif offset == CLOSE:
                if self.option == 1:
                    volume = self.pos_volume[SHORT]
                else:
                    self.close_entry_price[SHORT] = self.entry_price[SHORT]

                    if self.pos_volume[SHORT] > self.max_pos_volume / self.leverage:
                        volume = 0.1 * self.pos_volume[SHORT]
                    else:
                        pnl = self.realized_pnl[SHORT] + (self.entry_price[SHORT] - price) * self.pos_volume[SHORT]
                        if price < self.entry_price[SHORT] and pnl > self.pnl_ticksize * self.pricetick * self.traded_open_volume[SHORT]:
                            volume = max(self.pos_volume[SHORT] / 2, self.tick_volume)
                        else:
                            self.long_close_volume = min(self.long_close_volume, 3 * self.pos_volume[SHORT])
                            if self.last_traded_short_open_price:
                                volume = self.tick_volume
                                if self.pos_volume[SHORT] > self.long_close_volume and self.pos_volume[SHORT] > self.pos_volume[LONG]:
                                    volume = max(self.last_traded_short_open_volume / 2, 2 * self.tick_volume)
                            elif self.last_traded_long_close_price:
                                volume = self.tick_volume * (self.last_traded_long_close_price - price) / (self.close_ticksize * self.pricetick)
                                if self.pos_volume[SHORT] > 0.5 * self.long_close_volume:
                                    if self.pos_volume[SHORT] > self.pos_volume[LONG]:
                                        volume = 2 * volume
                                    else:
                                        volume = 1.5 * volume

                                    volume = max(min(self.pos_volume[SHORT] / 2, volume), self.tick_volume)

                    if volume >= self.pos_volume[SHORT]:
                        volume = self.pos_volume[SHORT]
        elif direction == SHORT:
            if offset == OPEN:
                if self.pos_volume[SHORT] == 0:
                    volume = self.tick_volume
                else:
                    if self.last_traded_short_open_price:
                        volume = self.tick_volume * (price - self.last_traded_short_open_price) / (self.grid_ticksize * self.pricetick)
                    else:
                        volume = self.tick_volume
            elif offset == CLOSE:
                if self.option == 1:
                    volume = self.pos_volume[LONG]
                else:
                    self.close_entry_price[LONG] = self.entry_price[LONG]

                    if self.pos_volume[LONG] > self.max_pos_volume / self.leverage:
                        volume = 0.1 * self.pos_volume[LONG]
                    else:
                        pnl = self.realized_pnl[LONG] + (price - self.entry_price[LONG]) * self.pos_volume[LONG]
                        if price > self.entry_price[LONG] and pnl > self.pnl_ticksize * self.pricetick * self.traded_open_volume[LONG]:
                            volume = max(self.pos_volume[LONG] / 2, self.tick_volume)
                        else:
                            self.short_close_volume = min(self.short_close_volume, 3 * self.pos_volume[LONG])
                            if self.last_traded_long_open_price:
                                volume = self.tick_volume
                                if self.pos_volume[LONG] > self.short_close_volume and self.pos_volume[LONG] > self.pos_volume[SHORT]:
                                    volume = max(self.last_traded_long_open_volume / 2, 2 * self.tick_volume)
                            elif self.last_traded_short_close_price:
                                volume = self.tick_volume * (price - self.last_traded_short_close_price) / (self.close_ticksize * self.pricetick)
                                if self.pos_volume[LONG] > 0.5 * self.short_close_volume:
                                    if self.pos_volume[LONG] > self.pos_volume[SHORT]:
                                        volume = 2 * volume
                                    else:
                                        volume = 1.5 * volume

                                    volume = max(min(self.pos_volume[LONG] / 2, volume), self.tick_volume)

                    if volume >= self.pos_volume[LONG]:
                        volume = self.pos_volume[LONG]

        if volume > self.max_order_volume:
            volume = self.max_order_volume

        return volume


    """
    "   Desc: Calculate a max_pos_volume, pos index, order min volume
    """
    def calc_maxpos_minvolume_posindex(self):
        self.max_pos_volume = round_to(self.leverage * self.balance / self.market_price, self.min_volume)

        self.open_min_volume = round_to(self.min_order_price / self.market_price, self.min_volume)
        self.tick_volume = max(self.tick_volume, self.open_min_volume)

        tick_n = self.market_price / self.pricetick
        self.tick_v = 100 * self.max_pos_volume / (self.leverage * tick_n)

        self.maker_fee = 2 * self.market_price * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
        self.close_ticksize = round(self.grid_ticksize + self.maker_fee / self.pricetick)

        self.long_open_ticksize = round(0.5 * self.pos_volume[LONG] / self.tick_volume)
        self.short_open_ticksize = round(0.5 * self.pos_volume[SHORT] / self.tick_volume)


    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'BINANCES':
            if account.accountid in self.symbol:
                self.balance = account.balance


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.long_open_count = 0
                    self.short_close_count = 0
                    self.short_close_volume = 0
                    self.realized_pnl[LONG] = 0
                    self.traded_open_volume[LONG] = 0
                    self.last_traded_short_close_price = 0
                    self.last_traded_short_close_volume = 0

                    os.system('cls')
                    print('==')
                    print('| Long position all has been closed. Congrats! Come on, please!')
                    print('==')

                    if (time() - self.restart_time) > 6 * 60 * 60:
                        os.system('cls')
                        print('==')
                        print('| Long position all has been closed, so Restarting now... Congrats! Come on, please!')
                        print('==')
                        self.restart_strategy_thread = Thread(target = self.restart_strategy)
                        self.restart_strategy_thread.setDaemon(True)
                        self.restart_strategy_thread.start()

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.short_open_count = 0
                    self.long_close_count = 0
                    self.long_close_volume = 0
                    self.realized_pnl[SHORT] = 0
                    self.traded_open_volume[SHORT] = 0
                    self.last_traded_long_close_price = 0
                    self.last_traded_long_close_volume = 0

                    os.system('cls')
                    print('==')
                    print('| Short position all has been closed. Congrats! Come on, please!')
                    print('==')

                    if (time() - self.restart_time) > 6 * 60 * 60:
                        os.system('cls')
                        print('==')
                        print('| Short position all has been closed, so Restarting now... Congrats! Come on, please!')
                        print('==')
                        self.restart_strategy_thread = Thread(target = self.restart_strategy)
                        self.restart_strategy_thread.setDaemon(True)
                        self.restart_strategy_thread.start()

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price


    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid        

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.current_traded_volume += order.volume
                self.total_volume += order.volume

                if order.type == OrderType.LIMIT:
                    self.traded_summary['maker'] += 1
                    self.current_traded_amount += order.price * order.volume
                    self.total_amount += order.price * order.volume
                    self.rebate -= order.price * order.volume * self.maker_fee_percent / 100

                    direction = self.order_info_queue[vt_orderid]['direction']
                    offset = self.order_info_queue[vt_orderid]['offset']
                    direction_offset = self.get_order_direction_offset_str(direction, offset)

                    if direction == LONG:
                        if offset == OPEN:
                            self.last_traded_long_open_price = order.price
                            self.last_traded_long_open_volume = order.volume

                            self.last_traded_short_close_price = 0
                            self.last_traded_short_close_volume = 0

                            self.long_open_count += 1
                            self.short_close_count = 0

                            # calc long_pnl
                            self.traded_open_volume[LONG] += order.volume
                            maker_fee = order.price * order.volume * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
                            self.realized_pnl[LONG] -= maker_fee
                        elif offset == CLOSE:
                            if self.pos_volume[SHORT] > 0:
                                self.last_traded_long_close_price = order.price
                                self.last_traded_long_close_volume = order.volume
                                self.long_close_volume += order.volume

                                self.long_close_count += 1

                                # calc short_pnl
                                maker_fee = order.price * order.volume * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
                                profit_amount = (self.close_entry_price[SHORT] - order.price) * order.volume
                                self.realized_pnl[SHORT] += (profit_amount - maker_fee)

                            self.last_traded_short_open_price = 0
                            self.last_traded_short_open_volume = 0
                            self.short_open_count = 0
                    elif direction == SHORT:
                        if offset == OPEN:
                            self.last_traded_short_open_price = order.price
                            self.last_traded_short_open_volume = order.volume

                            self.last_traded_long_close_price = 0
                            self.last_traded_long_close_volume = 0

                            self.short_open_count += 1
                            self.long_close_count = 0

                            # calc short_pnl
                            self.traded_open_volume[SHORT] += order.volume
                            maker_fee = order.price * order.volume * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
                            self.realized_pnl[SHORT] -= maker_fee
                        elif offset == CLOSE:
                            if self.pos_volume[LONG] > 0:
                                self.last_traded_short_close_price = order.price
                                self.last_traded_short_close_volume = order.volume
                                self.short_close_volume += order.volume

                                self.short_close_count += 1

                                # calc long_pnl
                                maker_fee = order.price * order.volume * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0
                                profit_amount = (order.price - self.close_entry_price[LONG]) * order.volume
                                self.realized_pnl[LONG] += (profit_amount - maker_fee)

                            self.last_traded_long_open_price = 0
                            self.last_traded_long_open_volume = 0
                            self.long_open_count = 0

                # current date and time
                now = datetime.now()
                date_time = now.strftime("%Y-%m-%d %H:%M")

                if order.type == OrderType.LIMIT:
                    if direction == LONG:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >10}{direction_offset: >12}{round_to(self.pos_volume[LONG], self.min_volume): >12}/{round_to(self.short_close_volume, self.min_volume): <10}{round_to(self.pos_volume[SHORT], self.min_volume): >12}/{round_to(self.long_close_volume, self.min_volume): <10}{round_to(self.entry_price[LONG], self.pricetick): >12}{round_to(order.price, self.pricetick): >16}{round_to(order.volume, self.min_volume): >12}{round_to(self.realized_pnl[LONG], self.pricetick): >12}/{round_to(self.unrealized_pnl[LONG], self.pricetick): <10}{round_to(self.realized_pnl[SHORT], self.pricetick): >12}/{round_to(self.unrealized_pnl[SHORT], self.pricetick): <10}{self.current_runtime: >8}{round_to(self.current_traded_volume, self.min_volume): >16}/{round_to(self.current_traded_amount, self.pricetick): <18}{date_time: >24}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >10}{direction_offset: >12}{round_to(self.pos_volume[LONG], self.min_volume): >12}/{round_to(self.short_close_volume, self.min_volume): <10}{round_to(self.pos_volume[SHORT], self.min_volume): >12}/{round_to(self.long_close_volume, self.min_volume): <10}{round_to(self.entry_price[SHORT], self.pricetick): >12}{round_to(order.price, self.pricetick): >16}{round_to(order.volume, self.min_volume): >12}{round_to(self.realized_pnl[LONG], self.pricetick): >12}/{round_to(self.unrealized_pnl[LONG], self.pricetick): <10}{round_to(self.realized_pnl[SHORT], self.pricetick): >12}/{round_to(self.unrealized_pnl[SHORT], self.pricetick): <10}{self.current_runtime: >8}{round_to(self.current_traded_volume, self.min_volume): >16}/{round_to(self.current_traded_amount, self.pricetick): <18}{date_time: >24}')
                    elif direction == SHORT:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >10}{direction_offset: >12}{round_to(self.pos_volume[LONG], self.min_volume): >12}/{round_to(self.short_close_volume, self.min_volume): <10}{round_to(self.pos_volume[SHORT], self.min_volume): >12}/{round_to(self.long_close_volume, self.min_volume): <10}{round_to(self.entry_price[SHORT], self.pricetick): >12}{round_to(order.price, self.pricetick): >16}{round_to(order.volume, self.min_volume): >12}{round_to(self.realized_pnl[LONG], self.pricetick): >12}/{round_to(self.unrealized_pnl[LONG], self.pricetick): <10}{round_to(self.realized_pnl[SHORT], self.pricetick): >12}/{round_to(self.unrealized_pnl[SHORT], self.pricetick): <10}{self.current_runtime: >8}{round_to(self.current_traded_volume, self.min_volume): >16}/{round_to(self.current_traded_amount, self.pricetick): <18}{date_time: >24}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >10}{direction_offset: >12}{round_to(self.pos_volume[LONG], self.min_volume): >12}/{round_to(self.short_close_volume, self.min_volume): <10}{round_to(self.pos_volume[SHORT], self.min_volume): >12}/{round_to(self.long_close_volume, self.min_volume): <10}{round_to(self.entry_price[LONG], self.pricetick): >12}{round_to(order.price, self.pricetick): >16}{round_to(order.volume, self.min_volume): >12}{round_to(self.realized_pnl[LONG], self.pricetick): >12}/{round_to(self.unrealized_pnl[LONG], self.pricetick): <10}{round_to(self.realized_pnl[SHORT], self.pricetick): >12}/{round_to(self.unrealized_pnl[SHORT], self.pricetick): <10}{self.current_runtime: >8}{round_to(self.current_traded_volume, self.min_volume): >16}/{round_to(self.current_traded_amount, self.pricetick): <18}{date_time: >24}')
            except:
                pass
        elif order.status == CANCELLED:
            self.traded_summary['cancelled'] += 1
        elif order.status == REJECTED:
            self.traded_summary['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")


    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   Desc: Write a traded info to a log file
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\binance\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{self.total_runtime}, {self.total_volume}, {self.total_amount}, {self.rebate}, {self.max_balance}, {self.min_balance}, {self.realized_pnl[LONG]}, {self.realized_pnl[SHORT]}, {self.traded_open_volume[LONG]}, {self.traded_open_volume[SHORT]}, {self.last_traded_long_open_price}, {self.last_traded_short_open_price}, {self.last_traded_long_close_price}, {self.last_traded_short_close_price}, {self.last_traded_long_open_volume}, {self.last_traded_short_open_volume}, {self.last_traded_long_close_volume}, {self.last_traded_short_close_volume}, {self.long_open_count}, {self.short_open_count}, {self.long_close_count}, {self.short_close_count}, {self.long_close_volume}, {self.short_close_volume}'
            f.write(traded_info)


    """
    "   Desc: Read a traded info from a log file
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\binance\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.total_runtime = 0
                self.total_volume = 0
                self.total_amount = 0
                self.rebate = 0
                self.max_balance = 0
                self.min_balance = 0
                self.realized_pnl[LONG] = 0
                self.realized_pnl[SHORT] = 0
                self.traded_open_volume[LONG] = 0
                self.traded_open_volume[SHORT] = 0
                self.last_traded_long_open_price = 0
                self.last_traded_short_open_price = 0
                self.last_traded_long_close_price = 0
                self.last_traded_short_close_price = 0
                self.last_traded_long_open_volume = 0
                self.last_traded_short_open_volume = 0
                self.last_traded_long_close_volume = 0
                self.last_traded_short_close_volume = 0
                self.long_open_count = 0
                self.short_open_count = 0
                self.long_close_count = 0
                self.short_close_count = 0
                self.long_close_volume = 0
                self.short_close_volume = 0
            else:
                self.total_runtime = float(data.split(', ')[0].strip())
                self.total_volume = float(data.split(', ')[1].strip())
                self.total_amount = float(data.split(', ')[2].strip())
                self.rebate = float(data.split(', ')[3].strip())
                self.max_balance = float(data.split(', ')[4].strip())
                self.min_balance = float(data.split(', ')[5].strip())
                self.realized_pnl[LONG] = float(data.split(', ')[6].strip())
                self.realized_pnl[SHORT] = float(data.split(', ')[7].strip())
                self.traded_open_volume[LONG] = float(data.split(', ')[8].strip())
                self.traded_open_volume[SHORT] = float(data.split(', ')[9].strip())
                self.last_traded_long_open_price = float(data.split(', ')[10].strip())
                self.last_traded_short_open_price = float(data.split(', ')[11].strip())
                self.last_traded_long_close_price = float(data.split(', ')[12].strip())
                self.last_traded_short_close_price = float(data.split(', ')[13].strip())
                self.last_traded_long_open_volume = float(data.split(', ')[14].strip())
                self.last_traded_short_open_volume = float(data.split(', ')[15].strip())
                self.last_traded_long_close_volume = float(data.split(', ')[16].strip())
                self.last_traded_short_close_volume = float(data.split(', ')[17].strip())
                self.long_open_count = int(data.split(', ')[18].strip())
                self.short_open_count = int(data.split(', ')[19].strip())
                self.long_close_count = int(data.split(', ')[20].strip())
                self.short_close_count = int(data.split(', ')[21].strip())
                self.long_close_volume = float(data.split(', ')[22].strip())
                self.short_close_volume = float(data.split(', ')[23].strip())
