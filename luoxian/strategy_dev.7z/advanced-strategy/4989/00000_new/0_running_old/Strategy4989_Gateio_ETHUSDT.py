from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "Earned($)", 2: "D/M/Y(%)", 3: "Trade Amount($)", 4: "Maker Rebate($)", 5: "Available($)", 6: "Max.($)", 7: "Min.($)"}

class Strategy4989_Gateio_ETHUSDT(CtaTemplate):

    author = "4989 Strategy"

    # Parameters
    start_balance = 0.0                         # a start balance (funded amount at first time)
    leverage = 20                               # a leverage
    sub_leverage = 100                          # a sub leverage
    big_pos_rate = 2.0                          # a big pos rate
    open_tick_volume = 1.0                      # an open tick volume
    close_tick_volume = 1.0                     # a close tick volume
    maker_fee_percent = -0.01                   # a maker fee, it depends on exchange policy
    min_order_price = 1                         # an open order min price, it depends on exchange policy
    max_order_volume = 10000                    # a max order volume, it depends on exchange policy
    last_price_option = 0                       # a last price option
    option = 0                                  # 0: default, 1: close all positions with market price

    # Variables
    balance = 0                                 # an available balance of account
    max_open_volume = 0                         # a max open volume
    open_min_volume = 0                         # an open min volume, will be calculated by min_order_price (it depends on exchange policy)
    max_balance = 0                             # a maximium value of balance when trading
    min_balance = 0                             # a minimium value of balance when trading
    rebate = 0                                  # a rebate till now (for a maker)
    max_pos_volume = 0                          # a max pos volume
    base_pos_volume = 0                         # a pos volume with leverage 1
    sub_pos_volume = 0                          # a sub pos volume
    maker_fee = 0                               # a maker_fee
    market_price = 0                            # a market price

    traded_long_open_order_dict = {}            # a dict for traded long_open price and volume
    traded_short_open_order_dict = {}           # a dict for traded short_open price and volume

    long_open_traded_min_max_price = {}         # a min/max price of traded_long_open_order_price_list
    short_open_traded_min_max_price = {}        # a min/max price of traded_short_open_order_price_list

    last_traded_long_open_price = 0             # the latest traded long open price
    last_traded_short_open_price = 0            # the latest traded short open price
    last_traded_long_close_price = 0            # the latest traded long close price
    last_traded_short_close_price = 0           # the latest traded short close price

    # un/realizedPNL
    realized_pnl = {}                           # a realized PNL of long/short
    unrealized_pnl = {}                         # an unrealizedPNL of long/short

    # Statistic data
    start_time = 0                              # a start time when strategy is started
    last_runtime = 0                            # a last runtime
    total_runtime = 0                           # a total runtime
    total_volume = 0                            # a total traded volume
    total_amount = 0                            # a total traded amount
    current_runtime = 0                         # a current runtime
    current_traded_volume = 0                   # a current traded volume
    current_traded_amount = 0                   # a current traded amount

    pos_volume = {LONG: 0, SHORT: 0}            # a position volume
    last_pos_volume = {LONG: 0, SHORT: 0}       # a last position volume before closing all positoins
    entry_price = {LONG: 0, SHORT: 0}           # an entry price of position
    close_entry_price = {LONG: 0, SHORT: 0}     # an entry price of position when send a close order

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['start_balance', 'leverage', 'sub_leverage', 'big_pos_rate', 'open_tick_volume', 'close_tick_volume', 'maker_fee_percent', 'min_order_price', 'max_order_volume', 'last_price_option', 'option']
    variables = ['max_open_volume', 'base_pos_volume', 'sub_pos_volume', 'max_pos_volume', 'open_min_volume']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume = contract.min_volume
        self.quanto_multiplier = contract.quanto_multiplier if contract.quanto_multiplier != 0 else 1

        # symbol (removed '.ExchangeName')
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.main_process_thread = None

        self.order_info_queue = {}
        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.realized_pnl = {LONG: 0, SHORT: 0}
        self.unrealized_pnl = {LONG: 0, SHORT: 0}
        self.last_pos_volume = {LONG: 0, SHORT: 0}

        self.traded_long_open_order_dict = {}
        self.traded_short_open_order_dict = {}

        self.long_open_traded_min_max_price = {'min': 0, 'max': 0}
        self.short_open_traded_min_max_price = {'min': 0, 'max': 0}


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('GATEIOS')


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.stop_main_process = False

        # main thread
        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.main_process_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round((tick.ask_price_1 + tick.bid_price_1) / 2, 2)

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.bid_price_1 == 0 or tick.ask_price_1 == 0: # or tick.last_price == 0
            return False
        else:
            return True


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        self.read_tradedinfo_from_file()
        self.read_dict_from_file(LONG)
        self.read_dict_from_file(SHORT)

        if self.start_time == 0:
            self.start_time = time()

        if self.last_runtime == 0:
            self.last_runtime = self.total_runtime

        if self.min_balance == 0:
            self.min_balance = self.balance

        # main process daemon
        print_count = 0
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            if self.balance > self.max_balance:
                self.max_balance = self.balance

            if self.balance < self.min_balance:
                self.min_balance = self.balance

            if print_count == 333 or print_count == 0:
                print(f'==')
                print(f'|{TRADED_INFO_TITLE[0]: >32}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >32}{TRADED_INFO_TITLE[4]: >24}{TRADED_INFO_TITLE[5]: >18}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18} |')
                print(f'-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------')
                runtime_minutes = round(self.total_runtime)
                runtime_hours = round(self.total_runtime / 60, 1)
                runtime_days = round(self.total_runtime / 1440, 2)
                runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'
                profit = round(self.balance - self.start_balance, 2)
                profit_percent = f'{round((profit / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (self.start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (self.start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0
                total_amount = round(self.total_amount, 2)
                rebate = f'{round(self.rebate, 2)}'
                available = f'{round(self.balance, 2)}'
                max_balance = round(self.max_balance, 2)
                min_balance = round(self.min_balance, 2)
                print(f'|{runtime: >31}{profit: >27}{profit_percent: >27}{total_amount: >32}{rebate: >24}{available: >18}{max_balance: >18}{min_balance: >18}  |')
                print(f'==')
                print_count = 1
            print_count += 1

            self.current_runtime = round((time() - self.start_time) / 60)
            self.total_runtime = self.last_runtime + self.current_runtime

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        del self.order_info_queue[open_orderid]
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        del self.order_info_queue[open_orderid]
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        volume = self.order_info_queue[open_orderid]['volume']
                        self.send_new_order(direction, OPEN, price, volume)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            del self.order_info_queue[close_orderid]
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            del self.order_info_queue[close_orderid]
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            volume = self.order_info_queue[close_orderid]['volume']
                            self.send_new_order(direction, CLOSE, price, volume)

        sleep(2)

        # cancel all long/short open/close orders
        for direction in (LONG, SHORT):
            open_orderid = self.registered_order_info[direction][OPEN]
            if open_orderid != '':
                if open_orderid in self.order_info_queue and (self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED):
                    self.cancel_order(open_orderid)

            close_orderid = self.registered_order_info[direction][CLOSE]
            if close_orderid != '':
                if close_orderid in self.order_info_queue and (self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED):
                    self.cancel_order(close_orderid)

        self.write_dict_to_file(LONG)
        self.write_dict_to_file(SHORT)
        self.write_tradedinfo_to_file()

        sleep(2)

        self.stop_main_process = False


    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1, old_volume = -1):
        if self.stop_main_process == True:
            return

        # calc a max pos, order min volume, position index
        self.calc_maxpos_minvolume_posindex()

        # get an order price and volume
        new_price = self.get_order_price(direction, offset)
        new_volume = self.get_order_volume(direction, offset, new_price)

        new_volume = round_to(new_volume, self.min_volume)
        if round(abs((new_price - old_price) / self.pricetick)) == 0 and new_volume == old_volume:
            return

        # get previous vt_orderid
        previous_vt_orderid = self.registered_order_info[direction][offset]
        if previous_vt_orderid != '':
            if previous_vt_orderid not in self.order_info_queue or self.order_info_queue[previous_vt_orderid]['status'] == SUBMITTING:
                return
            elif self.order_info_queue[previous_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[previous_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(previous_vt_orderid)

            self.registered_order_info[direction][offset] = ''

        if new_price == 0 or new_volume < self.open_min_volume:
            return

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return
        else:
            return


    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        self.unrealized_pnl[LONG] = (tick.ask_price_1 - self.entry_price[LONG]) * self.pos_volume[LONG] if self.pos_volume[LONG] > 0 else 0
        self.unrealized_pnl[SHORT] = (self.entry_price[SHORT] - tick.bid_price_1) * self.pos_volume[SHORT] if self.pos_volume[SHORT] > 0 else 0

        self.long_open_traded_min_max_price['min'] = min(self.traded_long_open_order_dict.keys()) if self.traded_long_open_order_dict else 0
        self.long_open_traded_min_max_price['max'] = max(self.traded_long_open_order_dict.keys()) if self.traded_long_open_order_dict else 0
        self.short_open_traded_min_max_price['max'] = max(self.traded_short_open_order_dict.keys()) if self.traded_short_open_order_dict else 0
        self.short_open_traded_min_max_price['min'] = min(self.traded_short_open_order_dict.keys()) if self.traded_short_open_order_dict else 0

        if direction == LONG:
            price = tick.bid_price_1
            if offset == OPEN:
                if self.option == 1:
                    return 0
                else:
                    if self.pos_volume[LONG] > 0:
                        if self.last_traded_long_open_price:
                            price = self.last_traded_long_open_price - self.pricetick
                        elif self.last_traded_short_close_price:
                            price = self.last_traded_short_close_price - self.pricetick
            elif offset == CLOSE:
                if self.option == 1 or self.unrealized_pnl[SHORT] > 0 and self.realized_pnl[SHORT] + self.unrealized_pnl[SHORT] > self.pricetick * self.pos_volume[SHORT]:
                    pass
                else:
                    if self.last_traded_short_open_price:
                        price = self.last_traded_short_open_price - self.pricetick
                    elif self.last_traded_long_close_price:
                        price = self.last_traded_long_close_price - self.pricetick

            if price > tick.bid_price_1:
                price = tick.bid_price_1

            if self.last_price_option == 0 and tick.last_price and price >= tick.last_price:
                return 0
        elif direction == SHORT:
            price = tick.ask_price_1
            if offset == OPEN:
                if self.option == 1:
                    return 0
                else:
                    if self.pos_volume[SHORT] > 0:
                        if self.last_traded_short_open_price:
                            price = self.last_traded_short_open_price + self.pricetick
                        elif self.last_traded_long_close_price:
                            price = self.last_traded_long_close_price + self.pricetick
            elif offset == CLOSE:
                if self.option == 1 or self.unrealized_pnl[LONG] > 0 and self.realized_pnl[LONG] + self.unrealized_pnl[LONG] > self.pricetick * self.pos_volume[LONG]:
                    pass
                else:
                    if self.last_traded_long_open_price:
                        price = self.last_traded_long_open_price + self.pricetick
                    elif self.last_traded_short_close_price:
                        price = self.last_traded_short_close_price + self.pricetick

            if price < tick.ask_price_1:
                price = tick.ask_price_1

            if self.last_price_option == 0 and tick.last_price and price <= tick.last_price:
                return 0

        price = round_to(price, self.pricetick)

        return price


    """
    "   Desc: Get an order volume
    """
    def get_order_volume(self, direction, offset, price):
        if price == 0:
            return 0

        volume = 0
        if direction == LONG:
            if offset == OPEN:
                if self.long_open_traded_min_max_price['min'] and price >= self.long_open_traded_min_max_price['min']:
                    volume = 0
                else:
                    v_r = max(1, self.pos_volume[LONG] / self.sub_pos_volume)
                    volume = min(self.max_open_volume, self.open_tick_volume * (self.last_traded_long_open_price - price) / (v_r * self.pricetick)) if self.last_traded_long_open_price else self.open_tick_volume
            elif offset == CLOSE:
                if self.option == 1:
                    volume = self.pos_volume[SHORT]
                else:
                    self.close_entry_price[SHORT] = self.entry_price[SHORT]

                    if self.traded_short_open_order_dict:
                        v_r = max(1, self.pos_volume[SHORT] / (2 * self.sub_pos_volume))
                        c_v = self.close_tick_volume * (self.last_traded_long_close_price - price) / (v_r * self.pricetick) if self.last_traded_long_close_price else self.close_tick_volume
                        volume = self.get_close_volume_from_dict(LONG, price) * (1 + (self.pos_volume[SHORT] - self.pos_volume[LONG]) / (self.big_pos_rate * self.sub_pos_volume)) if self.pos_volume[SHORT] > self.pos_volume[LONG] else min(c_v, self.get_close_volume_from_dict(LONG, price), self.max_open_volume)
                        if self.pos_volume[SHORT] < self.pos_volume[LONG] and volume > 0:
                            v_r = 1 + (self.pos_volume[LONG] - self.pos_volume[SHORT]) / self.sub_pos_volume
                            volume = max(volume / v_r, self.close_tick_volume)
                    else:
                        volume = self.close_tick_volume

                    if self.pos_volume[SHORT] > self.pos_volume[LONG] and price < self.entry_price[SHORT]:
                        volume = max(volume, (self.pos_volume[SHORT] - self.pos_volume[LONG]) / 4)

                    pnl = self.realized_pnl[SHORT] + (self.entry_price[SHORT] - price) * self.pos_volume[SHORT]
                    if price < self.entry_price[SHORT] and pnl > self.pricetick * self.pos_volume[SHORT]:
                        volume = max(volume, self.open_tick_volume, (self.pos_volume[SHORT] - self.pos_volume[LONG]) / 2) if self.pos_volume[SHORT] > self.pos_volume[LONG] else max(volume, self.close_tick_volume)

                    if volume >= self.pos_volume[SHORT] / 2:
                        volume = max(self.pos_volume[SHORT] / 2, self.close_tick_volume)
                    elif self.pos_volume[SHORT] > self.max_pos_volume:
                        volume = max(volume, self.max_open_volume)

                    if volume >= self.pos_volume[SHORT]:
                        volume = self.pos_volume[SHORT]
        elif direction == SHORT:
            if offset == OPEN:
                if self.short_open_traded_min_max_price['max'] and price <= self.short_open_traded_min_max_price['max']:
                    volume = 0
                else:
                    v_r = max(1, self.pos_volume[SHORT] / self.sub_pos_volume)
                    volume = min(self.max_open_volume, self.open_tick_volume * (price - self.last_traded_short_open_price) / (v_r * self.pricetick)) if self.last_traded_short_open_price else self.open_tick_volume
            elif offset == CLOSE:
                if self.option == 1:
                    volume = self.pos_volume[LONG]
                else:
                    self.close_entry_price[LONG] = self.entry_price[LONG]

                    if self.traded_long_open_order_dict:
                        v_r = max(1, self.pos_volume[LONG] / (2 * self.sub_pos_volume))
                        c_v = self.close_tick_volume * (price - self.last_traded_short_close_price) / (v_r * self.pricetick) if self.last_traded_short_close_price else self.close_tick_volume
                        volume = self.get_close_volume_from_dict(SHORT, price) * (1 + (self.pos_volume[LONG] - self.pos_volume[SHORT]) / (self.big_pos_rate * self.sub_pos_volume)) if self.pos_volume[LONG] > self.pos_volume[SHORT] else min(c_v, self.get_close_volume_from_dict(SHORT, price), self.max_open_volume)
                        if self.pos_volume[LONG] < self.pos_volume[SHORT] and volume > 0:
                            v_r = 1 + (self.pos_volume[SHORT] - self.pos_volume[LONG]) / self.sub_pos_volume
                            volume = max(volume / v_r, self.close_tick_volume)
                    else:
                        volume = self.close_tick_volume

                    if self.pos_volume[LONG] > self.pos_volume[SHORT] and price > self.entry_price[LONG]:
                        volume = max(volume, (self.pos_volume[LONG] - self.pos_volume[SHORT]) / 4)

                    pnl = self.realized_pnl[LONG] + (price - self.entry_price[LONG]) * self.pos_volume[LONG]
                    if price > self.entry_price[LONG] and pnl > self.pricetick * self.pos_volume[LONG]:
                        volume = max(volume, self.open_tick_volume, (self.pos_volume[LONG] - self.pos_volume[SHORT]) / 2) if self.pos_volume[LONG] > self.pos_volume[SHORT] else max(volume, self.close_tick_volume)

                    if volume >= self.pos_volume[LONG] / 2:
                        volume = max(self.pos_volume[LONG] / 2, self.close_tick_volume)
                    elif self.pos_volume[LONG] > self.max_pos_volume:
                        volume = max(volume, self.max_open_volume)

                    if volume >= self.pos_volume[LONG]:
                        volume = self.pos_volume[LONG]

        if volume > self.max_order_volume:
            volume = self.max_order_volume

        return volume


    """
    "   Desc: Calculate a max_pos_volume, pos index, order min volume
    """
    def calc_maxpos_minvolume_posindex(self):
        self.base_pos_volume = self.balance / (self.market_price * self.quanto_multiplier)
        self.max_pos_volume = 10 * self.base_pos_volume

        self.max_open_volume = self.leverage * self.open_tick_volume
        self.sub_pos_volume = self.sub_leverage * self.max_open_volume
        self.open_min_volume = self.min_order_price * self.min_volume

        self.maker_fee = 2 * self.market_price * self.maker_fee_percent / 100 if self.maker_fee_percent > 0 else 0


    """
    "   Desc: Update traded open order dict when maker order has been processed
    """
    def update_order_dict(self, direction, price, volume, status):
        if float(volume) <= 0.0:
            return

        if status == 0:
            if direction == LONG:
                if price in self.traded_long_open_order_dict:
                    self.traded_long_open_order_dict[price] += volume
                else:
                    self.traded_long_open_order_dict[price] = volume
            elif direction == SHORT:
                if price in self.traded_short_open_order_dict:
                    self.traded_short_open_order_dict[price] += volume
                else:
                    self.traded_short_open_order_dict[price] = volume
        elif status == 1:
            if direction == LONG:
                key_copy_short = tuple(self.traded_short_open_order_dict.keys())
                if key_copy_short:
                    for k in sorted(key_copy_short, reverse=True):
                        if volume > 0:
                            if self.traded_short_open_order_dict[k] == 0.0:
                                del self.traded_short_open_order_dict[k]
                                continue

                            if volume > self.traded_short_open_order_dict[k]:
                                volume -= self.traded_short_open_order_dict[k]
                                del self.traded_short_open_order_dict[k]
                            elif volume == self.traded_short_open_order_dict[k]:
                                del self.traded_short_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_short_open_order_dict[k]
                                if k_v > volume:
                                    self.traded_short_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break
            elif direction == SHORT:
                key_copy_long = tuple(self.traded_long_open_order_dict.keys())
                if key_copy_long:
                    for k in sorted(key_copy_long):
                        if volume > 0:
                            if self.traded_long_open_order_dict[k] == 0.0:
                                del self.traded_long_open_order_dict[k]
                                continue

                            if volume > self.traded_long_open_order_dict[k]:
                                volume -= self.traded_long_open_order_dict[k]
                                del self.traded_long_open_order_dict[k]
                            elif volume == self.traded_long_open_order_dict[k]:
                                del self.traded_long_open_order_dict[k]
                                volume = 0
                                break
                            else:
                                k_v = self.traded_long_open_order_dict[k]
                                if k_v > volume:
                                    self.traded_long_open_order_dict[k] = round_to(k_v - volume, self.min_volume)
                                    volume = 0
                                break


    """
    "   Desc: Get close voluem from an open order dict
    """
    def get_close_volume_from_dict(self, direction, price):
        close_volume = 0
        if direction == LONG:
            key_copy_short = tuple(self.traded_short_open_order_dict.keys())
            if key_copy_short:
                for k in sorted(key_copy_short, reverse=True):
                    if k - self.pricetick >= price:
                        if self.traded_short_open_order_dict[k] == 0.0:
                            del self.traded_short_open_order_dict[k]
                        else:
                            close_volume += self.traded_short_open_order_dict[k]
        elif direction == SHORT:
            key_copy_long = tuple(self.traded_long_open_order_dict.keys())
            if key_copy_long:
                for k in sorted(key_copy_long):
                    if k + self.pricetick <= price:
                        if self.traded_long_open_order_dict[k] == 0.0:
                            del self.traded_long_open_order_dict[k]
                        else:
                            close_volume += self.traded_long_open_order_dict[k]

        return close_volume


    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'GATEIOS':
            self.balance = account.balance


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
                # all long pos are closed
                if self.last_pos_volume[LONG] > 0 and self.pos_volume[LONG] == 0:
                    self.realized_pnl[LONG] = 0
                    self.last_traded_long_open_price = 0
                    self.last_traded_short_close_price = 0
                    self.traded_long_open_order_dict = {}

                    os.system('cls')
                    print('==')
                    print('| Long position all has been closed. Congrats! Come on, please!')
                    print('==')

                self.last_pos_volume[LONG] = self.pos_volume[LONG]
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)
                # all short pos closed
                if self.last_pos_volume[SHORT] > 0 and self.pos_volume[SHORT] == 0:
                    self.realized_pnl[SHORT] = 0
                    self.last_traded_short_open_price = 0
                    self.last_traded_long_close_price = 0
                    self.traded_short_open_order_dict = {}

                    os.system('cls')
                    print('==')
                    print('| Short position all has been closed. Congrats! Come on, please!')
                    print('==')

                self.last_pos_volume[SHORT] = self.pos_volume[SHORT]

            self.entry_price[direction] = position.price


    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                self.current_traded_volume += order.volume * self.quanto_multiplier
                self.total_volume += order.volume * self.quanto_multiplier

                if order.type == OrderType.LIMIT:
                    self.traded_summary['maker'] += 1
                    self.current_traded_amount += order.price * order.volume * self.quanto_multiplier
                    self.total_amount += order.price * order.volume * self.quanto_multiplier
                    self.rebate -= order.price * order.volume * self.quanto_multiplier * self.maker_fee_percent / 100

                    direction = self.order_info_queue[vt_orderid]['direction']
                    offset = self.order_info_queue[vt_orderid]['offset']
                    direction_offset = self.get_order_direction_offset_str(direction, offset)

                    if direction == LONG:
                        if offset == OPEN:
                            self.update_order_dict(LONG, order.price, order.volume, 0)
                            self.last_traded_long_open_price = order.price
                            self.last_traded_short_close_price = 0
                        elif offset == CLOSE:
                            self.update_order_dict(LONG, order.price, order.volume, 1)
                            self.last_traded_long_close_price = order.price
                            self.last_traded_short_open_price = 0

                            if self.pos_volume[SHORT] > 0:
                                # calc short_pnl
                                self.realized_pnl[SHORT] += (self.close_entry_price[SHORT] - order.price) * order.volume
                    elif direction == SHORT:
                        if offset == OPEN:
                            self.update_order_dict(SHORT, order.price, order.volume, 0)
                            self.last_traded_short_open_price = order.price
                            self.last_traded_long_close_price = 0
                        elif offset == CLOSE:
                            self.update_order_dict(SHORT, order.price, order.volume, 1)
                            self.last_traded_short_close_price = order.price
                            self.last_traded_long_open_price = 0

                            if self.pos_volume[LONG] > 0:
                                # calc long_pnl
                                self.realized_pnl[LONG] += (order.price - self.close_entry_price[LONG]) * order.volume

                    self.long_open_traded_min_max_price['min'] = min(self.traded_long_open_order_dict.keys()) if self.traded_long_open_order_dict else 0
                    self.long_open_traded_min_max_price['max'] = max(self.traded_long_open_order_dict.keys()) if self.traded_long_open_order_dict else 0
                    self.short_open_traded_min_max_price['max'] = max(self.traded_short_open_order_dict.keys()) if self.traded_short_open_order_dict else 0
                    self.short_open_traded_min_max_price['min'] = min(self.traded_short_open_order_dict.keys()) if self.traded_short_open_order_dict else 0

                    # current date and time
                    now = datetime.now()
                    date_time = now.strftime("%Y-%m-%d %H:%M")

                    if direction == LONG:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >8}{direction_offset: >10}{round_to(self.pos_volume[LONG], self.min_volume): >12}{round_to(self.pos_volume[SHORT], self.min_volume): >12}{round_to(self.entry_price[LONG], self.pricetick): >16}{round_to(order.price, self.pricetick): >12}{round_to(order.volume, self.min_volume): >10}{round_to(self.realized_pnl[LONG] * self.quanto_multiplier, self.pricetick): >16}/{round_to(self.unrealized_pnl[LONG] * self.quanto_multiplier, self.pricetick): <8}{round_to(self.realized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): >8}/{round_to(self.unrealized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): <8}{self.current_runtime: >8}{round(self.current_traded_volume, 2): >16}{round_to(self.current_traded_amount, self.pricetick): >18}{round_to(self.long_open_traded_min_max_price["min"], self.pricetick): >16}{round_to(self.short_open_traded_min_max_price["max"], self.pricetick): >12}{date_time: >24}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >8}{direction_offset: >10}{round_to(self.pos_volume[LONG], self.min_volume): >12}{round_to(self.pos_volume[SHORT], self.min_volume): >12}{round_to(self.entry_price[SHORT], self.pricetick): >16}{round_to(order.price, self.pricetick): >12}{round_to(order.volume, self.min_volume): >10}{round_to(self.realized_pnl[LONG] * self.quanto_multiplier, self.pricetick): >16}/{round_to(self.unrealized_pnl[LONG] * self.quanto_multiplier, self.pricetick): <8}{round_to(self.realized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): >8}/{round_to(self.unrealized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): <8}{self.current_runtime: >8}{round(self.current_traded_volume, 2): >16}{round_to(self.current_traded_amount, self.pricetick): >18}{round_to(self.long_open_traded_min_max_price["min"], self.pricetick): >16}{round_to(self.short_open_traded_min_max_price["max"], self.pricetick): >12}{date_time: >24}')
                    elif direction == SHORT:
                        if offset == OPEN:
                            print(f'{self.traded_summary["maker"]: >8}{direction_offset: >10}{round_to(self.pos_volume[LONG], self.min_volume): >12}{round_to(self.pos_volume[SHORT], self.min_volume): >12}{round_to(self.entry_price[SHORT], self.pricetick): >16}{round_to(order.price, self.pricetick): >12}{round_to(order.volume, self.min_volume): >10}{round_to(self.realized_pnl[LONG] * self.quanto_multiplier, self.pricetick): >16}/{round_to(self.unrealized_pnl[LONG] * self.quanto_multiplier, self.pricetick): <8}{round_to(self.realized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): >8}/{round_to(self.unrealized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): <8}{self.current_runtime: >8}{round(self.current_traded_volume, 2): >16}{round_to(self.current_traded_amount, self.pricetick): >18}{round_to(self.long_open_traded_min_max_price["min"], self.pricetick): >16}{round_to(self.short_open_traded_min_max_price["max"], self.pricetick): >12}{date_time: >24}')
                        elif offset == CLOSE:
                            print(f'{self.traded_summary["maker"]: >8}{direction_offset: >10}{round_to(self.pos_volume[LONG], self.min_volume): >12}{round_to(self.pos_volume[SHORT], self.min_volume): >12}{round_to(self.entry_price[LONG], self.pricetick): >16}{round_to(order.price, self.pricetick): >12}{round_to(order.volume, self.min_volume): >10}{round_to(self.realized_pnl[LONG] * self.quanto_multiplier, self.pricetick): >16}/{round_to(self.unrealized_pnl[LONG] * self.quanto_multiplier, self.pricetick): <8}{round_to(self.realized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): >8}/{round_to(self.unrealized_pnl[SHORT] * self.quanto_multiplier, self.pricetick): <8}{self.current_runtime: >8}{round(self.current_traded_volume, 2): >16}{round_to(self.current_traded_amount, self.pricetick): >18}{round_to(self.long_open_traded_min_max_price["min"], self.pricetick): >16}{round_to(self.short_open_traded_min_max_price["max"], self.pricetick): >12}{date_time: >24}')
            except:
                pass
        elif order.status == CANCELLED:
            self.traded_summary['cancelled'] += 1
        elif order.status == REJECTED:
            self.traded_summary['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")


    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }


    """
    "   Desc: Write a dict to a txt file
    """
    def write_dict_to_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\long.txt"
        else:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\short.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            if direction == SHORT:
                f.write(str(self.traded_short_open_order_dict).replace("{", "").replace("}", ""))
            else:
                f.write(str(self.traded_long_open_order_dict).replace("{", "").replace("}", ""))


    """
    "   Desc: Read dict from a txt file
    """
    def read_dict_from_file(self, direction):
        if direction == LONG:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\long.txt"
        else:
            log_file = "C:\\Users\\Administrator\\strategies\\gateio\\short.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                return False
            else:
                if direction == SHORT:
                    self.traded_short_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                else:
                    self.traded_long_open_order_dict = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                return True


    """
    "   Desc: Write a traded info to a log file
    """
    def write_tradedinfo_to_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\gateio\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "w") as f:
            traded_info = f'{self.total_runtime}, {self.total_volume}, {self.total_amount}, {self.rebate}, {self.max_balance}, {self.min_balance}, {self.realized_pnl[LONG]}, {self.realized_pnl[SHORT]}, {self.last_traded_long_open_price}, {self.last_traded_short_open_price}, {self.last_traded_long_close_price}, {self.last_traded_short_close_price}'
            f.write(traded_info)


    """
    "   Desc: Read a traded info from a log file
    """
    def read_tradedinfo_from_file(self):
        log_file = "C:\\Users\\Administrator\\strategies\\gateio\\log.txt"

        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        with open(log_file , "r") as f:
            data = f.read().rstrip()
            if data == "":
                self.total_runtime = 0
                self.total_volume = 0
                self.total_amount = 0
                self.rebate = 0
                self.max_balance = 0
                self.min_balance = 0
                self.realized_pnl[LONG] = 0
                self.realized_pnl[SHORT] = 0
                self.last_traded_long_open_price = 0
                self.last_traded_short_open_price = 0
                self.last_traded_long_close_price = 0
                self.last_traded_short_close_price = 0
            else:
                self.total_runtime = float(data.split(', ')[0].strip())
                self.total_volume = float(data.split(', ')[1].strip())
                self.total_amount = float(data.split(', ')[2].strip())
                self.rebate = float(data.split(', ')[3].strip())
                self.max_balance = float(data.split(', ')[4].strip())
                self.min_balance = float(data.split(', ')[5].strip())
                self.realized_pnl[LONG] = float(data.split(', ')[6].strip())
                self.realized_pnl[SHORT] = float(data.split(', ')[7].strip())
                self.last_traded_long_open_price = float(data.split(', ')[8].strip())
                self.last_traded_short_open_price = float(data.split(', ')[9].strip())
                self.last_traded_long_close_price = float(data.split(', ')[10].strip())
                self.last_traded_short_close_price = float(data.split(', ')[11].strip())
