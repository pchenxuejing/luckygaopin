#!/usr/bin/env python
import logging
from pybit.unified_trading import HTTP

from constant import BybitConstant, ExchangeConstant
from utils import Utils
from time import sleep

# logging.basicConfig(filename="pybit.log", level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

class BybitLinearRestApi:
    """
    exchange name
    """
    exchange = ExchangeConstant.BYBIT.value
    category = BybitConstant.LINEAR.value

    """
    Callback when this class is inited.
    """
    def __init__(self, api_key, api_secret, testnet=False):
        self.session = HTTP(
            testnet=testnet,
            api_key=api_key,
            api_secret=api_secret
        )

    """
    " get announcement
    """
    def get_announcement(self, locale, _type, _tag):
        try:
            response = self.session.get_announcement(locale=locale, type=_type, tag=_tag)
            return response
        except Exception as err:
            print(f"Error: get_announcement(): {err}")

    """
    " get account info
    """
    def get_account_info(self):
        try:
            account_info = {}
            response = self.session.get_account_info()
            ret_code = response["retCode"]
            if ret_code == 0:
                account_info["exchange"] = self.exchange
                account_info["margin_mode"] = response["result"]["marginMode"]
                account_info["updated_time"] = response["result"]["updatedTime"]
                account_info["unified_margin_status"] = int(response["result"]["unifiedMarginStatus"])
                account_info["dcp_status"] = response["result"]["dcpStatus"]
                account_info["time_window"] = int(response["result"]["timeWindow"])
                account_info["smp_group"] = int(response["result"]["smpGroup"])
                account_info["is_master"] = bool(response["result"]["isMasterTrader"])

            return account_info
        except Exception as err:
            print(f"Error: get_account_info(): {err}")

    """
    "   Desc: get api key information
    """
    def get_api_key_information(self):
        try:
            user = {}
            response = self.session.get_api_key_information()
            ret_code = response["retCode"]
            if ret_code == 0:
                user["note"] = response["result"]["note"]
                user["ips"] = []
                for ip in response["result"]["ips"]:
                    user["ips"].append(ip)
                user["deadline_day"] = response["result"]["deadlineDay"]
                user["expired_at"] = response["result"]["expiredAt"]
                user["created_at"] = response["result"]["createdAt"]
                user["unified"] = response["result"]["unified"]
                user["uta"] = int(response["result"]["uta"])
                user["uid"] = int(response["result"]["userID"])
                user["vip_level"] = response["result"]["vipLevel"]
                user["is_master"] = bool(response["result"]["isMaster"])

            return user
        except Exception as err:
            print(f"Error: get_api_key_information(): {err}")

    """
    "   Desc: upgraded account to UTA
    """
    def upgrade_to_uta(self):
        try:
            response = self.session.upgrade_to_unified_trading_account()
            ret_code = response["retCode"]
            if ret_code == 0:
                if response["result"]["unifiedUpdateStatus"] == BybitConstant.UPGRADE_UTA_STATUS_FAIL.value:
                    print(f"upgrade_to_uta is failed, following are error messages")
                    messages = response["result"]["unifiedUpdateMsg"]["msg"]
                    for msg in messages:
                        print(msg)
                elif response["result"]["unifiedUpdateStatus"] == BybitConstant.UPGRADE_UTA_STATUS_PROCESS.value:
                    print(f"The system needs asynchronous verification processing, after 3-5 minutes, check whether the upgrade is successful.")
                    while True:
                        sleep(60 * 5)
                        account_info = self.get_account_info()
                        if account_info["unified_margin_status"] == BybitConstant.UTA_PRO.value:
                            print(f"Upgraded to UTA Pro")
                            break
                elif response["result"]["unifiedUpdateStatus"] == BybitConstant.UPGRADE_UTA_STATUS_SUCCESS.value:
                    print(f"Upgraded to UTA Pro")
        except Exception as err:
            print(f"Error: upgrade_to_uta(): {err}")

    """
    "   Desc: query contract for all symbols
    """
    def query_contracts(self):
        try:
            contracts = {}
            response = self.session.get_instruments_info(category=self.category)
            if response:
                ret_code = response["retCode"]
                if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                    for contract_data in response["result"]["list"]:
                        quote_coin = contract_data["quoteCoin"]
                        contract_type = contract_data["contractType"]
                        if quote_coin == BybitConstant.QUOTE_USDT.value and contract_type == BybitConstant.PERPETUAL.value:
                            contract = {}

                            contract["exchange"] = self.exchange
                            contract["symbol"] = contract_data["symbol"]
                            contract["base_coin"] = contract_data["baseCoin"]
                            contract["quote_coin"] = contract_data["quoteCoin"]
                            contract["contract_type"] = contract_data["contractType"]
                            contract["delivery_time"] = int(contract_data["deliveryTime"])
                            contract["pricetick"] = float(contract_data["priceFilter"]["tickSize"])
                            contract["min_price"] = float(contract_data["priceFilter"]["minPrice"])
                            contract["max_price"] = float(contract_data["priceFilter"]["maxPrice"])
                            contract["round_volume"] = float(contract_data["lotSizeFilter"]["qtyStep"])
                            contract["min_order_qty"] = float(contract_data["lotSizeFilter"]["minOrderQty"])
                            contract["max_order_qty"] = float(contract_data["lotSizeFilter"]["maxOrderQty"])
                            contract["min_leverage"] = float(contract_data["leverageFilter"]["minLeverage"])
                            contract["max_leverage"] = float(contract_data["leverageFilter"]["maxLeverage"])
                            contract["leverage_step"] = float(contract_data["leverageFilter"]["leverageStep"])

                            contracts[contract["symbol"]] = contract

            return contracts
        except Exception as err:
            print(f"Error: query_contracts(): {err}")

    """
    "   Desc: query contract for a symbol
    """
    def query_contract(self, symbol):
        try:
            contracts = {}
            response = self.session.get_instruments_info(category=self.category, symbol=symbol)
            if response:
                ret_code = response["retCode"]
                if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                    for contract_data in response["result"]["list"]:
                        contract = {}

                        contract["exchange"] = self.exchange
                        contract["symbol"] = contract_data["symbol"]
                        contract["base_coin"] = contract_data["baseCoin"]
                        contract["quote_coin"] = contract_data["quoteCoin"]
                        contract["contract_type"] = contract_data["contractType"]
                        contract["delivery_time"] = int(contract_data["deliveryTime"])
                        contract["pricetick"] = float(contract_data["priceFilter"]["tickSize"])
                        contract["min_price"] = float(contract_data["priceFilter"]["minPrice"])
                        contract["max_price"] = float(contract_data["priceFilter"]["maxPrice"])
                        contract["round_volume"] = float(contract_data["lotSizeFilter"]["qtyStep"])
                        contract["min_order_qty"] = float(contract_data["lotSizeFilter"]["minOrderQty"])
                        contract["max_order_qty"] = float(contract_data["lotSizeFilter"]["maxOrderQty"])
                        contract["min_leverage"] = float(contract_data["leverageFilter"]["minLeverage"])
                        contract["max_leverage"] = float(contract_data["leverageFilter"]["maxLeverage"])
                        contract["leverage_step"] = float(contract_data["leverageFilter"]["leverageStep"])

                        contracts[contract["symbol"]] = contract

            return contracts
        except Exception as err:
            print(f"Error: query_contract({symbol}): {err}")

    """
    "   Desc: get account's fee rates for all symbols
    """
    def get_fee_rates(self):
        try:
            fee_rates = {}
            response = self.session.get_fee_rates(category=self.category)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for fee_rate_data in response["result"]["list"]:
                    fee_rate = {}

                    fee_rate["exchange"] = self.exchange
                    fee_rate["symbol"] = fee_rate_data["symbol"]
                    fee_rate["taker_fee_rate"] = float(fee_rate_data["takerFeeRate"])
                    fee_rate["maker_fee_rate"] = float(fee_rate_data["makerFeeRate"])

                    fee_rates[fee_rate_data["symbol"]] = fee_rate

            return fee_rates
        except Exception as err:
            print(f"Error: get_fee_rates(): {err}")

    """
    "   Desc: get account's fee rate
    """
    def get_fee_rate(self, symbol):
        try:
            fee_rates = {}
            response = self.session.get_fee_rates(category=self.category, symbol=symbol)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for fee_rate_data in response["result"]["list"]:
                    fee_rate = {}

                    fee_rate["exchange"] = self.exchange
                    fee_rate["symbol"] = fee_rate_data["symbol"]
                    fee_rate["taker_fee_rate"] = float(fee_rate_data["takerFeeRate"])
                    fee_rate["maker_fee_rate"] = float(fee_rate_data["makerFeeRate"])

                    fee_rates[fee_rate_data["symbol"]] = fee_rate

            return fee_rates
        except Exception as err:
            print(f"Error: get_fee_rate({symbol}): {err}")

    """
    "   Desc: get risk limits for all symbols
    """
    def get_risk_limits(self):
        try:
            risk_limits = {}
            response = self.session.get_risk_limit(category=self.category)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for risk_limit_data in response["result"]["list"]:
                    risk_limit = {}

                    risk_limit["symbol"] = risk_limit_data["symbol"]
                    risk_limit["risk_limit_value"] = float(risk_limit_data["riskLimitValue"])
                    risk_limit["maintenance_margin"] = float(risk_limit_data["maintenanceMargin"])
                    risk_limit["initial_margin"] = float(risk_limit_data["initialMargin"])
                    risk_limit["isLowest_risk"] = int(risk_limit_data["isLowestRisk"])
                    risk_limit["max_leverage"] = float(risk_limit_data["maxLeverage"])

                    risk_limits[risk_limit_data["symbol"]] = risk_limit

            return risk_limits
        except Exception as err:
            print(f"Error: get_risk_limits(): {err}")

    """
    "   Desc: get risk limit
    """
    def get_risk_limit(self, symbol):
        try:
            risk_limits = {}
            response = self.session.get_risk_limit(category=self.category, symbol=symbol)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for risk_limit_data in response["result"]["list"]:
                    risk_limit = {}

                    risk_limit["symbol"] = risk_limit_data["symbol"]
                    risk_limit["risk_limit_value"] = float(risk_limit_data["riskLimitValue"])
                    risk_limit["maintenance_margin"] = float(risk_limit_data["maintenanceMargin"])
                    risk_limit["initial_margin"] = float(risk_limit_data["initialMargin"])
                    risk_limit["isLowest_risk"] = int(risk_limit_data["isLowestRisk"])
                    risk_limit["max_leverage"] = float(risk_limit_data["maxLeverage"])

                    risk_limits[risk_limit_data["symbol"]] = risk_limit

            return risk_limits
        except Exception as err:
            print(f"Error: get_risk_limit({symbol}): {err}")

    """
    "   Desc: get wallet balances for all coins
    """
    def get_wallet_balances(self):
        try:
            wallets = {}
            response = self.session.get_wallet_balance(accountType=BybitConstant.UNIFIED.value)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for wallet_data in response["result"]["list"]:
                    for coin in wallet_data["coin"]:
                        wallet = {}

                        wallet["exchange"] = self.exchange
                        wallet["coin"] = coin["coin"]
                        wallet["balance"] = float(coin["walletBalance"]) if coin["walletBalance"] else 0
                        # wallet["bonus"] = float(coin["bonus"])
                        wallet["equity"] = float(coin["equity"]) if coin["equity"] else 0
                        wallet["available_withdraw"] = float(coin["availableToWithdraw"]) if coin["availableToWithdraw"] else 0
                        wallet["available_borrow"] = float(coin["availableToBorrow"]) if coin["availableToBorrow"] else 0
                        wallet["usd_value"] = float(coin["usdValue"]) if coin["usdValue"] else 0
                        wallet["unreal_pnl"] = float(coin["unrealisedPnl"]) if coin["unrealisedPnl"] else 0
                        wallet["cum_real_pnl"] = float(coin["cumRealisedPnl"]) if coin["cumRealisedPnl"] else 0

                        wallets[coin["coin"]] = wallet

            return wallets
        except Exception as err:
            print(f"Error: get_wallet_balances(): {err}")

    """
    "   Desc: get wallet balance
    """
    def get_wallet_balance(self, coin):
        try:
            wallets = {}
            response = self.session.get_wallet_balance(accountType=BybitConstant.UNIFIED.value, coin=coin)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for wallet_data in response["result"]["list"]:
                    for coin in wallet_data["coin"]:
                        wallet = {}

                        wallet["exchange"] = self.exchange
                        wallet["coin"] = coin["coin"]
                        wallet["balance"] = float(coin["walletBalance"]) if coin["walletBalance"] else 0
                        # wallet["bonus"] = float(coin["bonus"])
                        wallet["equity"] = float(coin["equity"]) if coin["equity"] else 0
                        wallet["available_withdraw"] = float(coin["availableToWithdraw"]) if coin["availableToWithdraw"] else 0
                        wallet["available_borrow"] = float(coin["availableToBorrow"]) if coin["availableToBorrow"] else 0
                        wallet["usd_value"] = float(coin["usdValue"]) if coin["usdValue"] else 0
                        wallet["unreal_pnl"] = float(coin["unrealisedPnl"]) if coin["unrealisedPnl"] else 0
                        wallet["cum_real_pnl"] = float(coin["cumRealisedPnl"]) if coin["cumRealisedPnl"] else 0

                        wallets[coin["coin"]] = wallet

            return wallets
        except Exception as err:
            print(f"Error: get_wallet_balance({coin}): {err}")

    """
    "   Desc: switch position mode
    """
    def switch_position_mode(self, symbol, mode):
        try:
            response = self.session.switch_position_mode(category=self.category, symbol=symbol, mode=mode)
            ret_code = response["retCode"]
            if ret_code == 0:
                print(f"{symbol}'s position Mode has been set to Hedge Mode.")
                return response["retMsg"]
        except Exception as err:
            print(f"Error: switch_position_mode({symbol}, {mode}): {err}")
            return "Error"

    """
    "   Desc: set leverage for linear
    """
    def set_linear_leverage(self, symbol, buyLeverage, sellLeverage):
        try:
            response = self.session.set_leverage(category=self.category, symbol=symbol, buyLeverage=buyLeverage, sellLeverage=sellLeverage)
            ret_code = response["retCode"]
            if ret_code == 0:
                print(f"Linear account {symbol}'s leverage has been set to {buyLeverage} and {sellLeverage}.")
        except Exception as err:
            print(f"Error: set_linear_leverage({symbol}, {buyLeverage}, {sellLeverage}): {err}")

    """
    "   Desc: query positions
    """
    def query_positions(self, symbol):
        try:
            positions = {}
            response = self.session.get_positions(category=self.category, symbol=symbol)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for position_data in response["result"]["list"]:
                    position = {}

                    position["exchange"] = self.exchange
                    position["position_idx"] = int(position_data["positionIdx"])
                    position["symbol"] = position_data["symbol"]
                    position["side"] = position_data["side"]
                    position["size"] = float(position_data["size"]) if position_data["size"] else 0.0
                    position["avg_price"] = float(position_data["avgPrice"]) if position_data["avgPrice"] else 0.0
                    position["leverage"] = float(position_data["leverage"])
                    position["balance"] = float(position_data["positionBalance"]) if position_data["positionBalance"] else 0.0
                    position["value"] = float(position_data["positionValue"]) if position_data["positionValue"] else 0.0
                    position["liq_price"] = float(position_data["liqPrice"]) if position_data["liqPrice"] else 0.0
                    position["unreal_pnl"] = float(position_data["unrealisedPnl"]) if position_data["unrealisedPnl"] else 0.0
                    position["cum_real_pnl"] = float(position_data["cumRealisedPnl"]) if position_data["cumRealisedPnl"] else 0.0
                    position["risk_limit_value"] = float(position_data["riskLimitValue"]) if position_data["riskLimitValue"] else 0.0
                    position["im"] = float(position_data["positionIM"]) if position_data["positionIM"] else 0.0
                    position["mmm"] = float(position_data["positionMM"]) if position_data["positionMM"] else 0.0

                    if position["symbol"] not in positions.keys():
                        positions[position["symbol"]] = {}

                    positions[position["symbol"]][position["position_idx"]] = position

            return positions
        except Exception as err:
            print(f"Error: query_positions({symbol}): {err}")

    """
    "   Desc: send a maker order
    """
    def send_maker_order(self, symbol, side, price, volume, position_idx, offset):
        if volume <= 0:
            return

        try:
            response = self.session.place_order(
                category=self.category,
                symbol=symbol,
                side=side,
                orderType=BybitConstant.LIMIT.value,
                price=str(price),
                qty=str(volume),
                timeInForce=BybitConstant.POST_ONLY.value,
                positionIdx=position_idx
            )
            if response["retMsg"] == BybitConstant.RETURN_OK_MSG.value:
                return response
        except Exception as err:
            print(f"Error: send_maker_order({symbol}, {side}, {price}, {volume}, {position_idx}, {offset}): {err}")
            return str(err)

    """
    "   Desc: send a taker order
    """
    def send_taker_order(self, symbol, side, volume, position_idx, offset):
        if volume <= 0:
            return

        try:
            response = self.session.place_order(
                category=self.category,
                symbol=symbol,
                side=side,
                orderType=BybitConstant.MARKET.value,
                qty=str(volume),
                positionIdx=position_idx
            )
            if response["retMsg"] == BybitConstant.RETURN_OK_MSG.value:
                return response
        except Exception as err:
            print(f"Error: send_taker_order({symbol}, {side}, {volume}, {offset}): {err}")
            return str(err)

    """
    "   Desc: get maker open orders
    """
    def get_open_orders(self, symbol):
        try:
            open_orders = {}
            response = self.session.get_open_orders(category=self.category, symbol=symbol)
            ret_code = response["retCode"]
            if ret_code == 0 and "list" in response["result"] and len(response["result"]["list"]) > 0:
                for open_order_data in response["result"]["list"]:
                    open_order = {}

                    open_order["exchange"] = self.exchange
                    open_order["order_id"] = open_order_data["orderId"]
                    open_order["symbol"] = open_order_data["symbol"]
                    open_order["price"] = float(open_order_data["price"])
                    open_order["qty"] = float(open_order_data["qty"])
                    open_order["side"] = open_order_data["side"]
                    open_order["position_idx"] = int(open_order_data["positionIdx"])
                    open_order["order_status"] = open_order_data["orderStatus"]
                    open_order["cancel_type"] = open_order_data["cancelType"]
                    open_order["order_type"] = open_order_data["orderType"]
                    open_order["reject_reason"] = open_order_data["rejectReason"]
                    open_order["avg_price"] = float(open_order_data["avgPrice"])
                    open_order["leaves_qty"] = float(open_order_data["leavesQty"])
                    open_order["leaves_value"] = float(open_order_data["leavesValue"])
                    open_order["cum_exec_qty"] = float(open_order_data["cumExecQty"])
                    open_order["cum_exec_value"] = float(open_order_data["cumExecValue"])
                    open_order["time_in_force"] = open_order_data["timeInForce"]
                    open_order["reduce_only"] = bool(open_order_data["reduceOnly"])

                    if open_order_data["side"] not in open_orders.keys():
                        open_orders[open_order_data["side"]] = {}

                    open_orders[open_order_data["side"]][open_order["position_idx"]] = open_order

            return open_orders
        except Exception as err:
            print(f"Error: get_open_orders({symbol}): {err}")

    """
    "   Desc: cancel maker open order
    """
    def cancel_order(self, symbol, order_id):
        try:
            response = self.session.cancel_order(category=self.category, symbol=symbol, orderId=order_id)
        except Exception as err:
            print(f"Error: cancel_order({symbol}, {order_id}): {err}")

    """
    "   Desc: cancel maker open orders by symbol
    """
    def cancel_all_orders_symbol(self, symbol):
        try:
            response = self.session.cancel_all_orders(category=self.category, symbol=symbol)
            ret_msg = response["retMsg"]
            if ret_msg == BybitConstant.RETURN_OK_MSG.value:
                if "list" in response["result"] and len(response["result"]["list"]) > 0:
                    cancelled_orders = response["result"]["list"]
                    print(f"Cancelled all {symbol}'s orders, cancelled order size is {len(cancelled_orders)}.")
                else:
                    print(f"No cancelled all {symbol}'s orders.")
            else:
                print(f"Failed to cancel all {symbol}'s orders.")

            return ret_msg
        except Exception as err:
            print(f"Error: cancel_all_orders_symbol({symbol}): {err}")

    """
    "   Desc: cancel maker open orders by settleCoin
    """
    def cancel_all_orders_settle_coin(self, settle_coin):
        try:
            response = self.session.cancel_all_orders(category=self.category, settleCoin=settle_coin)
            ret_msg = response["retMsg"]
            if ret_msg == BybitConstant.RETURN_OK_MSG.value:
                if "list" in response["result"] and len(response["result"]["list"]) > 0:
                    cancelled_orders = response["result"]["list"]
                    print(f"Cancelled all {settle_coin}'s orders, cancelled order size is {len(cancelled_orders)}.")
                else:
                    print(f"No cancelled all {settle_coin}'s orders.")
            else:
                print(f"Failed to cancel all {settle_coin}'s orders.")

            return ret_msg
        except Exception as err:
            print(f"Error: cancel_all_orders_settle_coin({settle_coin}): {err}")

    """
    "   Desc: close all positions
    """
    def close_all_positions(self, symbol, side, volume, position_idx):
        if volume <= 0:
            return

        try:
            response = self.session.place_order(
                category=self.category,
                symbol=symbol,
                side=side,
                orderType=BybitConstant.MARKET.value,
                qty=str(volume),
                positionIdx=position_idx
            )
        except Exception as err:
            print(f"Error: close_all_positions({symbol}, {side}, {volume}): {err}")
