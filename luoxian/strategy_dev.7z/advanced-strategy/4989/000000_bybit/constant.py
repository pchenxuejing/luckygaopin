"""
General constant string used in strategy.
"""
from enum import Enum

class RestApiConstant(Enum):
    """
    Account Type
    """
    MAKER = "MAKER"
    TAKER = "TAKER"

    """
    Rest API urls
    """
    WEB_HOST = 'http://www.tiptoptrading.cn/tiptoptrading'
    # WEB_HOST = 'http://localhost:5000/tiptoptrading'
    LOGIN_URL = WEB_HOST + '/auth/signin'

    GET_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/query'
    UPDATE_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/update'

    GET_TAKER_ACCOUNTS_URL = WEB_HOST + '/tapi/query'
    UPDATE_TAKER_ACCOUNT_URL = WEB_HOST + '/tapi/update'

    GET_TRADING_OPTION_URL = WEB_HOST + '/option/query?category='

    RUNNING_STATUS_LIST = ["waiting", "running"]
    STOP_STATUS_LIST = ["stopped", "closed"]
    CLOSE_STATUS_LIST = ["closed"]

    """
    WebSokcet
    """
    WEBSOCKET_HOST = "10.40.168.57"
    WEBSOCKET_PORT = 5000
    WEBSOCKET_URL = "ws://10.40.168.57:5000"

    WEBSOCKET_DIRECTION_FROM_TAKER = "FROM_TAKER"
    WEBSOCKET_DIRECTION_FROM_MAKER = "FROM_MAKER"

class ExchangeConstant(Enum):
    """
    Exchange
    """
    BINANCE = "BINANCE"
    BYBIT = "BYBIT"
    GATEIO = "GATEIO"
    BITMEX = "BITMEX"
    OKEX = "OKEX"
    HUOBI = "HUOBI"
    BITFINEX = "BITFINEX"
    COINBASE = "COINBASE"
    DERIBIT = "DERIBIT"
    BITSTAMP = "BITSTAMP"
    BITCOKE = "BITCOKE"
    PHEMEX = "PHEMEX"

class BybitConstant(Enum):

    UTA_PRO = 4
    """
    Quote Currency
    """
    QUOTE_USDT = "USDT"

    """
    Trade Category
    """
    SPOT = "spot"
    LINEAR = "linear"

    """
    Direction of order/trade/position.
    """
    LONG = "Buy"
    SHORT = "Sell"

    POSITION_LONG_IDX = 1
    POSITION_SHORT_IDX = 2

    OFFSET_OPEN = "OPEN"
    OFFSET_CLOSE = "CLOSE"

    """
    Order Status
    """
    SUBMITTING = "Created"
    NOTTRADED = "New"
    PARTTRADED = "PartiallyFilled"
    ALLTRADED = "Filled"
    CANCELLED = "Cancelled"
    REJECTED = "Rejected"

    """
    Order Type
    """
    LIMIT = "Limit"
    MARKET = "Market"
    STOP = "Stop"

    """
    TimeInForce
    """
    GTC = "GTC"
    IOC = "IOC"
    FOK = "FOK"
    POST_ONLY = "PostOnly"

    RETURN_OK_CODE = 0
    RETURN_OK_MSG = "OK"

    """
    Margin Mode
    """
    REGULAR_MARGIN = "REGULAR_MARGIN"
    ISOLATED_MARGIN = "ISOLATED_MARGIN"
    PORTFOLIO_MARGIN = "PORTFOLIO_MARGIN"

    """
    Position Mode
    """
    SINGLE_POSITION_MODE = 0
    BOTH_POSITION_MODE = 3

    """
    Account Type
    """
    UNIFIED = "UNIFIED"

    """
    Contract Type
    """
    PERPETUAL = "LinearPerpetual"

    UPGRADE_UTA_STATUS_FAIL = "FAIL"
    UPGRADE_UTA_STATUS_PROCESS = "PROCESS"
    UPGRADE_UTA_STATUS_SUCCESS = "SUCCESS"

    """
    Interval of bar data
    """
    MINUTE = "1m"
    HOUR = "1h"
    DAILY = "1d"
    WEEKLY = "1w"
    TICK = "tick"

    """
    Error Code
    """
    INSUFFICIENT_CODES = ["110004", "110007", "110012", "110044", "110014", "110044", "110045", "110047", "110052", "110058"]
    REDUCE_ERROR_CODE = "110017"

    """
    Announcement
    """
    LOCALE_EN = "en-US"
    LOCALE_FR = "fr-FR"
    LOCALE_DE = "de-DE"
    LOCALE_JP = "ja-JP"
    LOCALE_RU = "ru-RU"
    LOCALE_ZH_TW = "zh-TW"

    NEW_CRYPTO_TYPE = "new_crypto"
    LATEST_BYBIT_NEWS_TYPE = "latest_bybit_news"
    DELISTINGS_TYPE = "delistings"
    LATEST_ACTIVITIES_TYPE = "latest_activities"
    PRODUCT_UPDATES_TYPE = "product_updates"
    MAINTENANCE_UPDATES_TYPE = "maintenance_updates"
    NEW_FIAT_LISTINGS_TYPE = "new_fiat_listings"
    OTHER_TYPE = "other"

    SPOT_TAG = "Spot"
    DERIATIVES_TAG = "Derivatives"
    SPOT_LISTINGS_TAG = "Spot Listings"
    DELISTINGS_TAG = "Delistings"
    VIP_TAG = "VIP"
    FUTURES_TAG = "Futures"
    BTC_TAG = "BTC"
    ETH_TAG = "ETH"
    TRADING_BOTS_TAG = "Trading Bots"
    USDC_TAG = "USDC"
    LEVERAGED_TOKENS_TAG = "Leveraged Tokens"
    USDT_TAG = "USDT"
    MARGIN_TRADING_TAG = "Margin Trading"
    PARTNERSHIPS_TAG = "Partnerships"
    LAUNCHPAD_TAG = "Launchpad"
    UPGRADES_TAG = "Upgrades"
    BYVOTES_TAG = "ByVotes"
    INSTITUTIONS_TAG = "Institutions"
    OPTIONS_TAG = "Options"
    COPY_TRADING_TAG = "Copy Trading"
    EARN_TAG = "Earn"
    BYBIT_SAVINGS_TAG = "Bybit Savings"
    DUAL_ASSET_TAG = "Dual Asset"
    LIQUIDITY_MINING_TAG = "Liquidity Mining"
    SHARK_FIN_TAG = "Shark Fin"
    LAUNCHPOOL_TAG = "Launchpool"
    NFT_GRABPIC_TAG = "NFT GrabPic"
    BUY_CRYPTO_TAG = "Buy Crypto"
    P2P_TRADING_TAG = "P2P Trading"
    FIAT_DEPOSIT_TAG = "Fiat Deposit"
    CRYPTO_DEPOSIT_TAG = "Crypto Deposit"

    NEW_LISTING_TITLE = "New Listings"
    DELISTING_TITLE = "Delistings"

    NEW_LISTING_TAG = "New Listings"
    DELISTING_TAG = "Delistings"

    NEW_LISTING_KEY = "New Listings"
    DELISTING_KEY = "delistings"
