#!/usr/bin/env python
import logging
from pybit.unified_trading import WebSocket

import os
import os.path
import sys
import subprocess

import json
from typing import Dict
from time import sleep, time
import numpy as np

from utils import Utils
from rest_api import RestApi
from constant import RestApiConstant, ExchangeConstant, BybitConstant
from bybit_linear_rest_api import BybitLinearRestApi

# rest api
user_id = 0
token = ""
api_key = ""
api_secret = ""
maker_account = None
maker_account_id = None

# exchange api
uid = None
api_key_info = {}
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}
risk_limits = {}

maker_fee_rate = 0
taker_fee_rate = 0

# static parameters
long_position_values = {}
long_position_pnls = {}
short_position_values = {}
short_position_pnls = {}

balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_amount = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0

long_pnl = 0.0
short_pnl = 0.0

maker_rebate = 0.0
taker_fee = 0.0

insufficient_close = 0

delisting_symbols = []

traded_long_open_order_dict = {}
traded_short_open_order_dict = {}

long_open_traded_min_max_price = {'min': 0, 'max': 0}
short_open_traded_min_max_price = {'min': 0, 'max': 0}

EXCHANGE = ExchangeConstant.BYBIT.value
CATEGORY = BybitConstant.LINEAR.value
QUOTE_COIN = BybitConstant.QUOTE_USDT.value
ACCOUNT_TYPE = RestApiConstant.MAKER.value
OPPOSITE_SIDE: Dict[str, str] = {"Buy": "Sell", "Sell": "Buy"}
POSITION_IDX_TO_CLOSE_SIDE: Dict[int, str] = {1: "Sell", 2: "Buy"}
POSITION_IDX_TO_MINE_POS_SIDE: Dict[int, str] = {1: "LONG", 2: "SHORT"}
DIRECTION_OFFSET = {"Buy": {1: "LONG_OPEN", 2: "LONG_CLOSE"}, "Sell":{1: "SHORT_CLOSE", 2: "SHORT_OPEN"}}

LONG_SIDE = BybitConstant.LONG.value
SHORT_SIDE = BybitConstant.SHORT.value

LONG_POS = BybitConstant.POSITION_LONG_IDX.value
SHORT_POS = BybitConstant.POSITION_SHORT_IDX.value

OFFSET_OPEN = BybitConstant.OFFSET_OPEN.value
OFFSET_CLOSE = BybitConstant.OFFSET_CLOSE.value

CLS_TIME = 0
CLS_INTERVAL_TIME = 60 * 60

QUERY_CONTRACTS_TIME = 0
QUERY_CONTRACTS_INTERVAL_TIME = 24 * 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 1 * 60

ACCOUNT_STATUS_CHECK_TIME = 0
ACCOUNT_STATUS_CHECK_INTERVAL_TIME = 1 * 60

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "P.Daily Vol($/L)", 2: "D/M/Y P.Pnl(%)", 3: "Total Earned($)", 4: "Total Trade Vol($)", 5: "M/T.Fee($)", 6: "W.Bal($)", 7: "Max.Bal($)", 8: "Min.Bal($)"}

"""
"   Desc: Write a dict to a txt file
"""
def write_dict_to_file(exchange, symbol, side):
    global traded_long_open_order_dict, traded_short_open_order_dict

    log_file = ROOT_PATH + exchange.lower() + "\\traded_dict\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        if side == LONG_SIDE:
            f.write(str(traded_long_open_order_dict[symbol]).replace("{", "").replace("}", ""))
        elif side == SHORT_SIDE:
            f.write(str(traded_short_open_order_dict[symbol]).replace("{", "").replace("}", ""))

"""
"   Desc: Read dict from a txt file
"""
def read_dict_from_file(exchange, symbol, side):
    global traded_long_open_order_dict, traded_short_open_order_dict

    log_file = ROOT_PATH + exchange.lower() + "\\traded_dict\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            if side == LONG_SIDE:
                traded_long_open_order_dict[symbol] = {}
            elif side == SHORT_SIDE:
                traded_short_open_order_dict[symbol] = {}
        else:
            if side == LONG_SIDE:
                try:
                    traded_long_open_order_dict[symbol] = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                except ValueError:
                    print(f'ValueError: {symbol}-{side}')
            elif side == SHORT_SIDE:
                try:
                    traded_short_open_order_dict[symbol] = dict((float(x.strip()), float(y.strip()))
                     for x, y in (element.split(':')
                                  for element in data.split(', ')))
                except ValueError:
                    print(f'ValueError: {symbol}-{side}')

"""
"   Desc: Update traded open order dict when maker order has been traded
"""
def update_order_dict(symbol, side, price, volume, status):
    global traded_long_open_order_dict, traded_short_open_order_dict, contracts

    min_volume = contracts[symbol]["min_order_qty"]
    round_volume = contracts[symbol]["round_volume"]

    if float(volume) <= 0.0:
        return

    if status == 0:
        if side == LONG_SIDE:
            if price in traded_long_open_order_dict[symbol]:
                traded_long_open_order_dict[symbol][price] += Utils.c_round_to(volume, round_volume)
            else:
                traded_long_open_order_dict[symbol][price] = Utils.c_round_to(volume, round_volume)
        elif side == SHORT_SIDE:
            if price in traded_short_open_order_dict[symbol]:
                traded_short_open_order_dict[symbol][price] += Utils.c_round_to(volume, round_volume)
            else:
                traded_short_open_order_dict[symbol][price] = Utils.c_round_to(volume, round_volume)
    elif status == 1:
        if side == LONG_SIDE:
            key_copy_short = tuple(traded_short_open_order_dict[symbol].keys())
            if key_copy_short:
                for k in sorted(key_copy_short, reverse=True):
                    if volume > 0:
                        r_v = Utils.c_round_to(traded_short_open_order_dict[symbol][k], round_volume)
                        if r_v == 0.0:
                            del traded_short_open_order_dict[symbol][k]
                            continue

                        if volume > r_v:
                            volume = Utils.c_round_to(volume - r_v, round_volume)
                            del traded_short_open_order_dict[symbol][k]
                        elif volume == r_v:
                            del traded_short_open_order_dict[symbol][k]
                            volume = 0
                            break
                        else:
                            traded_short_open_order_dict[symbol][k] = Utils.c_round_to(r_v - volume, round_volume)
                            volume = 0
                            break
        elif side == SHORT_SIDE:
            key_copy_long = tuple(traded_long_open_order_dict[symbol].keys())
            if key_copy_long:
                for k in sorted(key_copy_long):
                    if volume > 0:
                        r_v = Utils.c_round_to(traded_long_open_order_dict[symbol][k], round_volume)
                        if r_v == 0.0:
                            del traded_long_open_order_dict[symbol][k]
                            continue

                        if volume > r_v:
                            volume = Utils.c_round_to(volume - r_v, round_volume)
                            del traded_long_open_order_dict[symbol][k]
                        elif volume == r_v:
                            del traded_long_open_order_dict[symbol][k]
                            volume = 0
                            break
                        else:
                            traded_long_open_order_dict[symbol][k] = Utils.c_round_to(r_v - volume, round_volume)
                            volume = 0
                            break

"""
"   Desc: Get close voluem from an open order dict
"""
def get_close_volume_from_dict(symbol, side, price, grid_tick):
    global traded_long_open_order_dict, traded_short_open_order_dict, contracts

    min_volume = contracts[symbol]["min_order_qty"]
    round_volume = contracts[symbol]["round_volume"]

    close_volume = 0
    if side == LONG_SIDE:
        key_copy_short = tuple(traded_short_open_order_dict[symbol].keys())
        if key_copy_short:
            for k in sorted(key_copy_short, reverse=True):
                if k - grid_tick >= price:
                    if traded_short_open_order_dict[symbol][k] == 0.0:
                        del traded_short_open_order_dict[symbol][k]
                    else:
                        close_volume = Utils.c_round_to(traded_short_open_order_dict[symbol][k], round_volume)
                        break
    elif side == SHORT_SIDE:
        key_copy_long = tuple(traded_long_open_order_dict[symbol].keys())
        if key_copy_long:
            for k in sorted(key_copy_long):
                if k + grid_tick <= price:
                    if traded_long_open_order_dict[symbol][k] == 0.0:
                        del traded_long_open_order_dict[symbol][k]
                    else:
                        close_volume = Utils.c_round_to(traded_long_open_order_dict[symbol][k], round_volume)
                        break

    return close_volume

"""
"   Desc: Write a traded info to a log file
"""
def write_tradedinfo_to_file(exchange, user_name):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, long_pnl, short_pnl, maker_rebate, taker_fee, insufficient_close

    log_file = ROOT_PATH + user_name + "\\" + exchange.lower() + "\\log.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{total_amount}, {total_runtime}, {start_balance}, {max_balance}, {min_balance}, {long_pnl}, {short_pnl}, {maker_rebate}, {taker_fee}, {insufficient_close}'
        f.write(traded_info)

"""
"   Desc: Read a traded info from a log file
"""
def read_tradedinfo_from_file(exchange, user_name):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, long_pnl, short_pnl, maker_rebate, taker_fee, insufficient_close

    log_file = ROOT_PATH + user_name + "\\" + exchange.lower() + "\\log.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_amount = 0
            total_runtime = 0
            start_balance = 0
            max_balance = 0
            min_balance = 0
            long_pnl = 0
            short_pnl = 0
            maker_rebate = 0
            taker_fee = 0
            insufficient_close = 0
        else:
            total_amount = float(data.split(', ')[0].strip())
            total_runtime = float(data.split(', ')[1].strip())
            start_balance = float(data.split(', ')[2].strip())
            max_balance = float(data.split(', ')[3].strip())
            min_balance = float(data.split(', ')[4].strip())
            long_pnl = float(data.split(', ')[5].strip())
            short_pnl = float(data.split(', ')[6].strip())
            maker_rebate = float(data.split(', ')[7].strip())
            taker_fee = float(data.split(', ')[8].strip())
            insufficient_close = int(data.split(', ')[9].strip())

####### Rest API Section #######
USER_NAME = str(sys.argv[1:][0])
USER_PWD = str(sys.argv[1:][1])
SYMBOL = str(sys.argv[1:][2])

read_tradedinfo_from_file(EXCHANGE, USER_NAME)

# login
rest_api = RestApi(USER_NAME, USER_PWD, EXCHANGE)
(user_id, token) = rest_api.login()

# get maker account
maker_account = rest_api.get_maker_account(user_id, token, CATEGORY)
if maker_account["account_status"] in RestApiConstant.STOP_STATUS_LIST.value:
    print("There is no running account.")
    while True:
        maker_account = rest_api.get_maker_account(user_id, token, CATEGORY)
        if maker_account["account_status"] in RestApiConstant.RUNNING_STATUS_LIST.value:
            break

        sleep(1)

print("|==================================================================================================|")

api_key = maker_account["api_key"]
api_secret = maker_account["api_secret"]
maker_account_id = maker_account["account_id"]

####### Exchange's Rest API #######
bybit_linear_rest_api = BybitLinearRestApi(api_key, api_secret, False)

if SYMBOL == 'ALL':
    fee_rates = bybit_linear_rest_api.get_fee_rates()
else:
    fee_rates = bybit_linear_rest_api.get_fee_rate(SYMBOL)

wallets = bybit_linear_rest_api.get_wallet_balance(QUOTE_COIN)

balance = wallets[QUOTE_COIN]["balance"]
if balance <= 0:
    print(f"Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}")
    while True:
        wallets = bybit_linear_rest_api.get_wallet_balance(QUOTE_COIN)
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(1)

if start_balance == 0:
    start_balance = balance

if min_balance == 0:
    min_balance = start_balance

if max_balance == 0:
    max_balance = start_balance

# check/upgrade UTA
api_key_info = bybit_linear_rest_api.get_api_key_information()
print(f'| {api_key_info["uid"]: >10}{api_key_info["note"]: >6}{api_key_info["ips"][0]: >20}{api_key_info["deadline_day"]: >6}{api_key_info["expired_at"]: >28}{api_key_info["vip_level"]: >8}{api_key_info["is_master"]: >5}{round(balance, 2): >12}  |')

account_info = bybit_linear_rest_api.get_account_info()
if account_info["unified_margin_status"] != BybitConstant.UTA_PRO.value:
    bybit_linear_rest_api.upgrade_to_uta()

print(f'| {account_info["margin_mode"]: >24}{account_info["unified_margin_status"]: >12}{account_info["dcp_status"]: >12}{account_info["time_window"]: >12}{account_info["smp_group"]: >12}{round(balance, 2): >23}  |')

# get contracts, update positions
if SYMBOL == 'ALL':
    contracts = bybit_linear_rest_api.query_contracts()
else:
    contracts = bybit_linear_rest_api.query_contract(SYMBOL)

if contracts:
    for symbol in list(contracts):
        contract = contracts[symbol]
        if contract["delivery_time"]:
            delisting_symbols.append(symbol)

        positions[symbol] = {}
        _positions = bybit_linear_rest_api.query_positions(symbol)
        if _positions:
            set_leverage_symbol = ""
            for position_value in _positions.values():
                for position in position_value.values():
                    position_idx = position["position_idx"]
                    if position_idx == BybitConstant.SINGLE_POSITION_MODE.value:
                        ret_msg = bybit_linear_rest_api.switch_position_mode(symbol, BybitConstant.BOTH_POSITION_MODE.value)
                        if symbol in contracts.keys():
                            contracts.pop(symbol)
                        continue

                    leverage = position["leverage"]
                    max_leverage = int(contracts[symbol]["max_leverage"])
                    if leverage < max_leverage and symbol != set_leverage_symbol:
                        bybit_linear_rest_api.set_linear_leverage(symbol, str(max_leverage), str(max_leverage))
                        set_leverage_symbol = symbol

                    positions[symbol][position_idx] = position

                    base_coin = contract["base_coin"]
                    if position_idx == LONG_POS:
                        long_position_values[base_coin] = position["value"]
                        long_position_pnls[base_coin] = position["unreal_pnl"]
                    elif position_idx == SHORT_POS:
                        short_position_values[base_coin] = position["value"]
                        short_position_pnls[base_coin] = position["unreal_pnl"]

# init session and websocket
ws = WebSocket(
    testnet=False,
    channel_type=CATEGORY,
)

ws_private = WebSocket(
    testnet=False,
    channel_type="private",
    api_key=api_key,
    api_secret=api_secret,
    trace_logging=False,
)

def handle_orderbook(message):
    global ticks
    if message:
        type_ = message["type"]
        if type_ == "snapshot":
            data = message["data"]
            symbol = data["s"]

            tick = {}

            bids = data["b"]
            tick["exchange"] = EXCHANGE
            tick["symbol"] = symbol

            tick["bid_price_1"] = float(bids[0][0])
            tick["bid_volume_1"] = float(bids[0][1])

            asks = data["a"]
            tick["ask_price_1"] = float(asks[0][0])
            tick["ask_volume_1"] = float(asks[0][1])

            ticks[symbol] = tick

for symbol in list(contracts):
    ws.orderbook_stream(1, symbol, handle_orderbook)

def handle_wallet(message):
    global wallets
    if message:
        for data in message["data"]:
            for coin in data["coin"]:
                wallet = {}

                wallet["exchange"] = EXCHANGE
                wallet["coin"] = coin["coin"]
                wallet["balance"] = float(coin["walletBalance"]) if coin["walletBalance"] else 0
                # wallet["bonus"] = float(coin["bonus"])
                wallet["equity"] = float(coin["equity"]) if coin["equity"] else 0
                wallet["available_withdraw"] = float(coin["availableToWithdraw"]) if coin["availableToWithdraw"] else 0
                wallet["available_borrow"] = float(coin["availableToBorrow"]) if coin["availableToBorrow"] else 0
                wallet["usd_value"] = float(coin["usdValue"]) if coin["usdValue"] else 0
                wallet["unreal_pnl"] = float(coin["unrealisedPnl"]) if coin["unrealisedPnl"] else 0
                wallet["cum_real_pnl"] = float(coin["cumRealisedPnl"]) if coin["cumRealisedPnl"] else 0

                wallets[coin["coin"]] = wallet

ws_private.wallet_stream(handle_wallet)

def handle_position(message):
    global traded_long_open_order_dict, traded_short_open_order_dict, positions, long_position_values, short_position_values, long_position_pnls, short_position_pnls
    if message:
        for position_data in message["data"]:
            position = {}

            position["exchange"] = EXCHANGE
            position["position_idx"] = int(position_data["positionIdx"])
            position["symbol"] = position_data["symbol"]
            position["side"] = position_data["side"]
            position["size"] = float(position_data["size"]) if position_data["size"] else 0.0
            position["avg_price"] = float(position_data["entryPrice"]) if position_data["entryPrice"] else 0.0
            position["leverage"] = float(position_data["leverage"])
            position["balance"] = float(position_data["positionBalance"]) if position_data["positionBalance"] else 0.0
            position["value"] = float(position_data["positionValue"]) if position_data["positionValue"] else 0.0
            position["liq_price"] = float(position_data["liqPrice"]) if position_data["liqPrice"] else 0.0
            position["unreal_pnl"] = float(position_data["unrealisedPnl"]) if position_data["unrealisedPnl"] else 0.0
            position["cum_real_pnl"] = float(position_data["cumRealisedPnl"]) if position_data["cumRealisedPnl"] else 0.0
            position["risk_limit_value"] = float(position_data["riskLimitValue"]) if position_data["riskLimitValue"] else 0.0
            position["im"] = float(position_data["positionIM"]) if position_data["positionIM"] else 0.0
            position["mmm"] = float(position_data["positionMM"]) if position_data["positionMM"] else 0.0

            symbol = position["symbol"]
            if symbol in contracts.keys():
                position_idx = position["position_idx"]
                base_coin = contracts[symbol]["base_coin"]

                if symbol not in positions.keys():
                    positions[symbol] = {}

                positions[symbol][position_idx] = position

                if position_idx == LONG_POS:
                    long_position_values[base_coin] = position["value"]
                    long_position_pnls[base_coin] = position["unreal_pnl"]
                elif position_idx == SHORT_POS:
                    short_position_values[base_coin] = position["value"]
                    short_position_pnls[base_coin] = position["unreal_pnl"]

                if position["size"] == 0:
                    if position_idx == LONG_POS:
                        traded_long_open_order_dict[symbol] = {}
                    elif position_idx == SHORT_POS:
                        traded_short_open_order_dict[symbol] = {}

ws_private.position_stream(handle_position)

def handle_order(message):
    if message:
        global traded_long_open_order_dict, traded_short_open_order_dict, total_amount, traded_count, current_traded_amount, long_pnl, short_pnl, maker_rebate, taker_fee
        for order_data in message["data"]:
            symbol = order_data["symbol"]
            if symbol in contracts.keys():
                order_id = order_data["orderId"]
                side = order_data["side"]
                price = float(order_data["price"])
                volume = float(order_data["qty"])
                order_type = order_data["orderType"]
                status = order_data["orderStatus"]
                position_idx = int(order_data["positionIdx"])
                filled_price = float(order_data["avgPrice"]) if order_data["avgPrice"] else 0.0

                pricetick = contracts[symbol]["pricetick"]
                min_volume = contracts[symbol]["min_order_qty"]
                round_volume = contracts[symbol]["round_volume"]
                base_coin = contracts[symbol]["base_coin"]
                maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
                taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]

                l_position_size = positions[symbol][LONG_POS]["size"]
                s_position_size = positions[symbol][SHORT_POS]["size"]

                l_position_pnl = positions[symbol][LONG_POS]["unreal_pnl"]
                s_position_pnl = positions[symbol][SHORT_POS]["unreal_pnl"]

                l_position_avg_price = positions[symbol][LONG_POS]["avg_price"]
                s_position_avg_price = positions[symbol][SHORT_POS]["avg_price"]

                long_open_traded_min_max_price['min'] = min(traded_long_open_order_dict[symbol].keys()) if traded_long_open_order_dict[symbol] else 0
                long_open_traded_min_max_price['max'] = max(traded_long_open_order_dict[symbol].keys()) if traded_long_open_order_dict[symbol] else 0
                short_open_traded_min_max_price['max'] = max(traded_short_open_order_dict[symbol].keys()) if traded_short_open_order_dict[symbol] else 0
                short_open_traded_min_max_price['min'] = min(traded_short_open_order_dict[symbol].keys()) if traded_short_open_order_dict[symbol] else 0

                diff_pricetick_size = "N/A"
                if status == BybitConstant.ALLTRADED.value:
                    traded_count += 1
                    if order_type == BybitConstant.LIMIT.value:
                        maker_rebate -= maker_fee_rate * filled_price * volume
                    elif order_type == BybitConstant.MARKET.value:
                        taker_fee += taker_fee_rate * filled_price * volume

                    if side == LONG_SIDE:
                        if position_idx == LONG_POS:
                            update_order_dict(symbol, LONG_SIDE, Utils.c_round_to(filled_price, pricetick), Utils.c_round_to(volume, round_volume), 0)
                            write_dict_to_file(EXCHANGE, symbol, LONG_SIDE)

                            if order_type == BybitConstant.LIMIT.value:
                                if short_open_traded_min_max_price["min"] and filled_price < short_open_traded_min_max_price["min"]:
                                    open_volume = volume if s_position_size > TAKER_TICK_VOLUME_RATE * l_position_size else max(Utils.c_round_to(TAKER_TICK_VOLUME_RATE * volume, round_volume), min_volume)
                                    bybit_linear_rest_api.send_taker_order(symbol, SHORT_SIDE, open_volume, SHORT_POS, OFFSET_OPEN)
                                elif not short_open_traded_min_max_price["min"]:
                                    open_volume = max(Utils.c_round_to(TAKER_TICK_VOLUME_RATE * volume, round_volume), min_volume)
                                    bybit_linear_rest_api.send_taker_order(symbol, SHORT_SIDE, open_volume, SHORT_POS, OFFSET_OPEN)
                        elif position_idx == SHORT_POS:
                            update_order_dict(symbol, LONG_SIDE, Utils.c_round_to(filled_price, pricetick), Utils.c_round_to(volume, round_volume), 1)
                            write_dict_to_file(EXCHANGE, symbol, SHORT_SIDE)

                            pnl = (positions[symbol][SHORT_POS]["avg_price"] - filled_price) * volume
                            short_pnl += pnl
                            diff_pricetick_size = str(int((positions[symbol][SHORT_POS]["avg_price"] - filled_price) / pricetick))
                    elif side == SHORT_SIDE:
                        if position_idx == LONG_POS:
                            update_order_dict(symbol, SHORT_SIDE, Utils.c_round_to(filled_price, pricetick), Utils.c_round_to(volume, round_volume), 1)
                            write_dict_to_file(EXCHANGE, symbol, LONG_SIDE)

                            pnl = (filled_price - positions[symbol][LONG_POS]["avg_price"]) * volume
                            long_pnl += pnl
                            diff_pricetick_size = str(int((filled_price - positions[symbol][LONG_POS]["avg_price"]) / pricetick))
                        elif position_idx == SHORT_POS:
                            update_order_dict(symbol, SHORT_SIDE, Utils.c_round_to(filled_price, pricetick), Utils.c_round_to(volume, round_volume), 0)
                            write_dict_to_file(EXCHANGE, symbol, SHORT_SIDE)

                            if order_type == BybitConstant.LIMIT.value:
                                if long_open_traded_min_max_price["max"] and filled_price > long_open_traded_min_max_price["max"]:
                                    open_volume = volume if l_position_size > TAKER_TICK_VOLUME_RATE * s_position_size else max(Utils.c_round_to(TAKER_TICK_VOLUME_RATE * volume, round_volume), min_volume)
                                    bybit_linear_rest_api.send_taker_order(symbol, LONG_SIDE, open_volume, LONG_POS, OFFSET_OPEN)
                                elif not long_open_traded_min_max_price["max"]:
                                    open_volume = max(Utils.c_round_to(TAKER_TICK_VOLUME_RATE * volume, round_volume), min_volume)
                                    bybit_linear_rest_api.send_taker_order(symbol, LONG_SIDE, open_volume, LONG_POS, OFFSET_OPEN)

                    traded_volume = filled_price * abs(volume)
                    total_amount += traded_volume
                    current_traded_amount += traded_volume

                    title = f'{base_coin}'
                    UID = f'UID.{api_key_info["uid"]}'
                    date_time = Utils.get_current_time()
                    direction_offset = DIRECTION_OFFSET[side][position_idx]

                    print(f'{traded_count: >8}{UID: >16}{order_type: >12}{title: >12}{direction_offset: >16}{Utils.c_round_to(l_position_size, round_volume): >14} / {Utils.c_round_to(s_position_size, round_volume): <14}{Utils.c_round_to(l_position_pnl, pricetick): >12} / {Utils.c_round_to(s_position_pnl, pricetick): <12}{Utils.c_round_to(l_position_avg_price, pricetick): >12} / {Utils.c_round_to(s_position_avg_price, pricetick): <12}{diff_pricetick_size: >6}{Utils.c_round_to(filled_price, pricetick): >14}{Utils.c_round_to(volume, round_volume): >12}{round(current_traded_amount, 2): >18}{int(current_runtime): >8}{date_time: >24}')

ws_private.order_stream(handle_order)

print("|==================================================================================================|")

rest_api.update_account_status(maker_account_id, token, ACCOUNT_TYPE, "running", CATEGORY)

PROFIT_TICKSIZE = int(sys.argv[1:][3])
ERROR_SLEEP_TIME_SECONDS = int(sys.argv[1:][4])
TAKER_TICK_VOLUME_RATE = int(sys.argv[1:][5])

CLS_TIME = time()
TRADED_INFO_TIME = time()
QUERY_CONTRACTS_TIME = time()
ACCOUNT_STATUS_CHECK_TIME = time()

start_time = time()
last_runtime = total_runtime

while True:
    for symbol in list(contracts):
        current_runtime = round((time() - start_time) / 60)
        # <!--- check some parameters for market/trade/account
        contract = contracts[symbol]
        if symbol not in ticks.keys():
            continue

        if symbol in delisting_symbols and positions[symbol][LONG_POS]["size"] == 0 and positions[symbol][SHORT_POS]["size"] == 0:
            if symbol in contracts.keys():
                contracts.pop(symbol)

            if symbol in traded_long_open_order_dict.keys():
                traded_long_open_order_dict.pop(symbol)

            if symbol in traded_short_open_order_dict.keys():
                traded_short_open_order_dict.pop(symbol)

            continue

        balance = wallets[QUOTE_COIN]["balance"]
        if balance > max_balance:
            max_balance = balance

        if balance < min_balance:
            min_balance = balance

        round_volume = contract["round_volume"]
        min_volume = contract["min_order_qty"]
        max_volume = contract["max_order_qty"]
        pricetick = contract["pricetick"]

        maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
        taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]

        if symbol not in traded_long_open_order_dict.keys():
            read_dict_from_file(EXCHANGE, symbol, LONG_SIDE)

        if symbol not in traded_short_open_order_dict.keys():
            read_dict_from_file(EXCHANGE, symbol, SHORT_SIDE)
        # --->

        _ask_price_1 = ticks[symbol]["ask_price_1"]

        # <!--- calc tick volume and grid ticksize
        contract_count = len(list(contracts))
        base_pos = balance / (TAKER_TICK_VOLUME_RATE * _ask_price_1)
        tick_volume = max(min_volume, min(base_pos * pricetick / _ask_price_1, (balance / contract_count) / _ask_price_1))
        # --->

        # sending orders
        open_orders = bybit_linear_rest_api.get_open_orders(symbol)
        for new_side in (LONG_SIDE, SHORT_SIDE):
            for new_position_idx in (LONG_POS, SHORT_POS):
                offset = OFFSET_OPEN
                new_price, new_volume = 0, 0

                bid_price_1 = ticks[symbol]["bid_price_1"]
                ask_price_1 = ticks[symbol]["ask_price_1"]

                long_pos_size = positions[symbol][LONG_POS]["size"]
                long_pos_entry_price = positions[symbol][LONG_POS]["avg_price"]

                short_pos_size = positions[symbol][SHORT_POS]["size"]
                short_pos_entry_price = positions[symbol][SHORT_POS]["avg_price"]

                long_open_traded_min_max_price['min'] = min(traded_long_open_order_dict[symbol].keys()) if traded_long_open_order_dict[symbol] else 0
                long_open_traded_min_max_price['max'] = max(traded_long_open_order_dict[symbol].keys()) if traded_long_open_order_dict[symbol] else 0
                short_open_traded_min_max_price['max'] = max(traded_short_open_order_dict[symbol].keys()) if traded_short_open_order_dict[symbol] else 0
                short_open_traded_min_max_price['min'] = min(traded_short_open_order_dict[symbol].keys()) if traded_short_open_order_dict[symbol] else 0

                fee_pricetick = max(Utils.c_round_to(taker_fee_rate * ask_price_1, pricetick), pricetick) if maker_fee_rate <= 0 else max(Utils.c_round_to((maker_fee_rate + taker_fee_rate) * ask_price_1, pricetick), pricetick)
                grid_tick = PROFIT_TICKSIZE * pricetick + fee_pricetick

                if new_side == LONG_SIDE:
                    new_price = Utils.c_round_to(bid_price_1, pricetick)
                    if new_position_idx == LONG_POS:
                        if symbol in delisting_symbols:
                            continue

                        if min_volume * ask_price_1 >= balance / contract_count and long_pos_size == 0:
                            new_volume = 0
                        else:
                            new_volume = tick_volume
                            if long_open_traded_min_max_price['min'] and new_price >= long_open_traded_min_max_price['min'] - grid_tick:
                                new_volume = 0
                    elif new_position_idx == SHORT_POS:
                        if short_pos_size > 0:
                            offset = OFFSET_CLOSE
                            new_volume = min(Utils.c_round_to(get_close_volume_from_dict(symbol, LONG_SIDE, new_price, grid_tick), round_volume), tick_volume, short_pos_size)

                            if symbol in delisting_symbols:
                                bybit_linear_rest_api.close_all_positions(symbol, LONG_SIDE, short_pos_size, SHORT_POS)
                                continue
                elif new_side == SHORT_SIDE:
                    new_price = Utils.c_round_to(ask_price_1, pricetick)
                    if new_position_idx == SHORT_POS:
                        if symbol in delisting_symbols:
                            continue

                        if min_volume * ask_price_1 >= balance / contract_count and short_pos_size == 0:
                            new_volume = 0
                        else:
                            new_volume = tick_volume
                            if short_open_traded_min_max_price['max'] and new_price <= short_open_traded_min_max_price['max'] + grid_tick:
                                new_volume = 0
                    elif new_position_idx == LONG_POS:
                        if long_pos_size > 0:
                            offset = OFFSET_CLOSE
                            new_volume = min(Utils.c_round_to(get_close_volume_from_dict(symbol, SHORT_SIDE, new_price, grid_tick), round_volume), tick_volume, long_pos_size)

                            if symbol in delisting_symbols:
                                bybit_linear_rest_api.close_all_positions(symbol, SHORT_SIDE, long_pos_size, LONG_POS)
                                continue

                new_volume = Utils.c_round_to(min(new_volume, max_volume), round_volume)
                if new_side in open_orders.keys() and open_orders[new_side] and new_position_idx in open_orders[new_side].keys() and open_orders[new_side][new_position_idx]:
                    open_order_id = open_orders[new_side][new_position_idx]["order_id"]
                    open_order_side = open_orders[new_side][new_position_idx]["side"]
                    open_order_price = float(open_orders[new_side][new_position_idx]["price"])
                    open_order_volume = float(open_orders[new_side][new_position_idx]["qty"])
                    if open_order_price == new_price:
                        if new_volume != open_order_volume:
                            bybit_linear_rest_api.cancel_order(symbol, open_order_id)
                    else:
                        bybit_linear_rest_api.cancel_order(symbol, open_order_id)
                else:
                    if new_volume and new_price:
                        response = bybit_linear_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_idx, offset)
                        if response == BybitConstant.RETURN_OK_MSG.value:
                            pass
                        elif "insufficient" in response.lower():
                            _symbol = max(long_position_values, key=long_position_values.get) + QUOTE_COIN
                            long_pos_volume = abs(positions[_symbol][LONG_POS]["size"])
                            long_open_index = int(np.sqrt(2 * long_pos_volume / tick_volume))
                            long_close_volume = min(Utils.c_round_to(tick_volume * long_open_index, round_volume), long_pos_volume)
                            if long_close_volume:
                                print(f"Insufficent Error: So, close {long_close_volume} positions for {_symbol}'s LONG...")
                                bybit_linear_rest_api.close_all_positions(_symbol, SHORT_SIDE, long_close_volume, LONG_POS)

                            _symbol = max(short_position_values, key=short_position_values.get) + QUOTE_COIN
                            short_pos_volume = abs(positions[_symbol][SHORT_POS]["size"])
                            short_open_index = int(np.sqrt(2 * short_pos_volume / tick_volume))
                            short_close_volume = min(Utils.c_round_to(tick_volume * short_open_index, round_volume), short_pos_volume)
                            if short_close_volume:
                                print(f"Insufficent Error: So, close {short_close_volume} positions for {_symbol}'s SHORT...")
                                bybit_linear_rest_api.close_all_positions(_symbol, LONG_SIDE, short_close_volume, SHORT_POS)

                            insufficient_close += 1
                        elif "Reduce-only rule not satisfied" in response:
                            bybit_linear_rest_api.cancel_all_orders(symbol)

    if time() - CLS_TIME > CLS_INTERVAL_TIME:
        os.system('cls')
        CLS_TIME = time()

    if time() - QUERY_CONTRACTS_TIME > QUERY_CONTRACTS_INTERVAL_TIME:
        if SYMBOL == 'ALL':
            _contracts = bybit_linear_rest_api.query_contracts()
        else:
            _contracts = bybit_linear_rest_api.query_contract(SYMBOL)

        if _contracts:
            for symbol in list(_contracts):
                contract = _contracts[symbol]
                if contract["delivery_time"]:
                    if symbol not in delisting_symbols:
                        delisting_symbols.append(symbol)

                if symbol not in positions.keys():
                    positions[symbol] = {}
                    _positions = bybit_linear_rest_api.query_positions(symbol)
                    if _positions:
                        set_leverage_symbol = ""
                        for position_value in _positions.values():
                            for position in position_value.values():
                                position_idx = position["position_idx"]
                                if position_idx == BybitConstant.SINGLE_POSITION_MODE.value:
                                    ret_msg = bybit_linear_rest_api.switch_position_mode(symbol, BybitConstant.BOTH_POSITION_MODE.value)
                                    continue

                                leverage = position["leverage"]
                                max_leverage = int(contracts[symbol]["max_leverage"])
                                if leverage < max_leverage and symbol != set_leverage_symbol:
                                    bybit_linear_rest_api.set_linear_leverage(symbol, str(max_leverage), str(max_leverage))
                                    set_leverage_symbol = symbol

                                positions[symbol][position_idx] = position

                                base_coin = contract["base_coin"]
                                if position_idx == LONG_POS:
                                    long_position_values[base_coin] = position["value"]
                                    long_position_pnls[base_coin] = position["unreal_pnl"]
                                    long_pos_size = positions[symbol][LONG_POS]["size"]
                                    if long_pos_size == 0:
                                        traded_long_open_order_dict[symbol] = {}
                                elif position_idx == SHORT_POS:
                                    short_position_values[base_coin] = position["value"]
                                    short_position_pnls[base_coin] = position["unreal_pnl"]
                                    short_pos_size = positions[symbol][SHORT_POS]["size"]
                                    if short_pos_size == 0:
                                        traded_short_open_order_dict[symbol] = {}

                                if symbol not in contracts.keys():
                                    contracts[symbol] = contract

        QUERY_CONTRACTS_TIME = time()

    if time() - TRADED_INFO_TIME > TRADED_INFO_INTERVAL_TIME:
        response = rest_api.update_account(maker_account_id, token, total_amount, wallets[QUOTE_COIN]["balance"], ACCOUNT_TYPE, CATEGORY)

        print(f"|===========================================================================================|")
        api_key_info_title = f"Current Trading API Key information({USER_NAME})"
        print(f'| {api_key_info_title: >89} |')
        print(f'| {api_key_info["uid"]: >8}{api_key_info["note"]: >8}{api_key_info["ips"][0]: >27}{api_key_info["deadline_day"]: >8}{api_key_info["expired_at"]: >24}{api_key_info["vip_level"]: >8}{api_key_info["is_master"]: >6} |')
        print(f"|==========================================================================|==========================================================================|============================|")
        long_value_title = f'Long Pos Value'
        long_pnl_title = f'Long Unreal.Pnl'
        long_realized_pnl_title = f"Long Real.Pnl"
        print(f"|{long_value_title: >74}|{long_pnl_title: >74}|{long_realized_pnl_title: >27} |")
        str_long_sum_value = f'Sum: {round(sum(long_position_values.values()), 3)}'
        str_long_max_value = f'Max: {round(max(long_position_values.values()), 3)}({max(long_position_values, key=long_position_values.get)})'
        str_long_min_value = f'Min: {round(min(long_position_values.values()), 3)}({min(long_position_values, key=long_position_values.get)})'
        str_long_sum_pnl = f'Sum: {round(sum(long_position_pnls.values()), 3)}'
        str_long_max_pnl = f'Max: {round(max(long_position_pnls.values()), 3)}({max(long_position_pnls, key=long_position_pnls.get)})'
        str_long_min_pnl = f'Min: {round(min(long_position_pnls.values()), 3)}({min(long_position_pnls, key=long_position_pnls.get)})'
        str_long_pnl = f'{round(long_pnl, 3)}'
        print(f'| {str_long_sum_value: <24}{str_long_max_value: <24}{str_long_min_value: <24} | {str_long_sum_pnl: <24}{str_long_max_pnl: <24}{str_long_min_pnl: <24} |{str_long_pnl: >27} |')
        print(f"|--------------------------------------------------------------------------|--------------------------------------------------------------------------|----------------------------|")
        short_value_title = f'Short Pos Value'
        short_pnl_title = f'Short Unreal.Pnl'
        short_realized_pnl_title = f"Short Real.Pnl"
        print(f"|{short_value_title: >74}|{short_pnl_title: >74}|{short_realized_pnl_title: >27} |")
        str_short_sum_value = f'Sum: {round(sum(short_position_values.values()), 3)}'
        str_short_max_value = f'Max: {round(max(short_position_values.values()), 3)}({max(short_position_values, key=short_position_values.get)})'
        str_short_min_value = f'Min: {round(min(short_position_values.values()), 3)}({min(short_position_values, key=short_position_values.get)})'
        str_short_sum_pnl = f'Sum: {round(sum(short_position_pnls.values()), 3)}'
        str_short_max_pnl = f'Max: {round(max(short_position_pnls.values()), 3)}({max(short_position_pnls, key=short_position_pnls.get)})'
        str_short_min_pnl = f'Min: {round(min(short_position_pnls.values()), 3)}({min(short_position_pnls, key=short_position_pnls.get)})'
        str_short_pnl = f'{round(short_pnl, 3)}'
        print(f'| {str_short_sum_value: <24}{str_short_max_value: <24}{str_short_min_value: <24} | {str_short_sum_pnl: <24}{str_short_max_pnl: <24}{str_short_min_pnl: <24} |{str_short_pnl: >27} |')
        print(f"|==========================================================================|==========================================================================|============================|=======================================|")
        print(f'|{TRADED_INFO_TITLE[0]: >26}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >27}{TRADED_INFO_TITLE[4]: >32}{TRADED_INFO_TITLE[5]: >24}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18}{TRADED_INFO_TITLE[8]: >18} |')
        print(f'|           ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|')
        total_runtime = last_runtime + current_runtime
        runtime_minutes = round(total_runtime)
        runtime_hours = round(total_runtime / 60, 1)
        runtime_days = round(total_runtime / 1440, 2)
        runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'

        predict_dailty_trade_amt = round(total_amount / (total_runtime / 1440), 1) if total_runtime > 1 else 0
        predict_daily_trade_leverage = round((total_amount / (total_runtime / 1440)) / balance, 1) if total_runtime > 1 else 0
        predict_dailty_trade_amt_leverage = f'{predict_dailty_trade_amt}/{predict_daily_trade_leverage}'

        profit = round(balance - start_balance, 2)
        profit_percent = f'{round((profit / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0

        rebate_fee = f'{round(maker_rebate, 2)}/{round(taker_fee, 2)}'
        print(f'| {runtime: >24}{predict_dailty_trade_amt_leverage: >27}{profit_percent: >27}{profit: >27}{round(total_amount, 3): >32}{rebate_fee: >24}{round(balance, 2): >18}{round(max_balance, 2): >18}{round(min_balance, 2): >18}  |')
        print(f'|==========================================================================================================================================================================================================================|')

        TRADED_INFO_TIME = time()

    if time() - ACCOUNT_STATUS_CHECK_TIME > ACCOUNT_STATUS_CHECK_INTERVAL_TIME:
        maker_account = rest_api.get_maker_account(user_id, token, CATEGORY)
        ACCOUNT_STATUS_CHECK_TIME = time()
        if maker_account["account_status"] in RestApiConstant.STOP_STATUS_LIST.value:
            print("There is no running account.")
            if maker_account["account_status"] in RestApiConstant.CLOSE_STATUS_LIST.value:
                print("Close all positons, and exit program automatically...")
                for symbol in list(contracts):
                    contract = contracts[symbol]
                    round_volume = contract["round_volume"]
                    min_volume = contract["min_order_qty"]
                    max_volume = contract["max_order_qty"]
                    pricetick = contract["pricetick"]

                    bybit_linear_rest_api.cancel_all_orders(symbol)
                    for close_position_idx in (LONG_POS, SHORT_POS):
                        close_side = POSITION_IDX_TO_CLOSE_SIDE[close_position_idx]
                        close_volume = abs(positions[symbol][close_position_idx]["size"])
                        bybit_linear_rest_api.close_all_positions(symbol, close_side, close_volume, close_position_idx)

                    traded_long_open_order_dict[symbol] = {}
                    traded_short_open_order_dict[symbol] = {}

                    write_dict_to_file(EXCHANGE, symbol, LONG_SIDE)
                    write_dict_to_file(EXCHANGE, symbol, SHORT_SIDE)

                total_amount = 0
                total_runtime = 0
                start_balance = 0
                max_balance = 0
                min_balance = 0
                long_pnl = 0
                short_pnl = 0
                maker_rebate = 0
                taker_fee = 0
                insufficient_close = 0

                break
            else:
                for symbol in list(contracts):
                    contract = contracts[symbol]
                    bybit_linear_rest_api.cancel_all_orders(symbol)

                    for side in (LONG_SIDE, SHORT_SIDE):
                        write_dict_to_file(EXCHANGE, symbol, side)

                sleep(1)

                break

write_tradedinfo_to_file(EXCHANGE, USER_NAME)
response = rest_api.update_account(maker_account_id, token, total_amount, wallets[QUOTE_COIN]["balance"], ACCOUNT_TYPE, CATEGORY)

sleep(1)
