#!/usr/bin/env python
import logging
from pybit.unified_trading import WebSocket

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

from utils import Utils
from rest_api import RestApi
from constant import RestApiConstant, ExchangeConstant, BybitConstant
from bybit_linear_rest_api import BybitLinearRestApi

# rest api
user_id = 0
token = ""
api_key = ""
api_secret = ""
maker_account = None
maker_account_id = None

# exchange api
uid = None
api_key_info = {}
contracts = {}
fee_rates = {}
wallets = {}
ticks = {}
positions = {}
risk_limits = {}

maker_fee_rate = 0
taker_fee_rate = 0

traded_long_open_order = {}
traded_short_open_order = {}

# static parameters
position_values = {}
position_pnls = {}

balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0

EXCHANGE = ExchangeConstant.BYBIT.value
CATEGORY = BybitConstant.LINEAR.value
QUOTE_COIN = BybitConstant.QUOTE_USDT.value
ACCOUNT_TYPE = RestApiConstant.MAKER.value
OPPOSITE_SIDE: Dict[str, str] = {"Buy": "Sell", "Sell": "Buy"}
POSITION_SIDE_TO_CLOSE_IDX: Dict[str, int] = {"Buy": 2, "Sell": 1}
REDUCE_ONLY = {"Buy": {1: False, 2: True}, "Sell":{1: True, 2: False}}
DIRECTION_OFFSET = {"Buy": {1: "LONG_OPEN", 2: "LONG_CLOSE"}, "Sell":{1: "SHORT_CLOSE", 2: "SHORT_OPEN"}}

LONG_SIDE = BybitConstant.LONG.value
SHORT_SIDE = BybitConstant.SHORT.value

LONG_POS = BybitConstant.POSITION_LONG_IDX.value
SHORT_POS = BybitConstant.POSITION_SHORT_IDX.value

OFFSET_OPEN = BybitConstant.OFFSET_OPEN.value
OFFSET_CLOSE = BybitConstant.OFFSET_CLOSE.value

TRADE_VOLUME = 0.0

CLS_TIME = 0
CLS_INTERVAL_TIME = 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 5 * 60

ACCOUNT_STATUS_CHECK_TIME = 0
ACCOUNT_STATUS_CHECK_INTERVAL_TIME = 0.2 * 60

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

print("|=========================================================================|")

####### Rest API Section #######
USER_NAME = str((sys.argv[1:][0]))
USER_PWD = str((sys.argv[1:][1]))

# login
rest_api = RestApi(USER_NAME, USER_PWD, EXCHANGE)
(user_id, token) = rest_api.login()

# get maker account
maker_account = rest_api.get_maker_account(user_id, token, CATEGORY)

api_key = maker_account["api_key"]
api_secret = maker_account["api_secret"]
maker_account_id = maker_account["account_id"]
TRADE_VOLUME = float(maker_account["trading_volume"])

####### Exchange's Rest API #######
bybit_linear_rest_api = BybitLinearRestApi(api_key, api_secret, False)

contracts = bybit_linear_rest_api.query_contracts()
print("|=========================================================================|")

while True:
    bybit_linear_rest_api.cancel_all_orders_settle_coin(QUOTE_COIN)
    for symbol in list(contracts):
        positions[symbol] = {}
        _positions = bybit_linear_rest_api.query_positions(symbol)
        if _positions:
            for position_value in _positions.values():
                for position in position_value.values():
                    position_idx = position["position_idx"]
                    positions[symbol][position_idx] = position

        for new_side in (BybitConstant.LONG.value, BybitConstant.SHORT.value):
            close_volume = abs(positions[symbol][POSITION_SIDE_TO_CLOSE_IDX[new_side]]["size"])
            if close_volume:
                bybit_linear_rest_api.close_all_positions(symbol, new_side, close_volume, POSITION_SIDE_TO_CLOSE_IDX[new_side])

    sleep(5)

    break
