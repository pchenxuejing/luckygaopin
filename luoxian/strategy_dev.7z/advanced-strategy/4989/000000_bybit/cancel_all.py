#!/usr/bin/env python
import logging

import sys
from time import sleep, time

from rest_api import RestApi
from constant import RestApiConstant, ExchangeConstant, BybitConstant
from bybit_linear_rest_api import BybitLinearRestApi

# rest api
user_id = 0
token = ""
api_key = ""
api_secret = ""
maker_account = None
maker_account_id = None

# exchange api
uid = None
api_key_info = {}

EXCHANGE = ExchangeConstant.BYBIT.value
CATEGORY = BybitConstant.LINEAR.value
QUOTE_COIN = BybitConstant.QUOTE_USDT.value
ACCOUNT_TYPE = RestApiConstant.MAKER.value

####### Rest API Section #######
USER_NAME = str(sys.argv[1:][0])
USER_PWD = str(sys.argv[1:][1])

# login
rest_api = RestApi(USER_NAME, USER_PWD, EXCHANGE)
(user_id, token) = rest_api.login()

# get maker account
maker_account = rest_api.get_maker_account(user_id, token, CATEGORY)
print("|==================================================================================================|")

api_key = maker_account["api_key"]
api_secret = maker_account["api_secret"]
maker_account_id = maker_account["account_id"]

####### Exchange's Rest API #######
bybit_linear_rest_api = BybitLinearRestApi(api_key, api_secret, False)

# check/upgrade UTA
api_key_info = bybit_linear_rest_api.get_api_key_information()
print(f'| {api_key_info["uid"]: >10}{api_key_info["note"]: >6}{api_key_info["ips"][0]: >20}{api_key_info["deadline_day"]: >6}{api_key_info["expired_at"]: >28}{api_key_info["vip_level"]: >8}{api_key_info["is_master"]: >5}  |')

account_info = bybit_linear_rest_api.get_account_info()
if account_info["unified_margin_status"] != BybitConstant.UTA_PRO.value:
    bybit_linear_rest_api.upgrade_to_uta()

print(f'| {account_info["margin_mode"]: >24}{account_info["unified_margin_status"]: >12}{account_info["dcp_status"]: >12}{account_info["time_window"]: >12}{account_info["smp_group"]: >12}  |')

bybit_linear_rest_api.cancel_all_orders_settle_coin(QUOTE_COIN)
sys.exit()
