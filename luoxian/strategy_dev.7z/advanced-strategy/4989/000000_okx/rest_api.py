#!/usr/bin/env python

from constant import RestApiConstant

import requests
import json

class RestApi:
    """
    Callback when this class is inited.
    """
    def __init__(self, user_name, user_pwd, exchange):
        self.user_name = user_name
        self.user_pwd = user_pwd
        self.exchange = exchange

    """
    "   Desc: login into Web
    """
    def login(self):
        data = json.dumps({
          "username": self.user_name,
          "password": self.user_pwd
        })

        headers = {'Content-Type': 'application/json'}
        response = requests.request("POST", RestApiConstant.LOGIN_URL.value, headers=headers, data=data)

        json_data = response.json()
        user_id = json_data["data"]["user_id"]
        token = json_data["data"]["token"]

        return (user_id, token)

    """
    "   Desc: Get maker account
    """
    def get_maker_account(self, user_id, token, category):
        data = json.dumps({
          "user_id": user_id,
          "category": category
        })

        headers = {'Authorization': 'Token ' + token, 'Content-Type': 'application/json'}
        response = requests.request("POST", RestApiConstant.GET_MAKER_ACCOUNT_URL.value, headers=headers, data=data)
        json_data = response.json()
        maker_account_data = json_data["data"]
        maker_account = {}

        maker_account["exchange"] = self.exchange
        maker_account["api_key"] = maker_account_data["api_key"]
        maker_account["api_secret"] = maker_account_data["secret_key"]
        maker_account["account_id"] = maker_account_data["maker_account_id"]
        maker_account["bonus"] = maker_account_data["bonus"]
        maker_account["trading_volume"] = maker_account_data["trading_volume"]
        maker_account["account_status"] = maker_account_data["account_status"]

        return maker_account

    """
    "   Desc: Get taker accounts
    """
    def get_taker_accounts(self, user_id, token, category):
        data = json.dumps({
          "user_id": user_id,
          "category": category
        })

        headers = {'Authorization': 'Token ' + token, 'Content-Type': 'application/json'}
        response = requests.request("POST", RestApiConstant.GET_TAKER_ACCOUNTS_URL.value, headers=headers, data=data)

        json_data = response.json()
        taker_accounts_data = json_data["data"]

        running_taker_accounts = []
        waiting_taker_accounts = []
        for taker_account_data in taker_accounts_data:
            taker_account = {}

            taker_account["exchange"] = self.exchange
            taker_account["api_key"] = taker_account_data["api_key"]
            taker_account["api_secret"] = taker_account_data["secret_key"]
            taker_account["account_id"] = taker_account_data["taker_account_id"]
            taker_account["bonus"] = taker_account_data["bonus"]
            taker_account["trading_volume"] = taker_account_data["trading_volume"]
            taker_account["account_status"] = taker_account_data["account_status"]

            if taker_account["account_status"] in RestApiConstant.RUNNING_STATUS_LIST.value:
                running_taker_accounts.append(taker_account)
                if taker_account["account_status"] == "waiting":
                    waiting_taker_accounts.append(taker_account)

        return (running_taker_accounts, waiting_taker_accounts)

    """
    "   Desc: Update account
    """
    def update_account(self, account_id, token, trade_volume, balance, user_type, category):
        update_url, data = "", ""
        if user_type == RestApiConstant.MAKER.value:
            update_url = RestApiConstant.UPDATE_MAKER_ACCOUNT_URL.value
            data = json.dumps({
                "maker_account_id": account_id,
                "trading_volume": trade_volume,
                "balance": balance,
                "category": category
            })
        else:
            update_url = RestApiConstant.UPDATE_TAKER_ACCOUNT_URL.value
            data = json.dumps({
                "taker_account_id": account_id,
                "trading_volume": trade_volume,
                "balance": balance,
                "category": category
            })

        headers = {'Authorization': 'Token ' + token, 'Content-Type': 'application/json'}
        response = requests.request("POST", update_url, headers=headers, data=data)

        return response.json()

    """
    "   Desc: Update account's status
    """
    def update_account_status(self, account_id, token, user_type, status, category):
        update_url, data = "", ""
        if user_type == RestApiConstant.MAKER.value:
            update_url = RestApiConstant.UPDATE_MAKER_ACCOUNT_URL.value
            data = json.dumps({
                "maker_account_id": account_id,
                "status": status,
                "category": category
            })
        else:
            update_url = RestApiConstant.UPDATE_TAKER_ACCOUNT_URL.value
            data = json.dumps({
                "taker_account_id": account_id,
                "status": status,
                "category": category
            })

        headers = {'Authorization': 'Token ' + token, 'Content-Type': 'application/json'}
        response = requests.request("POST", update_url, headers=headers, data=data)

        return response.json()

    """
    "   Desc: Get trading options
    """
    def get_trading_options(self, user_id, trade_category):
        response = requests.request("GET", RestApiConstant.GET_TRADING_OPTION_URL.value + trade_category)
        json_data = response.json()
        trading_options_data = json_data["data"]

        trading_options = []
        for trading_option_data in trading_options_data:
            user = trading_option_data["user"]
            category = trading_option_data["category"]
            if user == user_id and category == trade_category:
                trading_option = {}

                trading_option["exchange"] = self.exchange
                trading_option["symbol"] = trading_option_data["symbol"]
                trading_option["open_volume"] = float(trading_option_data["open_volume"])
                trading_option["direction"] = trading_option_data["direction"]
                trading_option["quote_currency"] = trading_option_data["quotecurrency"]
                trading_option["base_currency"] = trading_option_data["symbol"].replace(trading_option_data["quotecurrency"], '')
                trading_option["first_max_amt"] = float(trading_option_data["sub_max_volume"])
                trading_option["last_max_amt"] = float(trading_option_data["max_volume"])
                trading_option["category"] = trading_option_data["category"]

                trading_options.append(trading_option)

        return trading_options
