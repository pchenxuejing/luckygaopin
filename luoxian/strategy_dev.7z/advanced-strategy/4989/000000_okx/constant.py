"""
General constant string used in strategy.
"""
from enum import Enum

class RestApiConstant(Enum):
    """
    Account Type
    """
    MAKER = "MAKER"
    TAKER = "TAKER"

    """
    Rest API urls
    """
    WEB_HOST = 'http://www.tiptoptrading.cn/tiptoptrading'
    LOGIN_URL = WEB_HOST + '/auth/signin'

    GET_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/query'
    UPDATE_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/update'

    GET_TAKER_ACCOUNTS_URL = WEB_HOST + '/tapi/query'
    UPDATE_TAKER_ACCOUNT_URL = WEB_HOST + '/tapi/update'

    GET_TRADING_OPTION_URL = WEB_HOST + '/option/query?category='

    RUNNING_STATUS_LIST = ["waiting", "running"]
    STOP_STATUS_LIST = ["stopped", "closed"]
    CLOSE_STATUS_LIST = ["closed"]

    """
    WebSokcet
    """
    WEBSOCKET_HOST = "10.40.171.3"
    WEBSOCKET_PORT = 5000
    WEBSOCKET_URL = "ws://10.40.171.3:5000"

    WEBSOCKET_DIRECTION_FROM_TAKER = "FROM_TAKER"
    WEBSOCKET_DIRECTION_FROM_MAKER = "FROM_MAKER"

class ExchangeConstant(Enum):
    """
    Exchange
    """
    BINANCE = "BINANCE"
    BYBIT = "BYBIT"
    GATEIO = "GATEIO"
    BITMEX = "BITMEX"
    OKX = "OKX"
    HUOBI = "HUOBI"
    BITFINEX = "BITFINEX"
    COINBASE = "COINBASE"
    DERIBIT = "DERIBIT"
    BITSTAMP = "BITSTAMP"
    BITCOKE = "BITCOKE"
    PHEMEX = "PHEMEX"

class OkxConstant(Enum):
    SERVER_TIME_URL = "https://www.okx.com/api/v5/public/time"
    WEBSOCKET_PUBLIC_URL = "wss://ws.okx.com:8443/ws/v5/public"
    WEBSOCKET_PRIVATE_URL = "wss://ws.okx.com:8443/ws/v5/private"

    """
    Quote Currency
    """
    QUOTE_USDT = "USDT"
    QUOTE_USDC = "USDC"

    """
    Contract Type
    """
    LINEAR = "linear"
    INVERSE = "inverse"

    """
    Instrument Type
    """
    SPOT = "SPOT"
    MARGIN = "MARGIN"
    SWAP = "SWAP"
    FUTURES = "FUTURES"
    OPTION = "OPTION"
    ANY = "ANY"

    """
    Margin Mode
    """
    CROSS = "cross"
    ISOLATED = "isolated"

    """
    Position Mode
    """
    DUAL_MODE = "long_short_mode"
    SINGLE_MODE = "net_mode"

    """
    Direction of order/trade/position.
    """
    LONG = "buy"
    SHORT = "sell"

    """
    Position Side
    """
    POSITION_LONG = "long"
    POSITION_SHORT = "short"
    POSITION_NET = "net"

    OFFSET_OPEN = "OPEN"
    OFFSET_CLOSE = "CLOSE"

    """
    Order Status
    """
    NOTTRADED = "live"
    PARTTRADED = "partially_filled"
    ALLTRADED = "filled"
    CANCELLED = "canceled"

    """
    Order Type
    """
    LIMIT = "limit"
    MARKET = "market"
    IOC = "ioc"
    FOK = "fok"
    POST_ONLY = "post_only"
    OPTIMAL_LIMIT_IOC = "optimal_limit_ioc"
    MMP = "mmp"
    MMP_POST_ONLY = "mmp_and_post_only"

    """
    Order Exec Type
    """
    EXCEC_TYPE_MAKER = "M"
    EXCEC_TYPE_TAKER = "T"

    """
    Instrument alias
    """
    THIS_WEEK = "this_week"
    NEXT_WEEK = "next_week"
    QUARTER = "quarter"
    NEXT_QUARTER = "next_quarter"

    """
    Interval of bar data
    """
    MINUTE = "1m"
    HOUR = "1h"
    DAILY = "1d"
    WEEKLY = "1w"
    TICK = "tick"

    PLACE_ORDER_OK = "0"
    INSUFFICIENT_MARGIN = "Insufficient margin"
