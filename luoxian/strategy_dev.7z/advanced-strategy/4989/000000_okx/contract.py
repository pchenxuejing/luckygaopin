#!/usr/bin/env python
import sys
from constant import OkxConstant

import okx.Public_api as Public
import okx.status_api as Status

SWAP_INST_TYPE = OkxConstant.SWAP.value
QUOTE_COIN = OkxConstant.QUOTE_USDC.value

####### Rest API Section #######
SYMBOL = str(sys.argv[1:][0])
ULY = SYMBOL.replace("-SWAP", "")

api_key = "c2fe5f02-ea1a-4f91-b825-32103f253449"
secret_key = "3F3B1940CB68E488C424C74D56E6031D"
passphrase = "Fuyong123."
broker_code = "94d227e6c134BCDE"

####### Exchange's Rest API #######
# system status
system_status = Status.StatusAPI(api_key, secret_key, passphrase, False, '0')
result = system_status.status()

# public api
public_api = Public.PublicAPI(api_key, secret_key, passphrase, False, '0')

# get contracts, update positions
contracts_response = public_api.get_instruments(instType=SWAP_INST_TYPE, uly=ULY, instId=SYMBOL)
if contracts_response:
    for contract_data in contracts_response["data"]:
        contract = {}

        symbol = contract_data["instId"]
        contract["inst_family"] = contract_data["instFamily"]
        contract["symbol"] = contract_data["instId"]
        contract["base_coin"] = contract_data["ctValCcy"]
        contract["quote_coin"] = contract_data["settleCcy"]
        contract["contract_type"] = contract_data["instType"]
        contract["exp_time"] = contract_data["expTime"]
        contract["pricetick"] = float(contract_data["tickSz"])
        contract["round_volume"] = float(contract_data["lotSz"])
        contract["min_volume"] = float(contract_data["minSz"])
        contract["max_market_qty"] = float(contract_data["maxMktSz"])
        contract["max_limit_qty"] = float(contract_data["maxLmtSz"])
        contract["max_leverage"] = float(contract_data["lever"])
        contract["multiplier"] = float(contract_data["ctMult"])
        contract["value"] = float(contract_data["ctVal"])

        print(contract)
