#!/usr/bin/env python
import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

from utils import Utils
from constant import ExchangeConstant, RestApiConstant, OkxConstant

import websockets
import websocket
import requests
import hmac
import base64
import zlib
import datetime
import threading

import okx.Account_api as Account
import okx.Funding_api as Funding
import okx.Market_api as Market
import okx.Public_api as Public
import okx.Trade_api as Trade
import okx.subAccount_api as SubAccount
import okx.status_api as Status

api_key = "b37cd6a0-2cc6-4530-b883-3305e8c2d147"
secret_key = "44AC539C3A5FD2F18A1819326E63A3D9"
passphrase = "@Li12345"
broker_code = "94d227e6c134BCDE"

# exchange api
uid = None
contracts = {}
positions = {}
fee_rate = {}
wallets = {}
ticks = {}

maker_fee_rate = 0
taker_fee_rate = 0

# static parameters
balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_amount = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0

maker_rebate = 0.0
taker_fee = 0.0

TICK_VOLUME = 0
tick_volume_dict = {}

ask1_volume = 0
bid1_volume = 0

traded_long_open_order_dict = {}
traded_short_open_order_dict = {}

long_open_traded_min_max_price = {'min': 0, 'max': 0}
short_open_traded_min_max_price = {'min': 0, 'max': 0}

EXCHANGE = ExchangeConstant.OKX.value
CATEGORY = OkxConstant.LINEAR.value
SWAP_INST_TYPE = OkxConstant.SWAP.value
QUOTE_COIN = OkxConstant.QUOTE_USDC.value
OPPOSITE_SIDE: Dict[str, str] = {"buy": "sell", "sell": "buy"}
OPPOSITE_POS_SIDE: Dict[str, str] = {"long": "short", "short": "long"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"long": "sell", "short": "buy"}
DIRECTION_OFFSET = {"buy": {"long": "LONG_OPEN", "short": "LONG_CLOSE"}, "sell":{"long": "SHORT_CLOSE", "short": "SHORT_OPEN"}}

LONG_SIDE = OkxConstant.LONG.value
SHORT_SIDE = OkxConstant.SHORT.value

LONG_POS = OkxConstant.POSITION_LONG.value
SHORT_POS = OkxConstant.POSITION_SHORT.value

OFFSET_OPEN = OkxConstant.OFFSET_OPEN.value
OFFSET_CLOSE = OkxConstant.OFFSET_CLOSE.value

PROCESS_STATUS = 0 # 0: run, 1: stop, 2: close

CLS_TIME = 0
CLS_INTERVAL_TIME = 12 * 60 * 60

QUERY_CONTRACTS_TIME = 0
QUERY_CONTRACTS_INTERVAL_TIME = 24 * 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 60 * 60

ACCOUNT_STATUS_CHECK_TIME = 0
ACCOUNT_STATUS_CHECK_INTERVAL_TIME = 1 * 60

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "P.Daily Vol($/L)", 2: "D/M/Y P.Pnl(%)", 3: "Total Earned($)", 4: "Total Trade Vol($)", 5: "M/T.Fee($)", 6: "W.Bal($)", 7: "Max.Bal($)", 8: "Min.Bal($)"}

"""
"   Desc: empty a dict file
"""
def empty_dict_file(exchange, symbol, side):
    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        if side == LONG_SIDE:
            f.write("")
        elif side == SHORT_SIDE:
            f.write("")

"""
"   Desc: Write a dict to a txt file
"""
def write_dict_to_file(exchange, symbol, side):
    global traded_long_open_order_dict, traded_short_open_order_dict

    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        if side == LONG_SIDE:
            f.write(str(traded_long_open_order_dict[symbol]).replace("{", "").replace("}", ""))
        elif side == SHORT_SIDE:
            f.write(str(traded_short_open_order_dict[symbol]).replace("{", "").replace("}", ""))

"""
"   Desc: Read dict from a txt file
"""
def read_dict_from_file(exchange, symbol, side):
    global traded_long_open_order_dict, traded_short_open_order_dict

    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            if side == LONG_SIDE:
                traded_long_open_order_dict[symbol] = {}
            elif side == SHORT_SIDE:
                traded_short_open_order_dict[symbol] = {}
        else:
            if side == LONG_SIDE:
                try:
                    traded_long_open_order_dict[symbol] = dict((float(x.strip()), float(y.strip()))
                         for x, y in (element.split(':')
                                      for element in data.split(', ')))
                except ValueError:
                    print(f'ValueError: {symbol}-{side}')
            elif side == SHORT_SIDE:
                try:
                    traded_short_open_order_dict[symbol] = dict((float(x.strip()), float(y.strip()))
                     for x, y in (element.split(':')
                                  for element in data.split(', ')))
                except ValueError:
                    print(f'ValueError: {symbol}-{side}')

"""
"   Desc: Update traded open order dict when maker order has been traded
"""
def update_order_dict(symbol, side, price, volume, status):
    global traded_long_open_order_dict, traded_short_open_order_dict, contracts

    min_volume = contracts[symbol]["min_volume"]
    round_volume = contracts[symbol]["round_volume"]

    if float(volume) <= 0.0:
        return

    if status == 0:
        if side == LONG_SIDE:
            if price in traded_long_open_order_dict[symbol]:
                traded_long_open_order_dict[symbol][price] += Utils.c_round_to(volume, round_volume)
            else:
                traded_long_open_order_dict[symbol][price] = Utils.c_round_to(volume, round_volume)
        elif side == SHORT_SIDE:
            if price in traded_short_open_order_dict[symbol]:
                traded_short_open_order_dict[symbol][price] += Utils.c_round_to(volume, round_volume)
            else:
                traded_short_open_order_dict[symbol][price] = Utils.c_round_to(volume, round_volume)
    elif status == 1:
        if side == LONG_SIDE:
            key_copy_short = tuple(traded_short_open_order_dict[symbol].keys())
            if key_copy_short:
                for k in sorted(key_copy_short, reverse=True):
                    if volume > 0:
                        r_v = Utils.c_round_to(traded_short_open_order_dict[symbol][k], round_volume)
                        if r_v == 0.0:
                            del traded_short_open_order_dict[symbol][k]
                            continue

                        if volume > r_v:
                            volume = Utils.c_round_to(volume - r_v, round_volume)
                            del traded_short_open_order_dict[symbol][k]
                        elif volume == r_v:
                            del traded_short_open_order_dict[symbol][k]
                            volume = 0
                            break
                        else:
                            traded_short_open_order_dict[symbol][k] = Utils.c_round_to(r_v - volume, round_volume)
                            volume = 0
                            break
        elif side == SHORT_SIDE:
            key_copy_long = tuple(traded_long_open_order_dict[symbol].keys())
            if key_copy_long:
                for k in sorted(key_copy_long):
                    if volume > 0:
                        r_v = Utils.c_round_to(traded_long_open_order_dict[symbol][k], round_volume)
                        if r_v == 0.0:
                            del traded_long_open_order_dict[symbol][k]
                            continue

                        if volume > r_v:
                            volume = Utils.c_round_to(volume - r_v, round_volume)
                            del traded_long_open_order_dict[symbol][k]
                        elif volume == r_v:
                            del traded_long_open_order_dict[symbol][k]
                            volume = 0
                            break
                        else:
                            traded_long_open_order_dict[symbol][k] = Utils.c_round_to(r_v - volume, round_volume)
                            volume = 0
                            break

"""
"   Desc: Get close voluem from an open order dict
"""
def get_close_volume_from_dict(symbol, side, price, profit_pricetick):
    global traded_long_open_order_dict, traded_short_open_order_dict, contracts

    min_volume = contracts[symbol]["min_volume"]
    round_volume = contracts[symbol]["round_volume"]

    close_volume = 0
    if side == LONG_SIDE:
        key_copy_short = tuple(traded_short_open_order_dict[symbol].keys())
        if key_copy_short:
            for k in sorted(key_copy_short, reverse=True):
                if k - profit_pricetick >= price:
                    if traded_short_open_order_dict[symbol][k] == 0.0:
                        del traded_short_open_order_dict[symbol][k]
                    else:
                        close_volume = Utils.c_round_to(traded_short_open_order_dict[symbol][k], round_volume)
                        break
    elif side == SHORT_SIDE:
        key_copy_long = tuple(traded_long_open_order_dict[symbol].keys())
        if key_copy_long:
            for k in sorted(key_copy_long):
                if k + profit_pricetick <= price:
                    if traded_long_open_order_dict[symbol][k] == 0.0:
                        del traded_long_open_order_dict[symbol][k]
                    else:
                        close_volume = Utils.c_round_to(traded_long_open_order_dict[symbol][k], round_volume)
                        break

    return close_volume

"""
"   Desc: Write a tick_volume to a tick_volume log file
"""
def empty_tv_file(exchange, symbol):
    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + symbol.lower() + "\\t_v.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write("0")

"""
"   Desc: Write a tick_volume to a tick_volume log file
"""
def write_tv_to_file(exchange, symbol):
    global tick_volume_dict

    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + symbol.lower() + "\\t_v.txt"

    t_v = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        t_v = f'{tick_volume_dict[symbol]}'
        f.write(t_v)

"""
"   Desc: Read a tick_volume from a tick_volume log file
"""
def read_tv_from_file(exchange, symbol):
    global tick_volume_dict

    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + symbol.lower() + "\\t_v.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            tick_volume_dict[symbol] = 0
        else:
            tick_volume_dict[symbol] = float(data.strip())

"""
"   Desc: Write a traded info to a log file
"""
def write_tradedinfo_to_file(exchange):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee

    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + "log.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{total_amount}, {total_runtime}, {start_balance}, {max_balance}, {min_balance}, {maker_rebate}, {taker_fee}'
        f.write(traded_info)

"""
"   Desc: Read a traded info from a log file
"""
def read_tradedinfo_from_file(exchange):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee

    log_file = ROOT_PATH + exchange.lower() + "\\log\\" + "log.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_amount = 0
            total_runtime = 0
            start_balance = 0
            max_balance = 0
            min_balance = 0
            maker_rebate = 0
            taker_fee = 0
        else:
            total_amount = float(data.split(', ')[0].strip())
            total_runtime = float(data.split(', ')[1].strip())
            start_balance = float(data.split(', ')[2].strip())
            max_balance = float(data.split(', ')[3].strip())
            min_balance = float(data.split(', ')[4].strip())
            maker_rebate = float(data.split(', ')[5].strip())
            taker_fee = float(data.split(', ')[6].strip())

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_to_file(exchange):
    log_file = ROOT_PATH + exchange.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'0')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_from_file(exchange):
    log_file = ROOT_PATH + exchange.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

####### Rest API Section #######
_SYMBOL = str((sys.argv[1:][0]))

SYMBOL = None
ULY = None
if _SYMBOL != "ALL":
    SYMBOL = _SYMBOL
    ULY = _SYMBOL.replace("-SWAP", "")

read_tradedinfo_from_file(EXCHANGE)

print("|===================================================================================================|")

####### Exchange's Rest API #######
# system status
system_status = Status.StatusAPI(api_key, secret_key, passphrase, False, '0')
result = system_status.status()

# market api
market_api = Market.MarketAPI(api_key, secret_key, passphrase, False, '0')

# public api
public_api = Public.PublicAPI(api_key, secret_key, passphrase, False, '0')

# trade api
trade_api = Trade.TradeAPI(api_key, secret_key, passphrase, False, '0')

# subAccount api
sub_account_api = SubAccount.SubAccountAPI(api_key, secret_key, passphrase, False, '0')

# account api
account_api = Account.AccountAPI(api_key, secret_key, passphrase, False, '0')

# funding api
funding_api = Funding.FundingAPI(api_key, secret_key, passphrase, False, '0')

fee_response = account_api.get_fee_rates(instType=SWAP_INST_TYPE, uly=ULY, instId=SYMBOL)
if fee_response:
    fee_rate_data = fee_response["data"][0]
    fee_rate["exchange"] = EXCHANGE
    fee_rate["delivery"] = float(fee_rate_data["delivery"]) if fee_rate_data["delivery"] else 0
    fee_rate["taker"] = float(fee_rate_data["taker"]) if fee_rate_data["taker"] else 0
    fee_rate["maker"] = float(fee_rate_data["maker"]) if fee_rate_data["maker"] else 0
    fee_rate["takerU"] = float(fee_rate_data["takerU"]) if fee_rate_data["takerU"] else 0
    fee_rate["makerU"] = float(fee_rate_data["makerU"]) if fee_rate_data["makerU"] else 0
    fee_rate["takerUSDC"] = float(fee_rate_data["takerUSDC"]) if fee_rate_data["takerUSDC"] else 0
    fee_rate["makerUSDC"] = float(fee_rate_data["makerUSDC"]) if fee_rate_data["makerUSDC"] else 0

maker_fee_rate = fee_rate["makerUSDC"] if QUOTE_COIN == "USDC" else fee_rate["makerU"]
taker_fee_rate = fee_rate["takerUSDC"] if QUOTE_COIN == "USDC" else fee_rate["takerU"]

wallet_response = account_api.get_account(ccy=QUOTE_COIN)
if wallet_response:
    for wallet_data in wallet_response["data"][0]["details"]:
        wallet = {}
        wallet["exchange"] = EXCHANGE
        wallet["coin"] = wallet_data["ccy"]
        wallet["balance"] = float(wallet_data["eq"])
        wallet["available"] = float(wallet_data["availBal"])
        wallet["usd_value"] = float(wallet_data["eqUsd"])
        wallet["frozen"] = float(wallet_data["frozenBal"])

        wallets[wallet_data["ccy"]] = wallet

if not wallets:
    print(f"Wallet is empty!")
    sys.exit()

balance = wallets[QUOTE_COIN]["balance"]
if balance <= 0:
    print(f"Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}")

if start_balance == 0:
    start_balance = balance

if min_balance == 0:
    min_balance = start_balance

if max_balance == 0:
    max_balance = start_balance

account_info = account_api.get_account_config()
uid = account_info["data"][0]["uid"]
print(f'| {account_info["data"][0]["uid"]: >24}{account_info["data"][0]["acctLv"]: >8}{account_info["data"][0]["level"]: >8}{account_info["data"][0]["ip"]: >42}{round(balance, 2): >14}  |')

result = account_api.get_position_mode('long_short_mode')

# get contracts, update positions
contracts_response = public_api.get_instruments(instType=SWAP_INST_TYPE, uly=ULY, instId=SYMBOL)
if contracts_response:
    for contract_data in contracts_response["data"]:
        contract = {}

        symbol = contract_data["instId"]
        contract["exchange"] = EXCHANGE
        contract["inst_family"] = contract_data["instFamily"]
        contract["symbol"] = contract_data["instId"]
        contract["base_coin"] = contract_data["ctValCcy"]
        contract["quote_coin"] = contract_data["settleCcy"]
        contract["contract_type"] = contract_data["instType"]
        contract["exp_time"] = contract_data["expTime"]
        contract["pricetick"] = float(contract_data["tickSz"])
        contract["round_volume"] = float(contract_data["lotSz"])
        contract["min_volume"] = float(contract_data["minSz"])
        contract["max_market_qty"] = float(contract_data["maxMktSz"])
        contract["max_limit_qty"] = float(contract_data["maxLmtSz"])
        contract["max_leverage"] = float(contract_data["lever"])
        contract["multiplier"] = float(contract_data["ctMult"])
        contract["value"] = float(contract_data["ctVal"])

        if contract["quote_coin"] == QUOTE_COIN:
            contracts[symbol] = contract

        # leverage_response = account_api.get_leverage(symbol, 'cross')
        # if leverage_response["data"]:
        #     leverage = float(leverage_response["data"][0]["lever"])
        #     if leverage != contract["max_leverage"]:
        #         result = account_api.set_leverage(instId=symbol, lever=str(contract["max_leverage"]), mgnMode='cross')

        position = {}
        position["exchange"] = EXCHANGE
        position["symbol"] = symbol
        position["size"] = 0
        position["avg_price"] = 0
        position["leverage"] = 0
        position["value"] = 0
        position["liq_price"] = 0
        position["unreal_pnl"] = 0

        positions[symbol] = {}
        positions[symbol][LONG_POS] = position
        positions[symbol][SHORT_POS] = position

position_response = account_api.get_positions(instType=SWAP_INST_TYPE)
if position_response["data"]:
    for position_data in position_response["data"]:
        symbol = position_data["instId"]

        if symbol in contracts.keys():
            position = {}
            position["exchange"] = EXCHANGE
            position["symbol"] = position_data["instId"]
            position["pos_side"] = position_data["posSide"]
            position["size"] = float(position_data["pos"]) if position_data["pos"] else 0
            position["avg_price"] = float(position_data["avgPx"]) if position_data["avgPx"] else 0
            position["leverage"] = float(position_data["lever"]) if position_data["lever"] else 0
            position["value"] = float(position["avg_price"] * position["size"] * contracts[symbol]["value"])
            position["liq_price"] = float(position_data["liqPx"]) if position_data["liqPx"] else 0
            position["unreal_pnl"] = float(position_data["upl"]) if position_data["upl"] else 0

            pos_side = position["pos_side"]
            positions[symbol][pos_side] = position

class WebsocketClientThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self.stop_event = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self.stop_event.is_set():
            self.ws.run_forever()

    def stop(self):
        self.stop_event.set()

    def on_open(self, ws):
        print("WebSocket's Connection Opened.")

    def on_close(self, ws):
        print("WebSocket's Connection Closed.")

    def on_error(self, ws, error):
        print("WebSocket's Error: ", error)

    def on_message(self, ws, message):
        if ticks:
            if "direction" in message:
                json_msg = json.loads(message)
                if json_msg["direction"] == "maker":
                    symbol = json_msg["symbol"]
                    new_volume = TICK_VOLUME
                    new_side = OPPOSITE_SIDE[json_msg["side"]]
                    new_pos_side = OPPOSITE_POS_SIDE[json_msg["position_side"]]

                    if (new_side == LONG_SIDE and new_pos_side == LONG_POS) or (new_side == SHORT_SIDE and new_pos_side == SHORT_POS):
                        response = trade_api.place_order(instId=symbol, tdMode=OkxConstant.CROSS.value, side=new_side, ordType=OkxConstant.MARKET.value, sz=str(new_volume), posSide=new_pos_side, tag=broker_code)

    def send_message(self, message):
        self.ws.send(message)

websocket_client_thread = WebsocketClientThread(RestApiConstant.WEBSOCKET_URL.value, False, False)
websocket_client_thread.start()

# init session and websocket
class PublicWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self.stop_event = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self.stop_event.is_set():
            self.ws.run_forever()

    def stop(self):
        self.stop_event.set()

    def on_open(self, ws):
        print("Public WebSocket's Connection Opened.")
        if contracts:
            for symbol in list(contracts):
                channels = [{"channel": "books5", "instId": symbol}]
                self.ws.send(json.dumps({"op": "subscribe", "args": channels}))

    def on_close(self, ws):
        print("Public WebSocket's Connection Closed.")

    def on_error(self, ws, error):
        print("Public WebSocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        json_msg = json.loads(message)
        if json_msg:
            if "event" in json_msg:
                pass
            elif "arg" in json_msg and json_msg["arg"]["channel"] == "books5" and "data" in json_msg and json_msg["data"]:
                arg = json_msg["arg"]
                symbol = arg["instId"]
                data = json_msg["data"][0]

                tick = {}
                bids = data["bids"]
                tick["exchange"] = EXCHANGE
                tick["symbol"] = symbol

                tick["bid_price_1"] = float(bids[0][0])
                tick["bid_volume_1"] = float(bids[0][1])
                tick["bid_order_count"] = int(bids[0][3])

                asks = data["asks"]
                tick["ask_price_1"] = float(asks[0][0])
                tick["ask_volume_1"] = float(asks[0][1])
                tick["ask_order_count"] = int(asks[0][3])

                ticks[symbol] = tick

    def send_message(self, message):
        self.ws.send(message)

public_websocket_thread = PublicWebsocketThread(OkxConstant.WEBSOCKET_PUBLIC_URL.value, False, False)
public_websocket_thread.start()

class PrivateWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, api_key, secret_key, passphrase, trace=False, daemon=False):
        super().__init__()
        self.api_key = api_key
        self.secret_key = secret_key
        self.passphrase = passphrase
        self.stop_event = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self.stop_event.is_set():
            self.ws.run_forever()

    def stop(self):
        self.stop_event.set()

    def on_open(self, ws):
        print("Private WebSocket's Connection Opened.")
        timestamp = str(int(time()))
        message = timestamp + 'GET' + '/users/self/verify'
        mac = hmac.new(bytes(self.secret_key, encoding='utf8'), bytes(message, encoding='utf-8'), digestmod='sha256')
        d = mac.digest()
        sign = base64.b64encode(d)
        login_param = {"op": "login", "args": [{"apiKey": self.api_key,
                                                "passphrase": self.passphrase,
                                                "timestamp": timestamp,
                                                "sign": sign.decode("utf-8")}]}
        ws.send(json.dumps(login_param))

    def on_close(self, ws):
        print("Private WebSocket's Connection Closed.")

    def on_error(self, ws, error):
        print("Private WebSocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, total_amount, traded_count, current_traded_amount, maker_rebate, taker_fee
        json_msg = json.loads(message)
        if "event" in json_msg and json_msg["event"] == "login" and json_msg["code"] == "0":
            account_channels = [{"channel": "account", "ccy": QUOTE_COIN}]
            self.ws.send(json.dumps({"op": "subscribe", "args": account_channels}))
            if contracts:
                for symbol in list(contracts):
                    contract = contracts[symbol]
                    position_channels = [{"channel": "positions", "instType": SWAP_INST_TYPE, "instFamily": contract["inst_family"], "instId": contract["symbol"]}] # , "instId": contract["symbol"]
                    self.ws.send(json.dumps({"op": "subscribe", "args": position_channels}))

                    order_channels = [{"channel": "orders", "instType": SWAP_INST_TYPE, "instFamily": contract["inst_family"], "instId": contract["symbol"]}] # , "instId": contract["symbol"]
                    self.ws.send(json.dumps({"op": "subscribe", "args": order_channels}))
        elif "event" in json_msg and json_msg["event"] == "error" and json_msg["code"] == "60011":
            print("Websocket login failed. Try again...")
            timestamp = str(int(time()))
            message = timestamp + 'GET' + '/users/self/verify'
            mac = hmac.new(bytes(self.secret_key, encoding='utf8'), bytes(message, encoding='utf-8'), digestmod='sha256')
            d = mac.digest()
            sign = base64.b64encode(d)
            login_param = {"op": "login", "args": [{"apiKey": self.api_key,
                                                    "passphrase": self.passphrase,
                                                    "timestamp": timestamp,
                                                    "sign": sign.decode("utf-8")}]}
            ws.send(json.dumps(login_param))
        elif "event" not in json_msg and "data" in json_msg and json_msg["data"]:
            arg = json_msg["arg"]
            data = json_msg["data"][0]
            channel = arg["channel"]
            if channel == "account":
                wallets_data = data["details"]
                if wallets_data:
                    for wallet_data in wallets_data:
                        wallet = {}
                        wallet["exchange"] = EXCHANGE
                        wallet["coin"] = wallet_data["ccy"]
                        wallet["balance"] = float(wallet_data["eq"]) if wallet_data["eq"] else 0
                        wallet["available"] = float(wallet_data["availBal"]) if wallet_data["availBal"] else 0
                        wallet["usd_value"] = float(wallet_data["eqUsd"]) if wallet_data["eqUsd"] else 0
                        wallet["frozen"] = float(wallet_data["frozenBal"]) if wallet_data["frozenBal"] else 0

                        wallets[wallet_data["ccy"]] = wallet
            elif channel == "positions":
                position_data = data

                position = {}
                position["exchange"] = EXCHANGE
                position["symbol"] = position_data["instId"]
                position["pos_side"] = position_data["posSide"]
                position["size"] = float(position_data["pos"]) if position_data["pos"] else 0
                position["avg_price"] = float(position_data["avgPx"]) if position_data["avgPx"] else 0
                position["leverage"] = float(position_data["lever"]) if position_data["lever"] else 0
                position["value"] = float(position["avg_price"] * position["size"] * contracts[position["symbol"]]["value"])
                position["liq_price"] = float(position_data["liqPx"]) if position_data["liqPx"] else 0
                position["unreal_pnl"] = float(position_data["upl"]) if position_data["upl"] else 0

                symbol = position["symbol"]
                if symbol in contracts.keys():
                    pos_side = position["pos_side"]
                    positions[symbol][pos_side] = position
            elif channel == "orders":
                order_data = data

                symbol = order_data["instId"]
                if symbol in contracts.keys():
                    order_id = order_data["ordId"]
                    side = order_data["side"]
                    price = float(order_data["px"]) if order_data["px"] else 0
                    volume = float(order_data["sz"]) if order_data["sz"] else 0
                    order_type = order_data["ordType"]
                    exec_type = order_data["execType"]
                    status = order_data["state"]
                    position_side = order_data["posSide"]
                    filled_price = float(order_data["fillPx"]) if order_data["fillPx"] else 0
                    filled_volume = float(order_data["fillSz"]) if order_data["fillSz"] else 0

                    pricetick = contracts[symbol]["pricetick"]
                    min_volume = contracts[symbol]["min_volume"]
                    round_volume = contracts[symbol]["round_volume"]
                    base_coin = contracts[symbol]["base_coin"]
                    contract_value = contracts[symbol]["value"]

                    l_position_size = positions[symbol][LONG_POS]["size"]
                    s_position_size = positions[symbol][SHORT_POS]["size"]

                    l_position_pnl = positions[symbol][LONG_POS]["unreal_pnl"]
                    s_position_pnl = positions[symbol][SHORT_POS]["unreal_pnl"]

                    l_position_avg_price = positions[symbol][LONG_POS]["avg_price"]
                    s_position_avg_price = positions[symbol][SHORT_POS]["avg_price"]

                    if status == OkxConstant.ALLTRADED.value:
                        traded_count += 1
                        if exec_type == OkxConstant.EXCEC_TYPE_MAKER.value:
                            maker_rebate -= maker_fee_rate * filled_price * volume * contract_value
                        elif exec_type == OkxConstant.EXCEC_TYPE_TAKER.value:
                            taker_fee -= taker_fee_rate * filled_price * volume * contract_value

                        if side == LONG_SIDE:
                            if position_side == LONG_POS:
                                update_order_dict(symbol, LONG_SIDE, Utils.round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 0)
                            elif position_side == SHORT_POS:
                                update_order_dict(symbol, LONG_SIDE, Utils.round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 1)
                        elif side == SHORT_SIDE:
                            if position_side == SHORT_POS:
                                update_order_dict(symbol, SHORT_SIDE, Utils.c_round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 0)
                            elif position_side == LONG_POS:
                                update_order_dict(symbol, SHORT_SIDE, Utils.round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 1)

                        traded_volume = filled_price * abs(volume) * contract_value
                        total_amount += traded_volume
                        current_traded_amount += traded_volume

                        title = f'{base_coin}'
                        date_time = Utils.get_current_time_mdhms()
                        direction_offset = DIRECTION_OFFSET[side][position_side]

                        print(f'{traded_count: >10}{title: >12}{order_type: >12}{direction_offset: >16}{Utils.round_to(l_position_size, round_volume): >14} / {Utils.round_to(s_position_size, round_volume): <14}{Utils.round_to(l_position_pnl, pricetick): >14} / {Utils.round_to(s_position_pnl, pricetick): <12}{Utils.round_to(l_position_avg_price, pricetick): >14} / {Utils.round_to(s_position_avg_price, pricetick): <12}{Utils.round_to(filled_price, pricetick): >14}{Utils.round_to(volume, round_volume): >14}{round(current_traded_amount, 2): >20}{int(current_runtime): >8}{date_time: >18}')

    def send_message(self, message):
        self.ws.send(message)

private_websocket_thread = PrivateWebsocketThread(OkxConstant.WEBSOCKET_PRIVATE_URL.value, api_key, secret_key, passphrase, False, False)
private_websocket_thread.start()

print("|===================================================================================================|")

TICK_VOLUME = float(sys.argv[1:][1])
GRID_TICKSIZE = int(sys.argv[1:][2])
PROFIT_TICKSIZE = int(sys.argv[1:][3])
FUNDING_RATE = float(sys.argv[1:][4])

CLS_TIME = time()
TRADED_INFO_TIME = time()
QUERY_CONTRACTS_TIME = time()
ACCOUNT_STATUS_CHECK_TIME = time()

start_time = time()
last_runtime = total_runtime

sleep(5)

START_PROCESS = True
while START_PROCESS:
    current_runtime = round((time() - start_time) / 60)
    for symbol in list(contracts):
        sleep(0.5)

        # <!--- check some parameters for market/trade/account
        contract = contracts[symbol]
        if symbol not in ticks.keys():
            continue

        balance = wallets[QUOTE_COIN]["balance"]
        if balance > max_balance:
            max_balance = balance

        if balance < min_balance:
            min_balance = balance

        round_volume = contract["round_volume"]
        min_volume = contract["min_volume"]
        max_volume = min(contract["max_limit_qty"], contract["max_market_qty"])
        pricetick = contract["pricetick"]
        contract_value = contract["value"]

        if symbol not in tick_volume_dict.keys():
            read_tv_from_file(EXCHANGE, symbol)

        if symbol not in traded_long_open_order_dict.keys():
            read_dict_from_file(EXCHANGE, symbol, LONG_SIDE)

        if symbol not in traded_short_open_order_dict.keys():
            read_dict_from_file(EXCHANGE, symbol, SHORT_SIDE)
        # --->

        _ask_price_1 = ticks[symbol]["ask_price_1"]

        # <!--- calc tick volume and grid ticksize
        contract_count = len(list(contracts))
        if not tick_volume_dict[symbol]:
            tick_volume_dict[symbol] = min(TICK_VOLUME, max_volume)

        tick_volume = tick_volume_dict[symbol]
        # --->

        fee_pricetick = max(Utils.c_round_to(abs(taker_fee_rate) * _ask_price_1, pricetick), pricetick)
        _profit_tick = PROFIT_TICKSIZE * pricetick + fee_pricetick

        for new_side in (LONG_SIDE, SHORT_SIDE):
            for new_pos_side in (LONG_POS, SHORT_POS):
                new_price, new_volume = 0, 0

                bid_price_1 = ticks[symbol]["bid_price_1"]
                bid_volume_1 = ticks[symbol]["bid_volume_1"]
                ask_price_1 = ticks[symbol]["ask_price_1"]
                ask_volume_1 = ticks[symbol]["ask_volume_1"]

                # new price
                if new_side == LONG_SIDE:
                    new_price = Utils.round_to(bid_price_1, pricetick)
                elif new_side == SHORT_SIDE:
                    new_price = Utils.round_to(ask_price_1, pricetick)

                long_pos_size = positions[symbol][LONG_POS]["size"]
                long_pos_entry_price = positions[symbol][LONG_POS]["avg_price"]

                short_pos_size = positions[symbol][SHORT_POS]["size"]
                short_pos_entry_price = positions[symbol][SHORT_POS]["avg_price"]

                if new_side == LONG_SIDE:
                    if new_pos_side == SHORT_POS:
                        if short_pos_size:
                            new_volume = min(Utils.c_round_to(get_close_volume_from_dict(symbol, LONG_SIDE, new_price, _profit_tick), round_volume), short_pos_size)
                            if not traded_short_open_order_dict[symbol]:
                                new_volume = min(max(FUNDING_RATE * short_pos_size, TICK_VOLUME), short_pos_size)
                elif new_side == SHORT_SIDE:
                    if new_pos_side == LONG_POS:
                        if long_pos_size:
                            new_volume = min(Utils.c_round_to(get_close_volume_from_dict(symbol, SHORT_SIDE, new_price, _profit_tick), round_volume), long_pos_size)
                            if not traded_long_open_order_dict[symbol]:
                                new_volume = min(max(FUNDING_RATE * long_pos_size, TICK_VOLUME), long_pos_size)

                new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                if new_volume and new_price:
                    response = trade_api.place_order(instId=symbol, tdMode=OkxConstant.CROSS.value, side=new_side, ordType=OkxConstant.POST_ONLY.value, sz=str(new_volume), posSide=new_pos_side, px=str(new_price), tag=broker_code)

    if time() - CLS_TIME > CLS_INTERVAL_TIME:
        os.system('cls')
        CLS_TIME = time()

    if time() - TRADED_INFO_TIME > TRADED_INFO_INTERVAL_TIME:
        print(f"|==========================================================================================================================================================================================================================|")
        print(f'|{TRADED_INFO_TITLE[0]: >26}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >27}{TRADED_INFO_TITLE[4]: >32}{TRADED_INFO_TITLE[5]: >24}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18}{TRADED_INFO_TITLE[8]: >18} |')
        print(f'|           ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|')
        total_runtime = last_runtime + current_runtime
        runtime_minutes = round(total_runtime)
        runtime_hours = round(total_runtime / 60, 1)
        runtime_days = round(total_runtime / 1440, 2)
        runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'

        predict_dailty_trade_amt = round(total_amount / (total_runtime / 1440), 1) if total_runtime > 1 else 0
        predict_daily_trade_leverage = round((total_amount / (total_runtime / 1440)) / balance, 1) if total_runtime > 1 else 0
        predict_dailty_trade_amt_leverage = f'{predict_dailty_trade_amt}/{predict_daily_trade_leverage}'

        profit = round(balance - start_balance, 2)
        profit_percent = f'{round((profit / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0

        rebate_fee = f'{round(maker_rebate, 2)}/{round(taker_fee, 2)}'
        print(f'| {runtime: >24}{predict_dailty_trade_amt_leverage: >27}{profit_percent: >27}{profit: >27}{round(total_amount, 3): >32}{rebate_fee: >24}{round(balance, 2): >18}{round(max_balance, 2): >18}{round(min_balance, 2): >18}  |')
        print(f'|==========================================================================================================================================================================================================================|')

        TRADED_INFO_TIME = time()

    if time() - ACCOUNT_STATUS_CHECK_TIME > ACCOUNT_STATUS_CHECK_INTERVAL_TIME:
        PROCESS_STATUS = read_process_status_signal_from_file(EXCHANGE)
        ACCOUNT_STATUS_CHECK_TIME = time()
        if PROCESS_STATUS != 0:
            print("There is no running account.")
            open_orders_data = trade_api.get_order_list(instType=SWAP_INST_TYPE, uly=ULY, ordType=OkxConstant.POST_ONLY.value, state=OkxConstant.NOTTRADED.value)
            if open_orders_data["data"]:
                for open_order_data in open_orders_data["data"]:
                    if open_order_data["state"] == OkxConstant.NOTTRADED.value:
                        trade_api.cancel_order(instId=open_order_data["instId"], ordId=open_order_data["ordId"])

            if PROCESS_STATUS == 2:
                print("Close all positons, and exit program automatically...")
                for symbol in list(contracts):
                    contract = contracts[symbol]
                    round_volume = contract["round_volume"]
                    min_volume = contract["min_volume"]
                    max_volume = contract["max_limit_qty"]
                    pricetick = contract["pricetick"]

                    for close_position_side in (LONG_POS, SHORT_POS):
                        close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
                        close_volume = abs(positions[symbol][close_position_side]["size"])
                        if close_volume:
                            trade_api.close_positions(instId=symbol, mgnMode=OkxConstant.CROSS.value, posSide=close_position_side, tag=broker_code)

                    tick_volume_dict[symbol] = 0
                    empty_tv_file(EXCHANGE, symbol)
                    empty_dict_file(EXCHANGE, symbol, LONG_SIDE)
                    empty_dict_file(EXCHANGE, symbol, SHORT_SIDE)

                total_amount = 0
                total_runtime = 0
                start_balance = 0
                max_balance = 0
                min_balance = 0
                maker_rebate = 0
                taker_fee = 0

                START_PROCESS = False
            elif PROCESS_STATUS == 1:
                for symbol in list(contracts):
                    write_tv_to_file(EXCHANGE, symbol)
                    write_dict_to_file(EXCHANGE, symbol, LONG_SIDE)
                    write_dict_to_file(EXCHANGE, symbol, SHORT_SIDE)

                sleep(1)

                START_PROCESS = False

public_websocket_thread.stop()
private_websocket_thread.stop()
websocket_client_thread.stop()

write_tradedinfo_to_file(EXCHANGE)
write_process_status_to_file(EXCHANGE)

sleep(3)

sys.exit()
