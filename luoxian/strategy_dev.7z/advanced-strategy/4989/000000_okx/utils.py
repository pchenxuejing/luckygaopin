#!/usr/bin/env python

import pytz
import uuid
from time import sleep, time
from datetime import datetime
from decimal import Decimal
from typing import Dict
import numpy as np

CHINA_TZ = pytz.timezone("Asia/Shanghai")

class Utils:
    """
    "   Desc: Round price to price tick value.
    """
    def round_to(value: float, target: float) -> float:
        value = Decimal(str(value))
        target = Decimal(str(target))
        rounded = float(int(round(value / target)) * target)
        return rounded

    """
    "   Desc: Round price to price tick value.
    """
    def c_round_to(value: float, target: float) -> float:
        str_target = str(target)
        if "." in str_target:
            precision = len(str_target.split(".")[1])
            _rounded = round(value, precision)
        elif "e-" in str_target:
            precision = int(str_target.split("e-")[1])
            _rounded = round(value, precision)
        elif "E-" in str_target:
            precision = int(str_target.split("E-")[1])
            _rounded = round(value, precision)
        else:
            _rounded = round(value)

        _value = Decimal(str(_rounded))
        target = Decimal(str_target)
        rounded = float(int(round(_value / target)) * target)
        return rounded

    """
    "   Desc: generate datetime
    """
    def generate_datetime(timestamp: float) -> datetime:
        dt = datetime.fromtimestamp(timestamp / 1000)
        dt = CHINA_TZ.localize(dt)
        return dt

    """
    "   Desc: get current time
    """
    def get_current_time():
        now = datetime.now()
        date_time = now.strftime("%Y-%m-%d %H:%M:%S")
        return date_time

    """
    "   Desc: get current time
    """
    def get_current_time_mdhms():
        now = datetime.now()
        date_time = now.strftime("%m-%d %H:%M:%S")
        return date_time

    """
    "   Desc: get current time
    """
    def get_current_time_mdhm():
        now = datetime.now()
        date_time = now.strftime("%m-%d %H:%M")
        return date_time

    """
    "   Desc: get current time
    """
    def get_current_time_mdh():
        now = datetime.now()
        date_time = now.strftime("%m-%d-%H")
        return date_time

    """
    "   Desc: generate uuid
    """
    def generate_uuid() -> str:
        gen_uuid = uuid.uuid1()
        return str(gen_uuid)

    """
    "   Desc: get current time(ms)
    """
    def current_milli_time():
        return str(round(time.time() * 1000))
