#!/usr/bin/env python
from constant import OkxConstant

import okx.Account_api as Account
import okx.Trade_api as Trade
import okx.status_api as Status

SWAP_INST_TYPE = OkxConstant.SWAP.value

api_key = ""
secret_key = ""
passphrase = ""
broker_code = "94d227e6c134BCDE"

####### Exchange's Rest API #######
# system status
system_status = Status.StatusAPI(api_key, secret_key, passphrase, False, '0')
result = system_status.status()

# trade api
trade_api = Trade.TradeAPI(api_key, secret_key, passphrase, False, '0')

# account api
account_api = Account.AccountAPI(api_key, secret_key, passphrase, False, '0')

position_response = account_api.get_positions(SWAP_INST_TYPE)
if position_response["data"]:
    for position_data in position_response["data"]:
        symbol = position_data["instId"]
        pos_size = float(position_data["pos"])
        if pos_size:
            trade_api.close_positions(symbol, OkxConstant.CROSS.value, position_data["posSide"])

sleep(3)
