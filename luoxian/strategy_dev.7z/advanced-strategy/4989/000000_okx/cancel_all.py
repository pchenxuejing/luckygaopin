#!/usr/bin/env python
from constant import OkxConstant

import okx.Trade_api as Trade
import okx.status_api as Status

SWAP_INST_TYPE = OkxConstant.SWAP.value

api_key = ""
secret_key = ""
passphrase = ""
broker_code = "94d227e6c134BCDE"

####### Exchange's Rest API #######
# system status
system_status = Status.StatusAPI(api_key, secret_key, passphrase, False, '0')
result = system_status.status()

# trade api
trade_api = Trade.TradeAPI(api_key, secret_key, passphrase, False, '0')

print("|===================================================================================================|")

open_orders_data = trade_api.get_order_list(instType=SWAP_INST_TYPE, ordType=OkxConstant.POST_ONLY.value, state=OkxConstant.NOTTRADED.value)
if open_orders_data["data"]:
    for open_order_data in open_orders_data["data"]:
        if open_order_data["state"] == OkxConstant.NOTTRADED.value:
            trade_api.cancel_order(open_order_data["instId"], open_order_data["ordId"])

sleep(3)
