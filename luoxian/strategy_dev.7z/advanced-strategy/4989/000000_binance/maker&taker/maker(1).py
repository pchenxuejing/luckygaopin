#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

import threading
import websocket

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
# key = "sguwhAV1G7sHsPTuQ0gfPK8cLe1krUypRbtzkC2cMC17idTxIExUCH8mToZZk3SW"
# secret = "jAWOgr4Qqt619yxuA2KgE3V2Mr6xSlrS4Vl47cRVYpqBfMm2LHLzBCSTrYxmvxXo"

key = "8XAgHlNKhQQgDi3hJYVeEy38Mbp06vcjHFWDIX5nShZXiUcNQdQnL5Fix2DiMX8Q"
secret = "bZlV9kIE7e9wtKA2jzx80OemYoQWy3SFchvzEpsTUnbAf1McqhuTxPYohFrWYbKQ"

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}

round_volume = 0
min_volume = 0
max_volume = 0
pricetick = 0
notional_value = 0

bid_price_1 = 0
ask_price_1 = 0

maker_fee_rate = 0
taker_fee_rate = 0

base_coin = ''

traded_long_open_order_dict = {}
traded_short_open_order_dict = {}

long_open_traded_min_max_price = {'min': 0, 'max': 0}
short_open_traded_min_max_price = {'min': 0, 'max': 0}

last_traded_long_open_price = 0
last_traded_short_open_price = 0
last_traded_long_close_price = 0
last_traded_short_close_price = 0

long_open_traded_min_price = 0
short_open_traded_max_price = 0

long_open_count = 0
short_open_count = 0
long_close_count = 0
short_close_count = 0

long_pos_pnl_value = 0
short_pos_pnl_value = 0

# static parameters
balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_amount = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0
runtime_days = 0

maker_rebate = 0.0
taker_fee = 0.0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
OPPOSITE_SIDE: Dict[str, str] = {"BUY": "SELL", "SELL": "BUY"}
OPPOSITE_POSITION: Dict[str, str] = {"LONG": "SHORT", "SHORT": "LONG"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"BUY": "SHORT", "SELL": "LONG"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"LONG": "SELL", "SHORT": "BUY"}
DIRECTION_OFFSET = {"BUY": {"LONG": "LONG_OPEN", "SHORT": "LONG_CLOSE"}, "SELL":{"LONG": "SHORT_CLOSE", "SHORT": "SHORT_OPEN"}}

LONG_SIDE = BinanceConstant.LONG.value
SHORT_SIDE = BinanceConstant.SHORT.value

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

CLS_TIME = 0
CLS_INTERVAL_TIME = 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 5 * 60

ACCOUNT_STATUS_CHECK_TIME = 0
ACCOUNT_STATUS_CHECK_INTERVAL_TIME = 0.1 * 60

POSITION_STATUS_CHECK_TIME = 0
POSITION_STATUS_CHECK_INTERVAL_TIME = 1 * 60

USER_STREAM_STARTTIME = 0

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "P.Daily Vol($/L)", 2: "D/M/Y PNL(%)", 3: "Total Earned($)", 4: "Total Trade Vol($)", 5: "M/T.Fee($)", 6: "W.Bal($)", 7: "Max.Bal($)", 8: "Min.Bal($)"}

"""
"   Desc: Write a traded log to a txt file
"""
def write_log_to_file(exchange, symbol, txt, fname):
    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + fname + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "a") as f:
        f.write(str(txt) + "\n")

"""
"   Desc: Write a dict to a txt file
"""
def write_dict_to_file(exchange, symbol, side):
    global traded_long_open_order_dict, traded_short_open_order_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        if side == LONG_SIDE:
            f.write(str(traded_long_open_order_dict[symbol]).replace("{", "").replace("}", ""))
        elif side == SHORT_SIDE:
            f.write(str(traded_short_open_order_dict[symbol]).replace("{", "").replace("}", ""))

"""
"   Desc: Read dict from a txt file
"""
def read_dict_from_file(exchange, symbol, side):
    global traded_long_open_order_dict, traded_short_open_order_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            if side == LONG_SIDE:
                traded_long_open_order_dict[symbol] = {}
            elif side == SHORT_SIDE:
                traded_short_open_order_dict[symbol] = {}
        else:
            if side == LONG_SIDE:
                traded_long_open_order_dict[symbol] = dict((float(x.strip()), float(y.strip()))
                     for x, y in (element.split(':')
                                  for element in data.split(', ')))
            elif side == SHORT_SIDE:
                traded_short_open_order_dict[symbol] = dict((float(x.strip()), float(y.strip()))
                 for x, y in (element.split(':')
                              for element in data.split(', ')))

"""
"   Desc: Update traded open order dict when maker order has been traded
"""
def update_order_dict(symbol, side, price, volume, status):
    global traded_long_open_order_dict, traded_short_open_order_dict

    if float(volume) <= 0.0:
        return

    if status == 0:
        if side == LONG_SIDE:
            if price in traded_long_open_order_dict[symbol]:
                traded_long_open_order_dict[symbol][price] += volume
            else:
                traded_long_open_order_dict[symbol][price] = volume
        elif side == SHORT_SIDE:
            if price in traded_short_open_order_dict[symbol]:
                traded_short_open_order_dict[symbol][price] += volume
            else:
                traded_short_open_order_dict[symbol][price] = volume
    elif status == 1:
        if side == LONG_SIDE:
            key_copy_short = tuple(traded_short_open_order_dict[symbol].keys())
            if key_copy_short:
                for k in sorted(key_copy_short, reverse=True):
                    if volume > 0:
                        if traded_short_open_order_dict[symbol][k] == 0.0:
                            del traded_short_open_order_dict[symbol][k]
                            continue

                        if volume > traded_short_open_order_dict[symbol][k]:
                            volume -= traded_short_open_order_dict[symbol][k]
                            del traded_short_open_order_dict[symbol][k]
                        elif volume == traded_short_open_order_dict[symbol][k]:
                            del traded_short_open_order_dict[symbol][k]
                            volume = 0
                            break
                        else:
                            k_v = traded_short_open_order_dict[symbol][k]
                            if k_v > volume:
                                traded_short_open_order_dict[symbol][k] = k_v - volume
                                volume = 0
                            break
        elif side == SHORT_SIDE:
            key_copy_long = tuple(traded_long_open_order_dict[symbol].keys())
            if key_copy_long:
                for k in sorted(key_copy_long):
                    if volume > 0:
                        if traded_long_open_order_dict[symbol][k] == 0.0:
                            del traded_long_open_order_dict[symbol][k]
                            continue

                        if volume > traded_long_open_order_dict[symbol][k]:
                            volume -= traded_long_open_order_dict[symbol][k]
                            del traded_long_open_order_dict[symbol][k]
                        elif volume == traded_long_open_order_dict[symbol][k]:
                            del traded_long_open_order_dict[symbol][k]
                            volume = 0
                            break
                        else:
                            k_v = traded_long_open_order_dict[symbol][k]
                            if k_v > volume:
                                traded_long_open_order_dict[symbol][k] = k_v - volume
                                volume = 0
                            break

"""
"   Desc: Get close voluem from an open order dict
"""
def get_close_volume_from_dict(symbol, side, price, pricetick):
    global traded_long_open_order_dict, traded_short_open_order_dict

    close_volume = 0
    if side == LONG_SIDE:
        key_copy_short = tuple(traded_short_open_order_dict[symbol].keys())
        if key_copy_short:
            for k in sorted(key_copy_short, reverse=True):
                if k - pricetick >= price:
                    if traded_short_open_order_dict[symbol][k] == 0.0:
                        del traded_short_open_order_dict[symbol][k]
                    else:
                        close_volume += traded_short_open_order_dict[symbol][k]
    elif side == SHORT_SIDE:
        key_copy_long = tuple(traded_long_open_order_dict[symbol].keys())
        if key_copy_long:
            for k in sorted(key_copy_long):
                if k + pricetick <= price:
                    if traded_long_open_order_dict[symbol][k] == 0.0:
                        del traded_long_open_order_dict[symbol][k]
                    else:
                        close_volume += traded_long_open_order_dict[symbol][k]

    return close_volume

"""
"   Desc: Write a traded info to a log file
"""
def write_tradedinfo_to_file(exchange, symbol):
    global total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, last_traded_long_open_price, last_traded_short_open_price, last_traded_long_close_price, last_traded_short_close_price, long_open_traded_min_price, short_open_traded_max_price, long_open_count, short_open_count, long_close_count, short_close_count

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{total_amount}, {total_runtime}, {start_balance}, {max_balance}, {min_balance}, {maker_rebate}, {taker_fee}, {last_traded_long_open_price}, {last_traded_short_open_price}, {last_traded_long_close_price}, {last_traded_short_close_price}, {long_open_traded_min_price}, {short_open_traded_max_price}, {long_open_count}, {short_open_count}, {long_close_count}, {short_close_count}'
        f.write(traded_info)

"""
"   Desc: Read a traded info from a log file
"""
def read_tradedinfo_from_file(exchange, symbol):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, last_traded_long_open_price, last_traded_short_open_price, last_traded_long_close_price, last_traded_short_close_price, long_open_traded_min_price, short_open_traded_max_price, long_open_count, short_open_count, long_close_count, short_close_count

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_amount = 0
            total_runtime = 0
            start_balance = 0
            max_balance = 0
            min_balance = 0
            maker_rebate = 0
            taker_fee = 0
            last_traded_long_open_price = 0
            last_traded_short_open_price = 0
            last_traded_long_close_price = 0
            last_traded_short_close_price = 0
            long_open_traded_min_price = 0
            short_open_traded_max_price = 0
            long_open_count = 0
            short_open_count = 0
            long_close_count = 0
            short_close_count = 0
        else:
            total_amount = float(data.split(', ')[0].strip())
            total_runtime = float(data.split(', ')[1].strip())
            start_balance = float(data.split(', ')[2].strip())
            max_balance = float(data.split(', ')[3].strip())
            min_balance = float(data.split(', ')[4].strip())
            maker_rebate = float(data.split(', ')[5].strip())
            taker_fee = float(data.split(', ')[6].strip())
            last_traded_long_open_price = float(data.split(', ')[7].strip())
            last_traded_short_open_price = float(data.split(', ')[8].strip())
            last_traded_long_close_price = float(data.split(', ')[9].strip())
            last_traded_short_close_price = float(data.split(', ')[10].strip())
            long_open_traded_min_price = float(data.split(', ')[11].strip())
            short_open_traded_max_price = float(data.split(', ')[12].strip())
            long_open_count = int(data.split(', ')[13].strip())
            short_open_count = int(data.split(', ')[14].strip())
            long_close_count = int(data.split(', ')[15].strip())
            short_close_count = int(data.split(', ')[16].strip())

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_to_file(exchange, symbol):
    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'0')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_from_file(exchange, symbol):
    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

"""
"   Desc: Read a parameters from a start file
"""
def read_parameters_from_file(exchange, symbol):
    global LONG_OPEN_TICK_VOLUME, SHORT_OPEN_TICK_VOLUME, LONG_CLOSE_TICK_VOLUME_RATE, SHORT_CLOSE_TICK_VOLUME_RATE, GRID_TICKSIZE, DAILY_PROFIT_PERCENT, RISK_LEVERAGE, CLOSE_RATE, POSITION_STATUS_CHECK_INTERVAL_TIME, ADDED_BALANCE, PNL_RATE

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            LONG_OPEN_TICK_VOLUME = 0
            SHORT_OPEN_TICK_VOLUME = 0
            LONG_CLOSE_TICK_VOLUME_RATE = 0
            SHORT_CLOSE_TICK_VOLUME_RATE = 0
            GRID_TICKSIZE = 0
            DAILY_PROFIT_PERCENT = 0
            RISK_LEVERAGE = 0
            CLOSE_RATE = 0
            POSITION_STATUS_CHECK_INTERVAL_TIME = 0
            ADDED_BALANCE = 0
            PNL_RATE = 0
        else:
            LONG_OPEN_TICK_VOLUME = float(data.split(', ')[0].strip())
            SHORT_OPEN_TICK_VOLUME = float(data.split(', ')[1].strip())
            LONG_CLOSE_TICK_VOLUME_RATE = float(data.split(', ')[2].strip())
            SHORT_CLOSE_TICK_VOLUME_RATE = float(data.split(', ')[3].strip())
            GRID_TICKSIZE = int(data.split(', ')[4].strip())
            DAILY_PROFIT_PERCENT = float(data.split(', ')[5].strip())
            RISK_LEVERAGE = float(data.split(', ')[6].strip())
            CLOSE_RATE = float(data.split(', ')[7].strip())
            POSITION_STATUS_CHECK_INTERVAL_TIME = int(data.split(', ')[8].strip())
            ADDED_BALANCE = float(data.split(', ')[9].strip())
            PNL_RATE = float(data.split(', ')[10].strip())

"""
"   Desc: Write parameters to a log file
"""
def write_parameters_to_file(exchange, symbol):
    global LONG_OPEN_TICK_VOLUME, SHORT_OPEN_TICK_VOLUME, LONG_CLOSE_TICK_VOLUME_RATE, SHORT_CLOSE_TICK_VOLUME_RATE, GRID_TICKSIZE, DAILY_PROFIT_PERCENT, RISK_LEVERAGE, CLOSE_RATE, POSITION_STATUS_CHECK_INTERVAL_TIME, ADDED_BALANCE, PNL_RATE

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        parameters = f'{LONG_OPEN_TICK_VOLUME}, {SHORT_OPEN_TICK_VOLUME}, {LONG_CLOSE_TICK_VOLUME_RATE}, {SHORT_CLOSE_TICK_VOLUME_RATE}, {GRID_TICKSIZE}, {DAILY_PROFIT_PERCENT}, {RISK_LEVERAGE}, {CLOSE_RATE}, {POSITION_STATUS_CHECK_INTERVAL_TIME}, {ADDED_BALANCE}, {PNL_RATE}'
        f.write(parameters)

####### Rest API Section #######
SYMBOL = str(sys.argv[1:][0])
if "USDC" in SYMBOL:
    QUOTE_COIN = BinanceConstant.QUOTE_USDC.value

base_coin = SYMBOL.replace(QUOTE_COIN, "")

read_tradedinfo_from_file(EXCHANGE, SYMBOL)

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
for symbol in list(contracts):
    if symbol == SYMBOL:
        contract = contracts[symbol]
        fee_rate = binance_futures_rest_api.get_commission_rate(symbol)
        fee_rates[symbol] = fee_rate
    else:
        del contracts[symbol]

wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = binance_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(5)

if start_balance == 0:
    start_balance = balance

if min_balance == 0:
    min_balance = start_balance

if max_balance == 0:
    max_balance = start_balance

multi_asset_mode = binance_futures_rest_api.get_multi_asset_mode()
if not multi_asset_mode:
    binance_futures_rest_api.change_multi_asset_mode()

position_mode = binance_futures_rest_api.get_position_mode()
if not position_mode:
    binance_futures_rest_api.switch_position_mode()

if contracts:
    for symbol in list(contracts):
        contract = contracts[symbol]
        positions[symbol] = {}
        _positions = binance_futures_rest_api.get_symbol_positions(symbol)
        if _positions:
            set_leverage_symbol = ""
            for position_value in _positions.values():
                for position in position_value.values():
                    margin_type = position["margin_type"]
                    if margin_type == BinanceConstant.ISOLATED.value:
                        binance_futures_rest_api.change_margin_type(symbol, BinanceConstant.CROSSED.value)

                    leverage = position["leverage"]
                    max_leverage = int(binance_futures_rest_api.get_leverage(symbol))
                    if leverage < max_leverage and symbol != set_leverage_symbol:
                        binance_futures_rest_api.change_leverage(symbol, max_leverage)
                        set_leverage_symbol = symbol

                    position_side = position["side"]
                    positions[symbol][position_side] = position

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks, bid_price_1, ask_price_1
        message = json.loads(message)
        if message:
            symbol = message["s"]
            if symbol == SYMBOL:
                tick = {}
                tick["exchange"] = EXCHANGE
                tick["symbol"] = symbol
                tick["bid_price_1"] = float(message["b"])
                tick["bid_volume_1"] = float(message["B"])
                tick["ask_price_1"] = float(message["a"])
                tick["ask_volume_1"] = float(message["A"])

                ticks[symbol] = tick

                bid_price_1 = ticks[symbol]["bid_price_1"]
                ask_price_1 = ticks[symbol]["ask_price_1"]

# Traded Websocket Thread
class TradeWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("TradeWebsocket's Connection Opened.")

    def on_close(self, ws):
        print("TradeWebsocket's Connection Closed.")

    def on_error(self, ws, error):
        print("TradeWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, total_amount, traded_count, current_traded_amount, maker_rebate, taker_fee, last_traded_long_open_price, last_traded_short_open_price, last_traded_long_close_price, last_traded_short_close_price, long_open_traded_min_price, short_open_traded_max_price, long_open_count, short_open_count, long_close_count, short_close_count

        if message:
            message = json.loads(message)
            event = message["e"]
            if event == "ACCOUNT_UPDATE":
                for coin in message["a"]["B"]:
                    wallet = {}

                    wallet["exchange"] = EXCHANGE
                    wallet["asset"] = coin["a"]
                    wallet["balance"] = float(coin["wb"])

                    wallets[coin["a"]] = wallet

                for position_data in message["a"]["P"]:
                    if position_data["ps"] != "BOTH":
                        position = {}

                        if position_data["s"] == SYMBOL:
                            position["exchange"] = EXCHANGE
                            position["symbol"] = position_data["s"]
                            position["side"] = position_data["ps"]
                            position["size"] = abs(float(position_data["pa"]))
                            position["entry_price"] = float(position_data["ep"])
                            position["unreal_pnl"] = float(position_data["up"])
                            position["value"] = abs(float(position_data["pa"])) * float(position_data["ep"])

                            if position["symbol"] not in positions.keys():
                                positions[position["symbol"]] = {}

                            symbol = position["symbol"]
                            position_side = position["side"]
                            positions[symbol][position_side] = position
            elif event == "ORDER_TRADE_UPDATE":
                order_data = message["o"]
                symbol = order_data["s"]
                if symbol == SYMBOL:
                    order_id = order_data["i"]
                    side = order_data["S"]
                    pos_side = order_data["ps"]
                    price = float(order_data["p"])
                    status = order_data["X"]
                    execution_type = order_data["x"]
                    volume = float(order_data["q"])
                    order_type = order_data["ot"]
                    filled_price = float(order_data["L"])

                    l_position_size = positions[symbol][LONG_POS]["size"]
                    s_position_size = positions[symbol][SHORT_POS]["size"]
                    l_position_entry_price = positions[symbol][LONG_POS]["entry_price"]
                    s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"]

                    diff_pricetick_size = "N/A"
                    if status == BinanceConstant.ALLTRADED.value:
                        traded_count += 1

                        if order_type == BinanceConstant.LIMIT.value:
                            maker_rebate += maker_fee_rate * filled_price * volume
                        elif order_type == BinanceConstant.MARKET.value:
                            taker_fee += taker_fee_rate * filled_price * volume

                        if side == LONG_SIDE:
                            if pos_side == LONG_POS:
                                update_order_dict(symbol, LONG_SIDE, Utils.round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 0)
                                last_traded_long_open_price = filled_price
                                last_traded_short_close_price = 0
                                long_open_traded_min_price = min(filled_price, long_open_traded_min_price) if long_open_traded_min_price else filled_price
                                long_open_count += 1
                                short_close_count = 0
                            elif pos_side == SHORT_POS:
                                update_order_dict(symbol, LONG_SIDE, Utils.round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 1)
                                last_traded_long_close_price = filled_price
                                last_traded_short_open_price = 0
                                long_close_count += 1
                                short_open_count = 0
                                diff_pricetick_size = str(int((s_position_entry_price - filled_price) / pricetick))
                        elif side == SHORT_SIDE:
                            if pos_side == LONG_POS:
                                update_order_dict(symbol, SHORT_SIDE, Utils.round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 1)
                                last_traded_short_close_price = filled_price
                                last_traded_long_open_price = 0
                                diff_pricetick_size = str(int((filled_price - l_position_entry_price) / pricetick))
                                short_close_count += 1
                                long_open_count = 0
                            elif pos_side == SHORT_POS:
                                update_order_dict(symbol, SHORT_SIDE, Utils.round_to(filled_price, pricetick), Utils.round_to(volume, round_volume), 0)
                                last_traded_short_open_price = filled_price
                                last_traded_long_close_price = 0
                                short_open_traded_max_price = max(filled_price, short_open_traded_max_price) if short_open_traded_max_price else filled_price
                                short_open_count += 1
                                long_close_count = 0

                        traded_volume = filled_price * abs(volume)
                        total_amount += traded_volume
                        current_traded_amount += traded_volume

                        title = f'{base_coin}'
                        date_time = Utils.get_current_time_mdhm()
                        direction_offset = DIRECTION_OFFSET[side][pos_side]

                        log_txt = f'{traded_count: >8}{title: >8}{order_type: >8}{direction_offset: >16}{Utils.round_to(l_position_size, round_volume): >12} / {Utils.round_to(s_position_size, round_volume): <12}{Utils.round_to(long_pos_pnl_value, pricetick): >12} / {Utils.round_to(short_pos_pnl_value, pricetick): <12}{Utils.round_to(l_position_entry_price, pricetick): >12} / {Utils.round_to(s_position_entry_price, pricetick): <12}{diff_pricetick_size: >6}{Utils.round_to(filled_price, pricetick): >12}{Utils.round_to(volume, round_volume): >12}{round(current_traded_amount, 2): >16}{int(current_runtime): >8}{round(balance, 2): >12}{date_time: >18}'
                        print(log_txt)

                        log_file_name = Utils.get_current_time_mdh()
                        write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)

# orderbook websocket thread start
bookticker_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + BinanceConstant.F_WEBSOCKET_BOOK_TICKERS_STREAM_PARAM.value
orderbook_websocket_thread = OrderbookWebsocketThread(bookticker_url, False, False)
orderbook_websocket_thread.start()

# trade websocket thread start
listen_key = binance_futures_rest_api.get_new_listen_key()
USER_STREAM_STARTTIME = time()

trade_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + listen_key
trade_websocket_thread = TradeWebsocketThread(trade_url, False, False)
trade_websocket_thread.start()

read_process_status_signal_from_file(EXCHANGE, SYMBOL)

sleep(5)

LONG_OPEN_TICK_VOLUME = float(sys.argv[1:][1])
SHORT_OPEN_TICK_VOLUME = float(sys.argv[1:][2])
LONG_CLOSE_TICK_VOLUME_RATE = float(sys.argv[1:][3])
SHORT_CLOSE_TICK_VOLUME_RATE = float(sys.argv[1:][4])
GRID_TICKSIZE = int(sys.argv[1:][5])
DAILY_PROFIT_PERCENT = float(sys.argv[1:][6])
RISK_LEVERAGE = float(sys.argv[1:][7])
CLOSE_RATE = float(sys.argv[1:][8])
POSITION_STATUS_CHECK_INTERVAL_TIME = int(sys.argv[1:][9])
ADDED_BALANCE = float(sys.argv[1:][10])
PNL_RATE = float(sys.argv[1:][11])

write_parameters_to_file(EXCHANGE, SYMBOL)

CLS_TIME = time()
TRADED_INFO_TIME = time()
ACCOUNT_STATUS_CHECK_TIME = time()
POSITION_STATUS_CHECK_TIME = time()

print(f'==================================================')
print(balance, fee_rates[SYMBOL]["maker_fee_rate"], fee_rates[SYMBOL]["taker_fee_rate"])
print(f'==================================================')

start_time = time()
last_runtime = total_runtime

RUNNING_STATUS = True
while RUNNING_STATUS:
    read_parameters_from_file(EXCHANGE, SYMBOL)

    current_runtime = round((time() - start_time) / 60)
    if (time() - USER_STREAM_STARTTIME) >= BinanceConstant.USER_STREAM_TIMEOUT.value:
        binance_futures_rest_api.renew_listen_key(listen_key)
        USER_STREAM_STARTTIME = time()

    for symbol in list(contracts):
        sleep(0.5)

        # <!--- check some parameters for market/trade/account
        contract = contracts[symbol]
        if symbol not in ticks.keys():
            continue

        balance = wallets[QUOTE_COIN]["balance"]
        if balance > max_balance:
            max_balance = balance

        if balance < min_balance:
            min_balance = balance

        # <!--- get all values for trading
        round_volume = contract["round_volume"]
        min_volume = contract["min_order_qty"]
        max_volume = contract["max_order_qty"]
        pricetick = contract["pricetick"]
        notional_value = contract["notional"]

        maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
        taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]

        if symbol not in traded_long_open_order_dict.keys():
            read_dict_from_file(EXCHANGE, symbol, LONG_SIDE)

        if symbol not in traded_short_open_order_dict.keys():
            read_dict_from_file(EXCHANGE, symbol, SHORT_SIDE)
        # --->

        # <!--- calc tick volume and grid ticksize
        open_min_volume = 1.1 * notional_value / ask_price_1
        long_open_tick_volume = max(LONG_OPEN_TICK_VOLUME, open_min_volume, min_volume)
        short_open_tick_volume = max(SHORT_OPEN_TICK_VOLUME, open_min_volume, min_volume)
        long_close_tick_volume = max(short_open_tick_volume * LONG_CLOSE_TICK_VOLUME_RATE, min_volume)
        short_close_tick_volume = max(long_open_tick_volume * SHORT_CLOSE_TICK_VOLUME_RATE, min_volume)
        grid_ticksize = GRID_TICKSIZE if maker_fee_rate <=0 else max(GRID_TICKSIZE, round(2 * ask_price_1 * maker_fee_rate / pricetick))
        # -->

        open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
        open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

        # sending orders
        open_orders = binance_futures_rest_api.get_open_orders(symbol)
        for new_side in (LONG_SIDE, SHORT_SIDE):
            for new_position_side in (LONG_POS, SHORT_POS):
                new_price, new_volume = 0, 0

                bid_price_1 = ticks[symbol]["bid_price_1"]
                ask_price_1 = ticks[symbol]["ask_price_1"]

                open_order_ids[new_side][new_position_side] = ''
                open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                # new price
                if new_side == LONG_SIDE:
                    new_price = Utils.round_to(bid_price_1, pricetick)
                elif new_side == SHORT_SIDE:
                    new_price = Utils.round_to(ask_price_1, pricetick)

                if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                    open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                    open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                    open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                long_pos_size = positions[symbol][LONG_POS]["size"]
                long_pos_entry_price = positions[symbol][LONG_POS]["entry_price"]
                long_pos_pnl_value = (ask_price_1 - long_pos_entry_price) * long_pos_size if long_pos_size else 0
                if not long_pos_size:
                    traded_long_open_order_dict[symbol] = {}
                    long_open_traded_min_price = 0
                    long_open_count = 0
                    short_close_count = 0
                    last_traded_long_open_price = 0
                    last_traded_short_close_price = 0

                short_pos_size = positions[symbol][SHORT_POS]["size"]
                short_pos_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                short_pos_pnl_value = (short_pos_entry_price - bid_price_1) * short_pos_size if short_pos_size else 0
                if not short_pos_size:
                    traded_short_open_order_dict[symbol] = {}
                    short_open_traded_max_price = 0
                    short_open_count = 0
                    long_close_count = 0
                    last_traded_short_open_price = 0
                    last_traded_long_close_price = 0

                long_open_traded_min_max_price['min'] = min(traded_long_open_order_dict[symbol].keys()) if traded_long_open_order_dict[symbol] else 0
                long_open_traded_min_max_price['max'] = max(traded_long_open_order_dict[symbol].keys()) if traded_long_open_order_dict[symbol] else 0
                long_open_traded_min_max_distance = long_open_traded_min_max_price['max'] - long_open_traded_min_max_price['min']

                short_open_traded_min_max_price['max'] = max(traded_short_open_order_dict[symbol].keys()) if traded_short_open_order_dict[symbol] else 0
                short_open_traded_min_max_price['min'] = min(traded_short_open_order_dict[symbol].keys()) if traded_short_open_order_dict[symbol] else 0
                short_open_traded_min_max_distance = short_open_traded_min_max_price['max'] - short_open_traded_min_max_price['min']

                if new_side == LONG_SIDE:
                    if new_position_side == LONG_POS:
                        if long_pos_size:
                            if long_pos_pnl_value < 0:
                                grid_ticksize = grid_ticksize * (1 + abs(long_pos_pnl_value) / (start_balance * PNL_RATE))

                            # price
                            if last_traded_long_open_price:
                                tick_rate = 5 if long_pos_size > short_pos_size else 1
                                new_price = Utils.round_to(last_traded_long_open_price - tick_rate * (long_open_count + long_close_count + 1) * grid_ticksize * pricetick, pricetick)
                            elif last_traded_short_close_price:
                                new_price = Utils.round_to(last_traded_short_close_price - grid_ticksize * pricetick, pricetick)

                            if new_price > bid_price_1:
                                new_price = Utils.round_to(bid_price_1, pricetick)

                            # volume
                            if long_pos_size > short_pos_size and new_price > long_open_traded_min_price - grid_ticksize * pricetick:
                                new_volume = 0
                            else:
                                if new_price <= long_open_traded_min_max_price['min'] - grid_ticksize * pricetick:
                                    if last_traded_long_open_price:
                                        new_volume = long_open_tick_volume * (last_traded_long_open_price - new_price) / (grid_ticksize * pricetick)
                                    elif last_traded_short_close_price:
                                        new_volume = long_open_tick_volume
                                else:
                                    new_volume = 0
                        else:
                            new_volume = long_open_tick_volume
                    elif new_position_side == SHORT_POS:
                        if short_pos_size:
                            if short_pos_pnl_value < 0:
                                grid_ticksize = grid_ticksize * (1 + abs(short_pos_pnl_value) / (start_balance * PNL_RATE))

                            # price
                            if last_traded_short_open_price:
                                new_price = Utils.round_to(last_traded_short_open_price - grid_ticksize * pricetick, pricetick)
                            elif last_traded_long_close_price:
                                new_price = Utils.round_to(last_traded_long_close_price - grid_ticksize * pricetick, pricetick)

                            if new_price > bid_price_1:
                                new_price = Utils.round_to(bid_price_1, pricetick)

                            # volume
                            if short_pos_size < long_pos_size - long_open_tick_volume:
                                if new_price < short_pos_entry_price:
                                    c_v = get_close_volume_from_dict(symbol, LONG_SIDE, new_price, grid_ticksize * pricetick)
                                    if last_traded_short_open_price:
                                        new_volume = min(c_v, long_close_tick_volume)
                                    elif last_traded_long_close_price:
                                        new_volume = min(c_v, long_close_tick_volume * (last_traded_long_close_price - new_price) / (grid_ticksize * pricetick))
                            else:
                                c_v = get_close_volume_from_dict(symbol, LONG_SIDE, new_price, grid_ticksize * pricetick)
                                if last_traded_short_open_price:
                                    new_volume = min(c_v, long_close_tick_volume)
                                elif last_traded_long_close_price:
                                    new_volume = min(c_v, long_close_tick_volume * (last_traded_long_close_price - new_price) / (grid_ticksize * pricetick))

                            if not traded_short_open_order_dict[symbol]:
                                if new_price < short_pos_entry_price:
                                    new_volume = long_close_tick_volume * (short_pos_entry_price - new_price) / (grid_ticksize * pricetick)

                            new_volume = min(new_volume, short_pos_size)
                elif new_side == SHORT_SIDE:
                    if new_position_side == SHORT_POS:
                        if short_pos_size:
                            if short_pos_pnl_value < 0:
                                grid_ticksize = grid_ticksize * (1 + abs(short_pos_pnl_value) / (start_balance * PNL_RATE))

                            # price
                            if last_traded_short_open_price:
                                tick_rate = 5 if short_pos_size > long_pos_size else 1
                                new_price = Utils.round_to(last_traded_short_open_price + tick_rate * (short_open_count + short_close_count + 1) * grid_ticksize * pricetick, pricetick)
                            elif last_traded_long_close_price:
                                new_price = Utils.round_to(last_traded_long_close_price + grid_ticksize * pricetick, pricetick)

                            if new_price < ask_price_1:
                                new_price = Utils.round_to(ask_price_1, pricetick)

                            # volume
                            if short_pos_size > long_pos_size and new_price < short_open_traded_max_price + grid_ticksize * pricetick:
                                new_volume = 0
                            else:
                                if new_price >= short_open_traded_min_max_price['max'] + grid_ticksize * pricetick:
                                    if last_traded_short_open_price:
                                        new_volume = short_open_tick_volume * (new_price - last_traded_short_open_price) / (grid_ticksize * pricetick)
                                    elif last_traded_long_close_price:
                                        new_volume = short_open_tick_volume
                                else:
                                    new_volume = 0
                        else:
                            new_volume = short_open_tick_volume
                    elif new_position_side == LONG_POS:
                        if long_pos_size:
                            if long_pos_pnl_value < 0:
                                grid_ticksize = grid_ticksize * (1 + abs(long_pos_pnl_value) / (start_balance * PNL_RATE))

                            # price
                            if last_traded_long_open_price:
                                new_price = Utils.round_to(last_traded_long_open_price + grid_ticksize * pricetick, pricetick)
                            elif last_traded_short_close_price:
                                new_price = Utils.round_to(last_traded_short_close_price + grid_ticksize * pricetick, pricetick)

                            if new_price < ask_price_1:
                                new_price = Utils.round_to(ask_price_1, pricetick)

                            # volume
                            if long_pos_size < short_pos_size - short_open_tick_volume:
                                if new_price > long_pos_entry_price:
                                    c_v = get_close_volume_from_dict(symbol, SHORT_SIDE, new_price, grid_ticksize * pricetick)
                                    if last_traded_long_open_price:
                                        new_volume = min(c_v, short_close_tick_volume)
                                    elif last_traded_short_close_price:
                                        new_volume = min(c_v, short_close_tick_volume * (new_price - last_traded_short_close_price) / (grid_ticksize * pricetick))
                            else:
                                c_v = get_close_volume_from_dict(symbol, SHORT_SIDE, new_price, grid_ticksize * pricetick)
                                if last_traded_long_open_price:
                                    new_volume = min(c_v, short_close_tick_volume)
                                elif last_traded_short_close_price:
                                    new_volume = min(c_v, short_close_tick_volume * (new_price - last_traded_short_close_price) / (grid_ticksize * pricetick))

                            if not traded_long_open_order_dict[symbol]:
                                if new_price > long_pos_entry_price:
                                    new_volume = short_close_tick_volume * (new_price - long_pos_entry_price) / (grid_ticksize * pricetick)

                            new_volume = min(new_volume, long_pos_size)

                new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                if open_order_ids[new_side][new_position_side]:
                    open_order_id = open_order_ids[new_side][new_position_side]
                    old_price = open_order_info[new_side][new_position_side]["price"]
                    old_volume = open_order_info[new_side][new_position_side]["volume"]

                    if old_volume != new_volume or old_price != new_price:
                        binance_futures_rest_api.cancel_order(symbol, open_order_id)

                    continue

                if new_price and new_volume:
                    response = binance_futures_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_side)
                    if response and "insufficient" in str(response):
                        print(f'Insufficient Error: Close some of positions... ... ...')
                        binance_futures_rest_api.cancel_all_orders(symbol)

                        read_parameters_from_file(EXCHANGE, SYMBOL)

                        original_long_pos_size = positions[symbol][LONG_POS]["size"]
                        original_long_position_pnl = positions[symbol][LONG_POS]["unreal_pnl"]

                        original_short_pos_size = positions[symbol][SHORT_POS]["size"]
                        original_short_position_pnl = positions[symbol][SHORT_POS]["unreal_pnl"]

                        close_all_pos_direction = LONG_POS
                        close_volume = original_short_pos_size / CLOSE_RATE
                        if original_long_position_pnl < original_short_position_pnl:
                            close_all_pos_direction = SHORT_POS
                            close_volume = original_long_pos_size / CLOSE_RATE

                        long_pos_size = 0
                        short_pos_size = 0
                        while True:
                            for symbol in list(contracts):
                                sleep(0.5)

                                open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
                                open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

                                # sending orders
                                open_orders = binance_futures_rest_api.get_open_orders(symbol)
                                for new_side in (LONG_SIDE, SHORT_SIDE):
                                    for new_position_side in (LONG_POS, SHORT_POS):
                                        new_price, new_volume = 0, 0

                                        bid_price_1 = ticks[symbol]["bid_price_1"]
                                        ask_price_1 = ticks[symbol]["ask_price_1"]

                                        open_order_ids[new_side][new_position_side] = ''
                                        open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                                        # new price
                                        if new_side == LONG_SIDE:
                                            new_price = Utils.round_to(bid_price_1, pricetick)
                                        elif new_side == SHORT_SIDE:
                                            new_price = Utils.round_to(ask_price_1, pricetick)

                                        if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                                            open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                                            open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                                            open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                                        long_pos_size = positions[symbol][LONG_POS]["size"]
                                        short_pos_size = positions[symbol][SHORT_POS]["size"]

                                        if new_side == LONG_SIDE:
                                            if new_position_side == SHORT_POS:
                                                if short_pos_size:
                                                    new_volume = short_pos_size if close_all_pos_direction == SHORT_POS else (short_pos_size - (original_short_pos_size - close_volume))
                                        elif new_side == SHORT_SIDE:
                                            if new_position_side == LONG_POS:
                                                if long_pos_size:
                                                    new_volume = long_pos_size if close_all_pos_direction == LONG_POS else (long_pos_size - (original_long_pos_size - close_volume))

                                        new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                                        if open_order_ids[new_side][new_position_side]:
                                            open_order_id = open_order_ids[new_side][new_position_side]
                                            old_price = open_order_info[new_side][new_position_side]["price"]
                                            old_volume = open_order_info[new_side][new_position_side]["volume"]

                                            if old_volume != new_volume or old_price != new_price:
                                                binance_futures_rest_api.cancel_order(symbol, open_order_id)

                                            continue

                                        if new_price and new_volume:
                                            response = binance_futures_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_side)

                            if close_all_pos_direction == LONG_POS:
                                if long_pos_size == 0 and short_pos_size <= original_short_pos_size + min_volume - close_volume:
                                    log_txt = f'Restarting...'
                                    print(log_txt)
                                    log_file_name = Utils.get_current_time_mdh()
                                    write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)
                                    break
                            else:
                                if short_pos_size == 0 and long_pos_size <= original_long_pos_size + min_volume - close_volume:
                                    log_txt = f'Restarting...'
                                    print(log_txt)
                                    log_file_name = Utils.get_current_time_mdh()
                                    write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)
                                    break

    if time() - CLS_TIME > CLS_INTERVAL_TIME:
        os.system('cls')
        CLS_TIME = time()

    if time() - TRADED_INFO_TIME > TRADED_INFO_INTERVAL_TIME:
        print(f"|==========================================================================================================================================================================================================================|")
        print(f'|{TRADED_INFO_TITLE[0]: >26}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >27}{TRADED_INFO_TITLE[4]: >32}{TRADED_INFO_TITLE[5]: >24}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18}{TRADED_INFO_TITLE[8]: >18} |')
        print(f'|           ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|')
        total_runtime = last_runtime + current_runtime
        runtime_minutes = round(total_runtime)
        runtime_hours = round(total_runtime / 60, 1)
        runtime_days = round(total_runtime / 1440, 2)
        runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'

        predict_dailty_trade_amt = round(total_amount / (total_runtime / 1440), 1) if total_runtime > 1 else 0
        predict_daily_trade_leverage = round((total_amount / (total_runtime / 1440)) / balance, 1) if total_runtime > 1 else 0
        predict_dailty_trade_amt_leverage = f'{predict_dailty_trade_amt}/{predict_daily_trade_leverage}'

        profit = round(balance - start_balance - ADDED_BALANCE, 2)
        profit_percent = f'{round((profit / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0

        rebate_fee = f'{round(maker_rebate, 2)}/{round(taker_fee, 2)}'
        print(f'| {runtime: >24}{predict_dailty_trade_amt_leverage: >27}{profit_percent: >27}{profit: >27}{round(total_amount, 3): >32}{rebate_fee: >24}{round(balance, 2): >18}{round(max_balance, 2): >18}{round(min_balance, 2): >18}  |')
        print(f'|==========================================================================================================================================================================================================================|')

        TRADED_INFO_TIME = time()

    if current_runtime > 10 and time() - POSITION_STATUS_CHECK_TIME > POSITION_STATUS_CHECK_INTERVAL_TIME:
        POSITION_STATUS_CHECK_TIME = time()

        read_parameters_from_file(EXCHANGE, SYMBOL)

        bid_price_1 = ticks[SYMBOL]["bid_price_1"]
        ask_price_1 = ticks[SYMBOL]["ask_price_1"]

        original_long_pos_size = positions[SYMBOL][LONG_POS]["size"]
        long_pos_entry_price = positions[SYMBOL][LONG_POS]["entry_price"]
        long_pos_pnl_value = (ask_price_1 - long_pos_entry_price) * original_long_pos_size if original_long_pos_size else 0

        original_short_pos_size = positions[SYMBOL][SHORT_POS]["size"]
        short_pos_entry_price = positions[SYMBOL][SHORT_POS]["entry_price"]
        short_pos_pnl_value = (short_pos_entry_price - bid_price_1) * original_short_pos_size if original_short_pos_size else 0

        if original_long_pos_size > RISK_LEVERAGE * min(LONG_OPEN_TICK_VOLUME, SHORT_OPEN_TICK_VOLUME) or original_short_pos_size > RISK_LEVERAGE * min(LONG_OPEN_TICK_VOLUME, SHORT_OPEN_TICK_VOLUME):
            daily_profit_percent = 0
            close_all_pos_direction = ''
            close_volume = 0
            if long_pos_pnl_value >= 0:
                close_volume = original_short_pos_size / CLOSE_RATE
                close_all_pos_direction = LONG_POS
                daily_profit_percent = ((balance - start_balance - ADDED_BALANCE + long_pos_pnl_value + short_pos_pnl_value / CLOSE_RATE) / (start_balance * (total_runtime / 1440))) * 100 if total_runtime > 10 else 0
            elif short_pos_pnl_value >= 0:
                close_volume = original_long_pos_size / CLOSE_RATE
                close_all_pos_direction = SHORT_POS
                daily_profit_percent = ((balance - start_balance - ADDED_BALANCE + short_pos_pnl_value + long_pos_pnl_value / CLOSE_RATE) / (start_balance * (total_runtime / 1440))) * 100 if total_runtime > 10 else 0

            if daily_profit_percent >= DAILY_PROFIT_PERCENT:
                print(f'Managing position risk automatically: Close some of positions... ... ...')

                binance_futures_rest_api.cancel_all_orders(SYMBOL)

                long_pos_size = 0
                short_pos_size = 0
                while True:
                    for symbol in list(contracts):
                        sleep(0.5)

                        open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
                        open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

                        # sending orders
                        open_orders = binance_futures_rest_api.get_open_orders(symbol)
                        for new_side in (LONG_SIDE, SHORT_SIDE):
                            for new_position_side in (LONG_POS, SHORT_POS):
                                new_price, new_volume = 0, 0

                                bid_price_1 = ticks[symbol]["bid_price_1"]
                                ask_price_1 = ticks[symbol]["ask_price_1"]

                                open_order_ids[new_side][new_position_side] = ''
                                open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                                # new price
                                if new_side == LONG_SIDE:
                                    new_price = Utils.round_to(bid_price_1, pricetick)
                                elif new_side == SHORT_SIDE:
                                    new_price = Utils.round_to(ask_price_1, pricetick)

                                if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                                    open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                                    open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                                    open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                                long_pos_size = positions[symbol][LONG_POS]["size"]
                                short_pos_size = positions[symbol][SHORT_POS]["size"]

                                if new_side == LONG_SIDE:
                                    if new_position_side == SHORT_POS:
                                        if short_pos_size:
                                            new_volume = short_pos_size if close_all_pos_direction == SHORT_POS else (short_pos_size - (original_short_pos_size - close_volume))
                                elif new_side == SHORT_SIDE:
                                    if new_position_side == LONG_POS:
                                        if long_pos_size:
                                            new_volume = long_pos_size if close_all_pos_direction == LONG_POS else (long_pos_size - (original_long_pos_size - close_volume))

                                new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                                if open_order_ids[new_side][new_position_side]:
                                    open_order_id = open_order_ids[new_side][new_position_side]
                                    old_price = open_order_info[new_side][new_position_side]["price"]
                                    old_volume = open_order_info[new_side][new_position_side]["volume"]

                                    if old_volume != new_volume or old_price != new_price:
                                        binance_futures_rest_api.cancel_order(symbol, open_order_id)

                                    continue

                                if new_price and new_volume:
                                    response = binance_futures_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_side)

                    if close_all_pos_direction == LONG_POS:
                        if long_pos_size == 0 and short_pos_size <= original_short_pos_size + min_volume - close_volume:
                            log_txt = f'Restarting...'
                            print(log_txt)
                            log_file_name = Utils.get_current_time_mdh()
                            write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)
                            break
                    else:
                        if short_pos_size == 0 and long_pos_size <= original_long_pos_size + min_volume - close_volume:
                            log_txt = f'Restarting...'
                            print(log_txt)
                            log_file_name = Utils.get_current_time_mdh()
                            write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)
                            break

    if current_runtime > 10 and time() - ACCOUNT_STATUS_CHECK_TIME > ACCOUNT_STATUS_CHECK_INTERVAL_TIME:
        PROCESS_STATUS = read_process_status_signal_from_file(EXCHANGE, SYMBOL)
        ACCOUNT_STATUS_CHECK_TIME = time()
        if PROCESS_STATUS == 1:
            print(f'Saving trade info, and exit program automatically...')
            for symbol in list(contracts):
                symbol = contract["symbol"]
                binance_futures_rest_api.cancel_all_orders(symbol)
                for new_side in (LONG_SIDE, SHORT_SIDE):
                    write_dict_to_file(EXCHANGE, symbol, new_side)

            sleep(1)

            break
        elif PROCESS_STATUS == 2:
            print(f'Managing position risk manually: Close some of positions... ... ...')
            binance_futures_rest_api.cancel_all_orders(SYMBOL)

            read_parameters_from_file(EXCHANGE, SYMBOL)

            original_long_pos_size = positions[SYMBOL][LONG_POS]["size"]
            original_long_position_pnl = positions[SYMBOL][LONG_POS]["unreal_pnl"]

            original_short_pos_size = positions[SYMBOL][SHORT_POS]["size"]
            original_short_position_pnl = positions[SYMBOL][SHORT_POS]["unreal_pnl"]

            close_all_pos_direction = LONG_POS
            close_volume = original_short_pos_size / CLOSE_RATE
            if original_long_position_pnl < original_short_position_pnl:
                close_all_pos_direction = SHORT_POS
                close_volume = original_long_pos_size / CLOSE_RATE

            long_pos_size = 0
            short_pos_size = 0
            while True:
                for symbol in list(contracts):
                    sleep(0.5)

                    bid_price_1 = ticks[symbol]["bid_price_1"]
                    ask_price_1 = ticks[symbol]["ask_price_1"]

                    open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
                    open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

                    # sending orders
                    open_orders = binance_futures_rest_api.get_open_orders(symbol)
                    for new_side in (LONG_SIDE, SHORT_SIDE):
                        for new_position_side in (LONG_POS, SHORT_POS):
                            new_price, new_volume = 0, 0

                            open_order_ids[new_side][new_position_side] = ''
                            open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                            # new price
                            if new_side == LONG_SIDE:
                                new_price = Utils.round_to(bid_price_1, pricetick)
                            elif new_side == SHORT_SIDE:
                                new_price = Utils.round_to(ask_price_1, pricetick)

                            if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                                open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                                open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                                open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                            long_pos_size = positions[symbol][LONG_POS]["size"]
                            short_pos_size = positions[symbol][SHORT_POS]["size"]

                            if new_side == LONG_SIDE:
                                if new_position_side == SHORT_POS:
                                    if short_pos_size:
                                        new_volume = short_pos_size if close_all_pos_direction == SHORT_POS else (short_pos_size - (original_short_pos_size - close_volume))
                            elif new_side == SHORT_SIDE:
                                if new_position_side == LONG_POS:
                                    if long_pos_size:
                                        new_volume = long_pos_size if close_all_pos_direction == LONG_POS else (long_pos_size - (original_long_pos_size - close_volume))

                            new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                            if open_order_ids[new_side][new_position_side]:
                                open_order_id = open_order_ids[new_side][new_position_side]
                                old_price = open_order_info[new_side][new_position_side]["price"]
                                old_volume = open_order_info[new_side][new_position_side]["volume"]

                                if old_volume != new_volume or old_price != new_price:
                                    binance_futures_rest_api.cancel_order(symbol, open_order_id)

                                continue

                            if new_price and new_volume:
                                response = binance_futures_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_side)

                if close_all_pos_direction == LONG_POS:
                    if long_pos_size == 0 and short_pos_size <= original_short_pos_size + min_volume - close_volume:
                        write_process_status_to_file(EXCHANGE, SYMBOL)
                        log_txt = f'Restarting...'
                        print(log_txt)
                        log_file_name = Utils.get_current_time_mdh()
                        write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)
                        break
                else:
                    if short_pos_size == 0 and long_pos_size <= original_long_pos_size + min_volume - close_volume:
                        write_process_status_to_file(EXCHANGE, SYMBOL)
                        log_txt = f'Restarting...'
                        print(log_txt)
                        log_file_name = Utils.get_current_time_mdh()
                        write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)
                        break
        elif PROCESS_STATUS == 3:
            print("Close all positons, and exit program automatically...")
            for symbol in list(contracts):
                contract = contracts[symbol]
                binance_futures_rest_api.cancel_all_orders(symbol)
                for close_position_side in (LONG_POS, SHORT_POS):
                    close_side = POSITION_SIDE_TO_CLOSE_SIDE[new_side]
                    close_volume = abs(positions[symbol][close_position_side]["size"])
                    binance_futures_rest_api.close_all_positions(symbol, close_side, close_volume, close_position_side)

                    traded_long_open_order_dict[symbol] = {}
                    traded_short_open_order_dict[symbol] = {}

                    write_dict_to_file(EXCHANGE, symbol, OPPOSITE_SIDE[close_side])
            break

write_tradedinfo_to_file(EXCHANGE, SYMBOL)
write_process_status_to_file(EXCHANGE, SYMBOL)

sleep(1)

print(f"Exit!")
