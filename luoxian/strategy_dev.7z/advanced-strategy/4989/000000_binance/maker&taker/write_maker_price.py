import numpy as np
import os
import os.path
import sys

traded_maker_open_price = {}
traded_maker_open_price['XRP'] = [0.18429, 0.18439, 0.18449, 0.18459, 0.18469, 0.18479, 0.18489, 0.18499]

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

def write_maker_traded_price_array_file(exchange, symbol):
    global traded_maker_open_price

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + "maker_price.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        content = str(traded_maker_open_price[symbol])
        f.write(content.replace("[", "").replace("]", ""))
        f.close()

"""
"   Desc: Read an array of maker open traded price from a txt file
"""
def read_maker_traded_price_array_file(exchange, symbol):
    global traded_maker_open_price

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + "maker_price.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r", encoding="utf8") as f:
        data = f.read().rstrip()
        if data == "":
            traded_maker_open_price[symbol] = []
        else:
            string_array = list(data.split(", "))
            traded_maker_open_price[symbol] = [float(string) for string in string_array]

write_maker_traded_price_array_file("binance", "XRP")

read_maker_traded_price_array_file("binance", "XRP")

print(traded_maker_open_price["XRP"][0] + traded_maker_open_price["XRP"][1])
