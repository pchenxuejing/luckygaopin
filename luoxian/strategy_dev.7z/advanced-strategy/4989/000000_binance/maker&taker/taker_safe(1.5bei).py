#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

import threading
import websocket

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
key = "sguwhAV1G7sHsPTuQ0gfPK8cLe1krUypRbtzkC2cMC17idTxIExUCH8mToZZk3SW"
secret = "jAWOgr4Qqt619yxuA2KgE3V2Mr6xSlrS4Vl47cRVYpqBfMm2LHLzBCSTrYxmvxXo"

# symbol_list = ['XRPUSDT', 'EOSUSDT', 'TRXUSDT', 'XLMUSDT', 'ADAUSDT', 'XMRUSDT', 'DASHUSDT', 'ZECUSDT', 'XTZUSDT', 'ATOMUSDT', 'ONTUSDT', 'IOTAUSDT', 'BATUSDT', 'VETUSDT', 'NEOUSDT', 'QTUMUSDT', 'IOSTUSDT', 'THETAUSDT', 'ALGOUSDT', 'ZILUSDT', 'KNCUSDT', 'ZRXUSDT', 'COMPUSDT', 'OMGUSDT', 'DOGEUSDT', 'SXPUSDT', 'KAVAUSDT', 'BANDUSDT', 'RLCUSDT', 'WAVESUSDT', 'MKRUSDT', 'SNXUSDT', 'DOTUSDT', 'DEFIUSDT', 'BALUSDT', 'CRVUSDT', 'SUSHIUSDT', 'ICXUSDT', 'STORJUSDT', 'BLZUSDT', 'FTMUSDT', 'ENJUSDT', 'FLMUSDT', 'RENUSDT', 'KSMUSDT', 'FILUSDT', 'RSRUSDT', 'LRCUSDT', 'MATICUSDT', 'OCEANUSDT', 'BELUSDT', 'CTKUSDT', 'ALPHAUSDT', 'ZENUSDT', 'SKLUSDT', 'GRTUSDT', '1INCHUSDT', 'CHZUSDT', 'SANDUSDT', 'ANKRUSDT', 'LITUSDT', 'UNFIUSDT', 'REEFUSDT', 'RVNUSDT', 'SFPUSDT', 'XEMUSDT', 'COTIUSDT', 'CHRUSDT', 'MANAUSDT', 'ALICEUSDT', 'HBARUSDT', 'ONEUSDT', 'LINAUSDT', 'STMXUSDT', 'DENTUSDT', 'CELRUSDT', 'HOTUSDT', 'MTLUSDT', 'OGNUSDT', 'NKNUSDT', 'DGBUSDT', '1000SHIBUSDT', 'BAKEUSDT', 'GTCUSDT', 'BTCDOMUSDT', 'IOTXUSDT', 'AUDIOUSDT', 'C98USDT', 'MASKUSDT', 'ATAUSDT', 'DYDXUSDT', '1000XECUSDT', 'GALAUSDT', 'CELOUSDT', 'ARUSDT', 'KLAYUSDT', 'ARPAUSDT', 'CTSIUSDT', 'LPTUSDT', 'ENSUSDT', 'PEOPLEUSDT', 'ANTUSDT', 'ROSEUSDT', 'DUSKUSDT', 'FLOWUSDT', 'IMXUSDT', 'API3USDT', 'GMTUSDT', 'APEUSDT', 'WOOUSDT', 'JASMYUSDT', 'DARUSDT', 'OPUSDT', 'INJUSDT', 'STGUSDT', 'SPELLUSDT', '1000LUNCUSDT', 'LUNA2USDT', 'LDOUSDT', 'CVXUSDT', 'APTUSDT', 'BLUEBIRDUSDT', 'FETUSDT', 'FXSUSDT', 'HOOKUSDT', 'MAGICUSDT', 'TUSDT', 'RNDRUSDT', 'HIGHUSDT', 'MINAUSDT', 'ASTRUSDT', 'AGIXUSDT', 'PHBUSDT', 'GMXUSDT', 'CFXUSDT', 'STXUSDT', 'BNXUSDT', 'ACHUSDT', 'SSVUSDT', 'CKBUSDT', 'PERPUSDT', 'TRUUSDT', 'LQTYUSDT', 'USDCUSDT', 'IDUSDT', 'ARBUSDT', 'JOEUSDT', 'TLMUSDT', 'AMBUSDT', 'LEVERUSDT', 'RDNTUSDT', 'HFTUSDT', 'XVSUSDT', 'BLURUSDT', 'EDUUSDT', 'IDEXUSDT', 'SUIUSDT', '1000PEPEUSDT', '1000FLOKIUSDT', 'UMAUSDT', 'RADUSDT', 'KEYUSDT', 'COMBOUSDT', 'NMRUSDT', 'MAVUSDT', 'MDTUSDT', 'XVGUSDT', 'PENDLEUSDT', 'ARKMUSDT', 'AGLDUSDT', 'YGGUSDT', 'DODOXUSDT', 'BNTUSDT', 'OXTUSDT', 'SEIUSDT', 'CYBERUSDT', 'HIFIUSDT', 'ARKUSDT', 'FRONTUSDT', 'GLMRUSDT', 'BICOUSDT', 'LOOMUSDT', 'BIGTIMEUSDT', 'BONDUSDT', 'ORBSUSDT', 'STPTUSDT', 'WAXPUSDT', 'RIFUSDT', 'POLYXUSDT', 'GASUSDT', 'POWRUSDT', 'SLPUSDT', 'SNTUSDT', 'CAKEUSDT', 'MEMEUSDT', 'TWTUSDT', 'TOKENUSDT', 'STEEMUSDT', 'NTRNUSDT', 'MBLUSDT', 'KASUSDT', 'BEAMXUSDT', '1000BONKUSDT', 'PYTHUSDT', 'SUPERUSDT', 'USTCUSDT', 'ONGUSDT', 'ETHWUSDT', 'JTOUSDT', '1000SATSUSDT', 'AUCTIONUSDT', '1000RATSUSDT', 'ACEUSDT', 'MOVRUSDT', 'NFPUSDT', 'ETHUSDT_240628', 'AIUSDT', 'XAIUSDT', 'WIFUSDT', 'MANTAUSDT', 'ONDOUSDT', 'LSKUSDT', 'ALTUSDT', 'JUPUSDT', 'ZETAUSDT', 'RONINUSDT', 'DYMUSDT', 'OMUSDT', 'PIXELUSDT', 'STRKUSDT', 'MAVIAUSDT', 'GLMUSDT', 'PORTALUSDT', 'TONUSDT', 'AXLUSDT', 'MYROUSDT', 'METISUSDT', 'AEVOUSDT', 'VANRYUSDT', 'BOMEUSDT', 'ETHFIUSDT']
symbol_list = ['XRPUSDT', 'DOGEUSDT', '1000PEPEUSDT', '1000SHIBUSDT', '1000FLOKIUSDT']

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}

tick_volume_dict = {}
grid_ticksize_dict = {}
close_count_dict = {}

# static parameters
balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_amount = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0
runtime_days = 0

maker_rebate = 0.0
taker_fee = 0.0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
OPPOSITE_SIDE: Dict[str, str] = {"BUY": "SELL", "SELL": "BUY"}
OPPOSITE_POSITION: Dict[str, str] = {"LONG": "SHORT", "SHORT": "LONG"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"BUY": "SHORT", "SELL": "LONG"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"LONG": "SELL", "SHORT": "BUY"}
DIRECTION_OFFSET = {"BUY": {"LONG": "LONG_OPEN", "SHORT": "LONG_CLOSE"}, "SELL":{"LONG": "SHORT_CLOSE", "SHORT": "SHORT_OPEN"}}

LONG_SIDE = BinanceConstant.LONG.value
SHORT_SIDE = BinanceConstant.SHORT.value

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

CLS_TIME = 0
CLS_INTERVAL_TIME = 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 60 * 60

ACCOUNT_STATUS_CHECK_TIME = 0
ACCOUNT_STATUS_CHECK_INTERVAL_TIME = 0.1 * 60

USER_STREAM_STARTTIME = 0

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "P.Daily Vol($/L)", 2: "D/M/Y P.Pnl(%)", 3: "Total Earned($)", 4: "Total Trade Vol($)", 5: "M/T.Fee($)", 6: "W.Bal($)", 7: "Max.Bal($)", 8: "Min.Bal($)"}

"""
"   Desc: Write a traded log to a txt file
"""
def write_log_to_file(exchange, symbol, txt, fname):
    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + fname + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "a") as f:
        f.write(str(txt) + "\n")

"""
"   Desc: Read a parameters from a start file
"""
def read_parameters_from_file(exchange, symbol):
    global TICK_VOLUME_AMOUNT, GRID_TICKSIZE_RATE, POS_CLOSE_RATE, LONG_POS_DIRECTION, LONG_POS_CLOSE_RATE, SHORT_POS_DIRECTION, SHORT_POS_CLOSE_RATE

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            TICK_VOLUME_AMOUNT = 0
            GRID_TICKSIZE_RATE = 0
            POS_CLOSE_RATE = 0
            LONG_POS_DIRECTION = 0
            LONG_POS_CLOSE_RATE = 0
            SHORT_POS_DIRECTION = 0
            SHORT_POS_CLOSE_RATE = 0
        else:
            TICK_VOLUME_AMOUNT = float(data.split(', ')[0].strip())
            GRID_TICKSIZE_RATE = float(data.split(', ')[1].strip())
            POS_CLOSE_RATE = float(data.split(', ')[2].strip())
            LONG_POS_DIRECTION = int(data.split(', ')[3].strip())
            LONG_POS_CLOSE_RATE = float(data.split(', ')[4].strip())
            SHORT_POS_DIRECTION = int(data.split(', ')[5].strip())
            SHORT_POS_CLOSE_RATE = float(data.split(', ')[6].strip())

"""
"   Desc: Write parameters to a log file
"""
def write_parameters_to_file(exchange, symbol):
    global TICK_VOLUME_AMOUNT, GRID_TICKSIZE_RATE, POS_CLOSE_RATE, LONG_POS_DIRECTION, LONG_POS_CLOSE_RATE, SHORT_POS_DIRECTION, SHORT_POS_CLOSE_RATE

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        parameters = f'{TICK_VOLUME_AMOUNT}, {GRID_TICKSIZE_RATE}, {POS_CLOSE_RATE}, {LONG_POS_DIRECTION}, {LONG_POS_CLOSE_RATE}, {SHORT_POS_DIRECTION}, {SHORT_POS_CLOSE_RATE}'
        f.write(parameters)

"""
"   Desc: Write a traded info to a log file
"""
def write_tradedinfo_to_file(exchange, symbol):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, tick_volume_dict, grid_ticksize_dict, close_count_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{total_amount}, {total_runtime}, {start_balance}, {max_balance}, {min_balance}, {maker_rebate}, {taker_fee}, {tick_volume_dict[symbol]}, {grid_ticksize_dict[symbol]}, {close_count_dict[symbol]}'
        f.write(traded_info)

"""
"   Desc: Read a traded info from a log file
"""
def read_tradedinfo_from_file(exchange, symbol):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, tick_volume_dict, grid_ticksize_dict, close_count_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_amount = 0
            total_runtime = 0
            start_balance = 0
            max_balance = 0
            min_balance = 0
            maker_rebate = 0
            taker_fee = 0
            tick_volume_dict[symbol] = 0
            grid_ticksize_dict[symbol] = 0
            close_count_dict[symbol] = 0
        else:
            total_amount = float(data.split(', ')[0].strip())
            total_runtime = float(data.split(', ')[1].strip())
            start_balance = float(data.split(', ')[2].strip())
            max_balance = float(data.split(', ')[3].strip())
            min_balance = float(data.split(', ')[4].strip())
            maker_rebate = float(data.split(', ')[5].strip())
            taker_fee = float(data.split(', ')[6].strip())
            tick_volume_dict[symbol] = float(data.split(', ')[7].strip())
            grid_ticksize_dict[symbol] = float(data.split(', ')[8].strip())
            close_count_dict[symbol] = int(data.split(', ')[9].strip())

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_to_file(exchange, value):
    log_file = ROOT_PATH + exchange.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{value}')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_from_file(exchange):
    log_file = ROOT_PATH + exchange.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
for symbol in list(contracts):
    if symbol in symbol_list:
        contract = contracts[symbol]
        fee_rate = binance_futures_rest_api.get_commission_rate(symbol)
        fee_rates[symbol] = fee_rate
    else:
        del contracts[symbol]

wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = binance_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(5)

multi_asset_mode = binance_futures_rest_api.get_multi_asset_mode()
if not multi_asset_mode:
    binance_futures_rest_api.change_multi_asset_mode()

position_mode = binance_futures_rest_api.get_position_mode()
if not position_mode:
    binance_futures_rest_api.switch_position_mode()

if contracts:
    for symbol in list(contracts):
        contract = contracts[symbol]
        positions[symbol] = {}
        _positions = binance_futures_rest_api.get_symbol_positions(symbol)
        if _positions:
            set_leverage_symbol = ""
            for position_value in _positions.values():
                for position in position_value.values():
                    margin_type = position["margin_type"]
                    if margin_type == BinanceConstant.ISOLATED.value:
                        binance_futures_rest_api.change_margin_type(symbol, BinanceConstant.CROSSED.value)

                    leverage = position["leverage"]
                    max_leverage = int(binance_futures_rest_api.get_leverage(symbol))
                    if leverage < max_leverage and symbol != set_leverage_symbol:
                        binance_futures_rest_api.change_leverage(symbol, max_leverage)
                        set_leverage_symbol = symbol

                    position_side = position["side"]
                    positions[symbol][position_side] = position

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        message = json.loads(message)
        if message:
            symbol = message["s"]
            if symbol in symbol_list:
                tick = {}
                tick["exchange"] = EXCHANGE
                tick["symbol"] = symbol
                tick["bid_price_1"] = float(message["b"])
                tick["bid_volume_1"] = float(message["B"])
                tick["ask_price_1"] = float(message["a"])
                tick["ask_volume_1"] = float(message["A"])

                ticks[symbol] = tick

# Traded Websocket Thread
class TradeWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("TradeWebsocket's Connection Opened.")

    def on_close(self, ws):
        print("TradeWebsocket's Connection Closed.")

    def on_error(self, ws, error):
        print("TradeWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, total_amount, traded_count, current_traded_amount, maker_rebate, taker_fee, close_count_dict

        if message:
            message = json.loads(message)
            event = message["e"]
            if event == "ACCOUNT_UPDATE":
                for coin in message["a"]["B"]:
                    wallet = {}

                    wallet["exchange"] = EXCHANGE
                    wallet["asset"] = coin["a"]
                    wallet["balance"] = float(coin["wb"])

                    wallets[coin["a"]] = wallet

                for position_data in message["a"]["P"]:
                    if position_data["ps"] != "BOTH":
                        position = {}

                        if position_data["s"] in symbol_list:
                            position["exchange"] = EXCHANGE
                            position["symbol"] = position_data["s"]
                            position["side"] = position_data["ps"]
                            position["size"] = abs(float(position_data["pa"]))
                            position["entry_price"] = float(position_data["ep"])
                            position["unreal_pnl"] = float(position_data["up"])
                            position["value"] = abs(float(position_data["pa"])) * float(position_data["ep"])

                            if position["symbol"] not in positions.keys():
                                positions[position["symbol"]] = {}

                            symbol = position["symbol"]
                            position_side = position["side"]
                            positions[symbol][position_side] = position
            elif event == "ORDER_TRADE_UPDATE":
                order_data = message["o"]
                symbol = order_data["s"]
                if symbol in symbol_list:
                    order_id = order_data["i"]
                    side = order_data["S"]
                    pos_side = order_data["ps"]
                    price = float(order_data["p"])
                    status = order_data["X"]
                    execution_type = order_data["x"]
                    volume = float(order_data["q"])
                    order_type = order_data["ot"]
                    filled_price = float(order_data["L"])

                    l_position_size = positions[symbol][LONG_POS]["size"]
                    l_position_pnl = positions[symbol][LONG_POS]["unreal_pnl"]
                    l_position_entry_price = positions[symbol][LONG_POS]["entry_price"]

                    s_position_size = positions[symbol][SHORT_POS]["size"]
                    s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                    s_position_pnl = positions[symbol][SHORT_POS]["unreal_pnl"]

                    diff_pricetick_size = "N/A"
                    if status == BinanceConstant.ALLTRADED.value:
                        traded_count += 1

                        if order_type == BinanceConstant.MARKET.value:
                            taker_fee += taker_fee_rate * filled_price * volume

                        if side == LONG_SIDE:
                            if pos_side == SHORT_POS:
                                close_count_dict[symbol] += 1
                                diff_pricetick_size = str(int((s_position_entry_price - filled_price) / pricetick))
                        elif side == SHORT_SIDE:
                            if pos_side == LONG_POS:
                                close_count_dict[symbol] += 1
                                diff_pricetick_size = str(int((filled_price - l_position_entry_price) / pricetick))

                        traded_volume = filled_price * abs(volume)
                        total_amount += traded_volume
                        current_traded_amount += traded_volume

                        title = symbol.replace(QUOTE_COIN, "")
                        date_time = Utils.get_current_time_mdhm()
                        direction_offset = DIRECTION_OFFSET[side][pos_side]

                        log_txt = f'{traded_count: >8}{title: >12}{order_type: >8}{direction_offset: >16}{Utils.round_to(l_position_size, round_volume): >12} / {Utils.round_to(s_position_size, round_volume): <12}{Utils.round_to(l_position_pnl, pricetick): >12} / {Utils.round_to(s_position_pnl, pricetick): <12}{Utils.round_to(l_position_entry_price, pricetick): >12} / {Utils.round_to(s_position_entry_price, pricetick): <12}{diff_pricetick_size: >6}{Utils.round_to(filled_price, pricetick): >12}{Utils.round_to(volume, round_volume): >12}{round(current_traded_amount, 2): >16}{int(current_runtime): >8}{round(balance, 2): >12}{date_time: >18}'
                        print(log_txt)

                        log_file_name = Utils.get_current_time_mdh()
                        write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)

                        if order_type == "LIQUIDATION":
                            write_process_status_to_file(EXCHANGE, 1)

# orderbook websocket thread start
bookticker_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + BinanceConstant.F_WEBSOCKET_BOOK_TICKERS_STREAM_PARAM.value
orderbook_websocket_thread = OrderbookWebsocketThread(bookticker_url, False, False)
orderbook_websocket_thread.start()

# trade websocket thread start
listen_key = binance_futures_rest_api.get_new_listen_key()
USER_STREAM_STARTTIME = time()

trade_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + listen_key
trade_websocket_thread = TradeWebsocketThread(trade_url, False, False)
trade_websocket_thread.start()

sleep(5)

read_process_status_signal_from_file(EXCHANGE)

TICK_VOLUME_AMOUNT = float(sys.argv[1:][0])
GRID_TICKSIZE_RATE = float(sys.argv[1:][1])
POS_CLOSE_RATE = float(sys.argv[1:][2])
LONG_POS_DIRECTION = int(sys.argv[1:][3])
LONG_POS_CLOSE_RATE = float(sys.argv[1:][4])
SHORT_POS_DIRECTION = int(sys.argv[1:][5])
SHORT_POS_CLOSE_RATE = float(sys.argv[1:][6])

for symbol in symbol_list:
    write_parameters_to_file(EXCHANGE, symbol)
    read_tradedinfo_from_file(EXCHANGE, symbol)

CLS_TIME = time()
TRADED_INFO_TIME = time()
ACCOUNT_STATUS_CHECK_TIME = time()

print(f'==================================================')
print(balance, fee_rates[symbol_list[0]]["maker_fee_rate"], fee_rates[symbol_list[0]]["taker_fee_rate"])
print(f'==================================================')

if start_balance == 0:
    start_balance = balance

if min_balance == 0:
    min_balance = start_balance

if max_balance == 0:
    max_balance = start_balance

start_time = time()
last_runtime = total_runtime

while True:
    current_runtime = round((time() - start_time) / 60)
    if (time() - USER_STREAM_STARTTIME) >= BinanceConstant.USER_STREAM_TIMEOUT.value:
        binance_futures_rest_api.renew_listen_key(listen_key)
        USER_STREAM_STARTTIME = time()

    for symbol in symbol_list:
        sleep(0.1)

        read_parameters_from_file(EXCHANGE, symbol)

        # <!--- check some parameters for market/trade/account
        contract = contracts[symbol]
        if symbol not in ticks.keys():
            continue

        balance = wallets[QUOTE_COIN]["balance"]
        if balance > max_balance:
            max_balance = balance

        if balance < min_balance:
            min_balance = balance

        # <!--- get all values for trading
        round_volume = contract["round_volume"]
        min_volume = contract["min_order_qty"]
        max_volume = contract["max_order_qty"]
        pricetick = contract["pricetick"]
        notional_value = contract["notional"]

        maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
        taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]
        # --->

        # <!--- calc tick volume and grid ticksize
        ask_price_1 = ticks[symbol]["ask_price_1"]
        open_min_volume = Utils.c_round_to(1.1 * notional_value / ask_price_1, min_volume)
        if symbol not in tick_volume_dict.keys() or tick_volume_dict[symbol] == 0:
            _tick_volume = Utils.c_round_to(TICK_VOLUME_AMOUNT / ask_price_1, min_volume)
            tick_volume_dict[symbol] = _tick_volume

        tick_volume_dict[symbol] = max(tick_volume_dict[symbol], open_min_volume)

        grid_tick_percent = max(GRID_TICKSIZE_RATE / 100, 5 * taker_fee_rate)
        _grid_ticksize = round(2 * grid_tick_percent * ask_price_1 / pricetick)
        if symbol not in grid_ticksize_dict.keys() or grid_ticksize_dict[symbol] == 0:
            grid_ticksize_dict[symbol] = _grid_ticksize

        grid_ticksize_dict[symbol] = max(grid_ticksize_dict[symbol], _grid_ticksize)
        # -->

        if positions[symbol][LONG_POS]["size"] == 0 and positions[symbol][SHORT_POS]["size"] == 0:
            close_count_dict[symbol] = 0
            binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, tick_volume_dict[symbol], LONG_POS)
            binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, tick_volume_dict[symbol], SHORT_POS)
            continue

        # sending orders
        for new_side in (LONG_SIDE, SHORT_SIDE):
            for new_position_side in (LONG_POS, SHORT_POS):
                bid_price_1 = ticks[symbol]["bid_price_1"]
                ask_price_1 = ticks[symbol]["ask_price_1"]

                # new price
                if new_side == LONG_SIDE:
                    new_price = Utils.round_to(bid_price_1, pricetick)
                elif new_side == SHORT_SIDE:
                    new_price = Utils.round_to(ask_price_1, pricetick)

                long_pos_size = positions[symbol][LONG_POS]["size"]
                long_pos_entry_price = positions[symbol][LONG_POS]["entry_price"]

                short_pos_size = positions[symbol][SHORT_POS]["size"]
                short_pos_entry_price = positions[symbol][SHORT_POS]["entry_price"]

                if new_side == LONG_SIDE:
                    if new_position_side == SHORT_POS:
                        if short_pos_size:
                            if SHORT_POS_DIRECTION == 2 and SHORT_POS_CLOSE_RATE > 0:
                                binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.c_round_to(SHORT_POS_CLOSE_RATE * short_pos_size, min_volume), SHORT_POS)

                                SHORT_POS_DIRECTION = 0
                                SHORT_POS_CLOSE_RATE = 0
                                write_parameters_to_file(EXCHANGE, symbol)
                            else:
                                if long_pos_size:
                                    if close_count_dict[symbol] == 0:
                                        if long_pos_size == short_pos_size:
                                            if new_price <= short_pos_entry_price - grid_ticksize_dict[symbol] * pricetick:
                                                binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, short_pos_size, SHORT_POS)
                                                binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.c_round_to(short_pos_size * POS_CLOSE_RATE, min_volume), LONG_POS)
                                                binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, long_pos_size, SHORT_POS)
                                                binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.c_round_to(short_pos_size * POS_CLOSE_RATE, min_volume), LONG_POS)
                                    else:
                                        if new_price <= short_pos_entry_price - max(grid_ticksize_dict[symbol] * pricetick, max(long_pos_entry_price - short_pos_entry_price, 0)):
                                            binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, short_pos_size, SHORT_POS)
                                            binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, (2 * long_pos_size - Utils.c_round_to(short_pos_size * POS_CLOSE_RATE, min_volume)), SHORT_POS)
                                            binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, long_pos_size, LONG_POS)
                                            binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.c_round_to(short_pos_size * POS_CLOSE_RATE, min_volume), LONG_POS)
                elif new_side == SHORT_SIDE:
                    if new_position_side == LONG_POS:
                        if long_pos_size:
                            if LONG_POS_DIRECTION == 1 and LONG_POS_CLOSE_RATE > 0:
                                binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.c_round_to(LONG_POS_CLOSE_RATE * long_pos_size, min_volume), LONG_POS)

                                LONG_POS_DIRECTION = 0
                                LONG_POS_CLOSE_RATE = 0
                                write_parameters_to_file(EXCHANGE, symbol)
                            else:
                                if short_pos_size:
                                    if close_count_dict[symbol] == 0:
                                        if short_pos_size == long_pos_size:
                                            if new_price >= long_pos_entry_price + grid_ticksize_dict[symbol] * pricetick:
                                                binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, long_pos_size, LONG_POS)
                                                binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.c_round_to(long_pos_size * POS_CLOSE_RATE, min_volume), SHORT_POS)
                                                binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, short_pos_size, LONG_POS)
                                                binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.c_round_to(long_pos_size * POS_CLOSE_RATE, min_volume), SHORT_POS)
                                    else:
                                        if new_price >= long_pos_entry_price + max(grid_ticksize_dict[symbol] * pricetick, max(long_pos_entry_price - short_pos_entry_price, 0)):
                                            binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, long_pos_size, LONG_POS)
                                            binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, (2 * short_pos_size - Utils.c_round_to(long_pos_size * POS_CLOSE_RATE, min_volume)), LONG_POS)
                                            binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, short_pos_size, SHORT_POS)
                                            binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.c_round_to(long_pos_size * POS_CLOSE_RATE, min_volume), SHORT_POS)

    if time() - CLS_TIME > CLS_INTERVAL_TIME:
        os.system('cls')
        CLS_TIME = time()

    if time() - TRADED_INFO_TIME > TRADED_INFO_INTERVAL_TIME:
        print(f"|==========================================================================================================================================================================================================================|")
        print(f'|{TRADED_INFO_TITLE[0]: >26}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >27}{TRADED_INFO_TITLE[4]: >32}{TRADED_INFO_TITLE[5]: >24}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18}{TRADED_INFO_TITLE[8]: >18} |')
        print(f'|           ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|')
        total_runtime = last_runtime + current_runtime
        runtime_minutes = round(total_runtime)
        runtime_hours = round(total_runtime / 60, 1)
        runtime_days = round(total_runtime / 1440, 2)
        runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'

        predict_dailty_trade_amt = round(total_amount / (total_runtime / 1440), 1) if total_runtime > 1 else 0
        predict_daily_trade_leverage = round((total_amount / (total_runtime / 1440)) / balance, 1) if total_runtime > 1 else 0
        predict_dailty_trade_amt_leverage = f'{predict_dailty_trade_amt}/{predict_daily_trade_leverage}'

        profit = round(balance - start_balance, 2)
        profit_percent = f'{round((profit / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0

        rebate_fee = f'{round(maker_rebate, 2)}/{round(taker_fee, 2)}'
        print(f'| {runtime: >24}{predict_dailty_trade_amt_leverage: >27}{profit_percent: >27}{profit: >27}{round(total_amount, 3): >32}{rebate_fee: >24}{round(balance, 2): >18}{round(max_balance, 2): >18}{round(min_balance, 2): >18}  |')
        print(f'|==========================================================================================================================================================================================================================|')

        TRADED_INFO_TIME = time()

    if current_runtime > 1 and time() - ACCOUNT_STATUS_CHECK_TIME > ACCOUNT_STATUS_CHECK_INTERVAL_TIME:
        PROCESS_STATUS = read_process_status_signal_from_file(EXCHANGE)
        ACCOUNT_STATUS_CHECK_TIME = time()
        if PROCESS_STATUS == 1:
            print(f'Saving trade info, and exit program automatically...')
            for symbol in symbol_list:
                write_tradedinfo_to_file(EXCHANGE, symbol)

            sleep(1)

            break
        elif PROCESS_STATUS == 2:
            print("Pause program automatically...")
            for symbol in symbol_list:
                write_tradedinfo_to_file(EXCHANGE, symbol)

            sleep(1)

            while True:
                sleep(1)
                PROCESS_STATUS = read_process_status_signal_from_file(EXCHANGE)
                if PROCESS_STATUS != 2:
                    break
        elif PROCESS_STATUS == 3:
            print("Close all positons, and exit program automatically...")
            for symbol in symbol_list:
                contract = contracts[symbol]
                for close_position_side in (LONG_POS, SHORT_POS):
                    close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
                    close_volume = positions[symbol][close_position_side]["size"]
                    if close_volume:
                        binance_futures_rest_api.close_all_positions(symbol, close_side, close_volume, close_position_side)

                write_tradedinfo_to_file(EXCHANGE, symbol)

            break

write_process_status_to_file(EXCHANGE, 0)

print("Exit!")

sleep(1)
