#!/usr/bin/env python
import logging

import sys

import json
from typing import Dict
from time import sleep, time

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
key = "8XAgHlNKhQQgDi3hJYVeEy38Mbp06vcjHFWDIX5nShZXiUcNQdQnL5Fix2DiMX8Q"
secret = "bZlV9kIE7e9wtKA2jzx80OemYoQWy3SFchvzEpsTUnbAf1McqhuTxPYohFrWYbKQ"

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}

# static parameters
balance = 0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"LONG": "SELL", "SHORT": "BUY"}

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

####### Rest API Section #######
SYMBOL = str(sys.argv[1:][0])
if "USDC" in SYMBOL:
    QUOTE_COIN = BinanceConstant.QUOTE_USDC.value

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
for symbol in list(contracts):
    if symbol == SYMBOL:
        contract = contracts[symbol]
        fee_rate = binance_futures_rest_api.get_commission_rate(symbol)
        fee_rates[symbol] = fee_rate
    else:
        del contracts[symbol]

wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = binance_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(1)

if contracts:
    for symbol in list(contracts):
        contract = contracts[symbol]
        positions[symbol] = {}
        _positions = binance_futures_rest_api.get_symbol_positions(symbol)
        if _positions:
            for position_value in _positions.values():
                for position in position_value.values():
                    position_side = position["side"]
                    positions[symbol][position_side] = position

sleep(2)

print("Close all positons, and exit program automatically...")
for symbol in list(contracts):
    binance_futures_rest_api.cancel_all_orders(symbol)
    for close_position_side in (LONG_POS, SHORT_POS):
        close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
        close_volume = abs(positions[symbol][close_position_side]["size"])
        print(close_volume)
        binance_futures_rest_api.send_taker_order(symbol, close_side, close_volume, close_position_side)

sleep(1)
