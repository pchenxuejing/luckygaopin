#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

import threading
import websocket as wb

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
key = "sguwhAV1G7sHsPTuQ0gfPK8cLe1krUypRbtzkC2cMC17idTxIExUCH8mToZZk3SW"
secret = "jAWOgr4Qqt619yxuA2KgE3V2Mr6xSlrS4Vl47cRVYpqBfMm2LHLzBCSTrYxmvxXo"

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}

# static parameters
balance = 0
traded_count = 0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
OPPOSITE_SIDE: Dict[str, str] = {"BUY": "SELL", "SELL": "BUY"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"BUY": "SHORT", "SELL": "LONG"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"LONG": "SELL", "SHORT": "BUY"}
DIRECTION_OFFSET = {"BUY": {"LONG": "LONG_OPEN", "SHORT": "LONG_CLOSE"}, "SELL":{"LONG": "SHORT_CLOSE", "SHORT": "SHORT_OPEN"}}

LONG_SIDE = BinanceConstant.LONG.value
SHORT_SIDE = BinanceConstant.SHORT.value

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

USER_STREAM_STARTTIME = 0

####### Rest API Section #######
####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = binance_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(1)

print(balance)

if contracts:
    for symbol in list(contracts):
        sleep(0.1)

        contract = contracts[symbol]
        if time() >= contract["delivery_time"] / 1000:
            # del contracts[symbol]
            continue

        positions[symbol] = {}
        _positions = binance_futures_rest_api.get_symbol_positions(symbol)
        if _positions:
            for position_value in _positions.values():
                for position in position_value.values():
                    position_side = position["side"]
                    positions[symbol][position_side] = position

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        message = json.loads(message)
        if message:
            symbol = message["s"]
            tick = {}
            tick["exchange"] = EXCHANGE
            tick["symbol"] = symbol
            tick["bid_price_1"] = float(message["b"])
            tick["bid_volume_1"] = float(message["B"])
            tick["ask_price_1"] = float(message["a"])
            tick["ask_volume_1"] = float(message["A"])

            ticks[symbol] = tick

# Traded Websocket Thread
class TradeWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("TradeWebsocket's Connection Opened.")

    def on_close(self, ws):
        print("TradeWebsocket's Connection Closed.")

    def on_error(self, ws, error):
        print("TradeWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, traded_count

        if message:
            message = json.loads(message)
            event = message["e"]
            if event == "ACCOUNT_UPDATE":
                for coin in message["a"]["B"]:
                    wallet = {}

                    wallet["exchange"] = EXCHANGE
                    wallet["asset"] = coin["a"]
                    wallet["balance"] = float(coin["wb"])

                    wallets[coin["a"]] = wallet

                for position_data in message["a"]["P"]:
                    if position_data["ps"] != "BOTH":
                        position = {}

                        position["exchange"] = EXCHANGE
                        position["symbol"] = position_data["s"]
                        position["side"] = position_data["ps"]
                        position["size"] = abs(float(position_data["pa"]))
                        position["entry_price"] = float(position_data["ep"])
                        position["unreal_pnl"] = float(position_data["up"])
                        position["value"] = abs(float(position_data["pa"])) * float(position_data["ep"])

                        if position["symbol"] not in positions.keys():
                            positions[position["symbol"]] = {}

                        symbol = position["symbol"]
                        position_side = position["side"]
                        positions[symbol][position_side] = position
            elif event == "ORDER_TRADE_UPDATE":
                order_data = message["o"]
                symbol = order_data["s"]
                order_id = order_data["i"]
                side = order_data["S"]
                pos_side = order_data["ps"]
                price = float(order_data["p"])
                status = order_data["X"]
                execution_type = order_data["x"]
                volume = float(order_data["q"])
                order_type = order_data["ot"]
                filled_price = float(order_data["L"])

                pricetick = contracts[symbol]["pricetick"]
                round_volume = contracts[symbol]["round_volume"]
                base_coin = symbol.replace(QUOTE_COIN, "")

                l_position_size = positions[symbol][LONG_POS]["size"]
                s_position_size = positions[symbol][SHORT_POS]["size"]

                if status == BinanceConstant.ALLTRADED.value:
                    traded_count += 1

                    title = f'{base_coin}'
                    date_time = Utils.get_current_time_mdhm()
                    direction_offset = DIRECTION_OFFSET[side][pos_side]

                    print(f'{traded_count: >8}{title: >8}{order_type: >8}{direction_offset: >16}{Utils.round_to(l_position_size, round_volume): >14} / {Utils.round_to(s_position_size, round_volume): <14}{Utils.round_to(filled_price, pricetick): >14}{Utils.round_to(volume, round_volume): >14}{date_time: >18}')

# orderbook websocket thread start
bookticker_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + BinanceConstant.F_WEBSOCKET_BOOK_TICKERS_STREAM_PARAM.value
orderbook_websocket_thread = OrderbookWebsocketThread(bookticker_url, False, False)
orderbook_websocket_thread.start()

# trade websocket thread start
listen_key = binance_futures_rest_api.get_new_listen_key()
USER_STREAM_STARTTIME = time()

trade_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + listen_key
trade_websocket_thread = TradeWebsocketThread(trade_url, False, False)
trade_websocket_thread.start()

sleep(5)

if contracts:
    for symbol in list(contracts):
        binance_futures_rest_api.cancel_all_orders(symbol)

while True:
    for symbol in list(contracts):
        long_pos_size = 0
        short_pos_size = 0

        sleep(0.5)

        # <!--- check some parameters for market/trade/account
        contract = contracts[symbol]
        if symbol not in ticks.keys():
            continue

        balance = wallets[QUOTE_COIN]["balance"]

        # <!--- get all values for trading
        round_volume = contract["round_volume"]
        min_volume = contract["min_order_qty"]
        max_volume = contract["max_order_qty"]
        pricetick = contract["pricetick"]
        notional_value = contract["notional"]

        bid_price_1 = ticks[symbol]["bid_price_1"]
        ask_price_1 = ticks[symbol]["ask_price_1"]
        # --->

        open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
        open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

        # sending orders
        open_orders = binance_futures_rest_api.get_open_orders(symbol)
        for new_side in (LONG_SIDE, SHORT_SIDE):
            for new_position_side in (LONG_POS, SHORT_POS):
                new_price, new_volume = 0, 0

                open_order_ids[new_side][new_position_side] = ''
                open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                # new price
                if new_side == LONG_SIDE:
                    new_price = Utils.round_to(bid_price_1, pricetick)
                elif new_side == SHORT_SIDE:
                    new_price = Utils.round_to(ask_price_1, pricetick)

                if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                    open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                    open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                    open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                long_pos_size = positions[symbol][LONG_POS]["size"]
                short_pos_size = positions[symbol][SHORT_POS]["size"]

                if new_side == LONG_SIDE:
                    if new_position_side == SHORT_POS:
                        if short_pos_size:
                            new_volume = short_pos_size
                elif new_side == SHORT_SIDE:
                    if new_position_side == LONG_POS:
                        if long_pos_size:
                            new_volume = long_pos_size

                new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                if open_order_ids[new_side][new_position_side]:
                    open_order_id = open_order_ids[new_side][new_position_side]
                    old_price = open_order_info[new_side][new_position_side]["price"]
                    old_volume = open_order_info[new_side][new_position_side]["volume"]

                    if old_volume != new_volume or old_price != new_price:
                        binance_futures_rest_api.cancel_order(symbol, open_order_id)

                    continue

                if new_price and new_volume:
                    response = binance_futures_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_side)

        if long_pos_size == 0 and short_pos_size == 0:
            del contracts[symbol]
            continue

sleep(1)
