#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time

import threading
import websocket

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
# key = "sguwhAV1G7sHsPTuQ0gfPK8cLe1krUypRbtzkC2cMC17idTxIExUCH8mToZZk3SW"
# secret = "jAWOgr4Qqt619yxuA2KgE3V2Mr6xSlrS4Vl47cRVYpqBfMm2LHLzBCSTrYxmvxXo"

key = str(sys.argv[1:][0])
secret = str(sys.argv[1:][1])

# exchange api
contracts = {}
positions = {}
wallets = {}

# static parameters
balance = 0
start_time = 0
current_runtime = 0
traded_count = 0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
DIRECTION_OFFSET = {"BUY": {"LONG": "LONG_OPEN", "SHORT": "LONG_CLOSE"}, "SELL":{"LONG": "SHORT_CLOSE", "SHORT": "SHORT_OPEN"}}

LONG_SIDE = BinanceConstant.LONG.value
SHORT_SIDE = BinanceConstant.SHORT.value

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

USER_STREAM_STARTTIME = 0

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = binance_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(5)

if contracts:
    for symbol in list(contracts):
        sleep(0.1)
        contract = contracts[symbol]
        if time() >= contract["delivery_time"] / 1000:
            continue

        positions[symbol] = {}
        _positions = binance_futures_rest_api.get_symbol_positions(symbol)
        if _positions:
            for position_value in _positions.values():
                for position in position_value.values():
                    position_side = position["side"]
                    positions[symbol][position_side] = position

multi_asset_mode = binance_futures_rest_api.get_multi_asset_mode()
if not multi_asset_mode:
    binance_futures_rest_api.change_multi_asset_mode()

position_mode = binance_futures_rest_api.get_position_mode()
if not position_mode:
    binance_futures_rest_api.switch_position_mode()

class WebsocketClientThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self.stop_event = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self.stop_event.is_set():
            self.ws.run_forever()

    def stop(self):
        self.stop_event.set()

    def on_open(self, ws):
        print("WebSocket's Connection Opened.")

    def on_close(self, ws):
        print("WebSocket's Connection Closed.")

    def on_error(self, ws, error):
        print("WebSocket's Error: ", error)

    def on_message(self, ws, message):
        if "direction" in message:
            json_msg = json.loads(message)
            if json_msg["direction"] == "leader_order_update":
                _symbol = json_msg["symbol"]
                symbol = _symbol + "USDT"
                if symbol in list(contracts):
                    leader_volume = float(json_msg["volume"])
                    leader_side = json_msg["side"]
                    leader_pos_side = json_msg["pos_side"]
                    filled_price = float(json_msg["filled_price"])
                    leader_balance = float(json_msg["leader_balance"])
                    close_all_signal = int(json_msg["close_all_signal"])

                    round_volume = contracts[symbol]["round_volume"]
                    min_volume = contracts[symbol]["min_order_qty"]
                    max_volume = contracts[symbol]["max_order_qty"]
                    notional_value = contracts[symbol]["notional"]
                    open_min_volume = min(1.1 * notional_value / filled_price, leader_volume)

                    follower_volume = Utils.round_to(leader_volume * (balance / leader_balance), round_volume)
                    side = ""
                    pos_side = ""
                    if leader_side == "LONG_SIDE" and leader_pos_side == "LONG_POS":
                        side = LONG_SIDE
                        pos_side = LONG_POS
                        follower_volume = Utils.round_to(max(follower_volume, open_min_volume), round_volume)
                    elif leader_side == "SHORT_SIDE" and leader_pos_side == "SHORT_POS":
                        side = SHORT_SIDE
                        pos_side = SHORT_POS
                        follower_volume = Utils.round_to(max(follower_volume, open_min_volume), round_volume)
                    elif leader_side == "LONG_SIDE" and leader_pos_side == "SHORT_POS":
                        side = LONG_SIDE
                        pos_side = SHORT_POS
                        pos_volume = positions[symbol][SHORT_POS]["size"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0
                        follower_volume = min(max(follower_volume, min_volume), pos_volume)
                        if close_all_signal == 1:
                            follower_volume = pos_volume
                    elif leader_side == "SHORT_SIDE" and leader_pos_side == "LONG_POS":
                        side = SHORT_SIDE
                        pos_side = LONG_POS
                        pos_volume = positions[symbol][LONG_POS]["size"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                        follower_volume = min(max(follower_volume, min_volume), pos_volume)
                        if close_all_signal == 1:
                            follower_volume = pos_volume

                    if follower_volume:
                        response = binance_futures_rest_api.send_taker_order(symbol, side, follower_volume, pos_side)
            elif json_msg["direction"] == "leader_pos_update":
                _symbol = json_msg["symbol"]
                symbol = _symbol + "USDT"
                if symbol in list(contracts):
                    leader_pos_side = json_msg["pos_side"]

                    round_volume = contracts[symbol]["round_volume"]
                    min_volume = contracts[symbol]["min_order_qty"]
                    max_volume = contracts[symbol]["max_order_qty"]

                    side = ""
                    pos_side = ""
                    follower_volume = 0
                    if leader_pos_side == "SHORT_POS":
                        side = LONG_SIDE
                        pos_side = SHORT_POS
                        pos_volume = positions[symbol][SHORT_POS]["size"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0
                        follower_volume = pos_volume
                    elif leader_pos_side == "LONG_POS":
                        side = SHORT_SIDE
                        pos_side = LONG_POS
                        pos_volume = positions[symbol][LONG_POS]["size"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                        follower_volume = pos_volume

                    if follower_volume:
                        response = binance_futures_rest_api.send_taker_order(symbol, side, follower_volume, pos_side)

    def send_message(self, message):
        self.ws.send(message)

websocket_client_thread = WebsocketClientThread(RestApiConstant.WEBSOCKET_URL.value, False, False)
websocket_client_thread.start()

# Traded Websocket Thread
class TradeWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("TradeWebsocket's Connection Opened.")

    def on_close(self, ws):
        print("TradeWebsocket's Connection Closed.")

    def on_error(self, ws, error):
        print("TradeWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, traded_count

        if message:
            message = json.loads(message)
            event = message["e"]
            if event == "ACCOUNT_UPDATE":
                for coin in message["a"]["B"]:
                    wallet = {}

                    wallet["exchange"] = EXCHANGE
                    wallet["asset"] = coin["a"]
                    wallet["balance"] = float(coin["wb"])

                    wallets[coin["a"]] = wallet

                for position_data in message["a"]["P"]:
                    if position_data["ps"] != "BOTH":
                        position = {}

                        position["exchange"] = EXCHANGE
                        position["symbol"] = position_data["s"]
                        position["side"] = position_data["ps"]
                        position["size"] = abs(float(position_data["pa"]))
                        position["entry_price"] = float(position_data["ep"])
                        position["unreal_pnl"] = float(position_data["up"])
                        position["value"] = abs(float(position_data["pa"])) * float(position_data["ep"])

                        if position["symbol"] not in positions.keys():
                            positions[position["symbol"]] = {}

                        symbol = position["symbol"]
                        position_side = position["side"]
                        positions[symbol][position_side] = position
            elif event == "ORDER_TRADE_UPDATE":
                order_data = message["o"]

                symbol = order_data["s"]
                side = order_data["S"]
                pos_side = order_data["ps"]
                status = order_data["X"]
                volume = float(order_data["q"])
                order_type = order_data["ot"]
                filled_price = float(order_data["L"])

                l_position_size = positions[symbol][LONG_POS]["size"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                s_position_size = positions[symbol][SHORT_POS]["size"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0
                l_position_pnl = positions[symbol][LONG_POS]["unreal_pnl"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                s_position_pnl = positions[symbol][SHORT_POS]["unreal_pnl"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0
                l_position_entry_price = positions[symbol][LONG_POS]["entry_price"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0

                round_volume = contracts[symbol]["round_volume"]
                pricetick = contracts[symbol]["pricetick"]

                if status == BinanceConstant.ALLTRADED.value:
                    date_time = Utils.get_current_time_mdhm()

                    traded_count += 1
                    title = f'{symbol.replace(QUOTE_COIN, "")}'
                    direction_offset = DIRECTION_OFFSET[side][pos_side]

                    log_txt = f'{traded_count: >8}{title: >12}{order_type: >10}{direction_offset: >16}{Utils.round_to(l_position_pnl, pricetick): >14} / {Utils.round_to(s_position_pnl, pricetick): <12}{Utils.round_to(l_position_size, round_volume): >12} / {Utils.round_to(s_position_size, round_volume): <12}{Utils.round_to(l_position_entry_price, pricetick): >12} / {Utils.round_to(s_position_entry_price, pricetick): <12}{Utils.round_to(filled_price, pricetick): >12}{Utils.round_to(volume, round_volume): >14}{round(balance, 2): >16}{date_time: >18}'
                    print(log_txt)

# trade websocket thread start
listen_key = binance_futures_rest_api.get_new_listen_key()
USER_STREAM_STARTTIME = time()

trade_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + listen_key
trade_websocket_thread = TradeWebsocketThread(trade_url, False, False)
trade_websocket_thread.start()

sleep(5)

print(f'==================================================')
print(balance)
print(f'==================================================')

start_time = time()

while True:
    current_runtime = round((time() - start_time) / 60)
    if (time() - USER_STREAM_STARTTIME) >= BinanceConstant.USER_STREAM_TIMEOUT.value:
        binance_futures_rest_api.renew_listen_key(listen_key)
        USER_STREAM_STARTTIME = time()

    balance = wallets[QUOTE_COIN]["balance"]
    contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)

    sleep(1)

trade_websocket_thread.stop()
websocket_client_thread.stop()

sleep(1)
