#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time

import threading
import websocket

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
# key = "sqHuYGKIHX2v9HE22TffFHypRluB1kj3ToUy4QDF7XzJYvbItj9lIgWQtincPZxU"
# secret = "g1TYF64u5KCh69xAbOg0SWVdzhl7tHahBSfFkMyFC3MUzEB2rSTElwMhDo9A8MFb"

key = str(sys.argv[1:][0])
secret = str(sys.argv[1:][1])

# exchange api
contracts = {}
positions = {}
wallets = {}

# static parameters
balance = 0
start_time = 0
current_runtime = 0
traded_count = 0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
DIRECTION_OFFSET = {"BUY": {"LONG": "LONG_OPEN", "SHORT": "LONG_CLOSE"}, "SELL":{"LONG": "SHORT_CLOSE", "SHORT": "SHORT_OPEN"}}

LONG_SIDE = BinanceConstant.LONG.value
SHORT_SIDE = BinanceConstant.SHORT.value

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

USER_STREAM_STARTTIME = 0

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

class WebsocketClientThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self.stop_event = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self.stop_event.is_set():
            self.ws.run_forever()

    def stop(self):
        self.stop_event.set()

    def on_open(self, ws):
        print("WebSocket's Connection Opened.")

    def on_close(self, ws):
        print("WebSocket's Connection Closed.")

    def on_error(self, ws, error):
        print("WebSocket's Error: ", error)

    def on_message(self, ws, message):
        msg = json.loads(message)

    def send_message(self, message):
        self.ws.send(message)

websocket_client_thread = WebsocketClientThread(RestApiConstant.WEBSOCKET_URL.value, False, False)
websocket_client_thread.start()

# Traded Websocket Thread
class TradeWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("TradeWebsocket's Connection Opened.")

    def on_close(self, ws):
        print("TradeWebsocket's Connection Closed.")

    def on_error(self, ws, error):
        print("TradeWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, traded_count

        if message:
            message = json.loads(message)
            event = message["e"]
            if event == "ACCOUNT_UPDATE":
                for coin in message["a"]["B"]:
                    wallet = {}

                    wallet["exchange"] = EXCHANGE
                    wallet["asset"] = coin["a"]
                    wallet["balance"] = float(coin["wb"])

                    wallets[coin["a"]] = wallet

                for position_data in message["a"]["P"]:
                    if position_data["ps"] != "BOTH":
                        position = {}

                        position["exchange"] = EXCHANGE
                        position["symbol"] = position_data["s"]
                        position["side"] = position_data["ps"]
                        position["size"] = abs(float(position_data["pa"]))
                        position["entry_price"] = float(position_data["ep"])
                        position["unreal_pnl"] = float(position_data["up"])
                        position["value"] = abs(float(position_data["pa"])) * float(position_data["ep"])

                        if position["symbol"] not in positions.keys():
                            positions[position["symbol"]] = {}

                        symbol = position["symbol"]
                        pos_side = position["side"]
                        positions[symbol][pos_side] = position

                        if position["size"] == 0:
                            date_time = Utils.get_current_time_mdhm()
                            if pos_side == LONG_POS:
                                socket_msg = '{"direction": "leader_pos_update", "pos_side": "LONG_POS", "symbol": "' + symbol.replace("USDT", "") + '", "close_all_signal": "1", "date_time": "' + str(date_time) + '"}'
                                websocket_client_thread.send_message(socket_msg)
                            elif pos_side == SHORT_POS:
                                socket_msg = '{"direction": "leader_pos_update", "pos_side": "SHORT_POS", "symbol": "' + symbol.replace("USDT", "") + '", "close_all_signal": "1", "date_time": "' + str(date_time) + '"}'
                                websocket_client_thread.send_message(socket_msg)
            elif event == "ORDER_TRADE_UPDATE":
                order_data = message["o"]

                symbol = order_data["s"]
                side = order_data["S"]
                pos_side = order_data["ps"]
                status = order_data["X"]
                volume = float(order_data["q"])
                order_type = order_data["ot"]
                filled_price = float(order_data["L"])

                l_position_size = positions[symbol][LONG_POS]["size"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                s_position_size = positions[symbol][SHORT_POS]["size"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0
                l_position_pnl = positions[symbol][LONG_POS]["unreal_pnl"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                s_position_pnl = positions[symbol][SHORT_POS]["unreal_pnl"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0
                l_position_entry_price = positions[symbol][LONG_POS]["entry_price"] if symbol in positions.keys() and LONG_POS in positions[symbol].keys() else 0
                s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"] if symbol in positions.keys() and SHORT_POS in positions[symbol].keys() else 0

                round_volume = contracts[symbol]["round_volume"]
                pricetick = contracts[symbol]["pricetick"]

                close_all_signal = 0
                if status == BinanceConstant.ALLTRADED.value:
                    date_time = Utils.get_current_time_mdhm()

                    if side == LONG_SIDE:
                        if pos_side == LONG_POS:
                            socket_msg = '{"direction": "leader_order_update", "side": "LONG_SIDE", "pos_side": "LONG_POS", "symbol": "' + symbol.replace("USDT", "") + '", "volume": "' + str(volume) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "close_all_signal": "' + str(close_all_signal) + '", "date_time": "' + str(date_time) + '"}'
                            websocket_client_thread.send_message(socket_msg)
                        elif pos_side == SHORT_POS:
                            if s_position_size == 0:
                                close_all_signal = 1

                            socket_msg = '{"direction": "leader_order_update", "side": "LONG_SIDE", "pos_side": "SHORT_POS", "symbol": "' + symbol.replace("USDT", "") + '", "volume": "' + str(volume) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "close_all_signal": "' + str(close_all_signal) + '", "date_time": "' + str(date_time) + '"}'
                            websocket_client_thread.send_message(socket_msg)
                    elif side == SHORT_SIDE:
                        if pos_side == LONG_POS:
                            if l_position_size == 0:
                                close_all_signal = 1

                            socket_msg = '{"direction": "leader_order_update", "side": "SHORT_SIDE", "pos_side": "LONG_POS", "symbol": "' + symbol.replace("USDT", "") + '", "volume": "' + str(volume) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "close_all_signal": "' + str(close_all_signal) + '", "date_time": "' + str(date_time) + '"}'
                            websocket_client_thread.send_message(socket_msg)
                        elif pos_side == SHORT_POS:
                            socket_msg = '{"direction": "leader_order_update", "side": "SHORT_SIDE", "pos_side": "SHORT_POS", "symbol": "' + symbol.replace("USDT", "") + '", "volume": "' + str(volume) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "close_all_signal": "' + str(close_all_signal) + '", "date_time": "' + str(date_time) + '"}'
                            websocket_client_thread.send_message(socket_msg)

                    traded_count += 1
                    title = f'{symbol.replace(QUOTE_COIN, "")}'
                    direction_offset = DIRECTION_OFFSET[side][pos_side]

                    log_txt = f'{traded_count: >8}{title: >12}{order_type: >10}{direction_offset: >16}{Utils.round_to(l_position_pnl, pricetick): >14} / {Utils.round_to(s_position_pnl, pricetick): <12}{Utils.round_to(l_position_size, round_volume): >12} / {Utils.round_to(s_position_size, round_volume): <12}{Utils.round_to(l_position_entry_price, pricetick): >12} / {Utils.round_to(s_position_entry_price, pricetick): <12}{Utils.round_to(filled_price, pricetick): >12}{Utils.round_to(volume, round_volume): >14}{round(balance, 2): >16}{date_time: >18}'
                    print(log_txt)

# trade websocket thread start
listen_key = binance_futures_rest_api.get_new_listen_key()
USER_STREAM_STARTTIME = time()

trade_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + listen_key
trade_websocket_thread = TradeWebsocketThread(trade_url, False, False)
trade_websocket_thread.start()

sleep(5)

print(f'==================================================')
print(balance)
print(f'==================================================')

start_time = time()

while True:
    current_runtime = round((time() - start_time) / 60)
    if (time() - USER_STREAM_STARTTIME) >= BinanceConstant.USER_STREAM_TIMEOUT.value:
        binance_futures_rest_api.renew_listen_key(listen_key)
        USER_STREAM_STARTTIME = time()

    balance = wallets[QUOTE_COIN]["balance"]
    contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)

    sleep(1)

trade_websocket_thread.stop()
websocket_client_thread.stop()

sleep(1)
