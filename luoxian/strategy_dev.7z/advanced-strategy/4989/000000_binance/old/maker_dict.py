#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

import threading
import websocket

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
key = "sguwhAV1G7sHsPTuQ0gfPK8cLe1krUypRbtzkC2cMC17idTxIExUCH8mToZZk3SW"
secret = "jAWOgr4Qqt619yxuA2KgE3V2Mr6xSlrS4Vl47cRVYpqBfMm2LHLzBCSTrYxmvxXo"

# key = "8XAgHlNKhQQgDi3hJYVeEy38Mbp06vcjHFWDIX5nShZXiUcNQdQnL5Fix2DiMX8Q"
# secret = "bZlV9kIE7e9wtKA2jzx80OemYoQWy3SFchvzEpsTUnbAf1McqhuTxPYohFrWYbKQ"

# ['XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'TONUSDT', '1000SHIBUSDT', 'DOTUSDT', 'TRXUSDT', 'MATICUSDT', 'APTUSDT', 'STXUSDT', 'FILUSDT', 'ATOMUSDT', 'ARBUSDT', 'IMXUSDT', 'RNDRUSDT', 'XLMUSDT', 'OPUSDT', 'HBARUSDT', 'GRTUSDT', 'KASUSDT', 'INJUSDT', '1000PEPEUSDT', 'VETUSDT', 'FTMUSDT', 'MKRUSDT', 'LDOUSDT', 'THETAUSDT', 'WIFUSDT', 'XMRUSDT', 'HBARUSDT', 'ARUSDT', 'DARUSDT', 'SEIUSDT', '1000FLOKIUSDT', 'SUIUSDT', 'FETUSDT', 'ALGOUSDT', 'GALAUSDT', 'FLOWUSDT', 'CFXUSDT', 'JUPUSDT', 'STRKUSDT', 'DYDXUSDT', 'SNXUSDT', 'SANDUSDT', '1000BONKUSDT', 'AGIXUSDT', 'PYTHUSDT', '1000XECUSDT', 'MINAUSDT', 'ONDOUSDT', 'XTZUSDT', 'CHZUSDT', 'MANAUSDT', 'AXLUSDT', 'APEUSDT', 'EOSUSDT', 'CAKEUSDT', 'NEOUSDT', '1000SATSUSDT', 'IOTAUSDT', 'JASMYUSDT', 'KAVAUSDT']
symbol_list = ['DOGEUSDT'] 

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}

init_volume_dict = {}
tick_volume_dict = {}
profit_ticksize_dict = {}
grid_ticksize_dict = {}
fee_ticksize_dict = {}

traded_maker_open_price = {}
long_close_profit_dict = {}
short_close_profit_dict = {}

last_traded_long_open_price = {}
last_traded_short_open_price = {}
last_traded_long_close_price = {}
last_traded_short_close_price = {}

long_open_traded_min_price = {}
short_open_traded_max_price = {}

long_open_count = {}
short_open_count = {}
long_close_count = {}
short_close_count = {}

# static parameters
balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_amount = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0
runtime_days = 0

maker_rebate = 0.0
taker_fee = 0.0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
OPPOSITE_SIDE: Dict[str, str] = {"BUY": "SELL", "SELL": "BUY"}
OPPOSITE_POSITION: Dict[str, str] = {"LONG": "SHORT", "SHORT": "LONG"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"BUY": "SHORT", "SELL": "LONG"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"LONG": "SELL", "SHORT": "BUY"}
DIRECTION_OFFSET = {"BUY": {"LONG": "LONG_OPEN", "SHORT": "LONG_CLOSE"}, "SELL":{"LONG": "SHORT_CLOSE", "SHORT": "SHORT_OPEN"}}

LONG_SIDE = BinanceConstant.LONG.value
SHORT_SIDE = BinanceConstant.SHORT.value

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

CLS_TIME = 0
CLS_INTERVAL_TIME = 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 5 * 60

USER_STREAM_STARTTIME = 0

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "P.Daily Vol($/L)", 2: "D/M/Y PNL(%)", 3: "Total Earned($)", 4: "Total Trade Vol($)", 5: "M/T.Fee($)", 6: "W.Bal($)", 7: "Max.Bal($)", 8: "Min.Bal($)"}

"""
"   Desc: Write an array of maker open traded price to a txt file
"""
def write_maker_traded_price_array_file(exchange, symbol):
    global traded_maker_open_price

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + "maker_price.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        content = str(traded_maker_open_price[symbol])
        f.write(content.replace("[", "").replace("]", ""))
        f.close()

"""
"   Desc: Read an array of maker open traded price from a txt file
"""
def read_maker_traded_price_array_file(exchange, symbol):
    global traded_maker_open_price

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + "maker_price.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            traded_maker_open_price[symbol] = []
        else:
            string_array = list(data.split(", "))
            traded_maker_open_price[symbol] = [float(string) for string in string_array]

"""
"   Desc: Write a profit array to a txt file
"""
def write_close_profit_array_file(exchange, symbol, side):
    global long_close_profit_dict, short_close_profit_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        if side == LONG_SIDE:
            content = str(long_close_profit_dict[symbol])
            f.write(content.replace("[", "").replace("]", ""))
        elif side == SHORT_SIDE:
            content = str(short_close_profit_dict[symbol])
            f.write(content.replace("[", "").replace("]", ""))

        f.close()

"""
"   Desc: Read a profit array from a txt file
"""
def read_close_profit_array_file(exchange, symbol, side):
    global long_close_profit_dict, short_close_profit_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + side.lower() + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            if side == LONG_SIDE:
                long_close_profit_dict[symbol] = []
            elif side == SHORT_SIDE:
                short_close_profit_dict[symbol] = []
        else:
            if side == LONG_SIDE:
                string_array = list(data.split(", "))
                long_close_profit_dict[symbol] = [int(string) for string in string_array]
            elif side == SHORT_SIDE:
                string_array = list(data.split(", "))
                short_close_profit_dict[symbol] = [int(string) for string in string_array]

"""
"   Desc: Update traded open order dict when maker order has been traded
"""
def update_profit_dict(symbol, side, profit_ticksize, status):
    global long_close_profit_dict, short_close_profit_dict

    if status == 0:
        if side == LONG_SIDE:
            long_close_profit_dict[symbol].append(round(0.9 * profit_ticksize))
        elif side == SHORT_SIDE:
            short_close_profit_dict[symbol].append(round(0.9 * profit_ticksize))
    elif status == 1:
        if side == LONG_SIDE:
            if short_close_profit_dict[symbol]:
                n_scores = np.array(short_close_profit_dict[symbol])
                max_profit_ticksize = n_scores.max()
                short_close_profit_dict[symbol].remove(max_profit_ticksize)
        elif side == SHORT_SIDE:
            if long_close_profit_dict[symbol]:
                n_scores = np.array(long_close_profit_dict[symbol])
                max_profit_ticksize = n_scores.max()
                long_close_profit_dict[symbol].remove(max_profit_ticksize)

"""
"   Desc: Get close voluem from an open order dict
"""
def get_max_prfofit_ticksize(symbol, side):
    global long_close_profit_dict, short_close_profit_dict

    profit_ticksize = 0
    if side == LONG_SIDE:
        n_scores = np.array(long_close_profit_dict[symbol])
        profit_ticksize = n_scores.max()
    elif side == SHORT_SIDE:
        n_scores = np.array(short_close_profit_dict[symbol])
        profit_ticksize = n_scores.max()

    return profit_ticksize

"""
"   Desc: Write a traded log to a txt file
"""
def write_log_to_file(exchange, symbol, txt, fname):
    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\" + fname + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "a") as f:
        f.write(str(txt) + "\n")

"""
"   Desc: Write a traded info to a log file
"""
def write_tradedinfo_to_file(exchange, symbol):
    global total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, init_volume_dict, tick_volume_dict, profit_ticksize_dict, grid_ticksize_dict, fee_ticksize_dict, last_traded_long_open_price, last_traded_short_open_price, last_traded_long_close_price, last_traded_short_close_price, long_open_traded_min_price, short_open_traded_max_price, long_open_count, short_open_count, long_close_count, short_close_count

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{total_amount}, {total_runtime}, {start_balance}, {max_balance}, {min_balance}, {maker_rebate}, {taker_fee}, {init_volume_dict[symbol]}, {tick_volume_dict[symbol]}, {profit_ticksize_dict[symbol]}, {grid_ticksize_dict[symbol]}, {fee_ticksize_dict[symbol]}, {last_traded_long_open_price[symbol]}, {last_traded_short_open_price[symbol]}, {last_traded_long_close_price[symbol]}, {last_traded_short_close_price[symbol]}, {long_open_traded_min_price[symbol]}, {short_open_traded_max_price[symbol]}, {long_open_count[symbol]}, {short_open_count[symbol]}, {long_close_count[symbol]}, {short_close_count[symbol]}'
        f.write(traded_info)

"""
"   Desc: Read a traded info from a log file
"""
def read_tradedinfo_from_file(exchange, symbol):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, init_volume_dict, tick_volume_dict, profit_ticksize_dict, grid_ticksize_dict, fee_ticksize_dict, last_traded_long_open_price, last_traded_short_open_price, last_traded_long_close_price, last_traded_short_close_price, long_open_traded_min_price, short_open_traded_max_price, long_open_count, short_open_count, long_close_count, short_close_count

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_amount = 0
            total_runtime = 0
            start_balance = 0
            max_balance = 0
            min_balance = 0
            maker_rebate = 0
            taker_fee = 0
            init_volume_dict[symbol] = 0
            tick_volume_dict[symbol] = 0
            profit_ticksize_dict[symbol] = 0
            grid_ticksize_dict[symbol] = 0
            fee_ticksize_dict[symbol] = 0
            last_traded_long_open_price[symbol] = 0
            last_traded_short_open_price[symbol] = 0
            last_traded_long_close_price[symbol] = 0
            last_traded_short_close_price[symbol] = 0
            long_open_traded_min_price[symbol] = 0
            short_open_traded_max_price[symbol] = 0
            long_open_count[symbol] = 0
            short_open_count[symbol] = 0
            long_close_count[symbol] = 0
            short_close_count[symbol] = 0
        else:
            total_amount = float(data.split(', ')[0].strip())
            total_runtime = float(data.split(', ')[1].strip())
            start_balance = float(data.split(', ')[2].strip())
            max_balance = float(data.split(', ')[3].strip())
            min_balance = float(data.split(', ')[4].strip())
            maker_rebate = float(data.split(', ')[5].strip())
            taker_fee = float(data.split(', ')[6].strip())
            init_volume_dict[symbol] = float(data.split(', ')[7].strip())
            tick_volume_dict[symbol] = float(data.split(', ')[8].strip())
            profit_ticksize_dict[symbol] = int(data.split(', ')[9].strip())
            grid_ticksize_dict[symbol] = int(data.split(', ')[10].strip())
            fee_ticksize_dict[symbol] = int(data.split(', ')[11].strip())
            last_traded_long_open_price[symbol] = float(data.split(', ')[12].strip())
            last_traded_short_open_price[symbol] = float(data.split(', ')[13].strip())
            last_traded_long_close_price[symbol] = float(data.split(', ')[14].strip())
            last_traded_short_close_price[symbol] = float(data.split(', ')[15].strip())
            long_open_traded_min_price[symbol] = float(data.split(', ')[16].strip())
            short_open_traded_max_price[symbol] = float(data.split(', ')[17].strip())
            long_open_count[symbol] = int(data.split(', ')[18].strip())
            short_open_count[symbol] = int(data.split(', ')[19].strip())
            long_close_count[symbol] = int(data.split(', ')[20].strip())
            short_close_count[symbol] = int(data.split(', ')[21].strip())

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_for_all(exchange, value):
    log_file = ROOT_PATH + exchange.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{value}')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_for_all(exchange):
    log_file = ROOT_PATH + exchange.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_for_symbol(exchange, symbol, value):
    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{value}')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_for_symbol(exchange, symbol):
    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

"""
"   Desc: Read a parameters from a start file
"""
def read_parameters_from_file(exchange, symbol):
    global TAKER_VOLUME_RATE, TICK_VOLUME_AMOUNT, CLOSE_VOLUME_RATE, PROFIT_TICKSIZE_RATE, GRID_TICKSIZE_RATE, MAX_POS_RATE, LONG_POS_DIRECTION, LONG_POS_CLOSE_RATE, SHORT_POS_DIRECTION, SHORT_POS_CLOSE_RATE, ADDED_BALANCE

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            TAKER_VOLUME_RATE = 0
            TICK_VOLUME_AMOUNT = 0
            CLOSE_VOLUME_RATE = 0
            PROFIT_TICKSIZE_RATE = 0
            GRID_TICKSIZE_RATE = 0
            MAX_POS_RATE = 0
            LONG_POS_DIRECTION = 0
            LONG_POS_CLOSE_RATE = 0
            SHORT_POS_DIRECTION = 0
            SHORT_POS_CLOSE_RATE = 0
            ADDED_BALANCE = 0
        else:
            TAKER_VOLUME_RATE = float(data.split(', ')[0].strip())
            TICK_VOLUME_AMOUNT = float(data.split(', ')[1].strip())
            CLOSE_VOLUME_RATE = float(data.split(', ')[2].strip())
            PROFIT_TICKSIZE_RATE = float(data.split(', ')[3].strip())
            GRID_TICKSIZE_RATE = float(data.split(', ')[4].strip())
            MAX_POS_RATE = float(data.split(', ')[5].strip())
            LONG_POS_DIRECTION = int(data.split(', ')[6].strip())
            LONG_POS_CLOSE_RATE = float(data.split(', ')[7].strip())
            SHORT_POS_DIRECTION = int(data.split(', ')[8].strip())
            SHORT_POS_CLOSE_RATE = float(data.split(', ')[9].strip())
            ADDED_BALANCE = float(data.split(', ')[10].strip())

"""
"   Desc: Write parameters to a log file
"""
def write_parameters_to_file(exchange, symbol):
    global TAKER_VOLUME_RATE, TICK_VOLUME_AMOUNT, CLOSE_VOLUME_RATE, PROFIT_TICKSIZE_RATE, GRID_TICKSIZE_RATE, MAX_POS_RATE, LONG_POS_DIRECTION, LONG_POS_CLOSE_RATE, SHORT_POS_DIRECTION, SHORT_POS_CLOSE_RATE, ADDED_BALANCE

    log_file = ROOT_PATH + exchange.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        parameters = f'{TAKER_VOLUME_RATE}, {TICK_VOLUME_AMOUNT}, {CLOSE_VOLUME_RATE}, {PROFIT_TICKSIZE_RATE}, {GRID_TICKSIZE_RATE}, {MAX_POS_RATE}, {LONG_POS_DIRECTION}, {LONG_POS_CLOSE_RATE}, {SHORT_POS_DIRECTION}, {SHORT_POS_CLOSE_RATE}, {ADDED_BALANCE}'
        f.write(parameters)

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
for symbol in list(contracts):
    if symbol in symbol_list:
        fee_rate = binance_futures_rest_api.get_commission_rate(symbol)
        fee_rates[symbol] = fee_rate
    else:
        del contracts[symbol]

wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = binance_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(5)

multi_asset_mode = binance_futures_rest_api.get_multi_asset_mode()
if not multi_asset_mode:
    binance_futures_rest_api.change_multi_asset_mode()

position_mode = binance_futures_rest_api.get_position_mode()
if not position_mode:
    binance_futures_rest_api.switch_position_mode()

if contracts:
    for symbol in symbol_list:
        contract = contracts[symbol]
        positions[symbol] = {}
        _positions = binance_futures_rest_api.get_symbol_positions(symbol)
        if _positions:
            set_leverage_symbol = ""
            for position_value in _positions.values():
                for position in position_value.values():
                    margin_type = position["margin_type"]
                    if margin_type == BinanceConstant.ISOLATED.value:
                        binance_futures_rest_api.change_margin_type(symbol, BinanceConstant.CROSSED.value)

                    leverage = position["leverage"]
                    max_leverage = int(binance_futures_rest_api.get_leverage(symbol))
                    if leverage < max_leverage and symbol != set_leverage_symbol:
                        binance_futures_rest_api.change_leverage(symbol, max_leverage)
                        set_leverage_symbol = symbol

                    position_side = position["side"]
                    positions[symbol][position_side] = position

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        message = json.loads(message)
        if message:
            symbol = message["s"]
            if symbol in symbol_list:
                tick = {}
                tick["exchange"] = EXCHANGE
                tick["symbol"] = symbol
                tick["bid_price_1"] = float(message["b"])
                tick["bid_volume_1"] = float(message["B"])
                tick["ask_price_1"] = float(message["a"])
                tick["ask_volume_1"] = float(message["A"])

                ticks[symbol] = tick

# Traded Websocket Thread
class TradeWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("TradeWebsocket's Connection Opened.")

    def on_close(self, ws):
        print("TradeWebsocket's Connection Closed.")

    def on_error(self, ws, error):
        print("TradeWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, total_amount, traded_count, current_traded_amount, maker_rebate, taker_fee, traded_maker_open_price, last_traded_long_open_price, last_traded_short_open_price, last_traded_long_close_price, last_traded_short_close_price, long_open_traded_min_price, short_open_traded_max_price, long_open_count, short_open_count, long_close_count, short_close_count

        if message:
            message = json.loads(message)
            event = message["e"]
            if event == "ACCOUNT_UPDATE":
                for coin in message["a"]["B"]:
                    wallet = {}

                    wallet["exchange"] = EXCHANGE
                    wallet["asset"] = coin["a"]
                    wallet["balance"] = float(coin["wb"])

                    wallets[coin["a"]] = wallet

                for position_data in message["a"]["P"]:
                    if position_data["ps"] != "BOTH":
                        position = {}

                        if position_data["s"] in symbol_list:
                            position["exchange"] = EXCHANGE
                            position["symbol"] = position_data["s"]
                            position["side"] = position_data["ps"]
                            position["size"] = abs(float(position_data["pa"]))
                            position["entry_price"] = float(position_data["ep"])
                            position["unreal_pnl"] = float(position_data["up"])
                            position["value"] = abs(float(position_data["pa"])) * float(position_data["ep"])

                            if position["symbol"] not in positions.keys():
                                positions[position["symbol"]] = {}

                            symbol = position["symbol"]
                            position_side = position["side"]
                            positions[symbol][position_side] = position
            elif event == "ORDER_TRADE_UPDATE":
                order_data = message["o"]
                symbol = order_data["s"]
                if symbol in symbol_list:
                    order_id = order_data["i"]
                    side = order_data["S"]
                    pos_side = order_data["ps"]
                    price = float(order_data["p"])
                    status = order_data["X"]
                    execution_type = order_data["x"]
                    volume = float(order_data["q"])
                    order_type = order_data["ot"]
                    filled_price = float(order_data["L"])

                    # <!--- get all values for trading
                    round_volume = contracts[symbol]["round_volume"]
                    min_volume = contracts[symbol]["min_order_qty"]
                    max_volume = contracts[symbol]["max_order_qty"]
                    pricetick = contracts[symbol]["pricetick"]

                    maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
                    taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]
                    # --->

                    l_position_size = positions[symbol][LONG_POS]["size"]
                    l_position_pnl = positions[symbol][LONG_POS]["unreal_pnl"]
                    l_position_entry_price = positions[symbol][LONG_POS]["entry_price"]

                    s_position_size = positions[symbol][SHORT_POS]["size"]
                    s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                    s_position_pnl = positions[symbol][SHORT_POS]["unreal_pnl"]

                    bid_price_1 = ticks[symbol]["bid_price_1"]
                    ask_price_1 = ticks[symbol]["ask_price_1"]

                    diff_pricetick_size = "N/A"
                    if status == BinanceConstant.ALLTRADED.value:
                        traded_count += 1

                        if order_type == BinanceConstant.LIMIT.value:
                            maker_rebate += maker_fee_rate * filled_price * volume
                        elif order_type == BinanceConstant.MARKET.value:
                            taker_fee += taker_fee_rate * filled_price * volume

                        if order_type == BinanceConstant.LIMIT.value:
                            if side == LONG_SIDE:
                                if pos_side == LONG_POS:
                                    if s_position_size <= l_position_size:
                                        taker_volume = Utils.round_to(TAKER_VOLUME_RATE * volume, round_volume)
                                        if (s_position_size + taker_volume) * ask_price_1 < MAX_POS_RATE * balance / len(symbol_list):
                                            binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, taker_volume, SHORT_POS)

                                    traded_maker_open_price[symbol].append(Utils.round_to(filled_price, pricetick))
                                    last_traded_long_open_price[symbol] = filled_price
                                    last_traded_long_close_price[symbol] = filled_price
                                    last_traded_short_close_price[symbol] = 0
                                    long_open_traded_min_price[symbol] = min(filled_price, long_open_traded_min_price[symbol]) if long_open_traded_min_price[symbol] else filled_price
                                    long_open_count[symbol] += 1
                                elif pos_side == SHORT_POS:
                                    last_traded_long_close_price[symbol] = filled_price
                                    last_traded_short_close_price[symbol] = 0
                                    last_traded_short_open_price[symbol] = 0
                                    long_close_count[symbol] += 1
                                    profit_ticksize = int((s_position_entry_price - filled_price) / pricetick)
                                    diff_pricetick_size = str(profit_ticksize)
                                    if long_close_profit_dict[symbol]:
                                        update_profit_dict(symbol, side, round((volume / tick_volume_dict[symbol]) * profit_ticksize), 0)
                                    else:
                                        if short_close_profit_dict[symbol]:
                                            update_profit_dict(symbol, side, profit_ticksize, 1)
                                        else:
                                            update_profit_dict(symbol, side, round((volume / tick_volume_dict[symbol]) * profit_ticksize), 0)

                                    if traded_maker_open_price[symbol]:
                                        n_scores = np.array(traded_maker_open_price[symbol])
                                        max_maker_open_price = n_scores.max()
                                        traded_maker_open_price[symbol].remove(max_maker_open_price)
                            elif side == SHORT_SIDE:
                                if pos_side == LONG_POS:
                                    last_traded_short_close_price[symbol] = filled_price
                                    last_traded_long_close_price[symbol] = 0
                                    last_traded_long_open_price[symbol] = 0
                                    short_close_count[symbol] += 1
                                    profit_ticksize = int((filled_price - l_position_entry_price) / pricetick)
                                    diff_pricetick_size = str(profit_ticksize)
                                    if short_close_profit_dict[symbol]:
                                        update_profit_dict(symbol, side, round((volume / tick_volume_dict[symbol]) * profit_ticksize), 0)
                                    else:
                                        if long_close_profit_dict[symbol]:
                                            update_profit_dict(symbol, side, profit_ticksize, 1)
                                        else:
                                            update_profit_dict(symbol, side, round((volume / tick_volume_dict[symbol]) * profit_ticksize), 0)

                                    if traded_maker_open_price[symbol]:
                                        n_scores = np.array(traded_maker_open_price[symbol])
                                        min_maker_open_price = n_scores.min()
                                        traded_maker_open_price[symbol].remove(min_maker_open_price)
                                elif pos_side == SHORT_POS:
                                    if l_position_size <= s_position_size:
                                        taker_volume = Utils.round_to(TAKER_VOLUME_RATE * volume, round_volume)
                                        if (l_position_size + taker_volume) * ask_price_1 < MAX_POS_RATE * balance / len(symbol_list):
                                            binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, taker_volume, LONG_POS)

                                    traded_maker_open_price[symbol].append(Utils.round_to(filled_price, pricetick))
                                    last_traded_short_open_price[symbol] = filled_price
                                    last_traded_short_close_price[symbol] = filled_price
                                    last_traded_long_close_price[symbol] = 0
                                    short_open_traded_max_price[symbol] = max(filled_price, short_open_traded_max_price[symbol]) if short_open_traded_max_price[symbol] else filled_price
                                    short_open_count[symbol] += 1

                        traded_volume = filled_price * abs(volume)
                        total_amount += traded_volume
                        current_traded_amount += traded_volume

                        title = symbol.replace(QUOTE_COIN, "")
                        date_time = Utils.get_current_time_mdhm()
                        direction_offset = DIRECTION_OFFSET[side][pos_side]

                        log_txt = f'{traded_count: >8}{title: >12}{order_type: >8}{direction_offset: >16}{Utils.round_to(l_position_size, round_volume): >12} / {Utils.round_to(s_position_size, round_volume): <12}{Utils.round_to(l_position_pnl, pricetick): >12} / {Utils.round_to(s_position_pnl, pricetick): <12}{Utils.round_to(l_position_entry_price, pricetick): >12} / {Utils.round_to(s_position_entry_price, pricetick): <12}{diff_pricetick_size: >6}{Utils.round_to(filled_price, pricetick): >12}{Utils.round_to(volume, round_volume): >12}{round(current_traded_amount, 2): >16}{int(current_runtime): >8}{round(balance, 2): >12}{date_time: >18}'
                        print(log_txt)

                        log_file_name = Utils.get_current_time_mdh()
                        write_log_to_file(EXCHANGE, symbol, log_txt, log_file_name)

                        if order_type == "LIQUIDATION":
                            write_process_status_for_symbol(EXCHANGE, symbol, 400)

# orderbook websocket thread start
bookticker_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + BinanceConstant.F_WEBSOCKET_BOOK_TICKERS_STREAM_PARAM.value
orderbook_websocket_thread = OrderbookWebsocketThread(bookticker_url, False, False)
orderbook_websocket_thread.start()

# trade websocket thread start
listen_key = binance_futures_rest_api.get_new_listen_key()
USER_STREAM_STARTTIME = time()

trade_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + listen_key
trade_websocket_thread = TradeWebsocketThread(trade_url, False, False)
trade_websocket_thread.start()

sleep(5)

TAKER_VOLUME_RATE = float(sys.argv[1:][0])
TICK_VOLUME_AMOUNT = float(sys.argv[1:][1])
CLOSE_VOLUME_RATE = float(sys.argv[1:][2])
PROFIT_TICKSIZE_RATE = float(sys.argv[1:][3])
GRID_TICKSIZE_RATE = float(sys.argv[1:][4])
MAX_POS_RATE = float(sys.argv[1:][5])
LONG_POS_DIRECTION = int(sys.argv[1:][6])
LONG_POS_CLOSE_RATE = float(sys.argv[1:][7])
SHORT_POS_DIRECTION = int(sys.argv[1:][8])
SHORT_POS_CLOSE_RATE = float(sys.argv[1:][9])
ADDED_BALANCE = float(sys.argv[1:][10])

read_process_status_signal_for_all(EXCHANGE)

for symbol in symbol_list:
    read_process_status_signal_for_symbol(EXCHANGE, symbol)
    write_parameters_to_file(EXCHANGE, symbol)
    read_tradedinfo_from_file(EXCHANGE, symbol)
    read_maker_traded_price_array_file(EXCHANGE, symbol)
    for side in (LONG_SIDE, SHORT_SIDE):
        read_close_profit_array_file(EXCHANGE, symbol, side)

CLS_TIME = time()
TRADED_INFO_TIME = time()

print(f'==================================================')
print(balance, fee_rates[symbol_list[0]]["maker_fee_rate"], fee_rates[symbol_list[0]]["taker_fee_rate"])
print(f'==================================================')

start_time = time()
last_runtime = total_runtime

sleep(0.5)

if start_balance == 0:
    start_balance = balance

if min_balance == 0:
    min_balance = start_balance

if max_balance == 0:
    max_balance = start_balance

# main running
while True:
    current_runtime = round((time() - start_time) / 60)
    if (time() - USER_STREAM_STARTTIME) >= BinanceConstant.USER_STREAM_TIMEOUT.value:
        binance_futures_rest_api.renew_listen_key(listen_key)
        USER_STREAM_STARTTIME = time()

    if symbol_list:
        for symbol in symbol_list:
            sleep(0.5)

            read_parameters_from_file(EXCHANGE, symbol)

            # <!--- check some parameters for market/trade/account
            contract = contracts[symbol]
            if symbol not in ticks.keys():
                continue

            balance = wallets[QUOTE_COIN]["balance"]
            if balance > max_balance:
                max_balance = balance

            if balance < min_balance:
                min_balance = balance

            # <!--- get all values for trading
            round_volume = contract["round_volume"]
            min_volume = contract["min_order_qty"]
            max_volume = contract["max_order_qty"]
            pricetick = contract["pricetick"]
            notional_value = contract["notional"]

            maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
            taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]
            # --->

            # <!--- calc tick volume and grid ticksize
            ask_price_1 = ticks[symbol]["ask_price_1"]
            open_min_volume = Utils.round_to(1.1 * notional_value / ask_price_1, min_volume)
            if symbol not in tick_volume_dict.keys() or tick_volume_dict[symbol] == 0:
                _tick_volume = Utils.round_to(TICK_VOLUME_AMOUNT / ask_price_1, min_volume)
                tick_volume_dict[symbol] = _tick_volume
                print(f'Tick volume: {tick_volume_dict[symbol]}')
            tick_volume_dict[symbol] = max(tick_volume_dict[symbol], open_min_volume)

            _profit_ticksize = round(PROFIT_TICKSIZE_RATE * ask_price_1 / (100 * pricetick))
            if symbol not in profit_ticksize_dict.keys() or profit_ticksize_dict[symbol] == 0:
                profit_ticksize_dict[symbol] = _profit_ticksize + 1
                print(f'Profit ticksize: {profit_ticksize_dict[symbol]}')
            profit_ticksize_dict[symbol] = max(profit_ticksize_dict[symbol], _profit_ticksize + 1)

            _grid_ticksize = round(GRID_TICKSIZE_RATE * ask_price_1 / (100 * pricetick))
            if symbol not in grid_ticksize_dict.keys() or grid_ticksize_dict[symbol] == 0:
                grid_ticksize_dict[symbol] = _grid_ticksize + 1
                print(f'Grid ticksize: {grid_ticksize_dict[symbol]}')
            grid_ticksize_dict[symbol] = max(grid_ticksize_dict[symbol], _grid_ticksize + 1)

            _fee_pricetick = max(Utils.round_to(taker_fee_rate * ask_price_1, pricetick), pricetick) if maker_fee_rate <= 0 else max(Utils.round_to((2 * maker_fee_rate + taker_fee_rate) * ask_price_1, pricetick), pricetick)
            if symbol not in fee_ticksize_dict.keys() or fee_ticksize_dict[symbol] == 0:
                fee_ticksize_dict[symbol] = round((_fee_pricetick + pricetick) / pricetick)
                print(f'Fee ticksize: {fee_ticksize_dict[symbol]}')
            fee_ticksize_dict[symbol] = max(fee_ticksize_dict[symbol], round((_fee_pricetick + pricetick) / pricetick))
            # -->

            open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
            open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

            # sending orders
            open_orders = binance_futures_rest_api.get_open_orders(symbol)
            for new_side in (LONG_SIDE, SHORT_SIDE):
                for new_position_side in (LONG_POS, SHORT_POS):
                    new_price, new_volume = 0, 0

                    bid_price_1 = ticks[symbol]["bid_price_1"]
                    ask_price_1 = ticks[symbol]["ask_price_1"]

                    open_order_ids[new_side][new_position_side] = ''
                    open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                    # new price
                    if new_side == LONG_SIDE:
                        new_price = Utils.round_to(bid_price_1, pricetick)
                    elif new_side == SHORT_SIDE:
                        new_price = Utils.round_to(ask_price_1, pricetick)

                    if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                        open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                        open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                        open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                    long_pos_size = positions[symbol][LONG_POS]["size"]
                    long_pos_entry_price = positions[symbol][LONG_POS]["entry_price"]
                    if not long_pos_size:
                        long_open_count[symbol] = 0
                        short_close_count[symbol] = 0
                        long_open_traded_min_price[symbol] = 0
                        last_traded_long_open_price[symbol] = 0
                        last_traded_short_close_price[symbol] = 0

                    short_pos_size = positions[symbol][SHORT_POS]["size"]
                    short_pos_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                    if not short_pos_size:
                        short_open_count[symbol] = 0
                        long_close_count[symbol] = 0
                        short_open_traded_max_price[symbol] = 0
                        last_traded_short_open_price[symbol] = 0
                        last_traded_long_close_price[symbol] = 0

                    if new_side == LONG_SIDE:
                        if new_position_side == LONG_POS:
                            new_volume = tick_volume_dict[symbol]
                            if SHORT_POS_DIRECTION == 2 and SHORT_POS_CLOSE_RATE > 0:
                                binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.round_to(SHORT_POS_CLOSE_RATE * short_pos_size, min_volume), SHORT_POS)

                                SHORT_POS_DIRECTION = 0
                                SHORT_POS_CLOSE_RATE = 0
                                write_parameters_to_file(EXCHANGE, symbol)
                            else:
                                # price
                                if last_traded_short_open_price[symbol]:
                                    new_price = Utils.round_to(last_traded_short_open_price[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)
                                elif last_traded_long_open_price:
                                    new_price = Utils.round_to(last_traded_long_open_price[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)

                                if new_price > bid_price_1:
                                    new_price = Utils.round_to(bid_price_1, pricetick)

                                # volume
                                if long_pos_size * long_pos_entry_price > MAX_POS_RATE * balance / len(symbol_list) or short_pos_size * short_pos_entry_price > MAX_POS_RATE * balance / len(symbol_list):
                                    new_volume = 0
                                else:
                                    if traded_maker_open_price[symbol]:
                                        n_scores = np.array(traded_maker_open_price[symbol])
                                        min_maker_open_price = n_scores.min()
                                        if new_price > min_maker_open_price - grid_ticksize_dict[symbol] * pricetick:
                                            new_volume = 0
                        elif new_position_side == SHORT_POS:
                            if short_pos_size:
                                # price
                                if last_traded_long_close_price[symbol]:
                                    new_price = Utils.round_to(last_traded_long_close_price[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)
                                    if new_price > bid_price_1:
                                        new_price = Utils.round_to(bid_price_1, pricetick)

                                # volume
                                if short_close_profit_dict[symbol]:
                                    max_profit_ticksize = get_max_prfofit_ticksize(symbol, SHORT_SIDE)
                                    close_ticksize = max_profit_ticksize - profit_ticksize_dict[symbol] - fee_ticksize_dict[symbol]
                                    if new_price < short_pos_entry_price + close_ticksize * pricetick:
                                        new_volume = min(tick_volume_dict[symbol], short_pos_size - tick_volume_dict[symbol])
                                else:
                                    if short_pos_size > long_pos_size:
                                        if new_price < short_pos_entry_price - fee_ticksize_dict[symbol] * pricetick:
                                            new_volume = min(tick_volume_dict[symbol], short_pos_size - tick_volume_dict[symbol])
                                            if long_close_profit_dict[symbol]:
                                                max_profit_ticksize = get_max_prfofit_ticksize(symbol, LONG_SIDE)
                                                if (short_pos_entry_price - new_price) < max_profit_ticksize * pricetick:
                                                    new_volume = 0
                                                elif traded_maker_open_price[symbol]:
                                                    n_scores = np.array(traded_maker_open_price[symbol])
                                                    min_maker_open_price = n_scores.min()
                                                    if new_price > min_maker_open_price - grid_ticksize_dict[symbol] * pricetick:
                                                        new_volume = 0
                    elif new_side == SHORT_SIDE:
                        if new_position_side == SHORT_POS:
                            new_volume = tick_volume_dict[symbol]
                            if LONG_POS_DIRECTION == 1 and LONG_POS_CLOSE_RATE > 0:
                                binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.round_to(LONG_POS_CLOSE_RATE * long_pos_size, min_volume), LONG_POS)

                                LONG_POS_DIRECTION = 0
                                LONG_POS_CLOSE_RATE = 0
                                write_parameters_to_file(EXCHANGE, symbol)
                            else:
                                # price
                                if last_traded_long_open_price[symbol]:
                                    new_price = Utils.round_to(last_traded_long_open_price[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)
                                elif last_traded_short_open_price[symbol]:
                                    new_price = Utils.round_to(last_traded_short_open_price[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)

                                if new_price < ask_price_1:
                                    new_price = Utils.round_to(ask_price_1, pricetick)

                                # volume
                                if short_pos_size * short_pos_entry_price > MAX_POS_RATE * balance / len(symbol_list) or long_pos_size * long_pos_entry_price > MAX_POS_RATE * balance / len(symbol_list):
                                    new_volume = 0
                                else:
                                    if traded_maker_open_price[symbol]:
                                        n_scores = np.array(traded_maker_open_price[symbol])
                                        max_maker_open_price = n_scores.max()
                                        if new_price < max_maker_open_price + grid_ticksize_dict[symbol] * pricetick:
                                            new_volume = 0
                        elif new_position_side == LONG_POS:
                            if long_pos_size:
                                # price
                                if last_traded_short_close_price[symbol]:
                                    new_price = Utils.round_to(last_traded_short_close_price[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)
                                    if new_price < ask_price_1:
                                        new_price = Utils.round_to(ask_price_1, pricetick)

                                # volume
                                if long_close_profit_dict[symbol]:
                                    max_profit_ticksize = get_max_prfofit_ticksize(symbol, LONG_SIDE)
                                    close_ticksize = max_profit_ticksize - profit_ticksize_dict[symbol] - fee_ticksize_dict[symbol]
                                    if new_price > long_pos_entry_price - close_ticksize * pricetick:
                                        new_volume = min(tick_volume_dict[symbol], long_pos_size - tick_volume_dict[symbol])
                                else:
                                    if long_pos_size > short_pos_size:
                                        if new_price > long_pos_entry_price + fee_ticksize_dict[symbol] * pricetick:
                                            new_volume = min(tick_volume_dict[symbol], long_pos_size - tick_volume_dict[symbol])
                                            if short_close_profit_dict[symbol]:
                                                max_profit_ticksize = get_max_prfofit_ticksize(symbol, SHORT_SIDE)
                                                if (new_price - long_pos_entry_price) < max_profit_ticksize * pricetick:
                                                    new_volume = 0
                                                elif traded_maker_open_price[symbol]:
                                                    n_scores = np.array(traded_maker_open_price[symbol])
                                                    max_maker_open_price = n_scores.max()
                                                    if new_price < max_maker_open_price + grid_ticksize_dict[symbol] * pricetick:
                                                        new_volume = 0

                    new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                    if open_order_ids[new_side][new_position_side]:
                        open_order_id = open_order_ids[new_side][new_position_side]
                        old_price = open_order_info[new_side][new_position_side]["price"]
                        old_volume = open_order_info[new_side][new_position_side]["volume"]

                        if old_volume != new_volume or old_price != new_price:
                            binance_futures_rest_api.cancel_order(symbol, open_order_id)

                        continue

                    if new_price > 0 and new_volume >= min_volume:
                        response = binance_futures_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_side)

            run_signal_for_symbol = read_process_status_signal_for_symbol(EXCHANGE, symbol)
            if run_signal_for_symbol == 400:
                print(f"Close all positons for {symbol}, and remove {symbol} from symbol list...")
                contract = contracts[symbol]
                for close_position_side in (LONG_POS, SHORT_POS):
                    close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
                    close_volume = positions[symbol][close_position_side]["size"]
                    if close_volume:
                        binance_futures_rest_api.close_all_positions(symbol, close_side, close_volume, close_position_side)

                write_tradedinfo_to_file(EXCHANGE, symbol)
                write_maker_traded_price_array_file(EXCHANGE, symbol)
                for side in (LONG_SIDE, SHORT_SIDE):
                    write_close_profit_array_file(exchange, symbol, side)

                sleep(1)

                symbol_list.remove(symbol)

        if time() - CLS_TIME > CLS_INTERVAL_TIME:
            os.system('cls')
            CLS_TIME = time()

        if time() - TRADED_INFO_TIME > TRADED_INFO_INTERVAL_TIME:
            for symbol in symbol_list:
                print(f'{symbol}: {traded_maker_open_price[symbol]}, {long_close_profit_dict[symbol]}, {short_close_profit_dict[symbol]}')

            print(f"|==========================================================================================================================================================================================================================|")
            print(f'|{TRADED_INFO_TITLE[0]: >26}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >27}{TRADED_INFO_TITLE[4]: >32}{TRADED_INFO_TITLE[5]: >24}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18}{TRADED_INFO_TITLE[8]: >18} |')
            print(f'|           ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|')
            total_runtime = last_runtime + current_runtime
            runtime_minutes = round(total_runtime)
            runtime_hours = round(total_runtime / 60, 1)
            runtime_days = round(total_runtime / 1440, 2)
            runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'

            predict_dailty_trade_amt = round(total_amount / (total_runtime / 1440), 1) if total_runtime > 1 else 0
            predict_daily_trade_leverage = round((total_amount / (total_runtime / 1440)) / balance, 1) if total_runtime > 1 else 0
            predict_dailty_trade_amt_leverage = f'{predict_dailty_trade_amt}/{predict_daily_trade_leverage}'

            profit = round(balance - start_balance - ADDED_BALANCE, 2)
            profit_percent = f'{round((profit / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0

            rebate_fee = f'{round(maker_rebate, 2)}/{round(taker_fee, 2)}'
            print(f'| {runtime: >24}{predict_dailty_trade_amt_leverage: >27}{profit_percent: >27}{profit: >27}{round(total_amount, 3): >32}{rebate_fee: >24}{round(balance, 2): >18}{round(max_balance, 2): >18}{round(min_balance, 2): >18}  |')
            print(f'|==========================================================================================================================================================================================================================|')

            TRADED_INFO_TIME = time()

        run_signal_for_all = read_process_status_signal_for_all(EXCHANGE)
        if run_signal_for_all == 1:
            print(f'Stop! Cancelling all open orders...')

            for symbol in symbol_list:
                binance_futures_rest_api.cancel_all_orders(symbol)

            sleep(1)

            break
        elif run_signal_for_all == 2:
            print(f'Pause! Cancelling all open orders...')

            for symbol in symbol_list:
                binance_futures_rest_api.cancel_all_orders(symbol)

            sleep(1)

            while True:
                sleep(1)
                run_signal_for_all = read_process_status_signal_for_all(EXCHANGE)
                if run_signal_for_all != 2:
                    break
        elif run_signal_for_all == 3:
            print(f'All Close! Cancelling all open orders...')
            for symbol in symbol_list:
                binance_futures_rest_api.cancel_all_orders(symbol)

                sleep(0.5)

                print(f'Close all positions for {symbol}...')
                contract = contracts[symbol]
                for close_position_side in (LONG_POS, SHORT_POS):
                    close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
                    close_volume = positions[symbol][close_position_side]["size"]
                    if close_volume:
                        binance_futures_rest_api.close_all_positions(symbol, close_side, close_volume, close_position_side)
            break

sleep(3)

print(f'Saving trade info, and exit program automatically...')

write_process_status_for_all(EXCHANGE, 0)

for symbol in symbol_list:
    for symbol in symbol_list:
        print(f'{symbol}: {traded_maker_open_price[symbol]}, {long_close_profit_dict[symbol]}, {short_close_profit_dict[symbol]}')

    write_parameters_to_file(EXCHANGE, symbol)
    write_tradedinfo_to_file(EXCHANGE, symbol)
    write_maker_traded_price_array_file(EXCHANGE, symbol)
    write_process_status_for_symbol(EXCHANGE, symbol, 0)

    for side in (LONG_SIDE, SHORT_SIDE):
        write_close_profit_array_file(EXCHANGE, symbol, side)

sleep(3)

print(f'Exit!')
