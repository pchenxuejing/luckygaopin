#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

import threading
import websocket

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
key = "sguwhAV1G7sHsPTuQ0gfPK8cLe1krUypRbtzkC2cMC17idTxIExUCH8mToZZk3SW"
secret = "jAWOgr4Qqt619yxuA2KgE3V2Mr6xSlrS4Vl47cRVYpqBfMm2LHLzBCSTrYxmvxXo"
account_name = "mine"

# ['XRPUSDT', 'DOGEUSDT', 'ADAUSDT', 'TONUSDT', '1000SHIBUSDT', 'DOTUSDT', 'TRXUSDT', 'MATICUSDT', 'APTUSDT', 'STXUSDT', 'FILUSDT', 'ATOMUSDT', 'ARBUSDT', 'IMXUSDT', 'RNDRUSDT', 'XLMUSDT', 'OPUSDT', 'HBARUSDT', 'GRTUSDT', 'KASUSDT', 'INJUSDT', '1000PEPEUSDT', 'VETUSDT', 'FTMUSDT', 'MKRUSDT', 'LDOUSDT', 'THETAUSDT', 'WIFUSDT', 'XMRUSDT', 'HBARUSDT', 'ARUSDT', 'DARUSDT', 'SEIUSDT', '1000FLOKIUSDT', 'SUIUSDT', 'FETUSDT', 'ALGOUSDT', 'GALAUSDT', 'FLOWUSDT', 'CFXUSDT', 'JUPUSDT', 'STRKUSDT', 'DYDXUSDT', 'SNXUSDT', 'SANDUSDT', '1000BONKUSDT', 'AGIXUSDT', 'PYTHUSDT', '1000XECUSDT', 'MINAUSDT', 'ONDOUSDT', 'XTZUSDT', 'CHZUSDT', 'MANAUSDT', 'AXLUSDT', 'APEUSDT', 'EOSUSDT', 'CAKEUSDT', 'NEOUSDT', '1000SATSUSDT', 'IOTAUSDT', 'JASMYUSDT', 'KAVAUSDT']
symbol_list = ['DOGEUSDT'] 

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}

base_pos_volume_dict = {}
initial_taker_open_volume_dict = {}
open_tick_volume_dict = {}
close_tick_volume_dict = {}
profit_ticksize_dict = {}
grid_ticksize_dict = {}
open_ticksize_dict = {}
fee_ticksize_dict = {}
market_price_ticksize_dict = {}

long_close_profit_ticksize_dict = {}
short_close_profit_ticksize_dict = {}

last_traded_long_open_price_dict = {}
last_traded_short_open_price_dict = {}
last_traded_long_close_price_dict = {}
last_traded_short_close_price_dict = {}

long_open_traded_min_price_dict = {}
short_open_traded_max_price_dict = {}

long_open_count_dict = {}
short_open_count_dict = {}
long_close_count_dict = {}
short_close_count_dict = {}

# static parameters
balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_amount = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0
runtime_days = 0

maker_rebate = 0.0
taker_fee = 0.0

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value
OPPOSITE_SIDE: Dict[str, str] = {"BUY": "SELL", "SELL": "BUY"}
OPPOSITE_POSITION: Dict[str, str] = {"LONG": "SHORT", "SHORT": "LONG"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"BUY": "SHORT", "SELL": "LONG"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"LONG": "SELL", "SHORT": "BUY"}
DIRECTION_OFFSET = {"BUY": {"LONG": "LONG_OPEN", "SHORT": "LONG_CLOSE"}, "SELL":{"LONG": "SHORT_CLOSE", "SHORT": "SHORT_OPEN"}}

LONG_SIDE = BinanceConstant.LONG.value
SHORT_SIDE = BinanceConstant.SHORT.value

LONG_POS = BinanceConstant.POSITION_LONG.value
SHORT_POS = BinanceConstant.POSITION_SHORT.value

CLS_TIME = 0
CLS_INTERVAL_TIME = 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 10 * 60

USER_STREAM_STARTTIME = 0

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "P.Daily Vol($/L)", 2: "D/M/Y PNL(%)", 3: "Total Earned($)", 4: "Total Trade Vol($)", 5: "M/T.Fee($)", 6: "W.Bal($)", 7: "Max.Bal($)", 8: "Min.Bal($)"}

"""
"   Desc: Write a profit array to a txt file
"""
def write_close_profit_dict(exchange, account_name, symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\" + side.lower() + "_profit.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        if side == LONG_SIDE:
            content = str(long_close_profit_ticksize_dict[symbol])
            f.write(content.replace("[", "").replace("]", ""))
        elif side == SHORT_SIDE:
            content = str(short_close_profit_ticksize_dict[symbol])
            f.write(content.replace("[", "").replace("]", ""))

        f.close()

"""
"   Desc: Read a profit array from a txt file
"""
def read_close_profit_dict(exchange, account_name, symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\" + side.lower() + "_profit.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            if side == LONG_SIDE:
                long_close_profit_ticksize_dict[symbol] = []
            elif side == SHORT_SIDE:
                short_close_profit_ticksize_dict[symbol] = []
        else:
            if side == LONG_SIDE:
                string_array = list(data.split(", "))
                long_close_profit_ticksize_dict[symbol] = [int(string) for string in string_array]
            elif side == SHORT_SIDE:
                string_array = list(data.split(", "))
                short_close_profit_ticksize_dict[symbol] = [int(string) for string in string_array]

"""
"   Desc: Update traded open order dict when maker order has been traded
"""
def update_profit_dict(symbol, side, profit_ticksize, volume, ticksize, status):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    if status == 0:
        real_profit_ticksize = int(min(CLOSE_TICKSIZE_PERCENT / 100 + (profit_ticksize / ticksize), 0.99) * profit_ticksize)
        if side == LONG_SIDE:
            if volume > close_tick_volume_dict[symbol]:
                count = int(volume / close_tick_volume_dict[symbol])
                long_close_profit_ticksize_dict[symbol].append(count * real_profit_ticksize)
            else:
                long_close_profit_ticksize_dict[symbol].append(real_profit_ticksize)
        elif side == SHORT_SIDE:
            if volume > close_tick_volume_dict[symbol]:
                count = int(volume / close_tick_volume_dict[symbol])
                short_close_profit_ticksize_dict[symbol].append(count * real_profit_ticksize)
            else:
                short_close_profit_ticksize_dict[symbol].append(real_profit_ticksize)
    elif status == 1:
        if side == LONG_SIDE:
            if short_close_profit_ticksize_dict[symbol]:
                if volume > close_tick_volume_dict[symbol]:
                    count = int(volume / close_tick_volume_dict[symbol])
                    for i in range(count):
                        n_scores = np.array(short_close_profit_ticksize_dict[symbol])
                        max_profit_ticksize = n_scores.max()
                        short_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)
                else:
                    n_scores = np.array(short_close_profit_ticksize_dict[symbol])
                    max_profit_ticksize = n_scores.max()
                    short_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)
        elif side == SHORT_SIDE:
            if long_close_profit_ticksize_dict[symbol]:
                if volume > close_tick_volume_dict[symbol]:
                    count = int(volume / close_tick_volume_dict[symbol])
                    for i in range(count):
                        n_scores = np.array(long_close_profit_ticksize_dict[symbol])
                        max_profit_ticksize = n_scores.max()
                        long_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)
                else:
                    n_scores = np.array(long_close_profit_ticksize_dict[symbol])
                    max_profit_ticksize = n_scores.max()
                    long_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)

"""
"   Desc: Get a max profit ticksize from a profit dict
"""
def get_max_prfofit_ticksize(symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    max_profit_ticksize = 0
    if side == LONG_SIDE:
        if long_close_profit_ticksize_dict[symbol]:
            n_scores = np.array(long_close_profit_ticksize_dict[symbol])
            max_profit_ticksize = n_scores.max()
    elif side == SHORT_SIDE:
        if short_close_profit_ticksize_dict[symbol]:
            n_scores = np.array(short_close_profit_ticksize_dict[symbol])
            max_profit_ticksize = n_scores.max()

    return max_profit_ticksize

"""
"   Desc: Get close volume from a profit dict
"""
def get_minus_close_volume(symbol, side, minus_ticksize):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    close_volume = 0
    if side == LONG_SIDE:
        if short_close_profit_ticksize_dict[symbol]:
            x = np.array(short_close_profit_ticksize_dict[symbol])
            result = x[x > minus_ticksize]
            close_volume = len(result) * close_tick_volume_dict[symbol]
    elif side == SHORT_SIDE:
        if long_close_profit_ticksize_dict[symbol]:
            x = np.array(long_close_profit_ticksize_dict[symbol])
            result = x[x > minus_ticksize]
            close_volume = len(result) * close_tick_volume_dict[symbol]

    return close_volume

"""
"   Desc: Get a total profit ticksize from a profit dict
"""
def get_total_profit_ticksize(symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    total_profit_ticksize = 0
    if side == LONG_SIDE:
        if short_close_profit_ticksize_dict[symbol]:
            total_profit_ticksize = sum(short_close_profit_ticksize_dict[symbol])
    elif side == SHORT_SIDE:
        if long_close_profit_ticksize_dict[symbol]:
            total_profit_ticksize = sum(long_close_profit_ticksize_dict[symbol])

    return total_profit_ticksize

"""
"   Desc: Write a traded log to a txt file
"""
def write_log(exchange, account_name, symbol, txt, fname):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\" + fname + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "a") as f:
        f.write(str(txt) + "\n")

"""
"   Desc: Write a traded info to a log file
"""
def write_traded_info(exchange, account_name, symbol):
    global total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\traded_info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{total_amount}, {total_runtime}, {start_balance}, {max_balance}, {min_balance}, {maker_rebate}, {taker_fee}'
        f.write(traded_info)

"""
"   Desc: Read a traded info from a log file
"""
def read_traded_info(exchange, account_name, symbol):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\traded_info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_amount = 0
            total_runtime = 0
            start_balance = 0
            max_balance = 0
            min_balance = 0
            maker_rebate = 0
            taker_fee = 0
        else:
            total_amount = float(data.split(', ')[0].strip())
            total_runtime = float(data.split(', ')[1].strip())
            start_balance = float(data.split(', ')[2].strip())
            max_balance = float(data.split(', ')[3].strip())
            min_balance = float(data.split(', ')[4].strip())
            maker_rebate = float(data.split(', ')[5].strip())
            taker_fee = float(data.split(', ')[6].strip())

"""
"   Desc: Write a variables to a log file
"""
def write_variables(exchange, account_name, symbol):
    global base_pos_volume_dict, initial_taker_open_volume_dict, open_tick_volume_dict, close_tick_volume_dict, profit_ticksize_dict, grid_ticksize_dict, open_ticksize_dict, fee_ticksize_dict, market_price_ticksize_dict, last_traded_long_open_price_dict, last_traded_short_open_price_dict, last_traded_long_close_price_dict, last_traded_short_close_price_dict, long_open_traded_min_price_dict, short_open_traded_max_price_dict, long_open_count_dict, short_open_count_dict, long_close_count_dict, short_close_count_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\variables.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{base_pos_volume_dict[symbol]}, {initial_taker_open_volume_dict[symbol]}, {open_tick_volume_dict[symbol]}, {close_tick_volume_dict[symbol]}, {profit_ticksize_dict[symbol]}, {grid_ticksize_dict[symbol]}, {open_ticksize_dict[symbol]}, {fee_ticksize_dict[symbol]}, {market_price_ticksize_dict[symbol]}, {last_traded_long_open_price_dict[symbol]}, {last_traded_short_open_price_dict[symbol]}, {last_traded_long_close_price_dict[symbol]}, {last_traded_short_close_price_dict[symbol]}, {long_open_traded_min_price_dict[symbol]}, {short_open_traded_max_price_dict[symbol]}, {long_open_count_dict[symbol]}, {short_open_count_dict[symbol]}, {long_close_count_dict[symbol]}, {short_close_count_dict[symbol]}'
        f.write(traded_info)

"""
"   Desc: Read a variables from a log file
"""
def read_variables(exchange, account_name, symbol):
    global base_pos_volume_dict, initial_taker_open_volume_dict, open_tick_volume_dict, close_tick_volume_dict, profit_ticksize_dict, grid_ticksize_dict, open_ticksize_dict, fee_ticksize_dict, market_price_ticksize_dict, last_traded_long_open_price_dict, last_traded_short_open_price_dict, last_traded_long_close_price_dict, last_traded_short_close_price_dict, long_open_traded_min_price_dict, short_open_traded_max_price_dict, long_open_count_dict, short_open_count_dict, long_close_count_dict, short_close_count_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\variables.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            base_pos_volume_dict[symbol] = 0
            initial_taker_open_volume_dict[symbol] = 0
            open_tick_volume_dict[symbol] = 0
            close_tick_volume_dict[symbol] = 0
            profit_ticksize_dict[symbol] = 0
            grid_ticksize_dict[symbol] = 0
            open_ticksize_dict[symbol] = 0
            fee_ticksize_dict[symbol] = 0
            market_price_ticksize_dict[symbol] = 0
            last_traded_long_open_price_dict[symbol] = 0
            last_traded_short_open_price_dict[symbol] = 0
            last_traded_long_close_price_dict[symbol] = 0
            last_traded_short_close_price_dict[symbol] = 0
            long_open_traded_min_price_dict[symbol] = 0
            short_open_traded_max_price_dict[symbol] = 0
            long_open_count_dict[symbol] = 0
            short_open_count_dict[symbol] = 0
            long_close_count_dict[symbol] = 0
            short_close_count_dict[symbol] = 0
        else:
            base_pos_volume_dict[symbol] = float(data.split(', ')[0].strip())
            initial_taker_open_volume_dict[symbol] = float(data.split(', ')[1].strip())
            open_tick_volume_dict[symbol] = float(data.split(', ')[2].strip())
            close_tick_volume_dict[symbol] = float(data.split(', ')[3].strip())
            profit_ticksize_dict[symbol] = int(data.split(', ')[4].strip())
            grid_ticksize_dict[symbol] = int(data.split(', ')[5].strip())
            open_ticksize_dict[symbol] = int(data.split(', ')[6].strip())
            fee_ticksize_dict[symbol] = int(data.split(', ')[7].strip())
            market_price_ticksize_dict[symbol] = int(data.split(', ')[8].strip())
            last_traded_long_open_price_dict[symbol] = float(data.split(', ')[9].strip())
            last_traded_short_open_price_dict[symbol] = float(data.split(', ')[10].strip())
            last_traded_long_close_price_dict[symbol] = float(data.split(', ')[11].strip())
            last_traded_short_close_price_dict[symbol] = float(data.split(', ')[12].strip())
            long_open_traded_min_price_dict[symbol] = float(data.split(', ')[13].strip())
            short_open_traded_max_price_dict[symbol] = float(data.split(', ')[14].strip())
            long_open_count_dict[symbol] = int(data.split(', ')[15].strip())
            short_open_count_dict[symbol] = int(data.split(', ')[16].strip())
            long_close_count_dict[symbol] = int(data.split(', ')[17].strip())
            short_close_count_dict[symbol] = int(data.split(', ')[18].strip())

"""
"   Desc: Write parameters to a log file
"""
def write_parameters(exchange, account_name, symbol):
    global INITIAL_TAKER_VOLUME_PERCENT, BASE_POS_VOLUME_PERCENT, OPEN_TICK_VOLUME_RATE, CLOSE_TICK_VOLUME_RATE, PROFIT_TICKSIZE_PERCENT, GRID_TICKSIZE_PERCENT, CLOSE_TICKSIZE_PERCENT, OPEN_TICKSIZE_PERCENT, BOTH_OPEN_SIGNAL, BOTH_OPEN_POS_RATE, BOTH_CLOSE_SIGNAL, BOTH_CLOSE_POS_RATE, LONG_POS_CLOSE_SIGNAL, LONG_POS_CLOSE_RATE, SHORT_POS_CLOSE_SIGNAL, SHORT_POS_CLOSE_RATE, LONG_OPEN_SIGNAL, LONG_OPEN_RATE, SHORT_OPEN_SIGNAL, SHORT_OPEN_RATE, ADDED_BALANCE

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        parameters = f'{INITIAL_TAKER_VOLUME_PERCENT}, {BASE_POS_VOLUME_PERCENT}, {OPEN_TICK_VOLUME_RATE}, {CLOSE_TICK_VOLUME_RATE}, {PROFIT_TICKSIZE_PERCENT}, {GRID_TICKSIZE_PERCENT}, {CLOSE_TICKSIZE_PERCENT}, {OPEN_TICKSIZE_PERCENT}, {BOTH_OPEN_SIGNAL}, {BOTH_OPEN_POS_RATE}, {BOTH_CLOSE_SIGNAL}, {BOTH_CLOSE_POS_RATE}, {LONG_POS_CLOSE_SIGNAL}, {LONG_POS_CLOSE_RATE}, {SHORT_POS_CLOSE_SIGNAL}, {SHORT_POS_CLOSE_RATE}, {LONG_OPEN_SIGNAL}, {LONG_OPEN_RATE}, {SHORT_OPEN_SIGNAL}, {SHORT_OPEN_RATE}, {ADDED_BALANCE}'
        f.write(parameters)

"""
"   Desc: Read a parameters from a start file
"""
def read_parameters(exchange, account_name, symbol):
    global INITIAL_TAKER_VOLUME_PERCENT, BASE_POS_VOLUME_PERCENT, OPEN_TICK_VOLUME_RATE, CLOSE_TICK_VOLUME_RATE, PROFIT_TICKSIZE_PERCENT, GRID_TICKSIZE_PERCENT, CLOSE_TICKSIZE_PERCENT, OPEN_TICKSIZE_PERCENT, BOTH_OPEN_SIGNAL, BOTH_OPEN_POS_RATE, BOTH_CLOSE_SIGNAL, BOTH_CLOSE_POS_RATE, LONG_POS_CLOSE_SIGNAL, LONG_POS_CLOSE_RATE, SHORT_POS_CLOSE_SIGNAL, SHORT_POS_CLOSE_RATE, LONG_OPEN_SIGNAL, LONG_OPEN_RATE, SHORT_OPEN_SIGNAL, SHORT_OPEN_RATE, ADDED_BALANCE

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            INITIAL_TAKER_VOLUME_PERCENT = 0
            BASE_POS_VOLUME_PERCENT = 0
            OPEN_TICK_VOLUME_RATE = 0
            CLOSE_TICK_VOLUME_RATE = 0
            PROFIT_TICKSIZE_PERCENT = 0
            GRID_TICKSIZE_PERCENT = 0
            CLOSE_TICKSIZE_PERCENT = 0
            OPEN_TICKSIZE_PERCENT = 0
            BOTH_OPEN_SIGNAL = 0
            BOTH_OPEN_POS_RATE = 0
            BOTH_CLOSE_SIGNAL = 0
            BOTH_CLOSE_POS_RATE = 0
            LONG_POS_CLOSE_SIGNAL = 0
            LONG_POS_CLOSE_RATE = 0
            SHORT_POS_CLOSE_SIGNAL = 0
            SHORT_POS_CLOSE_RATE = 0
            LONG_OPEN_SIGNAL = 0
            LONG_OPEN_RATE = 0
            SHORT_OPEN_SIGNAL = 0
            SHORT_OPEN_RATE = 0
            ADDED_BALANCE = 0
        else:
            INITIAL_TAKER_VOLUME_PERCENT = float(data.split(', ')[0].strip())
            BASE_POS_VOLUME_PERCENT = float(data.split(', ')[1].strip())
            OPEN_TICK_VOLUME_RATE = int(data.split(', ')[2].strip())
            CLOSE_TICK_VOLUME_RATE = int(data.split(', ')[3].strip())
            PROFIT_TICKSIZE_PERCENT = float(data.split(', ')[4].strip())
            GRID_TICKSIZE_PERCENT = float(data.split(', ')[5].strip())
            CLOSE_TICKSIZE_PERCENT = float(data.split(', ')[6].strip())
            OPEN_TICKSIZE_PERCENT = float(data.split(', ')[7].strip())
            BOTH_OPEN_SIGNAL = int(data.split(', ')[8].strip())
            BOTH_OPEN_POS_RATE = int(data.split(', ')[9].strip())
            BOTH_CLOSE_SIGNAL = int(data.split(', ')[10].strip())
            BOTH_CLOSE_POS_RATE = int(data.split(', ')[11].strip())
            LONG_POS_CLOSE_SIGNAL = int(data.split(', ')[12].strip())
            LONG_POS_CLOSE_RATE = int(data.split(', ')[13].strip())
            SHORT_POS_CLOSE_SIGNAL = int(data.split(', ')[14].strip())
            SHORT_POS_CLOSE_RATE = int(data.split(', ')[15].strip())
            LONG_OPEN_SIGNAL = int(data.split(', ')[16].strip())
            LONG_OPEN_RATE = int(data.split(', ')[17].strip())
            SHORT_OPEN_SIGNAL = int(data.split(', ')[18].strip())
            SHORT_OPEN_RATE = int(data.split(', ')[19].strip())
            ADDED_BALANCE = float(data.split(', ')[20].strip())

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_for_all(exchange, account_name, value):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{value}')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_for_all(exchange, account_name):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_for_symbol(exchange, account_name, symbol, value):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{value}')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_for_symbol(exchange, account_name, symbol):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)

contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)
for symbol in list(contracts):
    if symbol in symbol_list:
        fee_rate = binance_futures_rest_api.get_commission_rate(symbol)
        fee_rates[symbol] = fee_rate
    else:
        del contracts[symbol]

wallets = binance_futures_rest_api.get_wallet_balance()
balance = wallets[QUOTE_COIN]["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = binance_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(5)

multi_asset_mode = binance_futures_rest_api.get_multi_asset_mode()
if not multi_asset_mode:
    binance_futures_rest_api.change_multi_asset_mode()

position_mode = binance_futures_rest_api.get_position_mode()
if not position_mode:
    binance_futures_rest_api.switch_position_mode()

if contracts:
    for symbol in symbol_list:
        contract = contracts[symbol]
        positions[symbol] = {}
        _positions = binance_futures_rest_api.get_symbol_positions(symbol)
        if _positions:
            set_leverage_symbol = ""
            for position_value in _positions.values():
                for position in position_value.values():
                    margin_type = position["margin_type"]
                    if margin_type == BinanceConstant.ISOLATED.value:
                        binance_futures_rest_api.change_margin_type(symbol, BinanceConstant.CROSSED.value)

                    leverage = position["leverage"]
                    max_leverage = int(binance_futures_rest_api.get_leverage(symbol))
                    if leverage < max_leverage and symbol != set_leverage_symbol:
                        binance_futures_rest_api.change_leverage(symbol, max_leverage)
                        set_leverage_symbol = symbol

                    position_side = position["side"]
                    positions[symbol][position_side] = position

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        message = json.loads(message)
        if message:
            symbol = message["s"]
            if symbol in symbol_list:
                tick = {}
                tick["exchange"] = EXCHANGE
                tick["symbol"] = symbol
                tick["bid_price_1"] = float(message["b"])
                tick["bid_volume_1"] = float(message["B"])
                tick["ask_price_1"] = float(message["a"])
                tick["ask_volume_1"] = float(message["A"])

                ticks[symbol] = tick

# Traded Websocket Thread
class TradeWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("TradeWebsocket's Connection Opened.")

    def on_close(self, ws):
        print("TradeWebsocket's Connection Closed.")

    def on_error(self, ws, error):
        print("TradeWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global wallets, positions, total_amount, traded_count, current_traded_amount, maker_rebate, taker_fee, last_traded_long_open_price_dict, last_traded_short_open_price_dict, last_traded_long_close_price_dict, last_traded_short_close_price_dict, long_open_traded_min_price_dict, short_open_traded_max_price_dict, long_open_count_dict, short_open_count_dict, long_close_count_dict, short_close_count_dict

        if message:
            message = json.loads(message)
            event = message["e"]
            if event == "ACCOUNT_UPDATE":
                for coin in message["a"]["B"]:
                    wallet = {}

                    wallet["exchange"] = EXCHANGE
                    wallet["asset"] = coin["a"]
                    wallet["balance"] = float(coin["wb"])

                    wallets[coin["a"]] = wallet

                for position_data in message["a"]["P"]:
                    if position_data["ps"] != "BOTH":
                        position = {}

                        if position_data["s"] in symbol_list:
                            position["exchange"] = EXCHANGE
                            position["symbol"] = position_data["s"]
                            position["side"] = position_data["ps"]
                            position["size"] = abs(float(position_data["pa"]))
                            position["entry_price"] = float(position_data["ep"])
                            position["unreal_pnl"] = float(position_data["up"])
                            position["value"] = abs(float(position_data["pa"])) * float(position_data["ep"])

                            if position["symbol"] not in positions.keys():
                                positions[position["symbol"]] = {}

                            symbol = position["symbol"]
                            position_side = position["side"]
                            positions[symbol][position_side] = position
            elif event == "ORDER_TRADE_UPDATE":
                order_data = message["o"]
                symbol = order_data["s"]
                if symbol in symbol_list:
                    order_id = order_data["i"]
                    side = order_data["S"]
                    pos_side = order_data["ps"]
                    price = float(order_data["p"])
                    status = order_data["X"]
                    execution_type = order_data["x"]
                    volume = float(order_data["q"])
                    order_type = order_data["ot"]
                    filled_price = float(order_data["L"])

                    # <!--- get all values for trading
                    round_volume = contracts[symbol]["round_volume"]
                    min_volume = contracts[symbol]["min_order_qty"]
                    max_volume = contracts[symbol]["max_order_qty"]
                    pricetick = contracts[symbol]["pricetick"]

                    maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
                    taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]

                    bid_price_1 = ticks[symbol]["bid_price_1"]
                    ask_price_1 = ticks[symbol]["ask_price_1"]
                    # --->

                    l_position_size = positions[symbol][LONG_POS]["size"]
                    l_position_entry_price = positions[symbol][LONG_POS]["entry_price"]
                    l_position_pnl = (ask_price_1 - l_position_entry_price) * l_position_size - taker_fee_rate * ask_price_1 * l_position_size if l_position_size else 0

                    s_position_size = positions[symbol][SHORT_POS]["size"]
                    s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                    s_position_pnl = (s_position_entry_price - bid_price_1) * s_position_size - taker_fee_rate * bid_price_1 * s_position_size if s_position_size else 0

                    diff_pricetick_size = "N/A"
                    if status == BinanceConstant.ALLTRADED.value:
                        traded_count += 1

                        if order_type == BinanceConstant.LIMIT.value:
                            maker_rebate += maker_fee_rate * filled_price * volume
                        elif order_type == BinanceConstant.MARKET.value:
                            taker_fee += taker_fee_rate * filled_price * volume

                        if order_type == BinanceConstant.LIMIT.value:
                            if side == LONG_SIDE:
                                if pos_side == LONG_POS:
                                    last_traded_long_open_price_dict[symbol] = filled_price
                                    last_traded_long_close_price_dict[symbol] = filled_price
                                    last_traded_short_close_price_dict[symbol] = 0
                                    long_open_traded_min_price_dict[symbol] = min(filled_price, long_open_traded_min_price_dict[symbol]) if long_open_traded_min_price_dict[symbol] else filled_price
                                    long_open_count_dict[symbol] += 1
                                elif pos_side == SHORT_POS:
                                    profit_ticksize = int((s_position_entry_price - filled_price) / pricetick)
                                    if long_close_profit_ticksize_dict[symbol]:
                                        update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                    else:
                                        if short_close_profit_ticksize_dict[symbol]:
                                            update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 1)
                                        else:
                                            update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                    last_traded_long_close_price_dict[symbol] = filled_price
                                    last_traded_short_close_price_dict[symbol] = 0
                                    last_traded_short_open_price_dict[symbol] = 0
                                    long_close_count_dict[symbol] += 1
                                    short_close_count_dict[symbol] = 0
                                    diff_pricetick_size = str(profit_ticksize)
                            elif side == SHORT_SIDE:
                                if pos_side == LONG_POS:
                                    profit_ticksize = int((filled_price - l_position_entry_price) / pricetick)
                                    if short_close_profit_ticksize_dict[symbol]:
                                        update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                    else:
                                        if long_close_profit_ticksize_dict[symbol]:
                                            update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 1)
                                        else:
                                            update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                    last_traded_short_close_price_dict[symbol] = filled_price
                                    last_traded_long_close_price_dict[symbol] = 0
                                    last_traded_long_open_price_dict[symbol] = 0
                                    short_close_count_dict[symbol] += 1
                                    long_close_count_dict[symbol] = 0
                                    diff_pricetick_size = str(profit_ticksize)
                                elif pos_side == SHORT_POS:
                                    last_traded_short_open_price_dict[symbol] = filled_price
                                    last_traded_short_close_price_dict[symbol] = filled_price
                                    last_traded_long_close_price_dict[symbol] = 0
                                    short_open_traded_max_price_dict[symbol] = max(filled_price, short_open_traded_max_price_dict[symbol]) if short_open_traded_max_price_dict[symbol] else filled_price
                                    short_open_count_dict[symbol] += 1

                        traded_volume = filled_price * abs(volume)
                        total_amount += traded_volume
                        current_traded_amount += traded_volume

                        title = symbol.replace(QUOTE_COIN, "")
                        date_time = Utils.get_current_time_mdhm()
                        direction_offset = DIRECTION_OFFSET[side][pos_side]

                        log_txt = f'{traded_count: >8}{title: >12}{order_type: >8}{direction_offset: >16}{Utils.round_to(l_position_size, round_volume): >12} / {Utils.round_to(s_position_size, round_volume): <12}{round(l_position_pnl, 2): >12} / {round(s_position_pnl, 2): <12}{Utils.round_to(l_position_entry_price, pricetick): >12} / {Utils.round_to(s_position_entry_price, pricetick): <12}{diff_pricetick_size: >6}{Utils.round_to(filled_price, pricetick): >12}{Utils.round_to(volume, round_volume): >12}{round(current_traded_amount, 2): >16}{int(current_runtime): >8}{round(balance, 2): >12}{date_time: >18}'
                        print(log_txt)

                        log_file_name = Utils.get_current_time_mdh()
                        write_log(EXCHANGE, account_name, symbol, log_txt, log_file_name)

                        if order_type == "LIQUIDATION":
                            write_process_status_for_symbol(EXCHANGE, account_name, symbol, 400)

# orderbook websocket thread start
bookticker_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + BinanceConstant.F_WEBSOCKET_BOOK_TICKERS_STREAM_PARAM.value
orderbook_websocket_thread = OrderbookWebsocketThread(bookticker_url, False, False)
orderbook_websocket_thread.start()

# trade websocket thread start
listen_key = binance_futures_rest_api.get_new_listen_key()
USER_STREAM_STARTTIME = time()

trade_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + listen_key
trade_websocket_thread = TradeWebsocketThread(trade_url, False, False)
trade_websocket_thread.start()

sleep(5)

INITIAL_TAKER_VOLUME_PERCENT = float(sys.argv[1:][0])
BASE_POS_VOLUME_PERCENT = float(sys.argv[1:][1])
OPEN_TICK_VOLUME_RATE = int(sys.argv[1:][2])
CLOSE_TICK_VOLUME_RATE = int(sys.argv[1:][3])
PROFIT_TICKSIZE_PERCENT = float(sys.argv[1:][4])
GRID_TICKSIZE_PERCENT = float(sys.argv[1:][5])
CLOSE_TICKSIZE_PERCENT = float(sys.argv[1:][6])
OPEN_TICKSIZE_PERCENT = float(sys.argv[1:][7])
BOTH_OPEN_SIGNAL = int(sys.argv[1:][8])
BOTH_OPEN_POS_RATE = int(sys.argv[1:][9])
BOTH_CLOSE_SIGNAL = int(sys.argv[1:][10])
BOTH_CLOSE_POS_RATE = int(sys.argv[1:][11])
LONG_POS_CLOSE_SIGNAL = int(sys.argv[1:][12])
LONG_POS_CLOSE_RATE = int(sys.argv[1:][13])
SHORT_POS_CLOSE_SIGNAL = int(sys.argv[1:][14])
SHORT_POS_CLOSE_RATE = int(sys.argv[1:][15])
LONG_OPEN_SIGNAL = int(sys.argv[1:][16])
LONG_OPEN_RATE = int(sys.argv[1:][17])
SHORT_OPEN_SIGNAL = int(sys.argv[1:][18])
SHORT_OPEN_RATE = int(sys.argv[1:][19])
ADDED_BALANCE = float(sys.argv[1:][20])

read_process_status_signal_for_all(EXCHANGE, account_name)

for symbol in symbol_list:
    read_process_status_signal_for_symbol(EXCHANGE, account_name, symbol)
    write_parameters(EXCHANGE, account_name, symbol)
    read_traded_info(EXCHANGE, account_name, symbol)
    read_variables(EXCHANGE, account_name, symbol)
    for side in (LONG_SIDE, SHORT_SIDE):
        read_close_profit_dict(EXCHANGE, account_name, symbol, side)

CLS_TIME = time()
TRADED_INFO_TIME = time()

print(f'==================================================')
print(balance, fee_rates[symbol_list[0]]["maker_fee_rate"], fee_rates[symbol_list[0]]["taker_fee_rate"])
print(f'==================================================')

sleep(5)

if start_balance == 0:
    start_balance = balance

if min_balance == 0:
    min_balance = start_balance

if max_balance == 0:
    max_balance = start_balance

start_time = time()
last_runtime = total_runtime

for symbol in symbol_list:
    # <!--- check some parameters for market/trade/account
    contract = contracts[symbol]
    if symbol not in ticks.keys():
        while True:
            sleep(1)
            if symbol in ticks.keys():
                break

    ask_price_1 = ticks[symbol]["ask_price_1"]
    round_volume = contract["round_volume"]
    max_volume = contract["max_order_qty"]
    taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]

    initial_volume = Utils.round_to(INITIAL_TAKER_VOLUME_PERCENT * balance / (100 * ask_price_1 * len(symbol_list)), round_volume)
    if symbol not in initial_taker_open_volume_dict.keys() or initial_taker_open_volume_dict[symbol] == 0:
        initial_taker_open_volume_dict[symbol] = min(initial_volume, max_volume)
        print(f'Initial long/short open volume: {initial_taker_open_volume_dict[symbol]}')

        initial_open_taker_fee = 2 * taker_fee_rate * ask_price_1 * initial_taker_open_volume_dict[symbol]
        initial_open_taker_fee_percent = (initial_open_taker_fee / balance) * 100
        print(f'Initial open taker fee / percent: {round(initial_open_taker_fee, 2)} / {round(initial_open_taker_fee_percent, 2)}')

    long_pos_size = positions[symbol][LONG_POS]["size"]
    short_pos_size = positions[symbol][SHORT_POS]["size"]

    if long_pos_size == 0 and short_pos_size == 0:
        # <!--- send taker order with initial volume
        response = binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, initial_taker_open_volume_dict[symbol], LONG_POS)
        response = binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, initial_taker_open_volume_dict[symbol], SHORT_POS)
        # --->

sleep(1)

# main running
while True:
    current_runtime = round((time() - start_time) / 60)
    if (time() - USER_STREAM_STARTTIME) >= BinanceConstant.USER_STREAM_TIMEOUT.value:
        binance_futures_rest_api.renew_listen_key(listen_key)
        USER_STREAM_STARTTIME = time()

    if symbol_list:
        for symbol in symbol_list:
            sleep(0.5)

            read_parameters(EXCHANGE, account_name, symbol)

            # <!--- check some parameters for market/trade/account
            contract = contracts[symbol]
            if symbol not in ticks.keys():
                continue

            balance = wallets[QUOTE_COIN]["balance"]
            if balance > max_balance:
                max_balance = balance

            if balance < min_balance:
                min_balance = balance

            # <!--- get all values for trading
            round_volume = contract["round_volume"]
            min_volume = contract["min_order_qty"]
            max_volume = contract["max_order_qty"]
            pricetick = contract["pricetick"]
            notional_value = contract["notional"]

            maker_fee_rate = fee_rates[symbol]["maker_fee_rate"]
            taker_fee_rate = fee_rates[symbol]["taker_fee_rate"]
            # --->

            # <!--- calc tick volume and grid ticksize
            ask_price_1 = ticks[symbol]["ask_price_1"]

            _initial_volume = Utils.round_to(INITIAL_TAKER_VOLUME_PERCENT * balance / (100 * ask_price_1 * len(symbol_list)), round_volume)
            if symbol not in initial_taker_open_volume_dict.keys() or initial_taker_open_volume_dict[symbol] == 0:
                initial_taker_open_volume_dict[symbol] = min(_initial_volume, max_volume)
                print(f'Initial long/short open volume: {initial_taker_open_volume_dict[symbol]}')

                _initial_open_taker_fee = 2 * taker_fee_rate * ask_price_1 * initial_taker_open_volume_dict[symbol]
                _initial_open_taker_fee_percent = (_initial_open_taker_fee / balance) * 100
                print(f'Initial taker open fee/percent: {round(_initial_open_taker_fee, 2)}/{round(_initial_open_taker_fee_percent, 2)}')
            initial_taker_open_volume_dict[symbol] = min(initial_taker_open_volume_dict[symbol], _initial_volume, max_volume)

            _base_pos_volume = Utils.round_to(BASE_POS_VOLUME_PERCENT * balance / (100 * ask_price_1 * len(symbol_list)), round_volume)
            if symbol not in base_pos_volume_dict.keys() or base_pos_volume_dict[symbol] == 0:
                base_pos_volume_dict[symbol] = min(_base_pos_volume, max_volume)
                print(f'Base position volume: {base_pos_volume_dict[symbol]}')
            base_pos_volume_dict[symbol] = min(base_pos_volume_dict[symbol], _base_pos_volume)

            open_min_volume = Utils.round_to(1.1 * notional_value / ask_price_1, round_volume)
            _open_tick_volume = Utils.round_to(base_pos_volume_dict[symbol] / OPEN_TICK_VOLUME_RATE, round_volume)
            if symbol not in open_tick_volume_dict.keys() or open_tick_volume_dict[symbol] == 0:
                open_tick_volume_dict[symbol] = _open_tick_volume
                print(f'Open tick volume: {open_tick_volume_dict[symbol]}')
            open_tick_volume_dict[symbol] = max(open_tick_volume_dict[symbol], open_min_volume)

            _close_tick_volume = Utils.round_to(base_pos_volume_dict[symbol] / CLOSE_TICK_VOLUME_RATE, round_volume)
            if symbol not in close_tick_volume_dict.keys() or close_tick_volume_dict[symbol] == 0:
                close_tick_volume_dict[symbol] = max(_close_tick_volume, min_volume)
                print(f'Close tick volume: {close_tick_volume_dict[symbol]}')
            close_tick_volume_dict[symbol] = max(_close_tick_volume, min_volume)

            _market_price_ticksize = int(ask_price_1 / pricetick)
            if symbol not in market_price_ticksize_dict.keys() or market_price_ticksize_dict[symbol] == 0:
                market_price_ticksize_dict[symbol] = _market_price_ticksize
                print(f'Market price ticksize: {market_price_ticksize_dict[symbol]}')
            market_price_ticksize_dict[symbol] = max(market_price_ticksize_dict[symbol], _market_price_ticksize)

            _grid_ticksize = int(GRID_TICKSIZE_PERCENT * market_price_ticksize_dict[symbol] / 100) + 1
            if symbol not in grid_ticksize_dict.keys() or grid_ticksize_dict[symbol] == 0:
                grid_ticksize_dict[symbol] = _grid_ticksize
                print(f'Grid ticksize: {grid_ticksize_dict[symbol]}')
            grid_ticksize_dict[symbol] = max(grid_ticksize_dict[symbol], _grid_ticksize)

            _profit_ticksize = int(PROFIT_TICKSIZE_PERCENT * market_price_ticksize_dict[symbol] / 100) + 1
            if symbol not in profit_ticksize_dict.keys() or profit_ticksize_dict[symbol] == 0:
                profit_ticksize_dict[symbol] = _profit_ticksize
                print(f'Profit ticksize: {profit_ticksize_dict[symbol]}')
            profit_ticksize_dict[symbol] = max(profit_ticksize_dict[symbol], _profit_ticksize)

            _fee_ticksize = int(2 * taker_fee_rate * market_price_ticksize_dict[symbol]) + 1 if maker_fee_rate <= 0 else int(2 * (maker_fee_rate + taker_fee_rate) * market_price_ticksize_dict[symbol]) + 1
            if symbol not in fee_ticksize_dict.keys() or fee_ticksize_dict[symbol] == 0:
                fee_ticksize_dict[symbol] = _fee_ticksize
                print(f'Fee ticksize: {fee_ticksize_dict[symbol]}')
            fee_ticksize_dict[symbol] = max(fee_ticksize_dict[symbol], _fee_ticksize)

            _open_ticksize = int((open_tick_volume_dict[symbol] / base_pos_volume_dict[symbol]) * market_price_ticksize_dict[symbol]) + 1
            if symbol not in open_ticksize_dict.keys() or open_ticksize_dict[symbol] == 0:
                open_ticksize_dict[symbol] = _open_ticksize
                print(f'Open ticksize: {open_ticksize_dict[symbol]}')
            open_ticksize_dict[symbol] =  max(open_ticksize_dict[symbol], _open_ticksize)
            # -->

            open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
            open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

            # sending orders
            open_orders = binance_futures_rest_api.get_open_orders(symbol)
            for new_side in (LONG_SIDE, SHORT_SIDE):
                for new_position_side in (LONG_POS, SHORT_POS):
                    new_price, new_volume = 0, 0

                    bid_price_1 = ticks[symbol]["bid_price_1"]
                    ask_price_1 = ticks[symbol]["ask_price_1"]

                    open_order_ids[new_side][new_position_side] = ''
                    open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                    # new price
                    if new_side == LONG_SIDE:
                        new_price = Utils.round_to(bid_price_1, pricetick)
                    elif new_side == SHORT_SIDE:
                        new_price = Utils.round_to(ask_price_1, pricetick)

                    if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                        open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                        open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                        open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                    long_pos_size = positions[symbol][LONG_POS]["size"]
                    long_pos_entry_price = positions[symbol][LONG_POS]["entry_price"]
                    long_pos_pnl_value = (ask_price_1 - long_pos_entry_price) * long_pos_size - taker_fee_rate * ask_price_1 * long_pos_size if long_pos_size else 0
                    if not long_open_traded_min_price_dict[symbol]:
                        long_open_traded_min_price_dict[symbol] = long_pos_entry_price if long_pos_size else 0

                    if not long_pos_size:
                        long_open_count_dict[symbol] = 0
                        short_close_count_dict[symbol] = 0
                        long_open_traded_min_price_dict[symbol] = 0
                        last_traded_long_open_price_dict[symbol] = 0
                        short_open_traded_max_price_dict[symbol] = short_pos_entry_price if short_pos_size else 0

                    short_pos_size = positions[symbol][SHORT_POS]["size"]
                    short_pos_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                    short_pos_pnl_value = (short_pos_entry_price - bid_price_1) * short_pos_size - taker_fee_rate * bid_price_1 * short_pos_size if short_pos_size else 0
                    if not short_open_traded_max_price_dict[symbol]:
                        short_open_traded_max_price_dict[symbol] = short_pos_entry_price if short_pos_size else 0

                    if not short_pos_size:
                        short_open_count_dict[symbol] = 0
                        long_close_count_dict[symbol] = 0
                        short_open_traded_max_price_dict[symbol] = 0
                        last_traded_short_open_price_dict[symbol] = 0
                        last_traded_long_close_price_dict[symbol] = 0

                    if long_pos_size and short_pos_size:
                        if BOTH_CLOSE_SIGNAL and BOTH_CLOSE_POS_RATE:
                            print(f'No.1: Manually close both positions: {Utils.round_to(long_pos_size / BOTH_CLOSE_POS_RATE, round_volume)} / {Utils.round_to(short_pos_size / BOTH_CLOSE_POS_RATE, round_volume)}')
                            binance_futures_rest_api.cancel_all_orders(symbol)
                            response = binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.round_to(long_pos_size / BOTH_CLOSE_POS_RATE, round_volume), LONG_POS)
                            response = binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.round_to(short_pos_size / BOTH_CLOSE_POS_RATE, round_volume), SHORT_POS)

                            long_close_profit_ticksize_dict[symbol] = []
                            short_close_profit_ticksize_dict[symbol] = []

                            BOTH_CLOSE_SIGNAL = 0
                            BOTH_CLOSE_POS_RATE = 0
                            write_parameters(EXCHANGE, account_name, symbol)

                            continue
                        elif BOTH_OPEN_SIGNAL and BOTH_OPEN_POS_RATE:
                            print(f'No.2: Manually open both positions: {Utils.round_to(long_pos_size / BOTH_OPEN_POS_RATE, round_volume)} / {Utils.round_to(short_pos_size / BOTH_OPEN_POS_RATE, round_volume)}')
                            binance_futures_rest_api.cancel_all_orders(symbol)
                            response = binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.round_to(long_pos_size / BOTH_OPEN_POS_RATE, round_volume), LONG_POS)
                            response = binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.round_to(short_pos_size / BOTH_OPEN_POS_RATE, round_volume), SHORT_POS)

                            BOTH_OPEN_SIGNAL = 0
                            BOTH_OPEN_POS_RATE = 0
                            write_parameters(EXCHANGE, account_name, symbol)

                            continue
                        elif long_pos_size <= 0.5 * initial_taker_open_volume_dict[symbol] or short_pos_size < 0.5 * initial_taker_open_volume_dict[symbol]:
                            print(f'No.3: Manually open both positions: {long_pos_size} / {short_pos_size}')
                            binance_futures_rest_api.cancel_all_orders(symbol)
                            response = binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, long_pos_size, LONG_POS)
                            response = binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, short_pos_size, SHORT_POS)

                            continue

                    if new_side == LONG_SIDE:
                        if new_position_side == LONG_POS:
                            if long_pos_size:
                                if LONG_OPEN_SIGNAL and LONG_OPEN_RATE > 0:
                                    print(f'No.3: Manually long open: {Utils.round_to(long_pos_size / LONG_OPEN_RATE, round_volume)}')
                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.round_to(long_pos_size / LONG_OPEN_RATE, round_volume), LONG_POS)

                                    LONG_OPEN_SIGNAL = 0
                                    LONG_OPEN_RATE = 0
                                    write_parameters(EXCHANGE, account_name, symbol)
                                else:
                                    if long_pos_size <= short_pos_size - base_pos_volume_dict[symbol]:
                                        if new_price < long_pos_entry_price - (long_pos_size / open_tick_volume_dict[symbol]) * pricetick:
                                            if last_traded_long_open_price_dict[symbol]:
                                                if new_price < last_traded_long_open_price_dict[symbol] - grid_ticksize_dict[symbol] * pricetick:
                                                    new_volume = open_tick_volume_dict[symbol]
                                            else:
                                                new_volume = open_tick_volume_dict[symbol]
                                        else:
                                            predict_long_pos_entry_price = (long_pos_entry_price * long_pos_size + new_price * open_tick_volume_dict[symbol]) / (long_pos_size + open_tick_volume_dict[symbol])
                                            if predict_long_pos_entry_price <= short_pos_entry_price - grid_ticksize_dict[symbol] * pricetick:
                                                new_volume = open_tick_volume_dict[symbol]
                                    else:
                                        if new_price < long_pos_entry_price - (long_pos_size / open_tick_volume_dict[symbol]) * pricetick:
                                            if long_open_traded_min_price_dict[symbol] and new_price <= long_open_traded_min_price_dict[symbol] - max(open_ticksize_dict[symbol], long_pos_size / open_tick_volume_dict[symbol]) * pricetick:
                                                new_volume = open_tick_volume_dict[symbol]
                            else:
                                if short_pos_size:
                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, initial_taker_open_volume_dict[symbol], SHORT_POS)
                                    binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, initial_taker_open_volume_dict[symbol], LONG_POS)

                                    continue
                                else:
                                    long_close_profit_ticksize_dict[symbol] = []
                                    short_close_profit_ticksize_dict[symbol] = []

                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, initial_taker_open_volume_dict[symbol], SHORT_POS)
                                    binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, initial_taker_open_volume_dict[symbol], LONG_POS)

                                    continue
                        elif new_position_side == SHORT_POS:
                            if short_pos_size:
                                if SHORT_POS_CLOSE_SIGNAL and SHORT_POS_CLOSE_RATE > 0:
                                    print(f'No.5: Manually close short position: {Utils.round_to(short_pos_size / SHORT_POS_CLOSE_RATE, round_volume)}')
                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, Utils.round_to(short_pos_size / SHORT_POS_CLOSE_RATE, round_volume), SHORT_POS)

                                    SHORT_POS_CLOSE_SIGNAL = 0
                                    SHORT_POS_CLOSE_RATE = 0
                                    write_parameters(EXCHANGE, account_name, symbol)
                                else:
                                    # price
                                    if last_traded_short_close_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_short_close_price_dict[symbol] - (grid_ticksize_dict[symbol] + profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol]) * pricetick, pricetick)
                                    elif last_traded_long_close_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_long_close_price_dict[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)

                                    if new_price > bid_price_1:
                                        new_price = Utils.round_to(bid_price_1, pricetick)

                                    # volume
                                    if short_close_profit_ticksize_dict[symbol]:
                                        if short_pos_size <= long_pos_size + close_tick_volume_dict[symbol] and new_price < short_pos_entry_price - fee_ticksize_dict[symbol] * pricetick and new_price < long_pos_entry_price - fee_ticksize_dict[symbol] * pricetick:
                                            long_close_count_dict[symbol] = 0
                                            short_close_count_dict[symbol] = 0
                                            short_open_traded_max_price_dict[symbol] = 0
                                            short_close_profit_ticksize_dict[symbol] = []
                                        else:
                                            minus_ticksize = round((new_price - short_pos_entry_price) / pricetick) + profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol]
                                            max_close_rate = max(round(np.sqrt(len(short_close_profit_ticksize_dict[symbol]))), 1)
                                            new_volume = min(get_minus_close_volume(symbol, new_side, minus_ticksize), max_close_rate * close_tick_volume_dict[symbol])

                                            if short_pos_size > long_pos_size:
                                                new_volume = 0
                                    else:
                                        short_open_traded_max_price_dict[symbol] = 0
                                        entry_price_dist = max(long_pos_entry_price - short_pos_entry_price, 0) if long_pos_size else 0
                                        if new_price < short_pos_entry_price - fee_ticksize_dict[symbol] * pricetick - entry_price_dist:
                                            new_volume = min(close_tick_volume_dict[symbol], short_pos_size)
                                            if long_close_profit_ticksize_dict[symbol]:
                                                max_profit_ticksize = get_max_prfofit_ticksize(symbol, LONG_SIDE)
                                                if (short_pos_entry_price - new_price) < (max_profit_ticksize + grid_ticksize_dict[symbol]) * pricetick:
                                                    new_volume = 0
                                                elif (long_pos_size - short_pos_size) >= base_pos_volume_dict[symbol]:
                                                    new_volume = 0
                    elif new_side == SHORT_SIDE:
                        if new_position_side == SHORT_POS:
                            if short_pos_size:
                                if SHORT_OPEN_SIGNAL and SHORT_OPEN_RATE > 0:
                                    print(f'No.5: Manually short open: {Utils.round_to(short_pos_size / SHORT_OPEN_RATE, round_volume)}')
                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.round_to(short_pos_size / SHORT_OPEN_RATE, round_volume), SHORT_POS)

                                    SHORT_OPEN_SIGNAL = 0
                                    SHORT_OPEN_RATE = 0
                                    write_parameters(EXCHANGE, account_name, symbol)
                                else:
                                    if short_pos_size <= long_pos_size - base_pos_volume_dict[symbol]:
                                        if new_price > short_pos_entry_price + (short_pos_size / open_tick_volume_dict[symbol]) * pricetick:
                                            if last_traded_short_open_price_dict[symbol]:
                                                if new_price > last_traded_short_open_price_dict[symbol] + grid_ticksize_dict[symbol] * pricetick:
                                                    new_volume = open_tick_volume_dict[symbol]
                                            else:
                                                new_volume = open_tick_volume_dict[symbol]
                                        else:
                                            predict_short_pos_entry_price = (short_pos_size * short_pos_entry_price + new_price * open_tick_volume_dict[symbol]) / (short_pos_size + open_tick_volume_dict[symbol])
                                            if predict_short_pos_entry_price >= long_pos_entry_price + grid_ticksize_dict[symbol] * pricetick:
                                                new_volume = open_tick_volume_dict[symbol]
                                    else:
                                        if new_price > short_pos_entry_price + (short_pos_size / open_tick_volume_dict[symbol]) * pricetick:
                                            if short_open_traded_max_price_dict[symbol] and new_price >= short_open_traded_max_price_dict[symbol] + max(open_ticksize_dict[symbol], (short_pos_size / open_tick_volume_dict[symbol])) * pricetick:
                                                new_volume = open_tick_volume_dict[symbol]
                            else:
                                if long_pos_size:
                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, initial_taker_open_volume_dict[symbol], LONG_POS)
                                    binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, initial_taker_open_volume_dict[symbol], SHORT_POS)

                                    continue
                                else:
                                    long_close_profit_ticksize_dict[symbol] = []
                                    short_close_profit_ticksize_dict[symbol] = []

                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, LONG_SIDE, initial_taker_open_volume_dict[symbol], LONG_POS)
                                    binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, initial_taker_open_volume_dict[symbol], SHORT_POS)

                                    continue
                        elif new_position_side == LONG_POS:
                            if long_pos_size:
                                if LONG_POS_CLOSE_SIGNAL and LONG_POS_CLOSE_RATE > 0:
                                    print(f'No.3: Manually close long position: {Utils.round_to(long_pos_size / LONG_POS_CLOSE_RATE, round_volume)}')
                                    binance_futures_rest_api.cancel_all_orders(symbol)
                                    binance_futures_rest_api.send_taker_order(symbol, SHORT_SIDE, Utils.round_to(long_pos_size / LONG_POS_CLOSE_RATE, round_volume), LONG_POS)

                                    LONG_POS_CLOSE_SIGNAL = 0
                                    LONG_POS_CLOSE_RATE = 0
                                    write_parameters(EXCHANGE, account_name, symbol)
                                else:
                                    # price
                                    if last_traded_long_close_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_long_close_price_dict[symbol] + (grid_ticksize_dict[symbol] + profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol]) * pricetick, pricetick)
                                    elif last_traded_short_close_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_short_close_price_dict[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)

                                    if new_price < ask_price_1:
                                        new_price = Utils.round_to(ask_price_1, pricetick)

                                    # volume
                                    if long_close_profit_ticksize_dict[symbol]:
                                        if long_pos_size <= short_pos_size + close_tick_volume_dict[symbol] and new_price > short_pos_entry_price - fee_ticksize_dict[symbol] * pricetick and new_price > long_pos_entry_price - fee_ticksize_dict[symbol] * pricetick:
                                            long_close_count_dict[symbol] = 0
                                            short_close_count_dict[symbol] = 0
                                            long_open_traded_min_price_dict[symbol] = 0
                                            long_close_profit_ticksize_dict[symbol] = []
                                        else:
                                            minus_ticksize = round((long_pos_entry_price - new_price) / pricetick) + profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol]
                                            max_close_rate = max(round(np.sqrt(len(long_close_profit_ticksize_dict[symbol]))), 1)
                                            new_volume = min(get_minus_close_volume(symbol, new_side, minus_ticksize), max_close_rate * close_tick_volume_dict[symbol])

                                            if long_pos_size < short_pos_size:
                                                new_volume = 0
                                    else:
                                        long_open_traded_min_price_dict[symbol] = 0
                                        entry_price_dist = max(long_pos_entry_price - short_pos_entry_price, 0) if short_pos_size else 0
                                        if new_price > long_pos_entry_price + fee_ticksize_dict[symbol] * pricetick + entry_price_dist:
                                            new_volume = min(close_tick_volume_dict[symbol], long_pos_size)
                                            if short_close_profit_ticksize_dict[symbol]:
                                                max_profit_ticksize = get_max_prfofit_ticksize(symbol, SHORT_SIDE)
                                                if (new_price - long_pos_entry_price) < (max_profit_ticksize + grid_ticksize_dict[symbol]) * pricetick:
                                                    new_volume = 0
                                                elif (short_pos_size - long_pos_size) >= base_pos_volume_dict[symbol]:
                                                    new_volume = 0

                    new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                    if open_order_ids[new_side][new_position_side]:
                        open_order_id = open_order_ids[new_side][new_position_side]
                        old_price = open_order_info[new_side][new_position_side]["price"]
                        old_volume = open_order_info[new_side][new_position_side]["volume"]

                        if old_volume != new_volume or old_price != new_price:
                            binance_futures_rest_api.cancel_order(symbol, open_order_id)

                        continue

                    if new_price > 0 and new_volume >= min_volume:
                        response = binance_futures_rest_api.send_maker_order(symbol, new_side, new_price, new_volume, new_position_side)

            run_signal_for_symbol = read_process_status_signal_for_symbol(EXCHANGE, account_name, symbol)
            if run_signal_for_symbol == 400:
                print(f"Close all positons for {symbol}, and remove {symbol} from symbol list...")
                contract = contracts[symbol]
                for close_position_side in (LONG_POS, SHORT_POS):
                    close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
                    close_volume = positions[symbol][close_position_side]["size"]
                    if close_volume:
                        binance_futures_rest_api.close_all_positions(symbol, close_side, close_volume, close_position_side)

                write_traded_info(EXCHANGE, account_name, symbol)
                write_variables(EXCHANGE, account_name, symbol)
                for side in (LONG_SIDE, SHORT_SIDE):
                    write_close_profit_dict(exchange, account_name, symbol, side)

                sleep(1)

                symbol_list.remove(symbol)

        if time() - CLS_TIME > CLS_INTERVAL_TIME:
            os.system('cls')
            CLS_TIME = time()

        if time() - TRADED_INFO_TIME > TRADED_INFO_INTERVAL_TIME:
            for symbol in symbol_list:
                print(f'{symbol}: {long_close_profit_ticksize_dict[symbol]}, {short_close_profit_ticksize_dict[symbol]}')

            print(f"|==========================================================================================================================================================================================================================|")
            print(f'|{TRADED_INFO_TITLE[0]: >26}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >27}{TRADED_INFO_TITLE[4]: >32}{TRADED_INFO_TITLE[5]: >24}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18}{TRADED_INFO_TITLE[8]: >18} |')
            print(f'|           ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|')
            total_runtime = last_runtime + current_runtime
            runtime_minutes = round(total_runtime)
            runtime_hours = round(total_runtime / 60, 1)
            runtime_days = round(total_runtime / 1440, 2)
            runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'

            predict_dailty_trade_amt = round(total_amount / (total_runtime / 1440), 1) if total_runtime > 1 else 0
            predict_daily_trade_leverage = round((total_amount / (total_runtime / 1440)) / balance, 1) if total_runtime > 1 else 0
            predict_dailty_trade_amt_leverage = f'{predict_dailty_trade_amt}/{predict_daily_trade_leverage}'

            profit = round(balance - start_balance - ADDED_BALANCE, 2)
            profit_percent = f'{round((profit / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0

            rebate_fee = f'{round(maker_rebate, 2)}/{round(taker_fee, 2)}'
            print(f'| {runtime: >24}{predict_dailty_trade_amt_leverage: >27}{profit_percent: >27}{profit: >27}{round(total_amount, 3): >32}{rebate_fee: >24}{round(balance, 2): >18}{round(max_balance, 2): >18}{round(min_balance, 2): >18}  |')
            print(f'|==========================================================================================================================================================================================================================|')

            TRADED_INFO_TIME = time()

        run_signal_for_all = read_process_status_signal_for_all(EXCHANGE, account_name)
        if run_signal_for_all == 1:
            print(f'Stop! Cancelling all open orders...')

            for symbol in symbol_list:
                binance_futures_rest_api.cancel_all_orders(symbol)

            sleep(1)

            break
        elif run_signal_for_all == 2:
            print(f'Pause! Cancelling all open orders...')

            for symbol in symbol_list:
                binance_futures_rest_api.cancel_all_orders(symbol)

            sleep(1)

            while True:
                sleep(1)
                run_signal_for_all = read_process_status_signal_for_all(EXCHANGE, account_name)
                if run_signal_for_all != 2:
                    break
        elif run_signal_for_all == 3:
            print(f'All Close! Cancelling all open orders...')
            for symbol in symbol_list:
                binance_futures_rest_api.cancel_all_orders(symbol)

                sleep(0.5)

                print(f'Close all positions for {symbol}...')
                contract = contracts[symbol]
                for close_position_side in (LONG_POS, SHORT_POS):
                    close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
                    close_volume = positions[symbol][close_position_side]["size"]
                    if close_volume:
                        binance_futures_rest_api.close_all_positions(symbol, close_side, close_volume, close_position_side)
            break

sleep(3)

print(f'Saving trade info, and exit program automatically...')

write_process_status_for_all(EXCHANGE, account_name, 0)

for symbol in symbol_list:
    print(f'{symbol}: {long_close_profit_ticksize_dict[symbol]}, {short_close_profit_ticksize_dict[symbol]}')

    write_parameters(EXCHANGE, account_name, symbol)
    write_traded_info(EXCHANGE, account_name, symbol)
    write_variables(EXCHANGE, account_name, symbol)
    write_process_status_for_symbol(EXCHANGE, account_name, symbol, 0)

    for side in (LONG_SIDE, SHORT_SIDE):
        write_close_profit_dict(EXCHANGE, account_name, symbol, side)

sleep(3)

print(f'Exit!')
