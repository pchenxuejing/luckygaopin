#!/usr/bin/env python
import logging
from binance.um_futures import UMFutures
from binance.lib.utils import config_logging
from binance.error import ClientError

from constant import BinanceConstant, ExchangeConstant
from utils import Utils

config_logging(logging, logging.INFO)

class BinanceFuturesRestApi:
    """
    exchange name
    """
    exchange = ExchangeConstant.BINANCE.value
    category = BinanceConstant.FUTURES.value

    """
    Callback when this class is inited.
    """
    def __init__(self, key, secret):
        self.session = UMFutures(
            key=key,
            secret=secret
        )

    """
    "   Desc: Get a new listen key
    """
    def get_new_listen_key(self):
        try:
            response = self.session.new_listen_key()
            if response:
                return response['listenKey']
        except ClientError as error:
            print(f"Error: get_new_listen_key(): {error}")

    """
    "   Desc: renew a listen key
    """
    def renew_listen_key(self, listen_key):
        self.session.renew_listen_key(listen_key)

    """
    "   Desc: query contract for all symbols
    """
    def query_contracts(self, quote_coin):
        try:
            contracts = {}
            response = self.session.exchange_info()
            if response:
                for contract_data in response["symbols"]:
                    contract = {}

                    quote_asset = contract_data["quoteAsset"]

                    if quote_asset == quote_coin:
                        contract["exchange"] = self.exchange
                        contract["symbol"] = contract_data["symbol"]
                        contract["delivery_time"] = int(contract_data["deliveryDate"])
                        for f in contract_data["filters"]:
                            if f["filterType"] == "PRICE_FILTER":
                                contract["pricetick"] = float(f["tickSize"])
                                contract["min_price"] = float(f["minPrice"])
                                contract["max_price"] = float(f["maxPrice"])
                            elif f["filterType"] == "LOT_SIZE":
                                contract["round_volume"] = float(f["stepSize"])
                                contract["min_order_qty"] = float(f["minQty"])
                                contract["max_order_qty"] = float(f["maxQty"])
                            elif f["filterType"] == "MIN_NOTIONAL":
                                contract["notional"] = float(f["notional"])

                        contracts[contract["symbol"]] = contract

            return contracts
        except ClientError as error:
            print(f"Error: query_contract(): {error}")

    """
    "   Desc: get account's commission rate
    """
    def get_commission_rate(self, symbol):
        try:
            fee_rate = {}
            response = self.session.commission_rate(symbol=symbol, recvWindow=6000)
            if response:
                fee_rate["exchange"] = self.exchange
                fee_rate["symbol"] = response["symbol"]
                fee_rate["taker_fee_rate"] = float(response["takerCommissionRate"])
                fee_rate["maker_fee_rate"] = float(response["makerCommissionRate"])

            return fee_rate
        except ClientError as error:
            print(f"Error: get_commission_rate({symbol}): {error}")

    """
    "   Desc: get income history
    """
    def get_income_history(symbol):
        try:
            income = {}
            response = self.session.get_income_history(recvWindow=6000)
            if response:
                for income_data in response:
                    if symbol == income_data["symbol"]:
                        income["symbol"] = income_data["symbol"]
                        income["income_type"] = income_data["incomeType"]
                        income["income"] = float(income_data["income"])
                        income["asset"] = float(income_data["asset"])
                        income["info"] = float(income_data["info"])

            return income
        except ClientError as error:
            print(f"Error: get_income_history({symbol}): {error}")

    """
    "   Desc: get wallet balance
    """
    def get_wallet_balance(self):
        try:
            wallets = {}
            response = self.session.balance(recvWindow=6000)
            if response:
                for asset in response:
                    wallet = {}

                    wallet["exchange"] = self.exchange
                    wallet["asset"] = asset["asset"]
                    wallet["balance"] = float(asset["balance"])
                    wallet["available_balance"] = float(asset["availableBalance"])
                    wallet["available_withdraw"] = float(asset["maxWithdrawAmount"])

                    wallets[asset["asset"]] = wallet

            return wallets
        except ClientError as error:
            print(f"Error: get_wallet_balance(): {error}")

    """
    "   Desc: get positions by symbol
    """
    def get_symbol_positions(self, symbol):
        try:
            positions = {}
            response = self.session.get_position_risk(symbol=symbol, recvWindow=6000)
            if response:
                for position_data in response:
                    position = {}

                    position["exchange"] = self.exchange
                    position["symbol"] = position_data["symbol"]
                    position["side"] = position_data["positionSide"]
                    position["size"] = abs(float(position_data["positionAmt"]))
                    position["entry_price"] = float(position_data["entryPrice"])
                    position["liq_price"] = float(position_data["liquidationPrice"])
                    position["leverage"] = float(position_data["leverage"])
                    position["unreal_pnl"] = float(position_data["unRealizedProfit"])
                    position["margin_type"] = position_data["marginType"]

                    if position["symbol"] not in positions.keys():
                        positions[position["symbol"]] = {}

                    positions[position["symbol"]][position["side"]] = position

            return positions
        except ClientError as error:
            print(f"Error: get_positions(): {error}")

    """
    "   Desc: get positions
    """
    def get_positions(self):
        try:
            positions = {}
            response = self.session.get_position_risk(recvWindow=6000)
            if response:
                for position_data in response:
                    position = {}

                    position["exchange"] = self.exchange
                    position["symbol"] = position_data["symbol"]
                    position["side"] = position_data["positionSide"]
                    position["size"] = abs(float(position_data["positionAmt"]))
                    position["entry_price"] = float(position_data["entryPrice"])
                    position["liq_price"] = float(position_data["liquidationPrice"])
                    position["leverage"] = float(position_data["leverage"])
                    position["unreal_pnl"] = float(position_data["unRealizedProfit"])
                    position["margin_type"] = position_data["marginType"]
                    position["value"] = abs(float(position_data["positionAmt"])) * float(position_data["entryPrice"])

                    if position["symbol"] not in positions.keys():
                        positions[position["symbol"]] = {}

                    positions[position["symbol"]][position["side"]] = position

            return positions
        except ClientError as error:
            print(f"Error: get_positions(): {error}")

    """
    "   Desc: get position mode
    """
    def get_position_mode(self):
        try:
            response = self.session.get_position_mode(recvWindow=6000)
            position_mode = bool(response['dualSidePosition'])

            return position_mode
        except ClientError as error:
            print(f"Error: get_position_mode(): {error}")

    """
    "   Desc: switch position mode
    """
    def switch_position_mode(self):
        try:
            response = self.session.change_position_mode(dualSidePosition="true", recvWindow=6000)
            if response and response["msg"] == "success":
                print(f"The account's position mode successfully has been set to hedge.")
            else:
                print(f"The account's position mode has been failed to change to hedge.")
        except ClientError as error:
            print(f"Error: switch_position_mode(): {error}")

    """
    "   Desc: get multi asset mode
    """
    def get_multi_asset_mode(self):
        try:
            response = self.session.get_multi_asset_mode(recvWindow=6000)
            multi_asset_mode = bool(response['multiAssetsMargin'])

            return multi_asset_mode
        except ClientError as error:
            print(f"Error: get_multi_asset_mode(): {error}")

    """
    "   Desc: change multi asset mode
    """
    def change_multi_asset_mode(self):
        try:
            response = self.session.change_multi_asset_mode(multiAssetsMargin="true", recvWindow=6000)
            if response and response["msg"] == "success":
                print(f"The account's multi-assets mode successfully has been set to true.")
            else:
                print(f"The account's multi-assets mode has been failed to change to multi-assets mode.")
        except ClientError as error:
            print(f"Error: change_multi_asset_mode(): {error}")

    """
    "   Desc: get leverage
    """
    def get_leverage(self, symbol):
        try:
            leverage = 0
            response = self.session.leverage_brackets(symbol=symbol, recvWindow=6000)
            if response:
                symbol = response[0]["symbol"]
                leverage = float(response[0]["brackets"][0]["initialLeverage"])

            return leverage
        except ClientError as error:
            print(f"Error: get_leverage({symbol}): {error}")

    """
    "   Desc: change leverage
    """
    def change_leverage(self, symbol, leverage):
        try:
            response = self.session.change_leverage(symbol=symbol, leverage=leverage, recvWindow=6000)
            if response:
                symbol = response["symbol"]
                leverage = float(response["leverage"])
                print(f"The account's initial leverage of {symbol} has been set to {leverage}.")
            else:
                print(f"The account's initial leverage of {symbol} has been failed to change to {leverage}.")
        except ClientError as error:
            print(f"Error: change_leverage({symbol}, {leverage}): {error}")

    """
    "   Desc: change margin type
    """
    def change_margin_type(self, symbol, margin_type):
        try:
            response = self.session.change_margin_type(symbol=symbol, marginType=margin_type, recvWindow=6000)
            if response and response["msg"] == "success":
                print(f"The margin type of {symbol} successfully has been set to {margin_type}.")
            else:
                print(f"The margin type of {symbol} has been failed to change to {margin_type}.")
        except ClientError as error:
            print(f"Error: change_margin_type({symbol}, {margin_type}): {error}")

    """
    "   Desc: send a maker order
    """
    def send_maker_order(self, symbol, side, price, volume, position_side):
        if volume <= 0:
            return

        try:
            response = self.session.new_order(
                symbol=symbol,
                side=side,
                positionSide=position_side,
                type=BinanceConstant.LIMIT.value,
                price=price,
                quantity=volume,
                timeInForce=BinanceConstant.POST_ONLY.value
            )
            return response
        except ClientError as error:
            # print(f"Error: send_maker_order({symbol}, {side}, {price}, {volume}, {position_side}): {error}")
            return error

    """
    "   Desc: modify a maker order
    """
    def modify_maker_order(self, order_id, symbol, side, price, volume):
        if volume <= 0:
            return

        try:
            response = self.session.modify_order(
                orderId=order_id,
                symbol=symbol,
                side=side,
                price=price,
                quantity=volume
            )
            return response
        except ClientError as error:
            # print(f"Error: modify_maker_order({order_id}, {symbol}, {side}, {price}, {volume}): {error}")
            return error

    """
    "   Desc: send a taker order
    """
    def send_taker_order(self, symbol, side, volume, position_side):
        if volume <= 0:
            return

        try:
            response = self.session.new_order(
                symbol=symbol,
                side=side,
                positionSide=position_side,
                type=BinanceConstant.MARKET.value,
                quantity=volume
            )
            return response
        except ClientError as error:
            return_msg = f"Error: {error}"
            return return_msg

    """
    "   Desc: get maker open order
    """
    def get_open_order(self, symbol, order_id):
        try:
            response = self.session.get_open_orders(symbol=symbol, orderId=order_id, recvWindow=6000)
            if response:
                open_order = {}

                open_order["exchange"] = self.exchange
                open_order["order_id"] = int(response["orderId"])
                open_order["symbol"] = response["symbol"]
                open_order["side"] = response["side"]
                open_order["position_side"] = response["positionSide"]
                open_order["price"] = float(response["price"])
                open_order["qty"] = float(response["origQty"])
                open_order["order_status"] = response["status"]
                open_order["order_type"] = response["type"]
                open_order["avg_price"] = float(response["avgPrice"])
                open_order["cum_exec_qty"] = float(response["executedQty"])
                open_order["time_in_force"] = response["timeInForce"]
                open_order["reduce_only"] = bool(response["reduceOnly"])

            return open_order
        except ClientError as error:
            print(f"Error: get_open_order({symbol}, {order_id}): {error}")

    """
    "   Desc: get maker open orders
    """
    def get_open_orders(self, symbol):
        try:
            open_orders = {}
            response = self.session.get_orders(symbol=symbol, recvWindow=6000)
            if response:
                for open_order_data in response:
                    open_order = {}

                    open_order["exchange"] = self.exchange
                    open_order["order_id"] = int(open_order_data["orderId"])
                    open_order["symbol"] = open_order_data["symbol"]
                    open_order["side"] = open_order_data["side"]
                    open_order["position_side"] = open_order_data["positionSide"]
                    open_order["price"] = float(open_order_data["price"])
                    open_order["qty"] = float(open_order_data["origQty"])
                    open_order["order_status"] = open_order_data["status"]
                    open_order["order_type"] = open_order_data["type"]
                    open_order["avg_price"] = float(open_order_data["avgPrice"])
                    open_order["cum_exec_qty"] = float(open_order_data["executedQty"])
                    open_order["time_in_force"] = open_order_data["timeInForce"]
                    open_order["reduce_only"] = bool(open_order_data["reduceOnly"])

                    if open_order_data["side"] not in open_orders.keys():
                        open_orders[open_order_data["side"]] = {}

                    open_orders[open_order_data["side"]][open_order_data["positionSide"]] = open_order

            return open_orders
        except ClientError as error:
            print(f"Error: get_open_orders({symbol}): {error}")

    """
    "   Desc: get all orders
    """
    def get_all_orders(self, symbol):
        try:
            all_orders = {}
            response = self.session.get_all_orders(symbol=symbol, recvWindow=6000)
            if response:
                for order_data in response:
                    order = {}

                    order["exchange"] = self.exchange
                    order["order_id"] = int(order_data["orderId"])
                    order["symbol"] = order_data["symbol"]
                    order["side"] = order_data["side"]
                    order["position_side"] = order_data["positionSide"]
                    order["price"] = float(order_data["price"])
                    order["qty"] = float(order_data["origQty"])
                    order["order_status"] = order_data["status"]
                    order["order_type"] = order_data["type"]
                    order["avg_price"] = float(order_data["avgPrice"])
                    order["cum_exec_qty"] = float(order_data["executedQty"])
                    order["time_in_force"] = order_data["timeInForce"]
                    order["reduce_only"] = bool(order_data["reduceOnly"])

                    if order_data["side"] not in all_orders.keys():
                        all_orders[order_data["side"]] = {}

                    all_orders[order_data["side"]][order_data["positionSide"]] = order

            return all_orders
        except ClientError as error:
            print(f"Error: get_all_orders({symbol}): {error}")

    """
    "   Desc: cancel maker open order
    """
    def cancel_order(self, symbol, order_id):
        try:
            response = self.session.cancel_order(symbol=symbol, orderId=order_id, recvWindow=6000)
            if response:
                open_order = {}

                open_order["exchange"] = self.exchange
                open_order["order_id"] = int(response["orderId"])
                open_order["symbol"] = response["symbol"]
                open_order["side"] = response["side"]
                open_order["position_side"] = response["positionSide"]
                open_order["price"] = float(response["price"])
                open_order["qty"] = float(response["origQty"])
                open_order["order_status"] = response["status"]
                open_order["order_type"] = response["type"]
                open_order["avg_price"] = float(response["avgPrice"])
                open_order["cum_exec_qty"] = float(response["executedQty"])
                open_order["time_in_force"] = response["timeInForce"]
                open_order["reduce_only"] = bool(response["reduceOnly"])

            return open_order
        except ClientError as error:
            print(f"Error: cancel_order({symbol}, {order_id}): {error}")

    """
    "   Desc: cancel maker open orders
    """
    def cancel_all_orders(self, symbol):
        try:
            response = self.session.cancel_open_orders(symbol=symbol, recvWindow=6000)
            if response:
                msg = response["msg"]
                print(f"{symbol}: {msg}")
        except ClientError as error:
            print(f"Error: cancel_all_orders({symbol}): {error}")

    """
    "   Desc: close all positions
    """
    def close_all_positions(self, symbol, side, volume, position_side):
        if volume <= 0:
            return

        try:
            response = self.session.new_order(
                symbol=symbol,
                side=side,
                positionSide=position_side,
                type=BinanceConstant.MARKET.value,
                quantity=volume
            )
            print(f"Close {volume} position for {symbol} and {position_side} position.")
        except ClientError as error:
            print(f"Error: close_all_positions({symbol}, {side}, {position_side}, {volume}): {error}")
