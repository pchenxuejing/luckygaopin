"""
General constant string used in strategy.
"""
from enum import Enum

class RestApiConstant(Enum):
    """
    Account Type
    """
    MAKER = "MAKER"
    TAKER = "TAKER"

    """
    Rest API urls
    """
    WEB_HOST = 'http://www.tiptoptrading.cn/tiptoptrading'
    LOGIN_URL = WEB_HOST + '/auth/signin'

    GET_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/query'
    UPDATE_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/update'

    GET_TAKER_ACCOUNTS_URL = WEB_HOST + '/tapi/query'
    UPDATE_TAKER_ACCOUNT_URL = WEB_HOST + '/tapi/update'

    GET_TRADING_OPTION_URL = WEB_HOST + '/option/query?category='

    RUNNING_STATUS_LIST = ["waiting", "running"]
    STOP_STATUS_LIST = ["stopped", "closed"]
    CLOSE_STATUS_LIST = ["closed"]

    """
    WebSokcet
    """
    WEBSOCKET_HOST = "10.40.168.57"
    WEBSOCKET_PORT = 5000
    WEBSOCKET_URL = "ws://10.40.168.57:5000"

    WEBSOCKET_DIRECTION_FROM_TAKER = "FROM_TAKER"
    WEBSOCKET_DIRECTION_FROM_MAKER = "FROM_MAKER"

class ExchangeConstant(Enum):
    """
    Exchange
    """
    BINANCE = "BINANCE"
    BYBIT = "BYBIT"
    GATEIO = "GATEIO"
    BITMEX = "BITMEX"
    OKEX = "OKEX"
    HUOBI = "HUOBI"
    BITFINEX = "BITFINEX"
    COINBASE = "COINBASE"
    DERIBIT = "DERIBIT"
    BITSTAMP = "BITSTAMP"
    BITCOKE = "BITCOKE"
    PHEMEX = "PHEMEX"

class BinanceConstant(Enum):
    """
    Websocket
    """
    F_WEBSOCKET_RAW_STREAM_HOST ="wss://fstream.binance.com/ws/"
    F_WEBSOCKET_COMBINED_STREAM_HOST ="wss://fstream.binance.com/stream?streams="
    F_WEBSOCKET_BOOK_TICKERS_STREAM_PARAM = "!bookTicker"

    USER_STREAM_TIMEOUT = 59 * 60

    """
    Quote currency
    """
    QUOTE_USDT = "USDT"
    QUOTE_USDC = "USDC"
    QUOTE_BUSD = "BUSD"

    """
    Trade Category
    """
    SPOT = "SPOT"
    FUTURES = "FUTURES"

    """
    Direction of order/trade/position.
    """
    LONG = "BUY"
    SHORT = "SELL"

    POSITION_LONG = "LONG"
    POSITION_SHORT = "SHORT"

    """
    Order Status
    """
    NOTTRADED = "NEW"
    PARTTRADED = "PARTIALLY_FILLED"
    ALLTRADED = "FILLED"
    CANCELLED = "CANCELED"
    REJECTED = "REJECTED"
    # EXPIRED = "EXPIRED"

    """
    Order Type
    """
    LIMIT = "LIMIT"
    MARKET = "MARKET"
    STOP = "STOP"
    TAKE_PROFIT = "TAKE_PROFIT"
    LIQUIDATION = "LIQUIDATION"

    """
    Execution Type
    """
    NEW = "NEW"
    CANCELED = "CANCELED"
    CALCULATED = "CALCULATED"
    EXPIRED = "EXPIRED"
    TRADE = "TRADE"
    AMENDMENT = "AMENDMENT"

    """
    TimeInForce
    """
    GTC = "GTC"
    IOC = "IOC"
    FOK = "FOK"
    POST_ONLY = "GTX"

    """
    Margin Type
    """
    ISOLATED = "ISOLATED"
    CROSSED = "CROSSED"

    """
    Transfer Type
    """
    MAIN_UMFUTURE = "MAIN_UMFUTURE"                                 # Spot account transfer to USDⓈ-M Futures account
    MAIN_CMFUTURE = "MAIN_CMFUTURE"                                 # Spot account transfer to COIN-M Futures account
    MAIN_MARGIN = "MAIN_MARGIN"                                     # Spot account transfer to Margin（cross）account
    UMFUTURE_MAIN = "UMFUTURE_MAIN"                                 # USDⓈ-M Futures account transfer to Spot account
    UMFUTURE_MARGIN = "UMFUTURE_MARGIN"                             # USDⓈ-M Futures account transfer to Margin（cross）account
    CMFUTURE_MAIN = "CMFUTURE_MAIN"                                 # COIN-M Futures account transfer to Spot account
    CMFUTURE_MARGIN = "CMFUTURE_MARGIN"                             # COIN-M Futures account transfer to Margin(cross) account
    MARGIN_MAIN = "MARGIN_MAIN"                                     # Margin（cross）account transfer to Spot account
    MARGIN_UMFUTURE = "MARGIN_UMFUTURE"                             # Margin（cross）account transfer to USDⓈ-M Futures
    MARGIN_CMFUTURE = "MARGIN_CMFUTURE"                             # Margin（cross）account transfer to COIN-M Futures
    ISOLATEDMARGIN_MARGIN = "ISOLATEDMARGIN_MARGIN"                 # Isolated margin account transfer to Margin(cross) account
    MARGIN_ISOLATEDMARGIN = "MARGIN_ISOLATEDMARGIN"                 # Margin(cross) account transfer to Isolated margin account
    ISOLATEDMARGIN_ISOLATEDMARGIN = "ISOLATEDMARGIN_ISOLATEDMARGIN" # Isolated margin account transfer to Isolated margin account
    MAIN_FUNDING = "MAIN_FUNDING"                                   # Spot account transfer to Funding account
    FUNDING_MAIN = "FUNDING_MAIN"                                   # Funding account transfer to Spot account
    FUNDING_UMFUTURE = "FUNDING_UMFUTURE"                           # Funding account transfer to UMFUTURE account
    UMFUTURE_FUNDING = "UMFUTURE_FUNDING"                           # UMFUTURE account transfer to Funding account
    MARGIN_FUNDING = "MARGIN_FUNDING"                               # MARGIN account transfer to Funding account
    FUNDING_MARGIN = "FUNDING_MARGIN"                               # Funding account transfer to Margin account
    FUNDING_CMFUTURE = "FUNDING_CMFUTURE"                           # Funding account transfer to CMFUTURE account
    CMFUTURE_FUNDING = "CMFUTURE_FUNDING"                           # CMFUTURE account transfer to Funding account
    MAIN_OPTION = "MAIN_OPTION"                                     # Spot account transfer to Options account
    OPTION_MAIN = "OPTION_MAIN"                                     # Options account transfer to Spot account
    UMFUTURE_OPTION = "UMFUTURE_OPTION"                             # USDⓈ-M Futures account transfer to Options account
    OPTION_UMFUTURE = "OPTION_UMFUTURE"                             # Options account transfer to USDⓈ-M Futures account
    MARGIN_OPTION = "MARGIN_OPTION"                                 # Margin（cross）account transfer to Options account
    OPTION_MARGIN = "OPTION_MARGIN"                                 # Options account transfer to Margin（cross）account
    FUNDING_OPTION = "FUNDING_OPTION"                               # Funding account transfer to Options account
    OPTION_FUNDING = "OPTION_FUNDING"                               # Options account transfer to Funding account
    MAIN_PORTFOLIO_MARGIN = "MAIN_PORTFOLIO_MARGIN"                 # Spot account transfer to Portfolio Margin account
    PORTFOLIO_MARGIN_MAIN = "PORTFOLIO_MARGIN_MAIN"                 # Portfolio Margin account transfer to Spot account

    """
    Interval of bar data
    """
    MINUTE = "1m"
    HOUR = "1h"
    DAILY = "1d"
    WEEKLY = "1w"
    TICK = "tick"

    """
    Error Codes
    """
    BALANCE_NOT_SUFFICIENT = "Balance is insufficient."
    MARGIN_NOT_SUFFICIEN = "Margin is insufficient."
