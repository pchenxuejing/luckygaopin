#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import Dict
from time import sleep, time
import numpy as np

import threading
import websocket

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, BinanceConstant
from binance_futures_rest_api import BinanceFuturesRestApi

# rest api
key = "sguwhAV1G7sHsPTuQ0gfPK8cLe1krUypRbtzkC2cMC17idTxIExUCH8mToZZk3SW"
secret = "jAWOgr4Qqt619yxuA2KgE3V2Mr6xSlrS4Vl47cRVYpqBfMm2LHLzBCSTrYxmvxXo"

# exchange api
contracts = {}
ticks = {}

EXCHANGE = ExchangeConstant.BINANCE.value
QUOTE_COIN = BinanceConstant.QUOTE_USDT.value

####### Exchange's Rest API #######
binance_futures_rest_api = BinanceFuturesRestApi(key, secret)
contracts = binance_futures_rest_api.query_contracts(QUOTE_COIN)

"""
"   Desc: Read symbols from a txt file
"""
def read_symbols_from_file():
    log_file = "C:\\Users\\Administrator\\strategies\\top 100 currencies.txt"

    arr = []
    file1 = open(log_file, 'r')
    lines = file1.readlines()
    for line in lines:
        if " logo" in line:
            arr.append(line.replace(" logo", "")[:-1])

    return arr

top_100_symbol_list = read_symbols_from_file()

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever()

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        message = json.loads(message)
        if message:
            symbol = message["s"]
            tick = {}
            tick["exchange"] = EXCHANGE
            tick["symbol"] = symbol
            tick["bid_price_1"] = float(message["b"])
            tick["bid_volume_1"] = float(message["B"])
            tick["ask_price_1"] = float(message["a"])
            tick["ask_volume_1"] = float(message["A"])

            ticks[symbol] = tick

# orderbook websocket thread start
bookticker_url = BinanceConstant.F_WEBSOCKET_RAW_STREAM_HOST.value + BinanceConstant.F_WEBSOCKET_BOOK_TICKERS_STREAM_PARAM.value
orderbook_websocket_thread = OrderbookWebsocketThread(bookticker_url, False, False)
orderbook_websocket_thread.start()

sleep(10)

symbol_list = []

while True:
    for symbol in list(contracts):
        if symbol not in ticks.keys():
            continue

        contract = contracts[symbol]

        round_volume = contract["round_volume"]
        min_volume = contract["min_order_qty"]
        notional_value = contract["notional"]

        if round_volume == min_volume and min_volume * ticks[symbol]["ask_price_1"] <= 5 and notional_value <= 5:
            symbol_list.append(symbol)

    break

result = []
for symbol in top_100_symbol_list:
    for s in symbol_list:
        if symbol + "USDT" in s:
            result.append(s)

print(result)

print(len(result))

sleep(1)
