#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import List, Dict
from time import sleep, time
import numpy as np

import threading
import threading
import websocket as wb

import hashlib
import hmac

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, GateioConstant
from gateio_futures_rest_api import GateioFuturesRestApi

# exchange api
uid = "15880324"
api_key = "29b40df0a26c1ac606ec4a7976f6a971"
api_secret = "87c2386bec4682c54552925fe1ea5303f33bccd2b2146532f1f466a15cd7f5dc"
account_name = "mine"

# ['XRP_USDT', 'DOGE_USDT', 'ADA_USDT', 'TON_USDT', '1000SHIB_USDT', 'DOT_USDT', 'TRX_USDT', 'MATIC_USDT', 'APT_USDT', 'STXUSDT', 'FIL_USDT', 'ATOM_USDT', 'ARB_USDT', 'IMX_USDT', 'RNDR_USDT', 'XLM_USDT', 'OP_USDT', 'HBAR_USDT', 'GRT_USDT', 'KAS_USDT', 'INJ_USDT', '1000PEPE_USDT', 'VET_USDT', 'FTM_USDT', 'MKR_USDT', 'LDO_USDT', 'THETA_USDT', 'WIF_USDT', 'XMR_USDT', 'HBAR_USDT', 'AR_USDT', 'DAR_USDT', 'SEI_USDT', '1000FLOKI_USDT', 'SUI_USDT', 'FET_USDT', 'ALGO_USDT', 'GALA_USDT', 'FLOW_USDT', 'CFX_USDT', 'JUP_USDT', 'STRK_USDT', 'DYDX_USDT', 'SNX_USDT', 'SAND_USDT', '1000BONK_USDT', 'AGIX_USDT', 'PYTH_USDT', '1000XEC_USDT', 'MINA_USDT', 'ONDO_USDT', 'XTZ_USDT', 'CHZ_USDT', 'MANA_USDT', 'AXL_USDT', 'APE_USDT', 'EOS_USDT', 'CAKE_USDT', 'NEO_USDT', '1000SATS_USDT', 'IOTA_USDT', 'JASMY_USDT', 'KAVA_USDT']
symbol_list = ['DOGE_USDT']

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}

traded_count = 0

EXCHANGE = ExchangeConstant.GATEIO.value
CATEGORY = GateioConstant.FUTURES.value
QUOTE_COIN = GateioConstant.QUOTE_USDT.value
ACCOUNT_TYPE = RestApiConstant.MAKER.value
OPPOSITE_SIDE: Dict[str, str] = {"bid": "ask", "ask": "bid"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"bid": "dual_short", "ask": "dual_long"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"dual_long": "ask", "dual_short": "bid"}
DIRECTION_OFFSET = {"bid": {"dual_long": "LONG_OPEN", "dual_short": "LONG_CLOSE"}, "ask":{"dual_long": "SHORT_CLOSE", "dual_short": "SHORT_OPEN"}}

LONG_SIDE = GateioConstant.LONG.value
SHORT_SIDE = GateioConstant.SHORT.value

LONG_POS = GateioConstant.POSITION_LONG.value
SHORT_POS = GateioConstant.POSITION_SHORT.value

OFFSET_OPEN = GateioConstant.OFFSET_OPEN.value
OFFSET_CLOSE = GateioConstant.OFFSET_CLOSE.value

def generate_websocket_sign(secret, channel, event, time):
    """"""
    message='channel=%s&event=%s&time=%s' % (channel, event, time)

    signature=hmac.new(
        secret.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha512
    ).hexdigest()

    return signature

def generate_req(key, secret, channel: str, event: str, pay_load: List):
    """"""
    expires=int(time())
    signature=generate_websocket_sign(secret, channel, event, expires)

    req={
        "time": expires,
        "channel": channel,
        "event": event,
        "payload": pay_load,
        "auth": {
            "method": "api_key",
            "KEY": key,
            "SIGN": signature
        }
    }

    return req

####### Exchange's Rest API #######
gateio_futures_rest_api = GateioFuturesRestApi(api_key, api_secret, GateioConstant.RUN_HOST.value, GateioConstant.SETTLE_USDT.value)

account = gateio_futures_rest_api.get_account_detail()
contracts = gateio_futures_rest_api.query_contracts()
wallet = gateio_futures_rest_api.get_wallet_balance()
balance = wallet["balance"]

print(balance)

if contracts:
    for symbol in symbol_list:
        contract = contracts[symbol]
        positions[symbol] = {}
        _positions = gateio_futures_rest_api.query_positions(symbol)

        if _positions:
            for position_value in _positions.values():
                for position in position_value.values():
                    position_side = position["side"]
                    positions[symbol][position_side] = position

        print(positions[symbol])

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, key, secret, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)
        self.key = key
        self.secret = secret

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever(ping_interval=5)

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")
        for symbol in symbol_list:
            req = generate_req(
                self.key,
                self.secret,
                channel=GateioConstant.ORDERBOOK_CHANNEL.value,
                event="subscribe",
                pay_load=[symbol, "5", "0"]
            )
            self.ws.send(json.dumps(req))

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        message = json.loads(message)
        if message:
            if message["event"] == "all":
                result = message["result"]
                symbol = result["contract"]

                if symbol in symbol_list:
                    tick = {}
                    tick["exchange"] = EXCHANGE
                    tick["symbol"] = symbol

                    if "asks" in result.keys():
                        ask = result["asks"][0]
                        tick["ask_price_1"] = float(ask["p"])
                        tick["ask_volume_1"] = float(ask["s"])
                    else:
                        return

                    if "bids" in result.keys():
                        bid = result["bids"][0]
                        tick["bid_price_1"] = float(bid["p"])
                        tick["bid_volume_1"] = float(bid["s"])
                    else:
                        return

                    ticks[symbol] = tick

# Positions Websocket Thread
class PositionsWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, key, secret, uid, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)
        self.key = key
        self.secret = secret
        self.uid = uid

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever(ping_interval=5)

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("PositionsWebsocketThread's Connection opened.")
        req = generate_req(
            self.key,
            self.secret,
            channel=GateioConstant.POSITION_CHANNEL.value,
            event="subscribe",
            pay_load=[self.uid, symbol]
        )
        self.ws.send(json.dumps(req))

    def on_close(self, ws):
        print("PositionsWebsocketThread's Connection closed.")

    def on_error(self, ws, error):
        print("PositionsWebsocketThread's Error: ", error)

    def on_message(self, ws, message):
        global positions
        message = json.loads(message)
        if message:
            if message["event"] == "update":
                result = message["result"]
                for position_data in result:                    
                    position = {}

                    symbol = position_data["contract"]
                    if symbol in symbol_list:
                        position["exchange"] = EXCHANGE
                        position["symbol"] = position_data["contract"]
                        position["side"] = position_data["mode"]
                        position["size"] = abs(float(position_data["size"]))
                        position["entry_price"] = float(position_data["entry_price"])
                        position["leverage"] = float(position_data["leverage"])
                        position["leverage_max"] = float(position_data["leverage_max"])
                        position["value"] = position["size"] * position["entry_price"]
                        position["liq_price"] = float(position_data["liq_price"])
                        position["margin"] = float(position_data["margin"])
                        position["risk_limit"] = float(position_data["risk_limit"])
                        position["maintenance_rate"] = float(position_data["maintenance_rate"])

                        if position["symbol"] not in positions.keys():
                            positions[position["symbol"]] = {}

                        positions[position["symbol"]][position["side"]] = position

# Order Websocket Thread
class OrderWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, key, secret, uid, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)
        self.key = key
        self.secret = secret
        self.uid = uid

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever(ping_interval=5)

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderWebsocketThread's Connection Opened.")
        req = generate_req(
            self.key,
            self.secret,
            channel=GateioConstant.ORDER_CHANNEL.value,
            event="subscribe",
            pay_load=[self.uid, symbol]
        )
        self.ws.send(json.dumps(req))

    def on_close(self, ws):
        print("OrderWebsocketThread's Connection Closed.")

    def on_error(self, ws, error):
        print("OrderWebsocketThread's Error: ", error)

    def on_message(self, ws, message):
        global traded_count

        message = json.loads(message)
        if message:
            if message["event"] == "update":
                for order_data in message["result"]:
                    symbol = order_data["contract"]

                    if symbol in symbol_list:
                        order_id = int(order_data["id"])
                        price = float(order_data["price"])
                        status = order_data["status"]
                        finish_as = order_data["finish_as"]
                        volume = abs(float(order_data["size"]))
                        filled_price = float(order_data["fill_price"])
                        tif = order_data["tif"]
                        is_reduce_only = bool(order_data["is_reduce_only"])

                        side = None
                        if float(order_data["size"]) > 0:
                            side = LONG_SIDE
                        else:
                            side = SHORT_SIDE

                        pos_side = None
                        if is_reduce_only:
                            if side == LONG_SIDE:
                                pos_side = SHORT_POS
                            else:
                                pos_side = LONG_POS
                        else:
                            if side == LONG_SIDE:
                                pos_side = LONG_POS
                            else:
                                pos_side = SHORT_POS

                        # <!--- get all values for trading
                        pricetick = contracts[symbol]["pricetick"]
                        round_volume = contracts[symbol]["round_volume"]
                        maker_fee_rate = contracts[symbol]["maker_fee_rate"]
                        taker_fee_rate = contracts[symbol]["taker_fee_rate"]
                        quanto_multiplier = contracts[symbol]["quanto_multiplier"]

                        bid_price_1 = ticks[symbol]["bid_price_1"]
                        ask_price_1 = ticks[symbol]["ask_price_1"]
                        # --->

                        l_position_size = positions[symbol][LONG_POS]["size"]
                        l_position_entry_price = positions[symbol][LONG_POS]["entry_price"]
                        l_maker_fee = maker_fee_rate * ask_price_1 * l_position_size * quanto_multiplier if maker_fee_rate > 0 else 0
                        l_position_pnl = (ask_price_1 - l_position_entry_price) * l_position_size * quanto_multiplier - l_maker_fee if l_position_size else 0

                        s_position_size = positions[symbol][SHORT_POS]["size"]
                        s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                        s_maker_fee = maker_fee_rate * bid_price_1 * s_position_size * quanto_multiplier if maker_fee_rate > 0 else 0
                        s_position_pnl = (s_position_entry_price - bid_price_1) * s_position_size * quanto_multiplier - s_maker_fee if s_position_size else 0

                        if status == GateioConstant.FINISHED.value and finish_as == GateioConstant.FINISH_AS_FILLED.value:
                            traded_count += 1

                            title = symbol.replace("_" + QUOTE_COIN, "")
                            date_time = Utils.get_current_time_mdhm()
                            direction_offset = DIRECTION_OFFSET[side][pos_side]

                            print(f'{traded_count: >8}{title: >8}{tif: >8}{direction_offset: >16}{Utils.round_to(l_position_size, round_volume): >14} / {Utils.round_to(s_position_size, round_volume): <14}{Utils.round_to(filled_price, pricetick): >14}{Utils.round_to(volume, round_volume): >14}{date_time: >18}')

orderbookWebsocketThread = OrderbookWebsocketThread(api_key, api_secret, GateioConstant.WEBSOCKET_HOST.value, False, False)
orderbookWebsocketThread.start()

positionsWebsocketThread = PositionsWebsocketThread(api_key, api_secret, uid, GateioConstant.WEBSOCKET_HOST.value, False, False)
positionsWebsocketThread.start()

orderWebsocketThread = OrderWebsocketThread(api_key, api_secret, uid, GateioConstant.WEBSOCKET_HOST.value, False, False)
orderWebsocketThread.start()

sleep(5)

long_pos_size = 0
short_pos_size = 0

while True:
    for symbol in symbol_list:
        sleep(0.5)

        # <!--- check some parameters for market/trade/account
        contract = contracts[symbol]
        if symbol not in ticks.keys():
            continue

        balance = wallet["balance"]

        # <!--- get all values for trading
        pricetick = contract["pricetick"]
        round_volume = contract["round_volume"]
        min_volume = contract["min_order_qty"]
        max_volume = contract["max_order_qty"]
        quanto_multiplier = contract["quanto_multiplier"]
        maker_fee_rate = contract["maker_fee_rate"]
        taker_fee_rate = contract["taker_fee_rate"]
        # --->

        open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
        open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

        # sending orders
        open_orders = gateio_futures_rest_api.get_open_orders(symbol)
        for new_side in (LONG_SIDE, SHORT_SIDE):
            for new_position_side in (LONG_POS, SHORT_POS):
                new_price, new_volume = 0, 0
                offset = OFFSET_OPEN

                bid_price_1 = ticks[symbol]["bid_price_1"]
                ask_price_1 = ticks[symbol]["ask_price_1"]

                open_order_ids[new_side][new_position_side] = ''
                open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                # new price
                if new_side == LONG_SIDE:
                    new_price = Utils.round_to(bid_price_1, pricetick)
                elif new_side == SHORT_SIDE:
                    new_price = Utils.round_to(ask_price_1, pricetick)

                if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                    open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                    open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                    open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                long_pos_size = positions[symbol][LONG_POS]["size"]
                short_pos_size = positions[symbol][SHORT_POS]["size"]

                offset = OFFSET_CLOSE
                if new_side == LONG_SIDE:
                    if new_position_side == SHORT_POS:
                        if short_pos_size:
                            new_volume = short_pos_size
                    # if new_position_side == LONG_POS:
                    #     if not long_pos_size:
                    #         offset = OFFSET_OPEN
                    #         new_volume = min_volume
                elif new_side == SHORT_SIDE:
                    if new_position_side == LONG_POS:
                        if long_pos_size:
                            new_volume = long_pos_size
                    # if new_position_side == SHORT_POS:
                    #     if not short_pos_size:
                    #         offset = OFFSET_OPEN
                    #         new_volume = min_volume

                new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                if open_order_ids[new_side][new_position_side]:
                    open_order_id = open_order_ids[new_side][new_position_side]
                    old_price = open_order_info[new_side][new_position_side]["price"]
                    old_volume = open_order_info[new_side][new_position_side]["volume"]

                    if abs(old_volume) != abs(new_volume) or old_price != new_price:
                        gateio_futures_rest_api.cancel_order(open_order_id)

                    continue

                if new_price and new_volume:
                    response = gateio_futures_rest_api.send_maker_order(symbol, new_side, new_volume, new_price, offset)

    if long_pos_size == 0 and short_pos_size == 0:
        print("Break...")
        break

sleep(3)

print(f'Exit!')

sys.exit()
