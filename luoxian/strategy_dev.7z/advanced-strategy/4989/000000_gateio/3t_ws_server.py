#!/usr/bin/env python
from websocket_server import WebsocketServer
import json

from constant import RestApiConstant

def new_client(client, server):
    print("New client connected and was given id %d" % client['id'])

def client_left(client, server):
    print("Client(%d) disconnected" % client['id'])

def message_received(client, server, message):
    print("Client(%d) said: %s" % (client['id'], message))
    if "direction" in message:
        server.send_message_to_all(message)

server = WebsocketServer(RestApiConstant.WEBSOCKET_HOST.value, port=RestApiConstant.WEBSOCKET_PORT.value)
server.set_fn_new_client(new_client)
server.set_fn_client_left(client_left)
server.set_fn_message_received(message_received)
server.run_forever()
