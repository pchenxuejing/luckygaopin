"""
General constant string used in strategy.
"""
from enum import Enum

class RestApiConstant(Enum):
    """
    Account Type
    """
    MAKER = "MAKER"
    TAKER = "TAKER"

    """
    Rest API urls
    """
    WEB_HOST = 'http://www.tiptoptrading.cn/tiptoptrading'
    LOGIN_URL = WEB_HOST + '/auth/signin'

    GET_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/query'
    UPDATE_MAKER_ACCOUNT_URL = WEB_HOST + '/mapi/update'

    GET_TAKER_ACCOUNTS_URL = WEB_HOST + '/tapi/query'
    UPDATE_TAKER_ACCOUNT_URL = WEB_HOST + '/tapi/update'

    GET_TRADING_OPTION_URL = WEB_HOST + '/option/query?category='

    RUNNING_STATUS_LIST = ["waiting", "running"]
    STOP_STATUS_LIST = ["stopped", "closed"]
    CLOSE_STATUS_LIST = ["closed"]

    """
    WebSokcet
    """
    WEBSOCKET_HOST = "10.40.125.45"
    WEBSOCKET_PORT = 5000
    WEBSOCKET_URL = "ws://10.40.125.45:5000"

    WEBSOCKET_DIRECTION_FROM_TAKER = "FROM_TAKER"
    WEBSOCKET_DIRECTION_FROM_MAKER = "FROM_MAKER"

class ExchangeConstant(Enum):
    """
    Exchange.
    """
    BINANCE = "BINANCE"
    BYBIT = "BYBIT"
    GATEIO = "GATEIO"
    BITMEX = "BITMEX"
    OKEX = "OKEX"
    HUOBI = "HUOBI"
    BITFINEX = "BITFINEX"
    COINBASE = "COINBASE"
    DERIBIT = "DERIBIT"
    BITSTAMP = "BITSTAMP"
    BITCOKE = "BITCOKE"
    PHEMEX = "PHEMEX"

class GateioConstant(Enum):
    """
    Rest Api/Websocket Host
    """
    RUN_HOST = "https://api.gateio.ws/api/v4"
    WEBSOCKET_HOST = "wss://fx-ws.gateio.ws/v4/ws/usdt"

    """
    Channel
    """
    ORDERBOOK_CHANNEL = "futures.order_book"
    ORDER_CHANNEL = "futures.orders"
    POSITION_CHANNEL = "futures.positions"
    TRADE_CHANNEL = ""
    BALANCE_CHANNEL = "futures.balances"

    """
    Quote currency
    """
    QUOTE_USDT = "USDT"
    SETTLE_USDT = "usdt"

    """
    Trade Category
    """
    SPOT = "spot"
    FUTURES = "linear"

    """
    Direction of order/trade/position.
    """
    LONG = "bid"
    SHORT = "ask"

    POSITION_LONG = "dual_long"
    POSITION_SHORT = "dual_short"

    OFFSET_OPEN = "OPEN"
    OFFSET_CLOSE = "CLOSE"

    """
    Order status.
    """
    SUBMITTING = "Created"
    NOTTRADED = "open"
    PARTTRADED = "partially filled"
    ALLTRADED = "filled"
    FINISHED = "finished"
    CLOSED = "closed"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    OPEN_ORDER_STATUS = "open"

    FINISH_AS_FILLED = "filled"
    FINISH_AS_CANCELLED = "cancelled"
    FINISH_AS_LIQUIDATED = "liquidated"
    FINISH_AS_IOC = "ioc"
    FINISH_AS_AUTO_DELEVERAGED = "auto_deleveraged"
    FINISH_AS_REDUCE_ONLY = "reduce_only"
    FINISH_AS_NEW = "_new"
    FINISH_AS_UPDATED = "_update"

    """
    Order type.
    """
    LIMIT = "Limit"
    MARKET = "Market"
    STOP = "Stop"

    """
    TimeInForce
    """
    GTC = "gtc"
    IOC = "ioc"
    FOK = "fok"
    POST_ONLY = "poc"

    """
    Position Mode
    """
    SINGLE_POSITION_MODE = "single"
    DUAL_POSITION_MODE = "dual"

    """
    Margin Mode
    """
    REGULAR_MARGIN = "REGULAR_MARGIN"
    ISOLATED_MARGIN = "ISOLATED_MARGIN"
    PORTFOLIO_MARGIN = "PORTFOLIO_MARGIN"

    """
    Account Type
    """
    UNIFIED = "UNIFIED"

    """
    Contract Type
    """
    PERPETUAL = "LinearPerpetual"

    UPGRADE_UTA_STATUS_FAIL = "FAIL"
    UPGRADE_UTA_STATUS_PROCESS = "PROCESS"
    UPGRADE_UTA_STATUS_SUCCESS = "SUCCESS"

    """
    Interval of bar data.
    """
    MINUTE = "1m"
    HOUR = "1h"
    DAILY = "1d"
    WEEKLY = "1w"
    TICK = "tick"

    """
    Error Code
    """
    INSUFFICIENT_CODES = [110004, 110007, 110044, 110045, 110052, 110058, 140004, 140007, 140044, 140045, 140052, 140058]