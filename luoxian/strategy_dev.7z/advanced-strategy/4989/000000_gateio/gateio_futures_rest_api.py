#!/usr/bin/env python
import logging
import time
from decimal import Decimal as D, ROUND_UP, getcontext

from gate_api import ApiClient, Configuration, FuturesApi, FuturesOrder, Transfer, WalletApi, AccountApi
from gate_api.exceptions import GateApiException

from constant import GateioConstant, ExchangeConstant
from utils import Utils
from time import sleep

logger = logging.getLogger(__name__)

class GateioFuturesRestApi:
    """
    exchange name
    """
    exchange = ExchangeConstant.GATEIO.value
    category = GateioConstant.FUTURES.value

    """
    Callback when this class is inited.
    """
    def __init__(self, api_key, api_secret, host, settle):
        self.config = Configuration(key=api_key, secret=api_secret, host=host)
        self.api_client = ApiClient(self.config)
        self.session = FuturesApi(self.api_client)
        self.account_api = AccountApi(self.api_client)
        self.settle = settle

    """
    "   Desc: get account detail
    """
    def get_account_detail(self):
        return self.account_api.get_account_detail()

    """
    "   Desc: query contract for all symbols
    """
    def query_contracts(self):
        try:
            contracts = {}
            response = self.session.list_futures_contracts(self.settle)
            if response:
                for contract_data in response:
                    contract = {}

                    contract["exchange"] = self.exchange
                    contract["symbol"] = contract_data.name
                    contract["base_coin"] = contract_data.name.replace("_" + self.settle.upper(), "")
                    contract["quote_coin"] = self.settle.upper()
                    contract["contract_type"] = contract_data.type
                    contract["pricetick"] = float(contract_data.order_price_round)
                    contract["round_volume"] = float(contract_data.order_size_min)
                    contract["min_order_qty"] = float(contract_data.order_size_min)
                    contract["max_order_qty"] = float(contract_data.order_size_max)
                    contract["min_leverage"] = float(contract_data.leverage_min)
                    contract["max_leverage"] = float(contract_data.leverage_max)
                    contract["maker_fee_rate"] = float(contract_data.maker_fee_rate)
                    contract["taker_fee_rate"] = float(contract_data.taker_fee_rate)
                    contract["in_delisting"] = bool(contract_data.in_delisting)
                    contract["quanto_multiplier"] = float(contract_data.quanto_multiplier)
                    contract["ref_rebate_rate"] = float(contract_data.ref_rebate_rate)
                    contract["ref_discount_rate"] = float(contract_data.ref_discount_rate)
                    contract["maintenance_rate"] = float(contract_data.maintenance_rate)
                    contract["risk_limit_step"] = float(contract_data.risk_limit_step)
                    contract["risk_limit_max"] = float(contract_data.risk_limit_max)
                    contract["funding_rate"] = float(contract_data.funding_rate)
                    contract["orders_limit"] = int(contract_data.orders_limit)
                    contract["enable_bonus"] = bool(contract_data.enable_bonus)
                    contract["enable_credit"] = bool(contract_data.enable_credit)

                    contracts[contract["symbol"]] = contract

            return contracts
        except GateApiException as ex:
            print("query_contracts(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: get wallet balance
    """
    def get_wallet_balance(self):
        try:
            wallet = {}
            response = self.session.list_futures_accounts(self.settle)
            if response:
                wallet["exchange"] = self.exchange
                wallet["currency"] = response.currency
                wallet["balance"] = float(response.total)
                wallet["bonus"] = float(response.bonus)
                wallet["available"] = float(response.available)
                wallet["unreal_pnl"] = float(response.unrealised_pnl)
                wallet["position_margin"] = float(response.position_margin)
                wallet["order_margin"] = float(response.order_margin)
                wallet["in_dual_mode"] = bool(response.in_dual_mode)

            return wallet
        except GateApiException as ex:
            print("get_wallet_balance(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: switch position mode
    """
    def switch_dual_mode(self):
        try:
            response = self.session.set_dual_mode(self.settle, True)
        except GateApiException as ex:
            print("switch_dual_mode(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: update position leverage
    """
    def update_position_leverage(self, symbol, leverage):
        try:
            response = self.session.update_dual_mode_position_leverage(self.settle, symbol, str(leverage))
        except GateApiException as ex:
            print("update_position_leverage(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: update position margin
    """
    def update_position_margin(self, symbol, side):
        try:
            response = self.session.update_dual_mode_position_margin(self.settle, symbol, "-0.01", side)
        except GateApiException as ex:
            print("update_position_margin(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: query positions
    """
    def query_positions(self, symbol):
        try:
            positions = {}
            response = self.session.get_dual_mode_position(self.settle, symbol)
            if response:
                for position_data in response:
                    position = {}

                    position["exchange"] = self.exchange
                    position["user"] = int(position_data.user)
                    position["symbol"] = position_data.contract
                    position["side"] = position_data.mode
                    position["size"] = abs(float(position_data.size))
                    position["entry_price"] = float(position_data.entry_price)
                    position["leverage"] = float(position_data.leverage)
                    position["leverage_max"] = float(position_data.leverage_max)
                    position["value"] = float(position_data.value)
                    position["liq_price"] = float(position_data.liq_price)
                    position["margin"] = float(position_data.margin)
                    position["unreal_pnl"] = float(position_data.unrealised_pnl)
                    position["risk_limit"] = float(position_data.risk_limit)
                    position["maintenance_rate"] = float(position_data.maintenance_rate)

                    if position["symbol"] not in positions.keys():
                        positions[position["symbol"]] = {}

                    positions[position["symbol"]][position["side"]] = position

            return positions
        except GateApiException as ex:
            print("query_positions(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: send a maker order
    """
    def send_maker_order(self, symbol, side, volume, price, offset):
        if volume <= 0:
            return

        if side == GateioConstant.LONG.value:
            pass
        else:
            volume = -volume

        _reduce_only = True if offset == GateioConstant.OFFSET_CLOSE.value else False

        limit_order = FuturesOrder(contract=symbol, size=volume, price=str(price), tif=GateioConstant.POST_ONLY.value, reduce_only=_reduce_only)

        try:
            response = self.session.create_futures_order(self.settle, limit_order)
        except GateApiException as ex:
            print("send_maker_order(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: send a taker order
    """
    def send_taker_order(self, symbol, side, volume, offset):
        if volume <= 0:
            return

        if side == GateioConstant.LONG.value:
            pass
        else:
            volume = -volume

        _reduce_only = True if offset == GateioConstant.OFFSET_CLOSE.value else False

        market_order = FuturesOrder(contract=symbol, size=volume, price="0", tif=GateioConstant.IOC.value, reduce_only=_reduce_only)

        try:
            response = self.session.create_futures_order(self.settle, market_order)
        except GateApiException as ex:
            print("send_taker_order(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: get maker open order
    """
    def get_open_order(self, order_id):
        try:
            open_order = {}
            response = self.session.get_futures_order(self.settle, order_id)
            if response:
                open_order["exchange"] = self.exchange
                open_order["order_id"] = int(open_order_data.id)
                open_order["symbol"] = open_order_data.contract
                open_order["price"] = float(open_order_data.price)
                open_order["qty"] = float(open_order_data.size)
                if open_order["qty"] > 0:
                    open_order["side"] = GateioConstant.LONG.value
                else:
                    open_order["side"] = GateioConstant.SHORT.value
                open_order["order_status"] = open_order_data.status
                open_order["type"] = GateioConstant.LIMIT.value
                open_order["left"] = float(open_order_data.left)
                open_order["traded"] = float(open_order_data.size) - float(open_order_data.left)
                open_order["time_in_force"] = open_order_data.tif
                open_order["reduce_only"] = bool(open_order_data.is_reduce_only)
                if open_order["reduce_only"]:
                    if open_order["side"] == GateioConstant.LONG.value:
                        open_order["position_side"] = GateioConstant.POSITION_SHORT.value
                    else:
                        open_order["position_side"] = GateioConstant.POSITION_LONG.value
                else:
                    if open_order["side"] == GateioConstant.LONG.value:
                        open_order["position_side"] = GateioConstant.POSITION_LONG.value
                    else:
                        open_order["position_side"] = GateioConstant.POSITION_SHORT.value

            return open_order
        except GateApiException as ex:
            print("get_open_order(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: get maker open orders
    """
    def get_open_orders(self, symbol):
        try:
            open_orders = {}
            response = self.session.list_futures_orders(self.settle, GateioConstant.OPEN_ORDER_STATUS.value, contract=symbol)
            if response:
                for open_order_data in response:
                    open_order = {}

                    open_order["exchange"] = self.exchange
                    open_order["order_id"] = int(open_order_data.id)
                    open_order["symbol"] = open_order_data.contract
                    open_order["price"] = float(open_order_data.price)
                    open_order["qty"] = float(open_order_data.size)
                    if open_order["qty"] > 0:
                        open_order["side"] = GateioConstant.LONG.value
                    else:
                        open_order["side"] = GateioConstant.SHORT.value
                    open_order["order_status"] = open_order_data.status
                    open_order["type"] = GateioConstant.LIMIT.value
                    open_order["left"] = float(open_order_data.left)
                    open_order["traded"] = float(open_order_data.size) - float(open_order_data.left)
                    open_order["time_in_force"] = open_order_data.tif
                    open_order["reduce_only"] = bool(open_order_data.is_reduce_only)
                    if open_order["reduce_only"]:
                        if open_order["side"] == GateioConstant.LONG.value:
                            open_order["position_side"] = GateioConstant.POSITION_SHORT.value
                        else:
                            open_order["position_side"] = GateioConstant.POSITION_LONG.value
                    else:
                        if open_order["side"] == GateioConstant.LONG.value:
                            open_order["position_side"] = GateioConstant.POSITION_LONG.value
                        else:
                            open_order["position_side"] = GateioConstant.POSITION_SHORT.value

                    if open_order["side"] not in open_orders.keys():
                        open_orders[open_order["side"]] = {}

                    open_orders[open_order["side"]][open_order["position_side"]] = open_order

            return open_orders
        except GateApiException as ex:
            print("get_open_orders(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: cancel maker open order
    """
    def cancel_order(self, order_id):
        try:
            response = self.session.cancel_futures_order(self.settle, order_id)
        except GateApiException as ex:
            print("cancel_order(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: cancel maker open orders
    """
    def cancel_all_orders(self, symbol):
        try:
            response = self.session.cancel_futures_orders(self.settle, symbol)
        except GateApiException as ex:
            print("cancel_all_orders(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))

    """
    "   Desc: close all positions
    """
    def close_all_positions(self, symbol, side, volume):
        if volume <= 0:
            return

        if side == GateioConstant.LONG.value:
            pass
        else:
            volume = -volume

        market_order = FuturesOrder(contract=symbol, size=volume, tif=GateioConstant.IOC.value, reduce_only=True)

        try:
            response = self.session.create_futures_order(self.settle, market_order)
        except GateApiException as ex:
            print("close_all_positions(): Gate api exception, label: %s, message: %s\n" % (ex.label, ex.message))
