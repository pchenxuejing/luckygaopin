#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import List, Dict
from time import sleep, time

import threading
import websocket

from constant import RestApiConstant, GateioConstant
from gateio_futures_rest_api import GateioFuturesRestApi

import asyncio

from gate_ws import Configuration, Connection, WebSocketResponse
from gate_ws.futures import FuturesPublicTradeChannel, FuturesOrderChannel, FuturesPositionsChannel

from utils import Utils

# exchange api
# api_key = "f6529c83320cc4af9a789a19b65bdafb"
# api_secret = "46930971ed14283d8bd28fd52cfe9db8abd9115e57c42a340fdf9a7766700f87"

api_key = str(sys.argv[1:][0])
api_secret = str(sys.argv[1:][1])

contracts = {}
positions = {}
wallet = {}

EXCHANGE = ExchangeConstant.GATEIO.value
QUOTE_COIN = GateioConstant.QUOTE_USDT.value
OPPOSITE_SIDE: Dict[str, str] = {"bid": "ask", "ask": "bid"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"bid": "dual_short", "ask": "dual_long"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"dual_long": "ask", "dual_short": "bid"}
DIRECTION_OFFSET = {"bid": {"dual_long": "LONG_OPEN", "dual_short": "LONG_CLOSE"}, "ask":{"dual_long": "SHORT_CLOSE", "dual_short": "SHORT_OPEN"}}

LONG_SIDE = GateioConstant.LONG.value
SHORT_SIDE = GateioConstant.SHORT.value

LONG_POS = GateioConstant.POSITION_LONG.value
SHORT_POS = GateioConstant.POSITION_SHORT.value

OFFSET_OPEN = GateioConstant.OFFSET_OPEN.value
OFFSET_CLOSE = GateioConstant.OFFSET_CLOSE.value

####### Exchange's Rest API #######
gateio_futures_rest_api = GateioFuturesRestApi(api_key, api_secret, GateioConstant.RUN_HOST.value, GateioConstant.SETTLE_USDT.value)

contracts = gateio_futures_rest_api.query_contracts()
wallet = gateio_futures_rest_api.get_wallet_balance()
balance = wallet["balance"]

print(f'==================================================')
print(balance)
print(f'==================================================')

class WebsocketClientThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self.stop_event = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self.stop_event.is_set():
            self.ws.run_forever()

    def stop(self):
        self.stop_event.set()

    def on_open(self, ws):
        print("WebSocket's Connection Opened.")

    def on_close(self, ws):
        print("WebSocket's Connection Closed.")

    def on_error(self, ws, error):
        print("WebSocket's Error: ", error)

    def on_message(self, ws, message):
        if "direction" in message:
            json_msg = json.loads(message)
            if json_msg["direction"] == "leader_order_update":
                _symbol = json_msg["symbol"]
                symbol = _symbol + "_USDT"
                if symbol in list(contracts):
                    leader_volume = float(json_msg["volume"])
                    leader_side = json_msg["side"]
                    leader_pos_side = json_msg["pos_side"]
                    filled_price = float(json_msg["filled_price"])
                    leader_balance = float(json_msg["leader_balance"])

                    round_volume = contracts[symbol]["round_volume"]
                    min_volume = contracts[symbol]["min_order_qty"]
                    max_volume = contracts[symbol]["max_order_qty"]
                    quanto_multiplier = contracts[symbol]["quanto_multiplier"]

                    side = ""
                    offset = OFFSET_OPEN
                    follower_volume = max(Utils.round_to(leader_volume * (balance / leader_balance) / quanto_multiplier, round_volume), min_volume)
                    if leader_side == "LONG_SIDE" and leader_pos_side == "LONG_POS":
                        side = LONG_SIDE
                    elif leader_side == "SHORT_SIDE" and leader_pos_side == "SHORT_POS":
                        side = SHORT_SIDE
                    elif leader_side == "LONG_SIDE" and leader_pos_side == "SHORT_POS":
                        offset = OFFSET_CLOSE
                        side = LONG_SIDE
                        follower_volume = min(follower_volume, positions[symbol][SHORT_POS]["size"])
                    elif leader_side == "SHORT_SIDE" and leader_pos_side == "LONG_POS":
                        offset = OFFSET_CLOSE
                        side = SHORT_SIDE
                        follower_volume = min(follower_volume, positions[symbol][LONG_POS]["size"])

                    if follower_volume:
                        response = gateio_futures_rest_api.send_taker_order(side, symbol, follower_volume, offset)

    def send_message(self, message):
        self.ws.send(message)

websocket_client_thread = WebsocketClientThread(RestApiConstant.WEBSOCKET_URL.value, False, False)
websocket_client_thread.start()

# define your callback function on message received
def print_message(conn: Connection, response: WebSocketResponse):
    global positions

    if response.error:
        print('error returned: ', response.error)
        conn.close()
        return

    for position_data in response.result:
        if position_data:
            position = {}

            position["exchange"] = EXCHANGE
            position["user"] = position_data["user"]
            position["symbol"] = position_data["contract"]
            position["side"] = position_data["mode"]
            position["size"] = abs(int(position_data["size"]))
            position["entry_price"] = float(position_data["entry_price"])
            position["leverage"] = int(position_data["leverage"])
            position["leverage_max"] = int(position_data["leverage_max"])
            position["liq_price"] = float(position_data["liq_price"])
            position["margin"] = float(position_data["margin"])
            position["risk_limit"] = float(position_data["risk_limit"])
            position["maintenance_rate"] = float(position_data["maintenance_rate"])

            if position["symbol"] not in positions.keys():
                positions[position["symbol"]] = {}

            positions[position["symbol"]][position["side"]] = position

async def main():
    # initialize default connection, which connects to spot WebSocket V4
    # it is recommended to use one conn to initialize multiple channels
    conn = Connection(Configuration(app='futures', settle='usdt', test_net=False, api_key=api_key, api_secret=api_secret))

    # subscribe to any channel you are interested into, with the callback function
    if contracts:
        for symbol in list(contracts):
            channel = FuturesPositionsChannel(conn, print_message)
            channel.subscribe([symbol])

    # start the client
    await conn.run()

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    loop.close()
