#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import List, Dict
from time import sleep, time
import numpy as np

import threading
import threading
import websocket as wb

import hashlib
import hmac

from utils import Utils
from constant import RestApiConstant, ExchangeConstant, GateioConstant
from gateio_futures_rest_api import GateioFuturesRestApi

# exchange api
uid = "15880324"
api_key = "29b40df0a26c1ac606ec4a7976f6a971"
api_secret = "87c2386bec4682c54552925fe1ea5303f33bccd2b2146532f1f466a15cd7f5dc"
account_name = "mine"

# ['XRP_USDT', 'DOGE_USDT', 'ADA_USDT', 'TON_USDT', '1000SHIB_USDT', 'DOT_USDT', 'TRX_USDT', 'MATIC_USDT', 'APT_USDT', 'STXUSDT', 'FIL_USDT', 'ATOM_USDT', 'ARB_USDT', 'IMX_USDT', 'RNDR_USDT', 'XLM_USDT', 'OP_USDT', 'HBAR_USDT', 'GRT_USDT', 'KAS_USDT', 'INJ_USDT', '1000PEPE_USDT', 'VET_USDT', 'FTM_USDT', 'MKR_USDT', 'LDO_USDT', 'THETA_USDT', 'WIF_USDT', 'XMR_USDT', 'HBAR_USDT', 'AR_USDT', 'DAR_USDT', 'SEI_USDT', '1000FLOKI_USDT', 'SUI_USDT', 'FET_USDT', 'ALGO_USDT', 'GALA_USDT', 'FLOW_USDT', 'CFX_USDT', 'JUP_USDT', 'STRK_USDT', 'DYDX_USDT', 'SNX_USDT', 'SAND_USDT', '1000BONK_USDT', 'AGIX_USDT', 'PYTH_USDT', '1000XEC_USDT', 'MINA_USDT', 'ONDO_USDT', 'XTZ_USDT', 'CHZ_USDT', 'MANA_USDT', 'AXL_USDT', 'APE_USDT', 'EOS_USDT', 'CAKE_USDT', 'NEO_USDT', '1000SATS_USDT', 'IOTA_USDT', 'JASMY_USDT', 'KAVA_USDT']
symbol_list = ['DOGE_USDT']

# exchange api
contracts = {}
positions = {}
fee_rates = {}
wallets = {}
ticks = {}

initial_start_dict = {}
base_pos_volume_dict = {}
max_pos_volume_dict = {}
open_tick_volume_dict = {}
close_tick_volume_dict = {}

grid_ticksize_dict = {}
fee_ticksize_dict = {}
profit_ticksize_dict = {}
market_price_ticksize_dict = {}
total_profit_ticksize_dict = {}
long_open_calc_ticksize_dict = {}
short_open_calc_ticksize_dict = {}

long_close_profit_ticksize_dict = {}
short_close_profit_ticksize_dict = {}

last_traded_long_open_price_dict = {}
last_traded_short_open_price_dict = {}
last_traded_long_close_price_dict = {}
last_traded_short_close_price_dict = {}

long_open_traded_min_price_dict = {}
short_open_traded_max_price_dict = {}

long_open_count_dict = {}
short_open_count_dict = {}
long_close_count_dict = {}
short_close_count_dict = {}

# static parameters
balance = 0
start_balance = 0
max_balance = 0
min_balance = 0

traded_count = 0
start_time = 0
last_runtime = 0
total_amount = 0
total_runtime = 0
current_runtime = 0
current_traded_amount = 0
runtime_days = 0

maker_rebate = 0.0
taker_fee = 0.0

EXCHANGE = ExchangeConstant.GATEIO.value
CATEGORY = GateioConstant.FUTURES.value
QUOTE_COIN = GateioConstant.QUOTE_USDT.value
ACCOUNT_TYPE = RestApiConstant.MAKER.value
OPPOSITE_SIDE: Dict[str, str] = {"bid": "ask", "ask": "bid"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"bid": "dual_short", "ask": "dual_long"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"dual_long": "ask", "dual_short": "bid"}
DIRECTION_OFFSET = {"bid": {"dual_long": "LONG_OPEN", "dual_short": "LONG_CLOSE"}, "ask":{"dual_long": "SHORT_CLOSE", "dual_short": "SHORT_OPEN"}}

LONG_SIDE = GateioConstant.LONG.value
SHORT_SIDE = GateioConstant.SHORT.value

LONG_POS = GateioConstant.POSITION_LONG.value
SHORT_POS = GateioConstant.POSITION_SHORT.value

OFFSET_OPEN = GateioConstant.OFFSET_OPEN.value
OFFSET_CLOSE = GateioConstant.OFFSET_CLOSE.value

CLS_TIME = 0
CLS_INTERVAL_TIME = 60 * 60

TRADED_INFO_TIME = 0
TRADED_INFO_INTERVAL_TIME = 5 * 60

USER_STREAM_STARTTIME = 0

ROOT_PATH = "C:\\Users\\Administrator\\strategies\\"

TRADED_INFO_TITLE: Dict[int, str] = {0: "Runtime(M/H/D)", 1: "P.Daily Vol($/L)", 2: "D/M/Y PNL(%)", 3: "Total Earned($)", 4: "Total Trade Vol($)", 5: "M/T.Fee($)", 6: "W.Bal($)", 7: "Max.Bal($)", 8: "Min.Bal($)"}

"""
"   Desc: Write a profit array to a txt file
"""
def write_close_profit_dict(exchange, account_name, symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\" + side.lower() + "_profit.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        if side == LONG_SIDE:
            content = str(long_close_profit_ticksize_dict[symbol])
            f.write(content.replace("[", "").replace("]", ""))
        elif side == SHORT_SIDE:
            content = str(short_close_profit_ticksize_dict[symbol])
            f.write(content.replace("[", "").replace("]", ""))

        f.close()

"""
"   Desc: Read a profit array from a txt file
"""
def read_close_profit_dict(exchange, account_name, symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\" + side.lower() + "_profit.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            if side == LONG_SIDE:
                long_close_profit_ticksize_dict[symbol] = []
            elif side == SHORT_SIDE:
                short_close_profit_ticksize_dict[symbol] = []
        else:
            if side == LONG_SIDE:
                string_array = list(data.split(", "))
                long_close_profit_ticksize_dict[symbol] = [int(string) for string in string_array]
            elif side == SHORT_SIDE:
                string_array = list(data.split(", "))
                short_close_profit_ticksize_dict[symbol] = [int(string) for string in string_array]

"""
"   Desc: Update traded open order dict when maker order has been traded
"""
def update_profit_dict(symbol, side, profit_ticksize, volume, ticksize, status):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    if status == 0:
        real_profit_ticksize = profit_ticksize - 2 * (profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol])
        # real_profit_ticksize = int(min(CLOSE_TICKSIZE_PERCENT / 100 + (profit_ticksize / ticksize), 0.99) * _profit_ticksize)
        if side == LONG_SIDE:
            if volume > close_tick_volume_dict[symbol]:
                _real_profit_ticksize = int(real_profit_ticksize * volume / close_tick_volume_dict[symbol])
                long_close_profit_ticksize_dict[symbol].append(_real_profit_ticksize)
            else:
                long_close_profit_ticksize_dict[symbol].append(real_profit_ticksize)
        elif side == SHORT_SIDE:
            if volume > close_tick_volume_dict[symbol]:
                _real_profit_ticksize = int(real_profit_ticksize * volume / close_tick_volume_dict[symbol])
                long_close_profit_ticksize_dict[symbol].append(_real_profit_ticksize)
            else:
                short_close_profit_ticksize_dict[symbol].append(real_profit_ticksize)
    elif status == 1:
        if side == LONG_SIDE:
            if short_close_profit_ticksize_dict[symbol]:
                if volume > close_tick_volume_dict[symbol]:
                    count = int(volume / close_tick_volume_dict[symbol])
                    for i in range(count):
                        n_scores = np.array(short_close_profit_ticksize_dict[symbol])
                        max_profit_ticksize = n_scores.max()
                        short_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)
                else:
                    n_scores = np.array(short_close_profit_ticksize_dict[symbol])
                    max_profit_ticksize = n_scores.max()
                    short_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)
        elif side == SHORT_SIDE:
            if long_close_profit_ticksize_dict[symbol]:
                if volume > close_tick_volume_dict[symbol]:
                    count = int(volume / close_tick_volume_dict[symbol])
                    for i in range(count):
                        n_scores = np.array(long_close_profit_ticksize_dict[symbol])
                        max_profit_ticksize = n_scores.max()
                        long_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)
                else:
                    n_scores = np.array(long_close_profit_ticksize_dict[symbol])
                    max_profit_ticksize = n_scores.max()
                    long_close_profit_ticksize_dict[symbol].remove(max_profit_ticksize)

"""
"   Desc: Get a max profit ticksize from a profit dict
"""
def get_max_prfofit_ticksize(symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    max_profit_ticksize = 0
    if side == LONG_SIDE:
        if long_close_profit_ticksize_dict[symbol]:
            n_scores = np.array(long_close_profit_ticksize_dict[symbol])
            max_profit_ticksize = n_scores.max()
    elif side == SHORT_SIDE:
        if short_close_profit_ticksize_dict[symbol]:
            n_scores = np.array(short_close_profit_ticksize_dict[symbol])
            max_profit_ticksize = n_scores.max()

    return max_profit_ticksize

"""
"   Desc: Get close volume from a profit dict
"""
def get_minus_close_volume(symbol, side, minus_ticksize):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    close_volume = 0
    if side == LONG_SIDE:
        if short_close_profit_ticksize_dict[symbol]:
            x = np.array(short_close_profit_ticksize_dict[symbol])
            result = x[x > minus_ticksize]
            close_volume = len(result) * close_tick_volume_dict[symbol]
    elif side == SHORT_SIDE:
        if long_close_profit_ticksize_dict[symbol]:
            x = np.array(long_close_profit_ticksize_dict[symbol])
            result = x[x > minus_ticksize]
            close_volume = len(result) * close_tick_volume_dict[symbol]

    return close_volume

"""
"   Desc: Get a total profit ticksize from a profit dict
"""
def get_total_profit_ticksize(symbol, side):
    global long_close_profit_ticksize_dict, short_close_profit_ticksize_dict

    total_profit_ticksize = 0
    if side == LONG_SIDE:
        if short_close_profit_ticksize_dict[symbol]:
            total_profit_ticksize = sum(short_close_profit_ticksize_dict[symbol])
    elif side == SHORT_SIDE:
        if long_close_profit_ticksize_dict[symbol]:
            total_profit_ticksize = sum(long_close_profit_ticksize_dict[symbol])

    return total_profit_ticksize

"""
"   Desc: Write a total profit ticksize
"""
def write_profit_ticksize(exchange, account_name, symbol):
    global total_profit_ticksize_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\profit.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{total_profit_ticksize_dict[symbol]}')

"""
"   Desc: Read a total profit ticksize
"""
def read_profit_ticksize(exchange, account_name, symbol):
    global total_profit_ticksize_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\profit.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_profit_ticksize_dict[symbol] = 0
        else:
            total_profit_ticksize_dict[symbol] = int(data.strip())

"""
"   Desc: Update a total profit ticksize
"""
def update_profit_ticksize(symbol, side, profit_ticksize, volume, ticksize):
    global total_profit_ticksize_dict

    if abs(profit_ticksize) >= ticksize / 2:
        return

    count = 1
    if volume > close_tick_volume_dict[symbol]:
        count = int(volume / close_tick_volume_dict[symbol])

    _profit_ticksize = profit_ticksize - 2 * (profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol])
    if _profit_ticksize > 0:
        real_profit_ticksize = int(min(CLOSE_TICKSIZE_PERCENT / 100 + (profit_ticksize / ticksize), 0.99) * _profit_ticksize)
        total_profit_ticksize_dict[symbol] += count * real_profit_ticksize
    elif _profit_ticksize < 0:
        total_profit_ticksize_dict[symbol] += count * _profit_ticksize

"""
"   Desc: Write a traded log to a txt file
"""
def write_log(exchange, account_name, symbol, txt, fname):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\" + fname + ".txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "a") as f:
        f.write(str(txt) + "\n")

"""
"   Desc: Write a traded info to a log file
"""
def write_traded_info(exchange, account_name, symbol):
    global total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, last_traded_long_open_price_dict, last_traded_short_open_price_dict, last_traded_long_close_price_dict, last_traded_short_close_price_dict, long_open_traded_min_price_dict, short_open_traded_max_price_dict, long_open_count_dict, short_open_count_dict, long_close_count_dict, short_close_count_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\traded_info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{total_amount}, {total_runtime}, {start_balance}, {max_balance}, {min_balance}, {maker_rebate}, {taker_fee}, {last_traded_long_open_price_dict[symbol]}, {last_traded_short_open_price_dict[symbol]}, {last_traded_long_close_price_dict[symbol]}, {last_traded_short_close_price_dict[symbol]}, {long_open_traded_min_price_dict[symbol]}, {short_open_traded_max_price_dict[symbol]}, {long_open_count_dict[symbol]}, {short_open_count_dict[symbol]}, {long_close_count_dict[symbol]}, {short_close_count_dict[symbol]}'
        f.write(traded_info)

"""
"   Desc: Read a traded info from a log file
"""
def read_traded_info(exchange, account_name, symbol):
    global total_amount, total_runtime, start_balance, max_balance, min_balance, maker_rebate, taker_fee, last_traded_long_open_price_dict, last_traded_short_open_price_dict, last_traded_long_close_price_dict, last_traded_short_close_price_dict, long_open_traded_min_price_dict, short_open_traded_max_price_dict, long_open_count_dict, short_open_count_dict, long_close_count_dict, short_close_count_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\traded_info.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            total_amount = 0
            total_runtime = 0
            start_balance = 0
            max_balance = 0
            min_balance = 0
            maker_rebate = 0
            taker_fee = 0
            last_traded_long_open_price_dict[symbol] = 0
            last_traded_short_open_price_dict[symbol] = 0
            last_traded_long_close_price_dict[symbol] = 0
            last_traded_short_close_price_dict[symbol] = 0
            long_open_traded_min_price_dict[symbol] = 0
            short_open_traded_max_price_dict[symbol] = 0
            long_open_count_dict[symbol] = 0
            short_open_count_dict[symbol] = 0
            long_close_count_dict[symbol] = 0
            short_close_count_dict[symbol] = 0
        else:
            total_amount = float(data.split(', ')[0].strip())
            total_runtime = float(data.split(', ')[1].strip())
            start_balance = float(data.split(', ')[2].strip())
            max_balance = float(data.split(', ')[3].strip())
            min_balance = float(data.split(', ')[4].strip())
            maker_rebate = float(data.split(', ')[5].strip())
            taker_fee = float(data.split(', ')[6].strip())
            last_traded_long_open_price_dict[symbol] = float(data.split(', ')[7].strip())
            last_traded_short_open_price_dict[symbol] = float(data.split(', ')[8].strip())
            last_traded_long_close_price_dict[symbol] = float(data.split(', ')[9].strip())
            last_traded_short_close_price_dict[symbol] = float(data.split(', ')[10].strip())
            long_open_traded_min_price_dict[symbol] = float(data.split(', ')[11].strip())
            short_open_traded_max_price_dict[symbol] = float(data.split(', ')[12].strip())
            long_open_count_dict[symbol] = int(data.split(', ')[13].strip())
            short_open_count_dict[symbol] = int(data.split(', ')[14].strip())
            long_close_count_dict[symbol] = int(data.split(', ')[15].strip())
            short_close_count_dict[symbol] = int(data.split(', ')[16].strip())

"""
"   Desc: Write a variables to a log file
"""
def write_variables(exchange, account_name, symbol):
    global base_pos_volume_dict, max_pos_volume_dict, open_tick_volume_dict, close_tick_volume_dict, market_price_ticksize_dict, grid_ticksize_dict, profit_ticksize_dict, fee_ticksize_dict, initial_start_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\variables.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        traded_info = f'{base_pos_volume_dict[symbol]}, {max_pos_volume_dict[symbol]}, {open_tick_volume_dict[symbol]}, {close_tick_volume_dict[symbol]}, {market_price_ticksize_dict[symbol]}, {grid_ticksize_dict[symbol]}, {profit_ticksize_dict[symbol]}, {fee_ticksize_dict[symbol]}, {initial_start_dict[symbol]}'
        f.write(traded_info)

"""
"   Desc: Read a variables from a log file
"""
def read_variables(exchange, account_name, symbol):
    global base_pos_volume_dict, max_pos_volume_dict, open_tick_volume_dict, close_tick_volume_dict, market_price_ticksize_dict, grid_ticksize_dict, profit_ticksize_dict, fee_ticksize_dict, initial_start_dict

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\variables.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            base_pos_volume_dict[symbol] = 0
            max_pos_volume_dict[symbol] = 0
            open_tick_volume_dict[symbol] = 0
            close_tick_volume_dict[symbol] = 0
            market_price_ticksize_dict[symbol] = 0
            grid_ticksize_dict[symbol] = 0
            profit_ticksize_dict[symbol] = 0
            fee_ticksize_dict[symbol] = 0
            initial_start_dict[symbol] = 0
        else:
            base_pos_volume_dict[symbol] = float(data.split(', ')[0].strip())
            max_pos_volume_dict[symbol] = float(data.split(', ')[1].strip())
            open_tick_volume_dict[symbol] = float(data.split(', ')[2].strip())
            close_tick_volume_dict[symbol] = float(data.split(', ')[3].strip())
            market_price_ticksize_dict[symbol] = int(data.split(', ')[4].strip())
            grid_ticksize_dict[symbol] = int(data.split(', ')[5].strip())
            profit_ticksize_dict[symbol] = int(data.split(', ')[6].strip())
            fee_ticksize_dict[symbol] = int(data.split(', ')[7].strip())
            initial_start_dict[symbol] = int(data.split(', ')[8].strip())

"""
"   Desc: Write parameters to a log file
"""
def write_parameters(exchange, account_name, symbol):
    global BASE_POS_VOLUME_MULTIPLY_RATE, HALF_POS_VOLUME_MULTIPLY_RATE, MAX_POS_VOLUME_MULTIPLY_RATE, OPEN_TICK_VOLUME_DIVIDE_RATE, CLOSE_TICK_VOLUME_DIVIDE_RATE, PROFIT_TICKSIZE_PERCENT, CLOSE_TICKSIZE_PERCENT, GRID_TICKSIZE_PERCENT

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        parameters = f'{BASE_POS_VOLUME_MULTIPLY_RATE}, {HALF_POS_VOLUME_MULTIPLY_RATE}, {MAX_POS_VOLUME_MULTIPLY_RATE}, {OPEN_TICK_VOLUME_DIVIDE_RATE}, {CLOSE_TICK_VOLUME_DIVIDE_RATE}, {PROFIT_TICKSIZE_PERCENT}, {CLOSE_TICKSIZE_PERCENT}, {GRID_TICKSIZE_PERCENT}'
        f.write(parameters)

"""
"   Desc: Read a parameters from a start file
"""
def read_parameters(exchange, account_name, symbol):
    global BASE_POS_VOLUME_MULTIPLY_RATE, HALF_POS_VOLUME_MULTIPLY_RATE, MAX_POS_VOLUME_MULTIPLY_RATE, OPEN_TICK_VOLUME_DIVIDE_RATE, CLOSE_TICK_VOLUME_DIVIDE_RATE, PROFIT_TICKSIZE_PERCENT, CLOSE_TICKSIZE_PERCENT, GRID_TICKSIZE_PERCENT

    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\parameters.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data == "":
            BASE_POS_VOLUME_MULTIPLY_RATE = 0
            HALF_POS_VOLUME_MULTIPLY_RATE = 0
            MAX_POS_VOLUME_MULTIPLY_RATE = 0
            OPEN_TICK_VOLUME_DIVIDE_RATE = 0
            CLOSE_TICK_VOLUME_DIVIDE_RATE = 0
            PROFIT_TICKSIZE_PERCENT = 0
            CLOSE_TICKSIZE_PERCENT = 0
            GRID_TICKSIZE_PERCENT = 0
        else:
            BASE_POS_VOLUME_MULTIPLY_RATE = float(data.split(', ')[0].strip())
            HALF_POS_VOLUME_MULTIPLY_RATE = float(data.split(', ')[1].strip())
            MAX_POS_VOLUME_MULTIPLY_RATE = float(data.split(', ')[2].strip())
            OPEN_TICK_VOLUME_DIVIDE_RATE = int(data.split(', ')[3].strip())
            CLOSE_TICK_VOLUME_DIVIDE_RATE = int(data.split(', ')[4].strip())
            PROFIT_TICKSIZE_PERCENT = float(data.split(', ')[5].strip())
            CLOSE_TICKSIZE_PERCENT = float(data.split(', ')[6].strip())
            GRID_TICKSIZE_PERCENT = float(data.split(', ')[7].strip())

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_for_all(exchange, account_name, value):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{value}')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_for_all(exchange, account_name):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

"""
"   Desc: Write a process status to a log file
"""
def write_process_status_for_symbol(exchange, account_name, symbol, value):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "w") as f:
        f.write(f'{value}')

"""
"   Desc: Read a process status signal from a file
"""
def read_process_status_signal_for_symbol(exchange, account_name, symbol):
    log_file = ROOT_PATH + exchange.lower() + "\\" + account_name.lower() + "\\" + symbol.lower() + "\\signal.txt"

    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    if not os.path.isfile(log_file):
        open(log_file , "x")

    process_status = 0
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    with open(log_file , "r") as f:
        data = f.read().rstrip()
        if data:
            process_status = int(data.strip())

    return process_status

def generate_websocket_sign(secret, channel, event, time):
    """"""
    message='channel=%s&event=%s&time=%s' % (channel, event, time)

    signature=hmac.new(
        secret.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha512
    ).hexdigest()

    return signature

def generate_req(key, secret, channel: str, event: str, pay_load: List):
    """"""
    expires=int(time())
    signature=generate_websocket_sign(secret, channel, event, expires)

    req={
        "time": expires,
        "channel": channel,
        "event": event,
        "payload": pay_load,
        "auth": {
            "method": "api_key",
            "KEY": key,
            "SIGN": signature
        }
    }

    return req

####### Exchange's Rest API #######
gateio_futures_rest_api = GateioFuturesRestApi(api_key, api_secret, GateioConstant.RUN_HOST.value, GateioConstant.SETTLE_USDT.value)

account = gateio_futures_rest_api.get_account_detail()
contracts = gateio_futures_rest_api.query_contracts()
wallet = gateio_futures_rest_api.get_wallet_balance()
balance = wallet["balance"]

if balance <= 0:
    print(f'Can not run strategy, because wallet banace is less than 0. {QUOTE_COIN}: {balance}')
    while True:
        wallets = gateio_futures_rest_api.get_wallet_balance()
        balance = wallets[QUOTE_COIN]["balance"]
        if balance > 0:
            break

        sleep(1)

gateio_futures_rest_api.switch_dual_mode()

LEVERAGE = int(sys.argv[1:][0])
if contracts:
    for symbol in symbol_list:
        contract = contracts[symbol]
        positions[symbol] = {}
        _positions = gateio_futures_rest_api.query_positions(symbol)
        if _positions:
            for position_value in _positions.values():
                for position in position_value.values():
                    position_side = position["side"]
                    positions[symbol][position_side] = position

# Orderbook Websocket Thread
class OrderbookWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, key, secret, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)
        self.key = key
        self.secret = secret

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever(ping_interval=5)

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderbookWebsocket's Connection opened.")
        for symbol in symbol_list:
            req = generate_req(
                self.key,
                self.secret,
                channel=GateioConstant.ORDERBOOK_CHANNEL.value,
                event="subscribe",
                pay_load=[symbol, "5", "0"]
            )
            self.ws.send(json.dumps(req))

    def on_close(self, ws):
        print("OrderbookWebsocket's Connection closed.")

    def on_error(self, ws, error):
        print("OrderbookWebsocket's Error: ", error)

    def on_message(self, ws, message):
        global ticks
        message = json.loads(message)
        if message:
            if message["event"] == "all":
                result = message["result"]
                symbol = result["contract"]

                if symbol in symbol_list:
                    tick = {}
                    tick["exchange"] = EXCHANGE
                    tick["symbol"] = symbol

                    if "asks" in result.keys():
                        ask = result["asks"][0]
                        tick["ask_price_1"] = float(ask["p"])
                        tick["ask_volume_1"] = float(ask["s"])
                    else:
                        return

                    if "bids" in result.keys():
                        bid = result["bids"][0]
                        tick["bid_price_1"] = float(bid["p"])
                        tick["bid_volume_1"] = float(bid["s"])
                    else:
                        return

                    ticks[symbol] = tick

# Balance Websocket Thread
class BalanceWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, key, secret, uid, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)
        self.key = key
        self.secret = secret
        self.uid = uid

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever(ping_interval=5)

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("BalanceWebsocketThread's Connection opened.")
        for symbol in symbol_list:
            req = generate_req(
                self.key,
                self.secret,
                channel=GateioConstant.BALANCE_CHANNEL.value,
                event="subscribe",
                pay_load=[self.uid]
            )
            self.ws.send(json.dumps(req))

    def on_close(self, ws):
        print("BalanceWebsocketThread's Connection closed.")

    def on_error(self, ws, error):
        print("BalanceWebsocketThread's Error: ", error)

    def on_message(self, ws, message):
        global wallet
        message = json.loads(message)
        if message:
            if message["event"] == "update":
                result = message["result"][0]
                balance = float(result["balance"])
                wallet["balance"] = balance

# Positions Websocket Thread
class PositionsWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, key, secret, uid, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)
        self.key = key
        self.secret = secret
        self.uid = uid

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever(ping_interval=5)

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("PositionsWebsocketThread's Connection opened.")
        req = generate_req(
            self.key,
            self.secret,
            channel=GateioConstant.POSITION_CHANNEL.value,
            event="subscribe",
            pay_load=[self.uid, symbol]
        )
        self.ws.send(json.dumps(req))

    def on_close(self, ws):
        print("PositionsWebsocketThread's Connection closed.")

    def on_error(self, ws, error):
        print("PositionsWebsocketThread's Error: ", error)

    def on_message(self, ws, message):
        global positions
        message = json.loads(message)
        if message:
            if message["event"] == "update":
                result = message["result"]
                for position_data in result:
                    position = {}

                    symbol = position_data["contract"]
                    if symbol in symbol_list:
                        position["exchange"] = EXCHANGE
                        position["symbol"] = position_data["contract"]
                        position["side"] = position_data["mode"]
                        position["size"] = abs(float(position_data["size"]))
                        position["entry_price"] = float(position_data["entry_price"])
                        position["leverage"] = float(position_data["leverage"])
                        position["leverage_max"] = float(position_data["leverage_max"])
                        position["value"] = position["size"] * position["entry_price"]
                        position["liq_price"] = float(position_data["liq_price"])
                        position["margin"] = float(position_data["margin"])
                        position["risk_limit"] = float(position_data["risk_limit"])
                        position["maintenance_rate"] = float(position_data["maintenance_rate"])

                        if position["symbol"] not in positions.keys():
                            positions[position["symbol"]] = {}

                        positions[position["symbol"]][position["side"]] = position

# Order Websocket Thread
class OrderWebsocketThread(threading.Thread):
    ws = None
    def __init__(self, key, secret, uid, url, trace=False, daemon=False):
        super().__init__()
        self._stop = threading.Event()
        self.ws = wb.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)
        self.key = key
        self.secret = secret
        self.uid = uid

    def run(self):
        while not self._stop.is_set():
            self.ws.run_forever(ping_interval=5)

    def stop(self):
        self._stop.set()

    def on_open(self, ws):
        print("OrderWebsocketThread's Connection Opened.")
        req = generate_req(
            self.key,
            self.secret,
            channel=GateioConstant.ORDER_CHANNEL.value,
            event="subscribe",
            pay_load=[self.uid, symbol]
        )
        self.ws.send(json.dumps(req))

    def on_close(self, ws):
        print("OrderWebsocketThread's Connection Closed.")

    def on_error(self, ws, error):
        print("OrderWebsocketThread's Error: ", error)

    def on_message(self, ws, message):
        global total_amount, traded_count, current_traded_amount, maker_rebate, taker_fee, last_traded_long_open_price_dict, last_traded_short_open_price_dict, last_traded_long_close_price_dict, last_traded_short_close_price_dict, long_open_traded_min_price_dict, short_open_traded_max_price_dict, long_open_count_dict, short_open_count_dict, long_close_count_dict, short_close_count_dict

        message = json.loads(message)
        if message:
            if message["event"] == "update":
                for order_data in message["result"]:
                    symbol = order_data["contract"]

                    if symbol in symbol_list:
                        order_id = int(order_data["id"])
                        price = float(order_data["price"])
                        status = order_data["status"]
                        finish_as = order_data["finish_as"]
                        volume = abs(float(order_data["size"]))
                        filled_price = float(order_data["fill_price"])
                        tif = order_data["tif"]
                        is_reduce_only = bool(order_data["is_reduce_only"])

                        side = None
                        if float(order_data["size"]) > 0:
                            side = LONG_SIDE
                        else:
                            side = SHORT_SIDE

                        pos_side = None
                        if is_reduce_only:
                            if side == LONG_SIDE:
                                pos_side = SHORT_POS
                            else:
                                pos_side = LONG_POS
                        else:
                            if side == LONG_SIDE:
                                pos_side = LONG_POS
                            else:
                                pos_side = SHORT_POS

                        # <!--- get all values for trading
                        pricetick = contracts[symbol]["pricetick"]
                        round_volume = contracts[symbol]["round_volume"]
                        maker_fee_rate = contracts[symbol]["maker_fee_rate"]
                        taker_fee_rate = contracts[symbol]["taker_fee_rate"]
                        quanto_multiplier = contracts[symbol]["quanto_multiplier"]

                        bid_price_1 = ticks[symbol]["bid_price_1"]
                        ask_price_1 = ticks[symbol]["ask_price_1"]
                        # --->

                        l_position_size = positions[symbol][LONG_POS]["size"]
                        l_position_entry_price = positions[symbol][LONG_POS]["entry_price"]
                        l_maker_fee = maker_fee_rate * ask_price_1 * l_position_size * quanto_multiplier if maker_fee_rate > 0 else 0
                        l_position_pnl = (ask_price_1 - l_position_entry_price) * l_position_size * quanto_multiplier - l_maker_fee if l_position_size else 0

                        s_position_size = positions[symbol][SHORT_POS]["size"]
                        s_position_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                        s_maker_fee = maker_fee_rate * bid_price_1 * s_position_size * quanto_multiplier if maker_fee_rate > 0 else 0
                        s_position_pnl = (s_position_entry_price - bid_price_1) * s_position_size * quanto_multiplier - s_maker_fee if s_position_size else 0

                        diff_pricetick_size = "N/A"
                        order_type = "MARKET"
                        if status == GateioConstant.FINISHED.value and finish_as == GateioConstant.FINISH_AS_FILLED.value:
                            traded_count += 1

                            if tif == GateioConstant.POST_ONLY.value:
                                maker_rebate += maker_fee_rate * filled_price * volume * quanto_multiplier
                            else:
                                taker_fee += taker_fee_rate * filled_price * volume * quanto_multiplier

                            if tif == GateioConstant.POST_ONLY.value:
                                order_type = "LIMIT"
                                if side == LONG_SIDE:
                                    if pos_side == SHORT_POS:
                                        profit_ticksize = int((s_position_entry_price - filled_price) / pricetick)
                                        if long_close_profit_ticksize_dict[symbol]:
                                            update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                        else:
                                            if short_close_profit_ticksize_dict[symbol]:
                                                update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 1)
                                            else:
                                                update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                        update_profit_ticksize(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol])
                                        diff_pricetick_size = str(profit_ticksize)
                                        last_traded_long_close_price_dict[symbol] = filled_price
                                        last_traded_short_open_price_dict[symbol] = 0
                                        last_traded_short_close_price_dict[symbol] = 0
                                        long_close_count_dict[symbol] += 1
                                    elif pos_side == LONG_POS:
                                        last_traded_long_open_price_dict[symbol] = filled_price
                                        last_traded_short_close_price_dict[symbol] = 0
                                        long_open_traded_min_price_dict[symbol] = min(filled_price, long_open_traded_min_price_dict[symbol]) if long_open_traded_min_price_dict[symbol] else filled_price
                                        long_open_count_dict[symbol] += 1
                                elif side == SHORT_SIDE:
                                    if pos_side == LONG_POS:
                                        profit_ticksize = int((filled_price - l_position_entry_price) / pricetick)
                                        if short_close_profit_ticksize_dict[symbol]:
                                            update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                        else:
                                            if long_close_profit_ticksize_dict[symbol]:
                                                update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 1)
                                            else:
                                                update_profit_dict(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol], 0)
                                        update_profit_ticksize(symbol, side, profit_ticksize, volume, market_price_ticksize_dict[symbol])
                                        diff_pricetick_size = str(profit_ticksize)
                                        last_traded_short_close_price_dict[symbol] = filled_price
                                        last_traded_long_open_price_dict[symbol] = 0
                                        last_traded_long_close_price_dict[symbol] = 0
                                        short_close_count_dict[symbol] += 1
                                    elif pos_side == SHORT_POS:
                                        last_traded_short_open_price_dict[symbol] = filled_price
                                        last_traded_long_close_price_dict[symbol] = 0
                                        short_open_traded_max_price_dict[symbol] = max(filled_price, short_open_traded_max_price_dict[symbol]) if short_open_traded_max_price_dict[symbol] else filled_price
                                        short_open_count_dict[symbol] += 1

                            traded_volume = filled_price * abs(volume) * quanto_multiplier
                            total_amount += traded_volume
                            current_traded_amount += traded_volume

                            title = symbol.replace("_" + QUOTE_COIN, "")
                            date_time = Utils.get_current_time_mdhm()
                            direction_offset = DIRECTION_OFFSET[side][pos_side]

                            log_txt = f'{traded_count: >8}{title: >12}{order_type: >8}{direction_offset: >14}{Utils.round_to(l_position_size, round_volume): >10}/{Utils.round_to(s_position_size, round_volume): <10}{round(l_position_pnl, 2): >10}/{round(s_position_pnl, 2): <10}{Utils.round_to(l_position_entry_price, pricetick): >12}/{Utils.round_to(s_position_entry_price, pricetick): <12}{diff_pricetick_size: >6}{Utils.round_to(filled_price, pricetick): >12}{Utils.round_to(volume, round_volume): >12}{int(current_runtime): >8}{round(current_traded_amount, 2): >16}{round(balance, 2): >12}{total_profit_ticksize_dict[symbol]: >10}{long_open_calc_ticksize_dict[symbol]: >10}/{short_open_calc_ticksize_dict[symbol]: <4}{date_time: >18}'
                            print(log_txt)

                            log_file_name = Utils.get_current_time_mdh()
                            write_log(EXCHANGE, account_name, symbol, log_txt, log_file_name)

orderbookWebsocketThread = OrderbookWebsocketThread(api_key, api_secret, GateioConstant.WEBSOCKET_HOST.value, False, False)
orderbookWebsocketThread.start()

balanceWebsocketThread = BalanceWebsocketThread(api_key, api_secret, uid, GateioConstant.WEBSOCKET_HOST.value, False, False)
balanceWebsocketThread.start()

positionsWebsocketThread = PositionsWebsocketThread(api_key, api_secret, uid, GateioConstant.WEBSOCKET_HOST.value, False, False)
positionsWebsocketThread.start()

orderWebsocketThread = OrderWebsocketThread(api_key, api_secret, uid, GateioConstant.WEBSOCKET_HOST.value, False, False)
orderWebsocketThread.start()

sleep(5)

BASE_POS_VOLUME_MULTIPLY_RATE = float(sys.argv[1:][1])
HALF_POS_VOLUME_MULTIPLY_RATE = float(sys.argv[1:][2])
MAX_POS_VOLUME_MULTIPLY_RATE = float(sys.argv[1:][3])
OPEN_TICK_VOLUME_DIVIDE_RATE = int(sys.argv[1:][4])
CLOSE_TICK_VOLUME_DIVIDE_RATE = int(sys.argv[1:][5])
PROFIT_TICKSIZE_PERCENT = float(sys.argv[1:][6])
CLOSE_TICKSIZE_PERCENT = float(sys.argv[1:][7])
GRID_TICKSIZE_PERCENT = float(sys.argv[1:][8])

read_process_status_signal_for_all(EXCHANGE, account_name)

for symbol in symbol_list:
    read_process_status_signal_for_symbol(EXCHANGE, account_name, symbol)
    write_parameters(EXCHANGE, account_name, symbol)
    read_traded_info(EXCHANGE, account_name, symbol)
    read_variables(EXCHANGE, account_name, symbol)
    read_profit_ticksize(EXCHANGE, account_name, symbol)

CLS_TIME = time()
TRADED_INFO_TIME = time()

print(f'==================================================')
print(balance, contracts[symbol_list[0]]["maker_fee_rate"], contracts[symbol_list[0]]["taker_fee_rate"])
print(f'==================================================')

sleep(5)

if start_balance == 0:
    start_balance = balance

if min_balance == 0:
    min_balance = start_balance

if max_balance == 0:
    max_balance = start_balance

start_time = time()
last_runtime = total_runtime

print(f'|==================================================|')
print(f'| Start main process...                            |')
print(f'|==================================================|')

while True:
    current_runtime = round((time() - start_time) / 60)
    if symbol_list:
        for symbol in symbol_list:
            sleep(0.5)

            read_parameters(EXCHANGE, account_name, symbol)
            write_profit_ticksize(EXCHANGE, account_name, symbol)
            write_traded_info(EXCHANGE, account_name, symbol)
            write_variables(EXCHANGE, account_name, symbol)
            write_process_status_for_symbol(EXCHANGE, account_name, symbol, 0)

            # <!--- check some parameters for market/trade/account
            contract = contracts[symbol]
            if symbol not in ticks.keys():
                continue

            balance = wallet["balance"]
            if balance > max_balance:
                max_balance = balance

            if balance < min_balance:
                min_balance = balance

            # <!--- get all values for trading
            pricetick = contract["pricetick"]
            round_volume = contract["round_volume"]
            min_volume = contract["min_order_qty"]
            max_volume = contract["max_order_qty"]
            quanto_multiplier = contract["quanto_multiplier"]
            maker_fee_rate = contract["maker_fee_rate"]
            taker_fee_rate = contract["taker_fee_rate"]
            # --->

            # <!--- calc tick volume and grid ticksize
            _ask_price_1 = ticks[symbol]["ask_price_1"]

            _base_pos_volume = Utils.round_to(BASE_POS_VOLUME_MULTIPLY_RATE * balance / (_ask_price_1 * len(symbol_list) * quanto_multiplier), round_volume)
            if symbol not in base_pos_volume_dict.keys() or base_pos_volume_dict[symbol] == 0:
                base_pos_volume_dict[symbol] = min(_base_pos_volume, max_volume)
                print(f'Base position volume: {base_pos_volume_dict[symbol]}')

            _max_pos_volume = Utils.round_to(MAX_POS_VOLUME_MULTIPLY_RATE * base_pos_volume_dict[symbol], round_volume)
            if symbol not in max_pos_volume_dict.keys() or max_pos_volume_dict[symbol] == 0:
                max_pos_volume_dict[symbol] = min(_max_pos_volume, max_volume)
                print(f'Max position volume: {max_pos_volume_dict[symbol]}')
                _max_pos_volume_maker_fee = 2 * maker_fee_rate * _ask_price_1 * max_pos_volume_dict[symbol] if maker_fee_rate > 0 else 0
                _max_pos_volume_maker_fee_percent = (_max_pos_volume_maker_fee / balance) * 100 if maker_fee_rate > 0 else 0
                print(f'Max position maker fee/percent: {round(_max_pos_volume_maker_fee, 2)}/{round(_max_pos_volume_maker_fee_percent, 2)}')

            if symbol not in open_tick_volume_dict.keys() or open_tick_volume_dict[symbol] == 0:
                _open_tick_volume = Utils.round_to(max_pos_volume_dict[symbol] / OPEN_TICK_VOLUME_DIVIDE_RATE, round_volume)
                open_tick_volume_dict[symbol] = max(_open_tick_volume, min_volume)
                print(f'Open tick volume: {open_tick_volume_dict[symbol]}')

            if symbol not in close_tick_volume_dict.keys() or close_tick_volume_dict[symbol] == 0:
                _close_tick_volume = Utils.round_to(max_pos_volume_dict[symbol] / CLOSE_TICK_VOLUME_DIVIDE_RATE, round_volume)
                close_tick_volume_dict[symbol] = max(_close_tick_volume, min_volume)
                print(f'Close tick volume: {close_tick_volume_dict[symbol]}')

            _market_price_ticksize = int(_ask_price_1 / pricetick)
            if symbol not in market_price_ticksize_dict.keys() or market_price_ticksize_dict[symbol] == 0:
                market_price_ticksize_dict[symbol] = _market_price_ticksize
                print(f'Market price ticksize: {market_price_ticksize_dict[symbol]}')
            market_price_ticksize_dict[symbol] = max(market_price_ticksize_dict[symbol], _market_price_ticksize)

            _grid_ticksize = int(GRID_TICKSIZE_PERCENT * int(_ask_price_1 / pricetick) / 100)
            if symbol not in grid_ticksize_dict.keys() or grid_ticksize_dict[symbol] == 0:
                grid_ticksize_dict[symbol] = _grid_ticksize
                print(f'Grid ticksize: {grid_ticksize_dict[symbol]}')
            grid_ticksize_dict[symbol] = _grid_ticksize # max(grid_ticksize_dict[symbol], _grid_ticksize)

            _profit_ticksize = int(PROFIT_TICKSIZE_PERCENT * market_price_ticksize_dict[symbol] / 100) + 1
            if symbol not in profit_ticksize_dict.keys() or profit_ticksize_dict[symbol] == 0:
                profit_ticksize_dict[symbol] = _profit_ticksize
                print(f'Profit ticksize: {profit_ticksize_dict[symbol]}')
            profit_ticksize_dict[symbol] = max(profit_ticksize_dict[symbol], _profit_ticksize)

            _fee_ticksize = int(maker_fee_rate * market_price_ticksize_dict[symbol]) + 1 if maker_fee_rate > 0 else 0
            if symbol not in fee_ticksize_dict.keys() or (fee_ticksize_dict[symbol] == 0 and maker_fee_rate > 0):
                fee_ticksize_dict[symbol] = _fee_ticksize
                print(f'Fee ticksize: {fee_ticksize_dict[symbol]}')
            fee_ticksize_dict[symbol] = max(fee_ticksize_dict[symbol], _fee_ticksize) if maker_fee_rate > 0 else 0

            if symbol not in long_open_calc_ticksize_dict.keys():
                long_open_calc_ticksize_dict[symbol] = 0

            if symbol not in short_open_calc_ticksize_dict.keys():
                short_open_calc_ticksize_dict[symbol] = 0
            # -->

            open_order_ids = {LONG_SIDE: {LONG_POS: '', SHORT_POS: ''}, SHORT_SIDE: {LONG_POS: '', SHORT_POS: ''}}
            open_order_info = {LONG_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}, SHORT_SIDE: {LONG_POS: {'price': 0, 'volume': 0}, SHORT_POS: {'price': 0, 'volume': 0}}}

            # sending orders
            open_orders = gateio_futures_rest_api.get_open_orders(symbol)
            for new_side in (LONG_SIDE, SHORT_SIDE):
                for new_position_side in (LONG_POS, SHORT_POS):
                    new_price, new_volume = 0, 0
                    offset = OFFSET_OPEN

                    bid_price_1 = ticks[symbol]["bid_price_1"]
                    ask_price_1 = ticks[symbol]["ask_price_1"]

                    open_order_ids[new_side][new_position_side] = ''
                    open_order_info[new_side][new_position_side] = {'price': 0, 'volume': 0}

                    # new price
                    if new_side == LONG_SIDE:
                        new_price = Utils.round_to(bid_price_1, pricetick)
                    elif new_side == SHORT_SIDE:
                        new_price = Utils.round_to(ask_price_1, pricetick)

                    if open_orders and new_side in open_orders.keys() and open_orders[new_side] and new_position_side in open_orders[new_side].keys() and open_orders[new_side][new_position_side]:
                        open_order_ids[new_side][new_position_side] = open_orders[new_side][new_position_side]["order_id"]
                        open_order_info[new_side][new_position_side]["price"] = float(open_orders[new_side][new_position_side]["price"])
                        open_order_info[new_side][new_position_side]["volume"] = float(open_orders[new_side][new_position_side]["qty"])

                    long_pos_size = positions[symbol][LONG_POS]["size"]
                    long_pos_entry_price = positions[symbol][LONG_POS]["entry_price"]
                    long_maker_fee = maker_fee_rate * ask_price_1 * long_pos_size * quanto_multiplier if maker_fee_rate > 0 else 0
                    long_pos_pnl_value = (ask_price_1 - long_pos_entry_price) * long_pos_size * quanto_multiplier - long_maker_fee if long_pos_size else 0
                    if not long_pos_size:
                        long_open_count_dict[symbol] = 0
                        short_close_count_dict[symbol] = 0
                        long_open_traded_min_price_dict[symbol] = 0
                        last_traded_long_open_price_dict[symbol] = 0
                        last_traded_short_close_price_dict[symbol] = 0

                    short_pos_size = positions[symbol][SHORT_POS]["size"]
                    short_pos_entry_price = positions[symbol][SHORT_POS]["entry_price"]
                    short_maker_fee = maker_fee_rate * bid_price_1 * short_pos_size * quanto_multiplier if maker_fee_rate > 0 else 0
                    short_pos_pnl_value = (short_pos_entry_price - bid_price_1) * short_pos_size * quanto_multiplier - short_maker_fee if short_pos_size else 0
                    if not short_pos_size:
                        short_open_count_dict[symbol] = 0
                        long_close_count_dict[symbol] = 0
                        short_open_traded_max_price_dict[symbol] = 0
                        last_traded_short_open_price_dict[symbol] = 0
                        last_traded_long_close_price_dict[symbol] = 0

                    entry_price_dist_ticksize = max((long_pos_entry_price - short_pos_entry_price) / pricetick, 0) if long_pos_size and short_pos_size else 0
                    if new_side == LONG_SIDE:
                        if new_position_side == LONG_POS: # LONG OPEN
                            if long_pos_size:
                                if long_pos_size <= max_pos_volume_dict[symbol] - open_tick_volume_dict[symbol]:
                                    if new_price < long_pos_entry_price:
                                        new_volume = open_tick_volume_dict[symbol]

                                if new_volume:
                                    if last_traded_long_open_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_long_open_price_dict[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)
                                    elif last_traded_short_close_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_short_close_price_dict[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)

                                    if new_price > bid_price_1:
                                        new_price = Utils.round_to(bid_price_1, pricetick)
                            else:
                                new_volume = max_pos_volume_dict[symbol]
                        elif new_position_side == SHORT_POS: # LONG CLOSE
                            if short_pos_size and long_pos_size:
                                # price
                                if last_traded_short_close_price_dict[symbol]:
                                    new_price = Utils.round_to(last_traded_short_close_price_dict[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)
                                elif last_traded_long_close_price_dict[symbol]:
                                    new_price = Utils.round_to(last_traded_long_close_price_dict[symbol] - grid_ticksize_dict[symbol] * pricetick, pricetick)

                                if new_price > bid_price_1:
                                    new_price = Utils.round_to(bid_price_1, pricetick)

                                # volume
                                if short_close_profit_ticksize_dict[symbol]:
                                    if new_price < short_pos_entry_price - fee_ticksize_dict[symbol] * pricetick and new_price < long_pos_entry_price - fee_ticksize_dict[symbol] * pricetick:
                                        long_close_profit_ticksize_dict[symbol] = short_close_profit_ticksize_dict[symbol]
                                        short_close_profit_ticksize_dict[symbol] = []
                                    else:
                                        minus_ticksize = round((new_price - short_pos_entry_price) / pricetick)
                                        new_volume = get_minus_close_volume(symbol, new_side, minus_ticksize)
                                else:
                                    if new_price < short_pos_entry_price - (4 * profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol] + entry_price_dist_ticksize) * pricetick:
                                        new_volume = min(close_tick_volume_dict[symbol], short_pos_size)
                                        if long_close_profit_ticksize_dict[symbol]:
                                            max_profit_ticksize = get_max_prfofit_ticksize(symbol, LONG_SIDE)
                                            if (short_pos_entry_price - new_price) < (max_profit_ticksize + grid_ticksize_dict[symbol]) * pricetick:
                                                new_volume = 0
                    elif new_side == SHORT_SIDE:
                        if new_position_side == SHORT_POS: # SHORT OPEN
                            if short_pos_size:
                                if short_pos_size <= max_pos_volume_dict[symbol] - open_tick_volume_dict[symbol]:
                                    if new_price > short_pos_entry_price:
                                        new_volume = open_tick_volume_dict[symbol]

                                if new_volume:
                                    # price
                                    if last_traded_short_open_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_short_open_price_dict[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)
                                    elif last_traded_long_close_price_dict[symbol]:
                                        new_price = Utils.round_to(last_traded_long_close_price_dict[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)

                                    if new_price < ask_price_1:
                                        new_price = Utils.round_to(ask_price_1, pricetick)
                            else:
                                new_volume = max_pos_volume_dict[symbol]
                        elif new_position_side == LONG_POS: # SHORT CLOSE
                            if long_pos_size and short_pos_size:
                                # price
                                if last_traded_long_close_price_dict[symbol]:
                                    new_price = Utils.round_to(last_traded_long_close_price_dict[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)
                                elif last_traded_short_close_price_dict[symbol]:
                                    new_price = Utils.round_to(last_traded_short_close_price_dict[symbol] + grid_ticksize_dict[symbol] * pricetick, pricetick)

                                if new_price < ask_price_1:
                                    new_price = Utils.round_to(ask_price_1, pricetick)

                                # volume
                                if long_close_profit_ticksize_dict[symbol]:
                                    if new_price > short_pos_entry_price - fee_ticksize_dict[symbol] * pricetick and new_price > long_pos_entry_price - fee_ticksize_dict[symbol] * pricetick:
                                        short_close_profit_ticksize_dict[symbol] = long_close_profit_ticksize_dict[symbol]
                                        long_close_profit_ticksize_dict[symbol] = []
                                    else:
                                        minus_ticksize = round((long_pos_entry_price - new_price) / pricetick)
                                        new_volume = get_minus_close_volume(symbol, new_side, minus_ticksize)
                                else:
                                    if new_price > long_pos_entry_price + (4 * profit_ticksize_dict[symbol] + fee_ticksize_dict[symbol] + entry_price_dist_ticksize) * pricetick:
                                        new_volume = min(close_tick_volume_dict[symbol], long_pos_size)
                                        # if short_close_profit_ticksize_dict[symbol]:
                                        #     max_profit_ticksize = get_max_prfofit_ticksize(symbol, SHORT_SIDE)
                                        #     if (new_price - long_pos_entry_price) < (max_profit_ticksize + grid_ticksize_dict[symbol]) * pricetick:
                                        #         new_volume = 0

                    new_volume = Utils.round_to(min(new_volume, max_volume), round_volume)

                    if open_order_ids[new_side][new_position_side]:
                        open_order_id = open_order_ids[new_side][new_position_side]
                        old_price = open_order_info[new_side][new_position_side]["price"]
                        old_volume = open_order_info[new_side][new_position_side]["volume"]

                        if abs(old_volume) != abs(new_volume) or old_price != new_price:
                            gateio_futures_rest_api.cancel_order(open_order_id)

                        continue

                    if new_price and new_volume:
                        response = gateio_futures_rest_api.send_maker_order(symbol, new_side, new_volume, new_price, offset)

        if time() - CLS_TIME > CLS_INTERVAL_TIME:
            os.system('cls')
            CLS_TIME = time()

        if time() - TRADED_INFO_TIME > TRADED_INFO_INTERVAL_TIME:
            for symbol in symbol_list:
                print(f'Total profit ticksize for {symbol}: {total_profit_ticksize_dict[symbol]}')

            print(f"|==========================================================================================================================================================================================================================|")
            print(f'|{TRADED_INFO_TITLE[0]: >26}{TRADED_INFO_TITLE[1]: >27}{TRADED_INFO_TITLE[2]: >27}{TRADED_INFO_TITLE[3]: >27}{TRADED_INFO_TITLE[4]: >32}{TRADED_INFO_TITLE[5]: >24}{TRADED_INFO_TITLE[6]: >18}{TRADED_INFO_TITLE[7]: >18}{TRADED_INFO_TITLE[8]: >18} |')
            print(f'|           ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|')
            total_runtime = last_runtime + current_runtime
            runtime_minutes = round(total_runtime)
            runtime_hours = round(total_runtime / 60, 1)
            runtime_days = round(total_runtime / 1440, 2)
            runtime = f'{runtime_minutes}/{runtime_hours}/{runtime_days}'

            predict_dailty_trade_amt = round(total_amount / (total_runtime / 1440), 1) if total_runtime > 1 else 0
            predict_daily_trade_leverage = round((total_amount / (total_runtime / 1440)) / balance, 1) if total_runtime > 1 else 0
            predict_dailty_trade_amt_leverage = f'{predict_dailty_trade_amt}/{predict_daily_trade_leverage}'

            profit = round(balance - start_balance, 2)
            profit_percent = f'{round((profit / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 30 / (start_balance * runtime_days)) * 100, 1)}/{round((profit * 365 / (start_balance * runtime_days)) * 100, 1)}' if profit != 0 and runtime_days != 0 else 0

            rebate_fee = f'{round(maker_rebate, 2)}/{round(taker_fee, 2)}'
            print(f'| {runtime: >24}{predict_dailty_trade_amt_leverage: >27}{profit_percent: >27}{profit: >27}{round(total_amount, 3): >32}{rebate_fee: >24}{round(balance, 2): >18}{round(max_balance, 2): >18}{round(min_balance, 2): >18}  |')
            print(f'|==========================================================================================================================================================================================================================|')

            TRADED_INFO_TIME = time()

        run_signal_for_all = read_process_status_signal_for_all(EXCHANGE, account_name)
        if run_signal_for_all == 1:
            print(f'Stop! Cancelling all open orders...')

            for symbol in symbol_list:
                gateio_futures_rest_api.cancel_all_orders(symbol)

            sleep(1)

            break
        elif run_signal_for_all == 2:
            print(f'Pause! Cancelling all open orders...')

            for symbol in symbol_list:
                gateio_futures_rest_api.cancel_all_orders(symbol)

            sleep(1)

            while True:
                sleep(1)
                run_signal_for_all = read_process_status_signal_for_all(EXCHANGE, account_name)
                if run_signal_for_all != 2:
                    break
        elif run_signal_for_all == 3:
            print(f'All Close! Cancelling all open orders...')
            for symbol in symbol_list:
                gateio_futures_rest_api.cancel_all_orders(symbol)

                sleep(0.5)

                print(f'Close all positions for {symbol}...')
                contract = contracts[symbol]
                for close_position_side in (LONG_POS, SHORT_POS):
                    close_side = POSITION_SIDE_TO_CLOSE_SIDE[close_position_side]
                    close_volume = positions[symbol][close_position_side]["size"]
                    if close_volume:
                        gateio_futures_rest_api.close_all_positions(symbol, close_side, close_volume)
            break

sleep(3)

print(f'Saving trade info, and exit program automatically...')

write_process_status_for_all(EXCHANGE, account_name, 0)

for symbol in symbol_list:
    print(f'Total profit ticksize for {symbol}: {total_profit_ticksize_dict[symbol]}')

    write_profit_ticksize(EXCHANGE, account_name, symbol)
    write_parameters(EXCHANGE, account_name, symbol)
    write_traded_info(EXCHANGE, account_name, symbol)
    write_variables(EXCHANGE, account_name, symbol)
    write_process_status_for_symbol(EXCHANGE, account_name, symbol, 0)

sleep(3)

print(f'Exit!')

sys.exit()
