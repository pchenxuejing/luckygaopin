#!/usr/bin/env python
import logging

import os
import os.path
import sys

import json
from typing import List, Dict
from time import sleep, time

import threading
import websocket

from constant import RestApiConstant, GateioConstant
from gateio_futures_rest_api import GateioFuturesRestApi

import asyncio

from gate_ws import Configuration, Connection, WebSocketResponse
from gate_ws.futures import FuturesPublicTradeChannel, FuturesOrderChannel

# exchange api
# api_key = "f6529c83320cc4af9a789a19b65bdafb"
# api_secret = "46930971ed14283d8bd28fd52cfe9db8abd9115e57c42a340fdf9a7766700f87"

api_key = str(sys.argv[1:][0])
api_secret = str(sys.argv[1:][1])

contracts = {}
wallet = {}

QUOTE_COIN = GateioConstant.QUOTE_USDT.value
OPPOSITE_SIDE: Dict[str, str] = {"bid": "ask", "ask": "bid"}
SIDE_TO_CLOSE_POSITION_SIDE: Dict[str, str] = {"bid": "dual_short", "ask": "dual_long"}
POSITION_SIDE_TO_CLOSE_SIDE: Dict[str, str] = {"dual_long": "ask", "dual_short": "bid"}
DIRECTION_OFFSET = {"bid": {"dual_long": "LONG_OPEN", "dual_short": "LONG_CLOSE"}, "ask":{"dual_long": "SHORT_CLOSE", "dual_short": "SHORT_OPEN"}}

LONG_SIDE = GateioConstant.LONG.value
SHORT_SIDE = GateioConstant.SHORT.value

LONG_POS = GateioConstant.POSITION_LONG.value
SHORT_POS = GateioConstant.POSITION_SHORT.value

####### Exchange's Rest API #######
gateio_futures_rest_api = GateioFuturesRestApi(api_key, api_secret, GateioConstant.RUN_HOST.value, GateioConstant.SETTLE_USDT.value)

contracts = gateio_futures_rest_api.query_contracts()
wallet = gateio_futures_rest_api.get_wallet_balance()
balance = wallet["balance"]

print(f'==================================================')
print(balance)
print(f'==================================================')

class WebsocketClientThread(threading.Thread):
    ws = None
    def __init__(self, url, trace=False, daemon=False):
        super().__init__()
        self.stop_event = threading.Event()
        self.ws = websocket.WebSocketApp(url, on_open=self.on_open, on_close=self.on_close, on_error=self.on_error, on_message=self.on_message)

    def run(self):
        while not self.stop_event.is_set():
            self.ws.run_forever()

    def stop(self):
        self.stop_event.set()

    def on_open(self, ws):
        print("WebSocket's Connection Opened.")

    def on_close(self, ws):
        print("WebSocket's Connection Closed.")

    def on_error(self, ws, error):
        print("WebSocket's Error: ", error)

    def on_message(self, ws, message):
        print(message)

    def send_message(self, message):
        self.ws.send(message)

websocket_client_thread = WebsocketClientThread(RestApiConstant.WEBSOCKET_URL.value, False, False)
websocket_client_thread.start()

# define your callback function on message received
def print_message(conn: Connection, response: WebSocketResponse):
    if response.error:
        print('error returned: ', response.error)
        conn.close()
        return

    for order_data in response.result:
        if "finish_as" in order_data and order_data["finish_as"] == GateioConstant.FINISH_AS_FILLED.value:
            symbol = order_data["contract"]
            order_id = int(order_data["id"])
            price = float(order_data["price"])
            status = order_data["status"]
            finish_as = order_data["finish_as"]
            volume = abs(float(order_data["size"]))
            filled_price = float(order_data["fill_price"])
            tif = order_data["tif"]
            is_reduce_only = bool(order_data["is_reduce_only"])

            side = None
            if float(order_data["size"]) > 0:
                side = LONG_SIDE
            else:
                side = SHORT_SIDE

            pos_side = None
            if is_reduce_only:
                if side == LONG_SIDE:
                    pos_side = SHORT_POS
                else:
                    pos_side = LONG_POS
            else:
                if side == LONG_SIDE:
                    pos_side = LONG_POS
                else:
                    pos_side = SHORT_POS

            date_time = Utils.get_current_time_mdhm()
            if status == GateioConstant.FINISHED.value and finish_as == GateioConstant.FINISH_AS_FILLED.value:
                if side == LONG_SIDE:
                    if pos_side == LONG_POS:
                        socket_msg = '{"direction": "leader_order_update", "side": "LONG_SIDE", "pos_side": "LONG_POS", "symbol": "' + symbol.replace("_USDT", "") + '", "volume": "' + str(volume * contracts[symbol]["quanto_multiplier"]) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "date_time": "' + str(date_time) + '"}'
                        websocket_client_thread.send_message(socket_msg)
                    elif pos_side == SHORT_POS:
                        socket_msg = '{"direction": "leader_order_update", "side": "LONG_SIDE", "pos_side": "SHORT_POS", "symbol": "' + symbol.replace("_USDT", "") + '", "volume": "' + str(volume * contracts[symbol]["quanto_multiplier"]) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "date_time": "' + str(date_time) + '"}'
                        websocket_client_thread.send_message(socket_msg)
                elif side == SHORT_SIDE:
                    if pos_side == LONG_POS:
                        socket_msg = '{"direction": "leader_order_update", "side": "SHORT_SIDE", "pos_side": "LONG_POS", "symbol": "' + symbol.replace("_USDT", "") + '", "volume": "' + str(volume * contracts[symbol]["quanto_multiplier"]) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "date_time": "' + str(date_time) + '"}'
                        websocket_client_thread.send_message(socket_msg)
                    elif pos_side == SHORT_POS:
                        socket_msg = '{"direction": "leader_order_update", "side": "SHORT_SIDE", "pos_side": "SHORT_POS", "symbol": "' + symbol.replace("_USDT", "") + '", "volume": "' + str(volume * contracts[symbol]["quanto_multiplier"]) + '", "filled_price": "' + str(filled_price) + '", "leader_balance": "' + str(balance) + '", "date_time": "' + str(date_time) + '"}'
                        websocket_client_thread.send_message(socket_msg)

async def main():
    # initialize default connection, which connects to spot WebSocket V4
    # it is recommended to use one conn to initialize multiple channels
    conn = Connection(Configuration(app='futures', settle='usdt', test_net=False, api_key=api_key, api_secret=api_secret))

    # subscribe to any channel you are interested into, with the callback function
    if contracts:
        for symbol in list(contracts):
            channel = FuturesOrderChannel(conn, print_message)
            channel.subscribe([symbol])

    # start the client
    await conn.run()

if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
    loop.close()
