from vnpy.app.cta_strategy import (
    CtaTemplate,
    TickData,
    TradeData,
    OrderData
)
from vnpy.trader.utility import round_to
from vnpy.trader.constant import Offset, Direction, Status, OrderType
from vnpy.trader.event import EVENT_ACCOUNT, EVENT_POSITION
from threading import Thread
from time import sleep, time
from datetime import datetime
from typing import Dict
import os
import os.path
import numpy as np

LONG = Direction.LONG
SHORT = Direction.SHORT

OPEN = Offset.OPEN
CLOSE = Offset.CLOSE
NONE = Offset.NONE

SUBMITTING = Status.SUBMITTING
NOTTRADED = Status.NOTTRADED
PARTTRADED = Status.PARTTRADED
ALLTRADED = Status.ALLTRADED
CANCELLED = Status.CANCELLED
REJECTED = Status.REJECTED

class rebate_test(CtaTemplate):

    author = "4989 Strategy"

    # Parameters
    start_balance = 0.0                         # a start balance (funded amount at first time)
    tick_volume = 0.01                          # a volume per tick

    # Variables
    balance = 0                                 # an available balance of account
    rebate = 0                                  # a rebate till now (for a maker)
    market_price = 0                            # a market price

    last_traded_long_open_price = 0             # the latest traded long open price
    last_traded_long_open_volume = 0            # the latest traded long open volume

    last_traded_short_open_price = 0            # the latest traded short open price
    last_traded_short_open_volume = 0           # the latest traded short open volume

    last_traded_long_close_price = 0            # the latest traded long close price
    last_traded_long_close_volume = 0           # the latest traded long close volume

    last_traded_short_close_price = 0           # the latest traded short close price
    last_traded_short_close_volume = 0          # the latest traded short close volume

    pos_volume = {LONG: 0, SHORT: 0}            # a position volume

    # Traded info
    traded_summary = {'total': 0, 'traded': 0, 'maker': 0, 'taker': 0, 'cancelled': 0, 'rejected': 0}

    # For edit and display
    parameters = ['start_balance', 'tick_volume']
    variables = ['rebate']


    """
    Callback when strategy is inited.
    """
    def __init__(self, cta_engine, strategy_name, vt_symbol, setting):
        """"""
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)

        # market price tick
        self.pricetick = self.get_pricetick()

        # contract instance
        contract = self.cta_engine.main_engine.get_contract(self.vt_symbol)
        self.min_volume = contract.min_volume
        self.quanto_multiplier = contract.quanto_multiplier if contract.quanto_multiplier != 0 else 1

        # symbol (removed '.ExchangeName')
        self.symbol = self.vt_symbol.split('.')[0]

        self.init()


    """
    "   Desc: init some parameters
    """
    def init(self):
        self.last_tick = None
        self.last_last_tick = None

        self.main_process_thread = None
        self.restart_strategy_thread = None

        self.order_info_queue = {}
        self.registered_order_info = {
            LONG: {
                OPEN: '',
                CLOSE: ''
            },
            SHORT: {
                OPEN: '',
                CLOSE: ''
            }
        }

        self.last_traded_long_open_price = 0
        self.last_traded_short_open_price = 0
        self.last_traded_long_close_price = 0
        self.last_traded_short_close_price = 0


    """
    Callback when strategy is inited.
    """
    def on_init(self):
        self.gateway = self.cta_engine.main_engine.get_gateway('GATEIOS')


    """
    Callback when strategy is started.
    """
    def on_start(self):
        self.cta_engine.event_engine.register(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.register(EVENT_POSITION, self.on_position)

        self.gateway.query_account()
        self.gateway.query_position()

        self.init()

        self.stop_main_process = False

        # main thread
        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.main_process_thread.start()

        self.put_event()


    """
    Callback when strategy is stopped
    """
    def on_stop(self):
        self.stop_main_process = True

        self.cta_engine.event_engine.unregister(EVENT_ACCOUNT, self.on_account)
        self.cta_engine.event_engine.unregister(EVENT_POSITION, self.on_position)

        self.put_event()


    """
    Callback of new tick data update.
    """
    def on_tick(self, tick: TickData):
        self.last_last_tick = self.last_tick
        self.last_tick = tick

        if self.is_valid_tick(tick) == False:
            pass
        else:
            self.market_price = round((tick.ask_price_1 + tick.bid_price_1) / 2, 2)

        self.put_event()


    def is_valid_tick(self, tick):
        if tick == None or tick.last_price == 0 or tick.bid_price_1 == 0 or tick.ask_price_1 == 0:
            return False
        else:
            return True


    """
    "   Desc: restart process
    """
    def restart_strategy(self):
        self.stop_main_process = True
        while self.stop_main_process == True:
            sleep(0.05)

        self.init()

        self.main_process_thread = Thread(target = self.main_process)
        self.main_process_thread.setDaemon(True)
        self.stop_main_process = False
        self.main_process_thread.start()


    """
    "   Desc: main process
    """
    def main_process(self):
        # lock until strategy start and balance is not empty
        while self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
            if self.stop_main_process == True:
                break
            sleep(0.05)

        # main process daemon
        while self.stop_main_process == False:
            sleep(0.5)

            if self.trading == False or self.balance == 0 or (self.is_valid_tick(self.last_tick) == False and self.is_valid_tick(self.last_last_tick) == False):
                continue

            for direction in (LONG, SHORT):
                if self.stop_main_process == True:
                    break

                # open
                open_orderid = self.registered_order_info[direction][OPEN]
                if open_orderid == '':
                    self.send_new_order(direction, OPEN)
                else:
                    if open_orderid not in self.order_info_queue:
                        continue

                    if self.order_info_queue[open_orderid]['status'] == REJECTED or self.order_info_queue[open_orderid]['status'] == CANCELLED:
                        del self.order_info_queue[open_orderid]
                        self.registered_order_info[direction][OPEN] = ''
                        self.send_new_order(direction, OPEN)
                    elif self.order_info_queue[open_orderid]['status'] == ALLTRADED:
                        del self.order_info_queue[open_orderid]
                        self.registered_order_info[direction][OPEN] = ''
                    elif self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED:
                        price = self.order_info_queue[open_orderid]['price']
                        volume = self.order_info_queue[open_orderid]['volume']
                        self.send_new_order(direction, OPEN, price, volume)

                # close
                if (direction == LONG and self.pos_volume[SHORT] > 0) or (direction == SHORT and self.pos_volume[LONG] > 0):
                    close_orderid = self.registered_order_info[direction][CLOSE]
                    if close_orderid == '':
                        self.send_new_order(direction, CLOSE)
                    else:
                        if close_orderid not in self.order_info_queue:
                            continue

                        if self.order_info_queue[close_orderid]['status'] == REJECTED or self.order_info_queue[close_orderid]['status'] == CANCELLED:
                            del self.order_info_queue[close_orderid]
                            self.registered_order_info[direction][CLOSE] = ''
                            self.send_new_order(direction, CLOSE)
                        elif self.order_info_queue[close_orderid]['status'] == ALLTRADED:
                            del self.order_info_queue[close_orderid]
                            self.registered_order_info[direction][CLOSE] = ''
                        elif self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED:
                            price = self.order_info_queue[close_orderid]['price']
                            volume = self.order_info_queue[close_orderid]['volume']
                            self.send_new_order(direction, CLOSE, price, volume)

        sleep(2)

        # cancel all long/short open/close orders
        for direction in (LONG, SHORT):
            open_orderid = self.registered_order_info[direction][OPEN]
            if open_orderid != '':
                if open_orderid in self.order_info_queue and (self.order_info_queue[open_orderid]['status'] == NOTTRADED or self.order_info_queue[open_orderid]['status'] == PARTTRADED):
                    self.cancel_order(open_orderid)

            close_orderid = self.registered_order_info[direction][CLOSE]
            if close_orderid != '':
                if close_orderid in self.order_info_queue and (self.order_info_queue[close_orderid]['status'] == NOTTRADED or self.order_info_queue[close_orderid]['status'] == PARTTRADED):
                    self.cancel_order(close_orderid)

        sleep(2)

        self.stop_main_process = False


    """
    "   Desc: Send new order
    """
    def send_new_order(self, direction, offset, old_price = -1, old_volume = -1):
        if self.stop_main_process == True:
            return

        # get an order price and volume
        new_price = self.get_order_price(direction, offset)
        new_volume = self.get_order_volume(direction, offset, new_price)

        new_volume = round_to(new_volume, self.min_volume)
        if round(abs((new_price - old_price) / self.pricetick)) == 0 and new_volume == old_volume:
            return

        # get previous vt_orderid
        previous_vt_orderid = self.registered_order_info[direction][offset]
        if previous_vt_orderid != '':
            if previous_vt_orderid not in self.order_info_queue or self.order_info_queue[previous_vt_orderid]['status'] == SUBMITTING:
                return
            elif self.order_info_queue[previous_vt_orderid]['status'] == NOTTRADED or self.order_info_queue[previous_vt_orderid]['status'] == PARTTRADED:
                self.cancel_order(previous_vt_orderid)

            self.registered_order_info[direction][offset] = ''

        if new_price == 0 or new_volume < self.tick_volume:
            return

        try:
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]
        except:
            print("Catched Exception:", direction, offset)
            vt_orderid = self.send_order(direction, offset, new_price, new_volume)[-1]

        if len(vt_orderid) > 0:
            self.registered_order_info[direction][offset] = vt_orderid
            self.set_order_info_queue(vt_orderid, direction, offset, new_price, new_volume, SUBMITTING)
            return
        else:
            return


    """
    "   Desc: Get ask/bid price
    """
    def get_order_price(self, direction, offset):
        while True:
            if self.is_valid_tick(self.last_tick) == True:
                tick = self.last_tick
                break
            elif self.is_valid_tick(self.last_last_tick) == True:
                tick = self.last_last_tick
                break

            if self.stop_main_process == True:
                return

            sleep(0.05)

        if direction == LONG:
            price = tick.bid_price_1
            if offset == OPEN:
                if self.pos_volume[LONG] > 0 or self.pos_volume[SHORT] > 0 or self.last_traded_short_close_price or self.last_traded_long_close_price:
                    return 0

            if price > tick.bid_price_1:
                price = tick.bid_price_1
        elif direction == SHORT:
            price = tick.ask_price_1
            if offset == OPEN:
                if self.pos_volume[LONG] > 0 or self.pos_volume[SHORT] > 0 or self.last_traded_long_close_price or self.last_traded_short_close_price:
                    return 0

            if price < tick.ask_price_1:
                price = tick.ask_price_1

        price = round_to(price, self.pricetick)

        return price


    """
    "   Desc: Get an order volume
    """
    def get_order_volume(self, direction, offset, price):
        if price == 0:
            return 0

        volume = 0
        if direction == LONG:
            if offset == OPEN:
                volume = self.tick_volume
            elif offset == CLOSE:
                volume = self.pos_volume[SHORT]
        elif direction == SHORT:
            if offset == OPEN:
                volume = self.tick_volume
            elif offset == CLOSE:
                volume = self.pos_volume[LONG]

        return volume


    """
    "   Desc: Get order direction and offset as string
    """
    def get_order_direction_offset_str(self, direction, offset):
        if direction == LONG:
            if offset == OPEN:
                return 'L_OPEN'
            elif offset == CLOSE:
                return 'L_CLOSE'
        elif direction == SHORT:
            if offset == OPEN:
                return 'S_OPEN'
            elif offset == CLOSE:
                return 'S_CLOSE'


    """
    "   Desc: Callback function for account change event
    """
    def on_account(self, event):
        account = event.data
        if account.gateway_name == 'GATEIOS':
            self.balance = account.balance


    """
    "   Desc: Callback function for position change event
    """
    def on_position(self, event):
        position = event.data
        if position.vt_symbol == self.vt_symbol:
            direction = position.direction
            if direction == LONG:
                self.pos_volume[LONG] = abs(position.volume)
            elif direction == SHORT:
                self.pos_volume[SHORT] = abs(position.volume)


    """
    "   Desc: Callback function for order data update
    """
    def on_order(self, order: OrderData):
        order_type = 'taker'
        vt_orderid = order.vt_orderid

        if order.status == SUBMITTING:
            pass
        elif order.status == NOTTRADED:
            order_type = 'maker'
        elif order.status == PARTTRADED:
            pass
        elif order.status == ALLTRADED:
            try:
                if order.type == OrderType.LIMIT:
                    direction = self.order_info_queue[vt_orderid]['direction']
                    offset = self.order_info_queue[vt_orderid]['offset']
                    direction_offset = self.get_order_direction_offset_str(direction, offset)

                    if direction == LONG:
                        if offset == OPEN:
                            self.last_traded_long_open_price = order.price
                            self.last_traded_long_open_volume = order.volume

                            self.rebate = self.balance - self.start_balance
                            print('L_OPEN', order.price, order.volume, self.start_balance, self.balance)
                        elif offset == CLOSE:
                            self.last_traded_long_close_price = order.price
                            self.last_traded_long_close_volume = order.volume

                            print('L_CLOSE', order.price, order.volume, self.start_balance, self.balance)
                    elif direction == SHORT:
                        if offset == OPEN:
                            self.last_traded_short_open_price = order.price
                            self.last_traded_short_open_volume = order.volume

                            self.rebate = self.balance - self.start_balance
                            print('S_OPEN', order.price, order.volume, self.start_balance, self.balance)
                        elif offset == CLOSE:
                            self.last_traded_short_close_price = order.price
                            self.last_traded_short_close_volume = order.volume

                            print('S_CLOSE', order.price, order.volume, self.start_balance, self.balance)
            except:
                pass
        elif order.status == CANCELLED:
            self.traded_summary['cancelled'] += 1
        elif order.status == REJECTED:
            self.traded_summary['rejected'] += 1

        try:
            self.set_order_info_queue(vt_orderid, order.direction, order.offset, order.price, order.volume, order.status, order_type)
        except:
            print("set order info queue exception")


    """
    "   Desc: set order info to queue
    """
    def set_order_info_queue(self, vt_orderid, direction, offset, price, volume, status, order_type = 'taker'):
        if vt_orderid in self.order_info_queue:
            if offset == NONE:
                offset = self.order_info_queue[vt_orderid]['offset']

            if self.order_info_queue[vt_orderid]['order_type'] == 'maker':
                order_type = 'maker'

            if status == SUBMITTING and self.order_info_queue[vt_orderid]['status'] != SUBMITTING:
                status = self.order_info_queue[vt_orderid]['status']

        self.order_info_queue[vt_orderid] = {
            'direction' : direction,
            'offset': offset,
            'price' : price,
            'volume': volume,
            'status': status,
            'order_type': order_type
        }
